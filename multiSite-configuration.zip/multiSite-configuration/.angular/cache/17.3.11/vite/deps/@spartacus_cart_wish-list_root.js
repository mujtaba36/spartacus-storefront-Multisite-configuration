import {
  ADD_TO_WISHLIST_FEATURE,
  CART_WISH_LIST_CORE_FEATURE,
  CART_WISH_LIST_FEATURE,
  WishListFacade,
  WishListRootModule,
  defaultCartWishListComponentsConfig
} from "./chunk-CECM6EW7.js";
import "./chunk-DJP5CYBU.js";
import "./chunk-FIMZ5LIU.js";
import "./chunk-CJWHFW34.js";
import "./chunk-OIYGDMWQ.js";
import "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import "./chunk-XWT3SXR6.js";
import "./chunk-JMCPXHNJ.js";
import "./chunk-FTQ24RAU.js";
export {
  ADD_TO_WISHLIST_FEATURE,
  CART_WISH_LIST_CORE_FEATURE,
  CART_WISH_LIST_FEATURE,
  WishListFacade,
  WishListRootModule,
  defaultCartWishListComponentsConfig
};
//# sourceMappingURL=@spartacus_cart_wish-list_root.js.map
