import {
  UserEmailFacade,
  UserPasswordFacade,
  UserProfileFacade,
  UserRegisterFacade
} from "./chunk-GPGDLQX4.js";
import {
  BtnLikeLinkDirective,
  BtnLikeLinkModule,
  CaptchaComponent,
  CaptchaModule,
  CardComponent,
  CardModule,
  CheckboxControlValueAccessor,
  CheckboxRequiredValidator,
  CustomFormValidators,
  DIALOG_TYPE,
  DefaultValueAccessor,
  FocusDirective,
  FormArrayName,
  FormControlName,
  FormErrorsComponent,
  FormErrorsModule,
  FormGroupDirective,
  FormGroupName,
  FormsModule,
  ICON_TYPE,
  IconComponent,
  IconModule,
  KeyboardFocusModule,
  LaunchDialogService,
  MessageComponent,
  MessageComponentModule,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  NgOptionComponent,
  NgSelectA11yDirective,
  NgSelectA11yModule,
  NgSelectComponent,
  NgSelectModule,
  PasswordVisibilityToggleDirective,
  PasswordVisibilityToggleModule,
  RadioControlValueAccessor,
  ReactiveFormsModule,
  RequiredValidator,
  SpinnerComponent,
  SpinnerModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
  getAddressNumbers,
  sortTitles,
  ɵNgNoValidate
} from "./chunk-FIMZ5LIU.js";
import {
  AnonymousConsentsConfig,
  AnonymousConsentsService,
  AuthConfigService,
  AuthGuard,
  AuthRedirectService,
  AuthService,
  FeatureConfigService,
  FeatureDirective,
  FeaturesConfigModule,
  GlobalMessageService,
  GlobalMessageType,
  HttpErrorModel,
  I18nModule,
  NotAuthGuard,
  OAuthFlow,
  RouterLink,
  RouterModule,
  RoutingService,
  TranslatePipe,
  TranslationService,
  UrlModule,
  UrlPipe,
  UserAddressService,
  provideDefaultConfig,
  provideDefaultConfigFactory,
  useFeatureStyles
} from "./chunk-CJWHFW34.js";
import {
  AsyncPipe,
  CommonModule,
  NgForOf,
  NgIf,
  NgTemplateOutlet
} from "./chunk-XWT3SXR6.js";
import {
  BehaviorSubject,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Injectable,
  InjectionToken,
  Input,
  NgModule,
  Optional,
  Output,
  Subject,
  Subscription,
  ViewChild,
  ViewContainerRef,
  combineLatest,
  filter,
  first,
  inject,
  map,
  setClassMetadata,
  switchMap,
  take,
  tap,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-JMCPXHNJ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/user/fesm2022/spartacus-user-profile-components.mjs
function CloseAccountModalComponent_ng_container_0_div_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 10);
    ɵɵelement(2, "cx-spinner");
    ɵɵelementEnd()();
  }
}
function CloseAccountModalComponent_ng_container_0_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 11)(1, "p", 12);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(4, "div", 13)(5, "button", 14);
    ɵɵlistener("click", function CloseAccountModalComponent_ng_container_0_ng_template_14_Template_button_click_5_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.closeAccount());
    });
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(8, "button", 15);
    ɵɵlistener("click", function CloseAccountModalComponent_ng_container_0_ng_template_14_Template_button_click_8_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.dismissModal("Cancel"));
    });
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 3, "closeAccount.confirmAccountClosureMessage"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 5, "closeAccount.closeMyAccount"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 7, "common.cancel"), " ");
  }
}
function CloseAccountModalComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2);
    ɵɵlistener("esc", function CloseAccountModalComponent_ng_container_0_Template_div_esc_1_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.dismissModal("Escape click"));
    });
    ɵɵelementStart(2, "div", 3)(3, "div", 4)(4, "h3", 5);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(7, "button", 6);
    ɵɵpipe(8, "cxTranslate");
    ɵɵpipe(9, "cxTranslate");
    ɵɵlistener("click", function CloseAccountModalComponent_ng_container_0_Template_button_click_7_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.dismissModal("Cross click"));
    });
    ɵɵelementStart(10, "span", 7);
    ɵɵelement(11, "cx-icon", 8);
    ɵɵelementEnd()()();
    ɵɵtemplate(12, CloseAccountModalComponent_ng_container_0_div_12_Template, 3, 0, "div", 9);
    ɵɵpipe(13, "async");
    ɵɵtemplate(14, CloseAccountModalComponent_ng_container_0_ng_template_14_Template, 11, 9, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const loaded_r4 = ɵɵreference(15);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("cxFocus", ctx_r1.focusConfig);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 7, "closeAccount.confirmAccountClosure"), " ");
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(8, 9, "common.close"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(9, 11, "common.close"));
    ɵɵadvance(4);
    ɵɵproperty("type", ctx_r1.iconTypes.CLOSE);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(13, 13, ctx_r1.isLoading$))("ngIfElse", loaded_r4);
  }
}
var _c0 = ["element"];
var _c1 = () => ({
  cxRoute: "home"
});
function CloseAccountComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "button", 6);
    ɵɵlistener("click", function CloseAccountComponent_ng_container_3_Template_button_click_1_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.navigateTo("home"));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "common.cancel"), " ");
  }
}
function CloseAccountComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 7);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction0(6, _c1)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 4, "common.cancel"));
  }
}
var _c2 = (a0) => ({
  label: a0
});
var _c3 = () => ({
  cxRoute: "login"
});
function ForgotPasswordComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 10);
  }
}
function ForgotPasswordComponent_p_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 11);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), "\n");
  }
}
function ForgotPasswordComponent_abbr_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 12);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function ForgotPasswordComponent_cx_form_errors_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 13);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "forgottenPassword.emailAddress.label")))("control", ctx_r0.form.get("userEmail"));
  }
}
function ForgotPasswordComponent_cx_form_errors_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r0.form.get("userEmail"));
  }
}
function ForgotPasswordComponent_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "button", 15);
    ɵɵlistener("click", function ForgotPasswordComponent_ng_container_13_Template_button_click_1_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r0 = ɵɵnextContext();
      return ɵɵresetView(ctx_r0.navigateTo("login"));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "common.cancel"), " ");
  }
}
function ForgotPasswordComponent_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 16);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction0(6, _c3)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 4, "common.cancel"));
  }
}
var _c4 = () => ({});
var _c5 = () => ({
  cxRoute: "termsAndConditions"
});
function RegisterComponent_section_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 32);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loaded"));
  }
}
function RegisterComponent_section_0_p_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 33);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), " ");
  }
}
function RegisterComponent_section_0_ng_template_20_Template(rf, ctx) {
}
function RegisterComponent_section_0_cx_form_errors_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 34);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.firstName.label")))("control", ctx_r1.registerForm.get("firstName"));
  }
}
function RegisterComponent_section_0_cx_form_errors_24_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 29);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("firstName"));
  }
}
function RegisterComponent_section_0_ng_template_30_Template(rf, ctx) {
}
function RegisterComponent_section_0_cx_form_errors_33_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 34);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.lastName.label")))("control", ctx_r1.registerForm.get("lastName"));
  }
}
function RegisterComponent_section_0_cx_form_errors_34_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 29);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("lastName"));
  }
}
function RegisterComponent_section_0_ng_template_40_Template(rf, ctx) {
}
function RegisterComponent_section_0_cx_form_errors_43_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 34);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.emailAddress.label")))("control", ctx_r1.registerForm.get("email"));
  }
}
function RegisterComponent_section_0_cx_form_errors_44_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 29);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("email"));
  }
}
function RegisterComponent_section_0_ng_template_50_Template(rf, ctx) {
}
function RegisterComponent_section_0_cx_form_errors_57_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 34);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.password.label")))("control", ctx_r1.registerForm.get("password"));
  }
}
function RegisterComponent_section_0_cx_form_errors_58_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 29);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("password"));
  }
}
function RegisterComponent_section_0_ng_template_64_Template(rf, ctx) {
}
function RegisterComponent_section_0_cx_form_errors_68_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 34);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.confirmPassword.label")))("control", ctx_r1.registerForm.get("passwordconf"));
  }
}
function RegisterComponent_section_0_cx_form_errors_69_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 29);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("passwordconf"));
  }
}
function RegisterComponent_section_0_label_72_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "label");
    ɵɵelement(1, "input", 35);
    ɵɵelementStart(2, "span", 26);
    ɵɵtext(3);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const anonymousConsent_r3 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("checked", ctx_r1.isConsentGiven(anonymousConsent_r3.consent));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", anonymousConsent_r3.template, " ");
  }
}
function RegisterComponent_section_0_div_74_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div")(1, "label")(2, "input", 38);
    ɵɵlistener("change", function RegisterComponent_section_0_div_74_div_1_div_1_Template_input_change_2_listener($event) {
      ɵɵrestoreView(_r4);
      const i_r5 = ɵɵnextContext().index;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.updateAdditionalConsents($event, i_r5));
    });
    ɵɵelementEnd();
    ɵɵelementStart(3, "span", 26);
    ɵɵtext(4);
    ɵɵelementEnd();
    ɵɵelement(5, "cx-form-errors", 29);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const id_r6 = ctx.ngIf;
    const ctx_r6 = ɵɵnextContext();
    const control_r8 = ctx_r6.$implicit;
    const i_r5 = ctx_r6.index;
    const consents_r9 = ɵɵnextContext().ngIf;
    ɵɵadvance(2);
    ɵɵproperty("required", consents_r9[i_r5].required)("name", id_r6)("formControlName", i_r5);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", consents_r9[i_r5].template.description, " ");
    ɵɵadvance();
    ɵɵproperty("control", control_r8);
  }
}
function RegisterComponent_section_0_div_74_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵtemplate(1, RegisterComponent_section_0_div_74_div_1_div_1_Template, 6, 5, "div", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const i_r5 = ctx.index;
    const consents_r9 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", consents_r9[i_r5] == null ? null : consents_r9[i_r5].template == null ? null : consents_r9[i_r5].template.id);
  }
}
function RegisterComponent_section_0_div_74_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 36);
    ɵɵtemplate(1, RegisterComponent_section_0_div_74_div_1_Template, 2, 1, "div", 37);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r1.additionalConsents.controls);
  }
}
function RegisterComponent_section_0_ng_template_86_Template(rf, ctx) {
}
function RegisterComponent_section_0_cx_form_errors_87_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 34);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.termsAndConditions")))("control", ctx_r1.registerForm.get("termsandconditions"));
  }
}
function RegisterComponent_section_0_cx_form_errors_88_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 29);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("termsandconditions"));
  }
}
function RegisterComponent_section_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "section", 3);
    ɵɵtemplate(1, RegisterComponent_section_0_div_1_Template, 2, 3, "div", 4);
    ɵɵelementStart(2, "div", 5)(3, "div", 6)(4, "div", 7);
    ɵɵtemplate(5, RegisterComponent_section_0_p_5_Template, 3, 3, "p", 8);
    ɵɵelementStart(6, "form", 9);
    ɵɵlistener("ngSubmit", function RegisterComponent_section_0_Template_form_ngSubmit_6_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.submitForm());
    });
    ɵɵelementStart(7, "div", 10)(8, "label")(9, "span", 11);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(12, "ng-select", 12);
    ɵɵpipe(13, "async");
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(15, "div", 10)(16, "label")(17, "span", 11);
    ɵɵtext(18);
    ɵɵpipe(19, "cxTranslate");
    ɵɵtemplate(20, RegisterComponent_section_0_ng_template_20_Template, 0, 0, "ng-template", 13);
    ɵɵelementEnd();
    ɵɵelement(21, "input", 14);
    ɵɵpipe(22, "cxTranslate");
    ɵɵtemplate(23, RegisterComponent_section_0_cx_form_errors_23_Template, 2, 6, "cx-form-errors", 15)(24, RegisterComponent_section_0_cx_form_errors_24_Template, 1, 1, "cx-form-errors", 16);
    ɵɵelementEnd()();
    ɵɵelementStart(25, "div", 10)(26, "label")(27, "span", 11);
    ɵɵtext(28);
    ɵɵpipe(29, "cxTranslate");
    ɵɵtemplate(30, RegisterComponent_section_0_ng_template_30_Template, 0, 0, "ng-template", 13);
    ɵɵelementEnd();
    ɵɵelement(31, "input", 17);
    ɵɵpipe(32, "cxTranslate");
    ɵɵtemplate(33, RegisterComponent_section_0_cx_form_errors_33_Template, 2, 6, "cx-form-errors", 15)(34, RegisterComponent_section_0_cx_form_errors_34_Template, 1, 1, "cx-form-errors", 16);
    ɵɵelementEnd()();
    ɵɵelementStart(35, "div", 10)(36, "label")(37, "span", 11);
    ɵɵtext(38);
    ɵɵpipe(39, "cxTranslate");
    ɵɵtemplate(40, RegisterComponent_section_0_ng_template_40_Template, 0, 0, "ng-template", 13);
    ɵɵelementEnd();
    ɵɵelement(41, "input", 18);
    ɵɵpipe(42, "cxTranslate");
    ɵɵtemplate(43, RegisterComponent_section_0_cx_form_errors_43_Template, 2, 6, "cx-form-errors", 15)(44, RegisterComponent_section_0_cx_form_errors_44_Template, 1, 1, "cx-form-errors", 16);
    ɵɵelementEnd()();
    ɵɵelementStart(45, "div", 10)(46, "label")(47, "span", 11);
    ɵɵtext(48);
    ɵɵpipe(49, "cxTranslate");
    ɵɵtemplate(50, RegisterComponent_section_0_ng_template_50_Template, 0, 0, "ng-template", 13);
    ɵɵelementEnd();
    ɵɵelement(51, "input", 19);
    ɵɵpipe(52, "cxTranslate");
    ɵɵpipe(53, "cxTranslate");
    ɵɵelementStart(54, "p", 20);
    ɵɵtext(55);
    ɵɵpipe(56, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(57, RegisterComponent_section_0_cx_form_errors_57_Template, 2, 6, "cx-form-errors", 15)(58, RegisterComponent_section_0_cx_form_errors_58_Template, 1, 1, "cx-form-errors", 16);
    ɵɵelementEnd()();
    ɵɵelementStart(59, "div", 10)(60, "label")(61, "span", 11);
    ɵɵtext(62);
    ɵɵpipe(63, "cxTranslate");
    ɵɵtemplate(64, RegisterComponent_section_0_ng_template_64_Template, 0, 0, "ng-template", 13);
    ɵɵelementEnd();
    ɵɵelement(65, "input", 21);
    ɵɵpipe(66, "cxTranslate");
    ɵɵpipe(67, "cxTranslate");
    ɵɵtemplate(68, RegisterComponent_section_0_cx_form_errors_68_Template, 2, 6, "cx-form-errors", 15)(69, RegisterComponent_section_0_cx_form_errors_69_Template, 1, 1, "cx-form-errors", 16);
    ɵɵelementEnd()();
    ɵɵelementStart(70, "div", 10)(71, "div", 22);
    ɵɵtemplate(72, RegisterComponent_section_0_label_72_Template, 4, 2, "label", 23);
    ɵɵpipe(73, "async");
    ɵɵelementEnd()();
    ɵɵtemplate(74, RegisterComponent_section_0_div_74_Template, 2, 1, "div", 24);
    ɵɵelementStart(75, "div", 10)(76, "div", 22)(77, "label");
    ɵɵelement(78, "input", 25);
    ɵɵelementStart(79, "span", 26);
    ɵɵtext(80);
    ɵɵpipe(81, "cxTranslate");
    ɵɵelementStart(82, "a", 27);
    ɵɵpipe(83, "cxUrl");
    ɵɵtext(84);
    ɵɵpipe(85, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(86, RegisterComponent_section_0_ng_template_86_Template, 0, 0, "ng-template", 13);
    ɵɵelementEnd();
    ɵɵtemplate(87, RegisterComponent_section_0_cx_form_errors_87_Template, 2, 6, "cx-form-errors", 15)(88, RegisterComponent_section_0_cx_form_errors_88_Template, 1, 1, "cx-form-errors", 16);
    ɵɵelementEnd()()();
    ɵɵelementStart(89, "cx-captcha", 28);
    ɵɵlistener("confirmed", function RegisterComponent_section_0_Template_cx_captcha_confirmed_89_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.captchaConfirmed());
    });
    ɵɵelementEnd();
    ɵɵelement(90, "cx-form-errors", 29);
    ɵɵelementStart(91, "button", 30);
    ɵɵtext(92);
    ɵɵpipe(93, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(94, "a", 31);
    ɵɵpipe(95, "cxUrl");
    ɵɵtext(96);
    ɵɵpipe(97, "cxTranslate");
    ɵɵelementEnd()()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    const requiredAsterisk_r10 = ɵɵreference(3);
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yRemoveStatusLoadedRole");
    ɵɵadvance(4);
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
    ɵɵadvance();
    ɵɵproperty("formGroup", ctx_r1.registerForm);
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(11, 49, "register.titleOptional"));
    ɵɵadvance(2);
    ɵɵproperty("clearable", false)("items", ɵɵpipeBind1(13, 51, ctx_r1.titles$))("placeholder", ɵɵpipeBind1(14, 53, "register.selectTitle"))("searchable", false)("cxNgSelectA11y", ɵɵpureFunction0(95, _c4));
    ɵɵadvance(6);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(19, 55, "register.firstName.label"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r10);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(22, 57, "register.firstName.placeholder"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(4);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(29, 59, "register.lastName.label"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r10);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(32, 61, "register.lastName.placeholder"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(4);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(39, 63, "register.emailAddress.label"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r10);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(42, 65, "register.emailAddress.placeholder"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(4);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(49, 67, "register.password.label"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r10);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(52, 69, "register.password.placeholder"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(53, 71, "register.password.placeholder"));
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(56, 73, "register.passwordMinRequirements"), " ");
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(4);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(63, 75, "register.confirmPassword.label"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r10);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(66, 77, "register.confirmPassword.placeholder"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(67, 79, "register.confirmPassword.placeholder"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ɵɵpipeBind1(73, 81, ctx_r1.anonymousConsent$));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.additionalRegistrationConsents);
    ɵɵadvance(6);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(81, 83, "register.confirmThatRead"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(83, 85, ɵɵpureFunction0(96, _c5)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(85, 87, "register.termsAndConditions"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r10);
    ɵɵadvance();
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(2);
    ɵɵproperty("control", ctx_r1.registerForm.get("captcha"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(93, 89, "register.register"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(95, 91, ɵɵpureFunction0(97, _c3)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(97, 93, "register.signIn"));
  }
}
function RegisterComponent_ng_template_2_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 40);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function RegisterComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, RegisterComponent_ng_template_2_abbr_0_Template, 3, 3, "abbr", 39);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function RegisterComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 41);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
function ResetPasswordComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 3);
  }
}
function ResetPasswordComponent_form_2_p_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 13);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), " ");
  }
}
function ResetPasswordComponent_form_2_ng_template_6_Template(rf, ctx) {
}
function ResetPasswordComponent_form_2_cx_form_errors_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.newPassword")))("control", ctx_r2.form.get("password"));
  }
}
function ResetPasswordComponent_form_2_cx_form_errors_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r2.form.get("password"));
  }
}
function ResetPasswordComponent_form_2_ng_template_16_Template(rf, ctx) {
}
function ResetPasswordComponent_form_2_cx_form_errors_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "register.passwordMinRequirements")))("control", ctx_r2.form.get("passwordConfirm"));
  }
}
function ResetPasswordComponent_form_2_cx_form_errors_21_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r2.form.get("passwordConfirm"));
  }
}
function ResetPasswordComponent_form_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "form", 4);
    ɵɵlistener("ngSubmit", function ResetPasswordComponent_form_2_Template_form_ngSubmit_0_listener() {
      const token_r2 = ɵɵrestoreView(_r1).ngIf;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onSubmit(token_r2));
    });
    ɵɵtemplate(1, ResetPasswordComponent_form_2_p_1_Template, 3, 3, "p", 5);
    ɵɵelementStart(2, "label")(3, "span", 6);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵtemplate(6, ResetPasswordComponent_form_2_ng_template_6_Template, 0, 0, "ng-template", 7);
    ɵɵelementEnd();
    ɵɵelement(7, "input", 8);
    ɵɵpipe(8, "cxTranslate");
    ɵɵpipe(9, "cxTranslate");
    ɵɵtemplate(10, ResetPasswordComponent_form_2_cx_form_errors_10_Template, 2, 6, "cx-form-errors", 9)(11, ResetPasswordComponent_form_2_cx_form_errors_11_Template, 1, 1, "cx-form-errors", 10);
    ɵɵelementEnd();
    ɵɵelementStart(12, "label")(13, "span", 6);
    ɵɵtext(14);
    ɵɵpipe(15, "cxTranslate");
    ɵɵtemplate(16, ResetPasswordComponent_form_2_ng_template_16_Template, 0, 0, "ng-template", 7);
    ɵɵelementEnd();
    ɵɵelement(17, "input", 11);
    ɵɵpipe(18, "cxTranslate");
    ɵɵpipe(19, "cxTranslate");
    ɵɵtemplate(20, ResetPasswordComponent_form_2_cx_form_errors_20_Template, 2, 6, "cx-form-errors", 9)(21, ResetPasswordComponent_form_2_cx_form_errors_21_Template, 1, 1, "cx-form-errors", 10);
    ɵɵelementEnd();
    ɵɵelementStart(22, "button", 12);
    ɵɵtext(23);
    ɵɵpipe(24, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    const requiredAsterisk_r4 = ɵɵreference(5);
    ɵɵproperty("formGroup", ctx_r2.form);
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 16, "register.newPassword"));
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r4);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(8, 18, "register.password.placeholder"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(9, 20, "register.password.placeholder"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(15, 22, "register.passwordMinRequirements"));
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r4);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(18, 24, "register.confirmPassword.placeholder"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(19, 26, "register.confirmPassword.placeholder"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("disabled", ctx_r2.form.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(24, 28, "register.resetPassword"), " ");
  }
}
function ResetPasswordComponent_ng_template_4_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 17);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function ResetPasswordComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ResetPasswordComponent_ng_template_4_abbr_0_Template, 3, 3, "abbr", 16);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function UpdateEmailComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 13);
  }
}
function UpdateEmailComponent_p_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 14);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), "\n");
  }
}
function UpdateEmailComponent_ng_template_8_Template(rf, ctx) {
}
function UpdateEmailComponent_cx_form_errors_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateEmailForm.newEmailAddress.label")))("control", ctx_r1.form.get("email"));
  }
}
function UpdateEmailComponent_cx_form_errors_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("email"));
  }
}
function UpdateEmailComponent_ng_template_17_Template(rf, ctx) {
}
function UpdateEmailComponent_cx_form_errors_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateEmailForm.confirmNewEmailAddress.label")))("control", ctx_r1.form.get("confirmEmail"));
  }
}
function UpdateEmailComponent_cx_form_errors_21_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("confirmEmail"));
  }
}
function UpdateEmailComponent_ng_template_26_Template(rf, ctx) {
}
function UpdateEmailComponent_cx_form_errors_30_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateEmailForm.password.label")))("control", ctx_r1.form.get("password"));
  }
}
function UpdateEmailComponent_cx_form_errors_31_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("password"));
  }
}
function UpdateEmailComponent_ng_template_39_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 18);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function UpdateEmailComponent_ng_template_39_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, UpdateEmailComponent_ng_template_39_abbr_0_Template, 3, 3, "abbr", 17);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function MyAccountV2EmailComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 7);
  }
}
function MyAccountV2EmailComponent_button_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 8);
    ɵɵlistener("click", function MyAccountV2EmailComponent_button_8_Template_button_click_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onEdit());
    });
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "common.edit"), " ");
  }
}
function MyAccountV2EmailComponent_div_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 1)(2, "label", 9);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "label", 10);
    ɵɵtext(6);
    ɵɵpipe(7, "async");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 2, "myAccountV2Email.email"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", (tmp_2_0 = ɵɵpipeBind1(7, 4, ctx_r1.user$)) == null ? null : tmp_2_0.uid, " ");
  }
}
function MyAccountV2EmailComponent_cx_message_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 11);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function MyAccountV2EmailComponent_cx_message_11_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.closeDialogConfirmationAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "myAccountV2Email.reloginIndicator"))("type", ctx_r1.globalMessageType.MSG_TYPE_INFO);
  }
}
function MyAccountV2EmailComponent_div_12_cx_form_errors_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 24);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateEmailForm.newEmailAddress.label")))("control", ctx_r1.form.get("email"));
  }
}
function MyAccountV2EmailComponent_div_12_cx_form_errors_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 25);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.form.get("email"));
  }
}
function MyAccountV2EmailComponent_div_12_cx_form_errors_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 24);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateEmailForm.confirmNewEmailAddress.label")))("control", ctx_r1.form.get("confirmEmail"));
  }
}
function MyAccountV2EmailComponent_div_12_cx_form_errors_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 25);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.form.get("confirmEmail"));
  }
}
function MyAccountV2EmailComponent_div_12_cx_form_errors_31_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 24);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateEmailForm.password.label")))("control", ctx_r1.form.get("password"));
  }
}
function MyAccountV2EmailComponent_div_12_cx_form_errors_32_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 25);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.form.get("password"));
  }
}
function MyAccountV2EmailComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 12)(1, "form", 13);
    ɵɵlistener("ngSubmit", function MyAccountV2EmailComponent_div_12_Template_form_ngSubmit_1_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵelementStart(2, "label")(3, "span", 9);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(6, "input", 14);
    ɵɵpipe(7, "async");
    ɵɵelementEnd();
    ɵɵelementStart(8, "label")(9, "span", 9);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(12, "input", 15);
    ɵɵpipe(13, "cxTranslate");
    ɵɵtemplate(14, MyAccountV2EmailComponent_div_12_cx_form_errors_14_Template, 2, 6, "cx-form-errors", 16)(15, MyAccountV2EmailComponent_div_12_cx_form_errors_15_Template, 1, 1, "cx-form-errors", 17);
    ɵɵelementEnd();
    ɵɵelementStart(16, "label")(17, "span", 9);
    ɵɵtext(18);
    ɵɵpipe(19, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(20, "input", 18);
    ɵɵpipe(21, "cxTranslate");
    ɵɵtemplate(22, MyAccountV2EmailComponent_div_12_cx_form_errors_22_Template, 2, 6, "cx-form-errors", 16)(23, MyAccountV2EmailComponent_div_12_cx_form_errors_23_Template, 1, 1, "cx-form-errors", 17);
    ɵɵelementEnd();
    ɵɵelementStart(24, "label")(25, "span", 19);
    ɵɵtext(26);
    ɵɵpipe(27, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(28, "input", 20);
    ɵɵpipe(29, "cxTranslate");
    ɵɵpipe(30, "cxTranslate");
    ɵɵtemplate(31, MyAccountV2EmailComponent_div_12_cx_form_errors_31_Template, 2, 6, "cx-form-errors", 16)(32, MyAccountV2EmailComponent_div_12_cx_form_errors_32_Template, 1, 1, "cx-form-errors", 17);
    ɵɵelementEnd();
    ɵɵelementStart(33, "div", 21)(34, "button", 22);
    ɵɵlistener("click", function MyAccountV2EmailComponent_div_12_Template_button_click_34_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.cancelEdit());
    });
    ɵɵtext(35);
    ɵɵpipe(36, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(37, "button", 23);
    ɵɵlistener("click", function MyAccountV2EmailComponent_div_12_Template_button_click_37_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵtext(38);
    ɵɵpipe(39, "cxTranslate");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    let tmp_3_0;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("formGroup", ctx_r1.form);
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 19, "myAccountV2Email.emailAddress"));
    ɵɵadvance(2);
    ɵɵproperty("value", (tmp_3_0 = ɵɵpipeBind1(7, 21, ctx_r1.user$)) == null ? null : tmp_3_0.uid);
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(11, 23, "myAccountV2Email.newEmailAddress"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(13, 25, "myAccountV2Email.emailPlaceHolder"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(19, 27, "myAccountV2Email.confirmNewEmailAddress"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(21, 29, "myAccountV2Email.emailPlaceHolder"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(27, 31, "myAccountV2Email.password"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(29, 33, "myAccountV2Email.passwordPlaceHolder"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(30, 35, "myAccountV2Email.passwordPlaceHolder"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(36, 37, "common.cancel"), " ");
    ɵɵadvance(2);
    ɵɵproperty("disabled", ctx_r1.form.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(39, 39, "common.save"), " ");
  }
}
function UpdatePasswordComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 13);
  }
}
function UpdatePasswordComponent_p_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 14);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), "\n");
  }
}
function UpdatePasswordComponent_ng_template_8_Template(rf, ctx) {
}
function UpdatePasswordComponent_cx_form_errors_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updatePasswordForm.oldPassword.label")))("control", ctx_r1.form.get("oldPassword"));
  }
}
function UpdatePasswordComponent_cx_form_errors_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("oldPassword"));
  }
}
function UpdatePasswordComponent_ng_template_18_Template(rf, ctx) {
}
function UpdatePasswordComponent_cx_form_errors_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updatePasswordForm.newPassword.label")))("control", ctx_r1.form.get("newPassword"));
  }
}
function UpdatePasswordComponent_cx_form_errors_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("newPassword"));
  }
}
function UpdatePasswordComponent_ng_template_28_Template(rf, ctx) {
}
function UpdatePasswordComponent_cx_form_errors_32_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updatePasswordForm.confirmPassword.label")))("control", ctx_r1.form.get("newPasswordConfirm"));
  }
}
function UpdatePasswordComponent_cx_form_errors_33_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("newPasswordConfirm"));
  }
}
function UpdatePasswordComponent_ng_container_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "button", 17);
    ɵɵlistener("click", function UpdatePasswordComponent_ng_container_34_Template_button_click_1_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.navigateTo("home"));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "common.cancel"), " ");
  }
}
function UpdatePasswordComponent_ng_container_35_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 18);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction0(6, _c1)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 4, "common.cancel"));
  }
}
function UpdatePasswordComponent_ng_template_39_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 20);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function UpdatePasswordComponent_ng_template_39_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, UpdatePasswordComponent_ng_template_39_abbr_0_Template, 3, 3, "abbr", 19);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function MyAccountV2PasswordComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 14);
  }
}
function MyAccountV2PasswordComponent_cx_message_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 15);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function MyAccountV2PasswordComponent_cx_message_6_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.closeDialogConfirmationAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "myAccountV2PasswordForm.reloginIndicator"))("type", ctx_r1.globalMessageType.MSG_TYPE_INFO);
  }
}
function MyAccountV2PasswordComponent_cx_form_errors_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updatePasswordForm.oldPassword.label")))("control", ctx_r1.form.get("oldPassword"));
  }
}
function MyAccountV2PasswordComponent_cx_form_errors_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 17);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("oldPassword"));
  }
}
function MyAccountV2PasswordComponent_cx_form_errors_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updatePasswordForm.newPassword.label")))("control", ctx_r1.form.get("newPassword"));
  }
}
function MyAccountV2PasswordComponent_cx_form_errors_24_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 17);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("newPassword"));
  }
}
function MyAccountV2PasswordComponent_cx_form_errors_32_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 16);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updatePasswordForm.confirmPassword.label")))("control", ctx_r1.form.get("newPasswordConfirm"));
  }
}
function MyAccountV2PasswordComponent_cx_form_errors_33_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 17);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("newPasswordConfirm"));
  }
}
var _c6 = (a0) => ({
  ariaLabel: a0
});
function UpdateProfileComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 15);
  }
}
function UpdateProfileComponent_p_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 16);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), "\n");
  }
}
function UpdateProfileComponent_ng_option_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "ng-option", 17);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const title_r2 = ctx.$implicit;
    ɵɵproperty("value", title_r2.code);
    ɵɵadvance();
    ɵɵtextInterpolate(title_r2.name);
  }
}
function UpdateProfileComponent_ng_template_16_Template(rf, ctx) {
}
function UpdateProfileComponent_cx_form_errors_19_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 18);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateProfileForm.firstName.label")))("control", ctx_r2.form.get("firstName"));
  }
}
function UpdateProfileComponent_cx_form_errors_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 19);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.form.get("firstName"));
  }
}
function UpdateProfileComponent_ng_template_25_Template(rf, ctx) {
}
function UpdateProfileComponent_cx_form_errors_28_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 18);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateProfileForm.lastName.label")))("control", ctx_r2.form.get("lastName"));
  }
}
function UpdateProfileComponent_cx_form_errors_29_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 19);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.form.get("lastName"));
  }
}
function UpdateProfileComponent_cx_form_errors_35_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 18);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateProfileForm.customerId")))("control", ctx_r2.form.get("customerId"));
  }
}
function UpdateProfileComponent_cx_form_errors_36_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 19);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.form.get("customerId"));
  }
}
function UpdateProfileComponent_ng_container_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "button", 20);
    ɵɵlistener("click", function UpdateProfileComponent_ng_container_37_Template_button_click_1_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.navigateTo("home"));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "common.cancel"), " ");
  }
}
function UpdateProfileComponent_ng_container_38_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 21);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction0(6, _c1)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 4, "common.cancel"));
  }
}
function UpdateProfileComponent_ng_template_42_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 23);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function UpdateProfileComponent_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, UpdateProfileComponent_ng_template_42_abbr_0_Template, 3, 3, "abbr", 22);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function MyAccountV2ProfileComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 6);
  }
}
function MyAccountV2ProfileComponent_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 7);
    ɵɵlistener("click", function MyAccountV2ProfileComponent_button_9_Template_button_click_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onEdit());
    });
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "common.edit"), " ");
  }
}
function MyAccountV2ProfileComponent_div_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 1)(2, "label", 8);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "label", 9);
    ɵɵtext(6);
    ɵɵpipe(7, "async");
    ɵɵelementEnd()();
    ɵɵelementStart(8, "div", 1)(9, "label", 8);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(12, "label", 9);
    ɵɵtext(13);
    ɵɵpipe(14, "async");
    ɵɵpipe(15, "async");
    ɵɵelementEnd()();
    ɵɵelementStart(16, "div", 1)(17, "label", 8);
    ɵɵtext(18);
    ɵɵpipe(19, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(20, "label", 9);
    ɵɵtext(21);
    ɵɵpipe(22, "async");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    let tmp_2_0;
    let tmp_4_0;
    let tmp_6_0;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 7, "myAccountV2UserProfile.title"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", (tmp_2_0 = ɵɵpipeBind1(7, 9, ctx_r1.user$)) == null ? null : tmp_2_0.title, " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 11, "myAccountV2UserProfile.name"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate2(" ", (tmp_4_0 = ɵɵpipeBind1(14, 13, ctx_r1.user$)) == null ? null : tmp_4_0.firstName, " ", (tmp_4_0 = ɵɵpipeBind1(15, 15, ctx_r1.user$)) == null ? null : tmp_4_0.lastName, " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 17, "myAccountV2UserProfile.customerId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", (tmp_6_0 = ɵɵpipeBind1(22, 19, ctx_r1.user$)) == null ? null : tmp_6_0.customerId, " ");
  }
}
function MyAccountV2ProfileComponent_div_11_ng_option_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "ng-option", 23);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const title_r4 = ctx.$implicit;
    ɵɵproperty("value", title_r4.code);
    ɵɵadvance();
    ɵɵtextInterpolate(title_r4.name);
  }
}
function MyAccountV2ProfileComponent_div_11_cx_form_errors_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 24);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateProfileForm.firstName.label")))("control", ctx_r1.form.get("firstName"));
  }
}
function MyAccountV2ProfileComponent_div_11_cx_form_errors_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 25);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.form.get("firstName"));
  }
}
function MyAccountV2ProfileComponent_div_11_cx_form_errors_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 24);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateProfileForm.lastName.label")))("control", ctx_r1.form.get("lastName"));
  }
}
function MyAccountV2ProfileComponent_div_11_cx_form_errors_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 25);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.form.get("lastName"));
  }
}
function MyAccountV2ProfileComponent_div_11_cx_form_errors_29_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 24);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "updateProfileForm.customerId")))("control", ctx_r1.form.get("customerId"));
  }
}
function MyAccountV2ProfileComponent_div_11_cx_form_errors_30_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 25);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.form.get("customerId"));
  }
}
function MyAccountV2ProfileComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 10)(1, "form", 11);
    ɵɵlistener("ngSubmit", function MyAccountV2ProfileComponent_div_11_Template_form_ngSubmit_1_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵelementStart(2, "label")(3, "span", 12);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(6, "ng-select", 13);
    ɵɵpipe(7, "cxTranslate");
    ɵɵtemplate(8, MyAccountV2ProfileComponent_div_11_ng_option_8_Template, 2, 2, "ng-option", 14);
    ɵɵpipe(9, "async");
    ɵɵelementEnd()();
    ɵɵelementStart(10, "label")(11, "span", 12);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(14, "input", 15);
    ɵɵtemplate(15, MyAccountV2ProfileComponent_div_11_cx_form_errors_15_Template, 2, 6, "cx-form-errors", 16)(16, MyAccountV2ProfileComponent_div_11_cx_form_errors_16_Template, 1, 1, "cx-form-errors", 17);
    ɵɵelementEnd();
    ɵɵelementStart(17, "label")(18, "span", 12);
    ɵɵtext(19);
    ɵɵpipe(20, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(21, "input", 18);
    ɵɵtemplate(22, MyAccountV2ProfileComponent_div_11_cx_form_errors_22_Template, 2, 6, "cx-form-errors", 16)(23, MyAccountV2ProfileComponent_div_11_cx_form_errors_23_Template, 1, 1, "cx-form-errors", 17);
    ɵɵelementEnd();
    ɵɵelementStart(24, "label")(25, "span", 12);
    ɵɵtext(26);
    ɵɵpipe(27, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(28, "input", 19);
    ɵɵtemplate(29, MyAccountV2ProfileComponent_div_11_cx_form_errors_29_Template, 2, 6, "cx-form-errors", 16)(30, MyAccountV2ProfileComponent_div_11_cx_form_errors_30_Template, 1, 1, "cx-form-errors", 17);
    ɵɵelementEnd()();
    ɵɵelementStart(31, "div", 20)(32, "button", 21);
    ɵɵlistener("click", function MyAccountV2ProfileComponent_div_11_Template_button_click_32_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.cancelEdit());
    });
    ɵɵtext(33);
    ɵɵpipe(34, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(35, "button", 22);
    ɵɵlistener("click", function MyAccountV2ProfileComponent_div_11_Template_button_click_35_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵtext(36);
    ɵɵpipe(37, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("formGroup", ctx_r1.form);
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 18, "myAccountV2UserProfile.title"));
    ɵɵadvance(2);
    ɵɵproperty("clearable", false)("searchable", false)("cxNgSelectA11y", ɵɵpureFunction1(34, _c6, ɵɵpipeBind1(7, 20, "myAccountV2UserProfile.title")));
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ɵɵpipeBind1(9, 22, ctx_r1.titles$));
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(13, 24, "myAccountV2UserProfile.firstName"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(20, 26, "myAccountV2UserProfile.lastName"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(27, 28, "myAccountV2UserProfile.customerId"));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(34, 30, "common.cancel"), " ");
    ɵɵadvance(2);
    ɵɵproperty("disabled", ctx_r1.form.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(37, 32, "common.save"), " ");
  }
}
var _c7 = ["submit"];
var _c8 = () => ({
  required: "true"
});
function AddressFormComponent_p_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 29);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), "\n");
  }
}
function AddressFormComponent_ng_container_3_div_1_ng_template_5_Template(rf, ctx) {
}
function AddressFormComponent_ng_container_3_div_1_cx_form_errors_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(3);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "addressForm.country")))("control", ctx_r2.addressForm.get("country.isocode"));
  }
}
function AddressFormComponent_ng_container_3_div_1_cx_form_errors_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(3);
    ɵɵproperty("control", ctx_r2.addressForm.get("country.isocode"));
  }
}
function AddressFormComponent_ng_container_3_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div")(1, "label")(2, "span", 8);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵtemplate(5, AddressFormComponent_ng_container_3_div_1_ng_template_5_Template, 0, 0, "ng-template", 9);
    ɵɵelementEnd();
    ɵɵelementStart(6, "ng-select", 30);
    ɵɵpipe(7, "cxTranslate");
    ɵɵpipe(8, "cxTranslate");
    ɵɵlistener("change", function AddressFormComponent_ng_container_3_div_1_Template_ng_select_change_6_listener($event) {
      ɵɵrestoreView(_r2);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.countrySelected($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(9, AddressFormComponent_ng_container_3_div_1_cx_form_errors_9_Template, 2, 6, "cx-form-errors", 11)(10, AddressFormComponent_ng_container_3_div_1_cx_form_errors_10_Template, 1, 1, "cx-form-errors", 12);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const countries_r4 = ɵɵnextContext().ngIf;
    ɵɵnextContext();
    const requiredAsterisk_r5 = ɵɵreference(92);
    ɵɵadvance(3);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(4, 10, "addressForm.country"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(7, 12, "addressForm.selectOne"));
    ɵɵproperty("inputAttrs", ɵɵpureFunction0(16, _c8))("searchable", true)("clearable", false)("items", countries_r4)("cxNgSelectA11y", ɵɵpureFunction1(17, _c6, ɵɵpipeBind1(8, 14, "addressForm.country")));
    ɵɵadvance(3);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
  }
}
function AddressFormComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, AddressFormComponent_ng_container_3_div_1_Template, 11, 19, "div", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const countries_r4 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", countries_r4.length !== 0);
  }
}
function AddressFormComponent_div_5_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "label")(2, "span", 8);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(5, "ng-select", 33);
    ɵɵpipe(6, "cxTranslate");
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const titles_r6 = ɵɵnextContext().ngIf;
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 6, "addressForm.titleOptional"));
    ɵɵadvance(2);
    ɵɵproperty("searchable", true)("clearable", false)("items", titles_r6)("placeholder", ɵɵpipeBind1(6, 8, "addressForm.title"))("cxNgSelectA11y", ɵɵpureFunction1(12, _c6, ɵɵpipeBind1(7, 10, "addressForm.title")));
  }
}
function AddressFormComponent_div_5_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, AddressFormComponent_div_5_ng_container_1_div_1_Template, 8, 14, "div", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const titles_r6 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", titles_r6.length !== 0);
  }
}
function AddressFormComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 7);
    ɵɵtemplate(1, AddressFormComponent_div_5_ng_container_1_Template, 2, 1, "ng-container", 5);
    ɵɵpipe(2, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 1, ctx_r2.titles$));
  }
}
function AddressFormComponent_ng_template_11_Template(rf, ctx) {
}
function AddressFormComponent_cx_form_errors_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "addressForm.firstName.label")))("control", ctx_r2.addressForm.get("firstName"));
  }
}
function AddressFormComponent_cx_form_errors_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.addressForm.get("firstName"));
  }
}
function AddressFormComponent_ng_template_21_Template(rf, ctx) {
}
function AddressFormComponent_cx_form_errors_24_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "addressForm.lastName.label")))("control", ctx_r2.addressForm.get("lastName"));
  }
}
function AddressFormComponent_cx_form_errors_25_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.addressForm.get("lastName"));
  }
}
function AddressFormComponent_ng_template_31_Template(rf, ctx) {
}
function AddressFormComponent_cx_form_errors_34_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "addressForm.address1")))("control", ctx_r2.addressForm.get("line1"));
  }
}
function AddressFormComponent_cx_form_errors_35_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.addressForm.get("line1"));
  }
}
function AddressFormComponent_ng_template_49_Template(rf, ctx) {
}
function AddressFormComponent_cx_form_errors_52_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "addressForm.city.label")))("control", ctx_r2.addressForm.get("town"));
  }
}
function AddressFormComponent_cx_form_errors_53_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.addressForm.get("town"));
  }
}
function AddressFormComponent_ng_template_59_Template(rf, ctx) {
}
function AddressFormComponent_cx_form_errors_62_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c2, ɵɵpipeBind1(1, 2, "addressForm.zipCode.label")))("control", ctx_r2.addressForm.get("postalCode"));
  }
}
function AddressFormComponent_cx_form_errors_63_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r2.addressForm.get("postalCode"));
  }
}
function AddressFormComponent_ng_container_64_ng_container_1_ng_template_6_Template(rf, ctx) {
}
function AddressFormComponent_ng_container_64_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 22)(2, "label")(3, "span", 8);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵtemplate(6, AddressFormComponent_ng_container_64_ng_container_1_ng_template_6_Template, 0, 0, "ng-template", 9);
    ɵɵelementEnd();
    ɵɵelement(7, "ng-select", 35);
    ɵɵpipe(8, "cxTranslate");
    ɵɵpipe(9, "cxTranslate");
    ɵɵelement(10, "cx-form-errors", 32);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const regions_r7 = ɵɵnextContext().ngIf;
    const ctx_r2 = ɵɵnextContext();
    const requiredAsterisk_r5 = ɵɵreference(92);
    ɵɵadvance(4);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(5, 11, "addressForm.state"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
    ɵɵadvance();
    ɵɵpropertyInterpolate("bindLabel", regions_r7[0].name ? "name" : "isocode");
    ɵɵpropertyInterpolate("bindValue", regions_r7[0].name ? "isocode" : "region");
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(8, 13, "addressForm.selectOne"));
    ɵɵproperty("inputAttrs", ɵɵpureFunction0(17, _c8))("searchable", true)("clearable", false)("items", regions_r7)("cxNgSelectA11y", ɵɵpureFunction1(18, _c6, ɵɵpipeBind1(9, 15, "addressForm.state")));
    ɵɵadvance(3);
    ɵɵproperty("control", ctx_r2.addressForm.get("region.isocode"));
  }
}
function AddressFormComponent_ng_container_64_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0, 34);
    ɵɵtemplate(1, AddressFormComponent_ng_container_64_ng_container_1_Template, 11, 20, "ng-container", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const regions_r7 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", regions_r7.length !== 0);
  }
}
function AddressFormComponent_div_81_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 7)(1, "div", 36)(2, "label")(3, "input", 37);
    ɵɵlistener("change", function AddressFormComponent_div_81_Template_input_change_3_listener() {
      ɵɵrestoreView(_r8);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.toggleDefaultAddress());
    });
    ɵɵelementEnd();
    ɵɵelementStart(4, "span", 38);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    ɵɵadvance(5);
    ɵɵtextInterpolate(ɵɵpipeBind1(6, 1, "addressForm.setAsDefault"));
  }
}
function AddressFormComponent_div_85_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 27)(1, "button", 39);
    ɵɵlistener("click", function AddressFormComponent_div_85_Template_button_click_1_listener() {
      ɵɵrestoreView(_r9);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.back());
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ctx_r2.cancelBtnLabel || ɵɵpipeBind1(3, 1, "addressForm.chooseAddress"), " ");
  }
}
function AddressFormComponent_ng_template_91_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 41);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function AddressFormComponent_ng_template_91_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, AddressFormComponent_ng_template_91_abbr_0_Template, 3, 3, "abbr", 40);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function AddressBookComponent_ng_container_1_div_6_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 10);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loaded"));
  }
}
function AddressBookComponent_ng_container_1_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 11)(1, "cx-card", 12);
    ɵɵpipe(2, "async");
    ɵɵlistener("editCard", function AddressBookComponent_ng_container_1_div_6_div_2_Template_cx_card_editCard_1_listener() {
      const address_r4 = ɵɵrestoreView(_r3).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.editAddressButtonHandle(address_r4));
    })("setDefaultCard", function AddressBookComponent_ng_container_1_div_6_div_2_Template_cx_card_setDefaultCard_1_listener() {
      const address_r4 = ɵɵrestoreView(_r3).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.setAddressAsDefault(address_r4));
    })("deleteCard", function AddressBookComponent_ng_container_1_div_6_div_2_Template_cx_card_deleteCard_1_listener() {
      let tmp_7_0;
      const address_r4 = ɵɵrestoreView(_r3).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.setEdit((tmp_7_0 = address_r4.id) !== null && tmp_7_0 !== void 0 ? tmp_7_0 : ""));
    })("cancelCard", function AddressBookComponent_ng_container_1_div_6_div_2_Template_cx_card_cancelCard_1_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.cancelCard());
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const address_r4 = ctx.$implicit;
    const i_r5 = ctx.index;
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("index", i_r5)("border", true)("fitToContainer", true)("content", ɵɵpipeBind1(2, 5, ctx_r1.getCardContent(address_r4)))("editMode", address_r4.id === ctx_r1.editCard);
  }
}
function AddressBookComponent_ng_container_1_div_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 7);
    ɵɵtemplate(1, AddressBookComponent_ng_container_1_div_6_div_1_Template, 2, 3, "div", 8)(2, AddressBookComponent_ng_container_1_div_6_div_2_Template, 3, 7, "div", 9);
    ɵɵpipe(3, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yRemoveStatusLoadedRole");
    ɵɵadvance();
    ɵɵproperty("ngForOf", ɵɵpipeBind1(3, 2, ctx_r1.addresses$));
  }
}
function AddressBookComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 3)(2, "div", 4)(3, "button", 5);
    ɵɵlistener("click", function AddressBookComponent_ng_container_1_Template_button_click_3_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.addAddressButtonHandle());
    });
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵtemplate(6, AddressBookComponent_ng_container_1_div_6_Template, 4, 4, "div", 6);
    ɵɵpipe(7, "async");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    const loading_r6 = ɵɵreference(7);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 3, "addressBook.addNewAddress"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ɵɵpipeBind1(7, 5, ctx_r1.addressesStateLoading$))("ngIfElse", loading_r6);
  }
}
function AddressBookComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "section")(2, "h2", 13);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "cx-address-form", 14);
    ɵɵpipe(6, "cxTranslate");
    ɵɵpipe(7, "cxTranslate");
    ɵɵpipe(8, "async");
    ɵɵpipe(9, "async");
    ɵɵlistener("submitAddress", function AddressBookComponent_ng_container_3_Template_cx_address_form_submitAddress_5_listener($event) {
      ɵɵrestoreView(_r7);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.addAddressSubmit($event));
    })("backToAddress", function AddressBookComponent_ng_container_3_Template_cx_address_form_backToAddress_5_listener() {
      ɵɵrestoreView(_r7);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.addAddressCancel());
    })("cancelCard", function AddressBookComponent_ng_container_3_Template_cx_address_form_cancelCard_5_listener() {
      ɵɵrestoreView(_r7);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.cancelCard());
    });
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    let tmp_6_0;
    let tmp_7_0;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 6, "addressBook.addNewDeliveryAddress"), " ");
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("actionBtnLabel", ɵɵpipeBind1(6, 8, "addressBook.addAddress"));
    ɵɵpropertyInterpolate("cancelBtnLabel", ɵɵpipeBind1(7, 10, "addressBook.backToAddressList"));
    ɵɵproperty("showTitleCode", true)("showCancelBtn", !(((tmp_6_0 = ɵɵpipeBind1(8, 12, ctx_r1.addresses$)) == null ? null : tmp_6_0.length) === 0))("setAsDefaultField", !(((tmp_7_0 = ɵɵpipeBind1(9, 14, ctx_r1.addresses$)) == null ? null : tmp_7_0.length) === 0));
  }
}
function AddressBookComponent_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "section")(2, "h2", 13);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "cx-address-form", 15);
    ɵɵpipe(6, "cxTranslate");
    ɵɵpipe(7, "cxTranslate");
    ɵɵlistener("submitAddress", function AddressBookComponent_ng_container_5_Template_cx_address_form_submitAddress_5_listener($event) {
      ɵɵrestoreView(_r8);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.editAddressSubmit($event));
    })("backToAddress", function AddressBookComponent_ng_container_5_Template_cx_address_form_backToAddress_5_listener() {
      ɵɵrestoreView(_r8);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.editAddressCancel());
    });
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 5, "addressBook.editDeliveryAddress"), " ");
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("actionBtnLabel", ɵɵpipeBind1(6, 7, "addressBook.updateAddress"));
    ɵɵpropertyInterpolate("cancelBtnLabel", ɵɵpipeBind1(7, 9, "addressBook.backToAddressList"));
    ɵɵproperty("showTitleCode", true)("addressData", ctx_r1.currentAddress);
  }
}
function AddressBookComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 16);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
function SuggestedAddressDialogComponent_div_1_h3_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h3", 23);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "addressSuggestion.verifyYourAddress"), " ");
  }
}
function SuggestedAddressDialogComponent_div_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 23);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "addressSuggestion.verifyYourAddress"), " ");
  }
}
function SuggestedAddressDialogComponent_div_1_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 12)(1, "input", 24);
    ɵɵtwoWayListener("ngModelChange", function SuggestedAddressDialogComponent_div_1_div_16_Template_input_ngModelChange_1_listener($event) {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(2);
      ɵɵtwoWayBindingSet(ctx_r1.selectedAddress, $event) || (ctx_r1.selectedAddress = $event);
      return ɵɵresetView($event);
    });
    ɵɵelementEnd();
    ɵɵelementStart(2, "label", 25);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "div", 26)(6, "div", 16)(7, "div", 17);
    ɵɵtext(8);
    ɵɵelementEnd();
    ɵɵelementStart(9, "div", 17);
    ɵɵtext(10);
    ɵɵelementEnd();
    ɵɵelementStart(11, "div", 17);
    ɵɵtext(12);
    ɵɵelementEnd();
    ɵɵelementStart(13, "div", 17)(14, "span");
    ɵɵtext(15);
    ɵɵelementEnd()();
    ɵɵelementStart(16, "div", 17);
    ɵɵtext(17);
    ɵɵelementEnd();
    ɵɵelementStart(18, "div", 17);
    ɵɵtext(19);
    ɵɵelementEnd();
    ɵɵelementStart(20, "div", 17);
    ɵɵtext(21);
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    const suggestedAddress_r4 = ctx.$implicit;
    const i_r5 = ctx.index;
    const data_r6 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵtwoWayProperty("ngModel", ctx_r1.selectedAddress);
    ɵɵproperty("value", suggestedAddress_r4)("id", "suggested-addresses--suggested-" + i_r5);
    ɵɵadvance();
    ɵɵproperty("for", "suggested-addresses--suggested-" + i_r5);
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(4, 13, "addressSuggestion.suggestedAddress"), " ", data_r6.suggestedAddresses.length > 1 ? i_r5 + 1 : null, " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate(suggestedAddress_r4 == null ? null : suggestedAddress_r4.firstName);
    ɵɵadvance(2);
    ɵɵtextInterpolate(suggestedAddress_r4 == null ? null : suggestedAddress_r4.lastName);
    ɵɵadvance(2);
    ɵɵtextInterpolate(suggestedAddress_r4 == null ? null : suggestedAddress_r4.line1);
    ɵɵadvance(3);
    ɵɵtextInterpolate(suggestedAddress_r4 == null ? null : suggestedAddress_r4.line2);
    ɵɵadvance(2);
    ɵɵtextInterpolate(suggestedAddress_r4 == null ? null : suggestedAddress_r4.town);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", suggestedAddress_r4 == null ? null : suggestedAddress_r4.region == null ? null : suggestedAddress_r4.region.isocode, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", suggestedAddress_r4 == null ? null : suggestedAddress_r4.postalCode, " ");
  }
}
function SuggestedAddressDialogComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 2)(1, "div", 3);
    ɵɵtemplate(2, SuggestedAddressDialogComponent_div_1_h3_2_Template, 3, 3, "h3", 4)(3, SuggestedAddressDialogComponent_div_1_div_3_Template, 3, 3, "div", 4);
    ɵɵelementStart(4, "button", 5);
    ɵɵpipe(5, "cxTranslate");
    ɵɵpipe(6, "cxTranslate");
    ɵɵlistener("click", function SuggestedAddressDialogComponent_div_1_Template_button_click_4_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.closeModal("Cross click"));
    });
    ɵɵelementStart(7, "span", 6);
    ɵɵelement(8, "cx-icon", 7);
    ɵɵelementEnd()()();
    ɵɵelementStart(9, "div", 8)(10, "div", 9)(11, "p");
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(15, "div", 10);
    ɵɵtemplate(16, SuggestedAddressDialogComponent_div_1_div_16_Template, 22, 15, "div", 11);
    ɵɵelementStart(17, "div", 12)(18, "input", 13);
    ɵɵtwoWayListener("ngModelChange", function SuggestedAddressDialogComponent_div_1_Template_input_ngModelChange_18_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      ɵɵtwoWayBindingSet(ctx_r1.selectedAddress, $event) || (ctx_r1.selectedAddress = $event);
      return ɵɵresetView($event);
    });
    ɵɵelementEnd();
    ɵɵelementStart(19, "label", 14);
    ɵɵtext(20);
    ɵɵpipe(21, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(22, "div", 15)(23, "div", 16)(24, "div", 17);
    ɵɵtext(25);
    ɵɵelementEnd();
    ɵɵelementStart(26, "div", 17);
    ɵɵtext(27);
    ɵɵelementEnd();
    ɵɵelementStart(28, "div", 17)(29, "span");
    ɵɵtext(30);
    ɵɵelementEnd()();
    ɵɵelementStart(31, "div", 17);
    ɵɵtext(32);
    ɵɵelementEnd();
    ɵɵelementStart(33, "div", 17);
    ɵɵtext(34);
    ɵɵelementEnd()()()()()();
    ɵɵelementStart(35, "div", 18)(36, "div", 19)(37, "div", 20)(38, "button", 21);
    ɵɵlistener("click", function SuggestedAddressDialogComponent_div_1_Template_button_click_38_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.closeModal("Edit address"));
    });
    ɵɵtext(39);
    ɵɵpipe(40, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(41, "button", 22);
    ɵɵlistener("click", function SuggestedAddressDialogComponent_div_1_Template_button_click_41_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.closeModal(ctx_r1.selectedAddress));
    });
    ɵɵtext(42);
    ɵɵpipe(43, "cxTranslate");
    ɵɵelementEnd()()()()();
  }
  if (rf & 2) {
    const data_r6 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "a11yDialogsHeading");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yDialogsHeading");
    ɵɵadvance();
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(5, 20, "common.close"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 22, "common.close"));
    ɵɵadvance(4);
    ɵɵproperty("type", ctx_r1.iconTypes.CLOSE);
    ɵɵadvance(4);
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(13, 24, "addressSuggestion.ensureAccuracySuggestChange"), " ", ɵɵpipeBind1(14, 26, "addressSuggestion.chooseAddressToUse"), " ");
    ɵɵadvance(4);
    ɵɵproperty("ngForOf", data_r6.suggestedAddresses);
    ɵɵadvance(2);
    ɵɵtwoWayProperty("ngModel", ctx_r1.selectedAddress);
    ɵɵproperty("value", data_r6.enteredAddress);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(21, 28, "addressSuggestion.enteredAddress"), " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate2(" ", data_r6.enteredAddress == null ? null : data_r6.enteredAddress.firstName, " ", data_r6.enteredAddress == null ? null : data_r6.enteredAddress.lastName, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate(data_r6.enteredAddress == null ? null : data_r6.enteredAddress.line1);
    ɵɵadvance(3);
    ɵɵtextInterpolate(data_r6.enteredAddress == null ? null : data_r6.enteredAddress.line2);
    ɵɵadvance(2);
    ɵɵtextInterpolate2(" ", data_r6.enteredAddress == null ? null : data_r6.enteredAddress.town, " ", data_r6.enteredAddress == null ? null : data_r6.enteredAddress.region == null ? null : data_r6.enteredAddress.region.isocode, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", data_r6.enteredAddress == null ? null : data_r6.enteredAddress.postalCode, " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(40, 30, "addressSuggestion.editAddress"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(43, 32, "addressSuggestion.saveAddress"), " ");
  }
}
var CloseAccountModalComponent = class _CloseAccountModalComponent {
  handleClick(event) {
    if (event.target.tagName === this.el.nativeElement.tagName) {
      this.dismissModal("Cross click");
    }
  }
  constructor(authService, globalMessageService, routingService, translationService, userProfile, launchDialogService, el) {
    this.authService = authService;
    this.globalMessageService = globalMessageService;
    this.routingService = routingService;
    this.translationService = translationService;
    this.userProfile = userProfile;
    this.launchDialogService = launchDialogService;
    this.el = el;
    this.iconTypes = ICON_TYPE;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: "button",
      focusOnEscape: true
    };
    this.loading$ = new BehaviorSubject(false);
  }
  get isLoading$() {
    return this.loading$.asObservable();
  }
  ngOnInit() {
    this.isLoggedIn$ = this.authService.isUserLoggedIn();
  }
  onSuccess() {
    this.dismissModal("Success");
    this.translationService.translate("closeAccount.accountClosedSuccessfully").pipe(first()).subscribe((text) => {
      this.globalMessageService.add(text, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    });
    this.authService.coreLogout().then(() => {
      this.routingService.go({
        cxRoute: "home"
      });
    });
  }
  onError() {
    this.dismissModal("Error");
    this.translationService.translate("closeAccount.accountClosedFailure").pipe(first()).subscribe((text) => {
      this.globalMessageService.add(text, GlobalMessageType.MSG_TYPE_ERROR);
    });
  }
  dismissModal(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  closeAccount() {
    this.loading$.next(true);
    this.userProfile.close().subscribe({
      next: () => {
        this.onSuccess();
        this.loading$.next(false);
      },
      error: () => {
        this.onError();
        this.loading$.next(false);
      }
    });
  }
  static {
    this.ɵfac = function CloseAccountModalComponent_Factory(t) {
      return new (t || _CloseAccountModalComponent)(ɵɵdirectiveInject(AuthService), ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(UserProfileFacade), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ElementRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CloseAccountModalComponent,
      selectors: [["cx-close-account-modal"]],
      hostBindings: function CloseAccountModalComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          ɵɵlistener("click", function CloseAccountModalComponent_click_HostBindingHandler($event) {
            return ctx.handleClick($event);
          });
        }
      },
      decls: 2,
      vars: 3,
      consts: [["loaded", ""], [4, "ngIf"], [1, "cx-close-account-modal", 3, "esc", "cxFocus"], [1, "cx-close-account-modal-container"], [1, "cx-close-account-modal-header", "cx-modal-header"], [1, "cx-close-account-modal-title"], ["type", "button", 1, "close", 3, "click", "title"], ["aria-hidden", "true"], [3, "type"], [4, "ngIf", "ngIfElse"], [1, "cx-spinner"], [1, "cx-close-account-modal-body", "modal-body"], [1, "cx-confirmation"], [1, "cx-close-account-modal-footer", "cx-modal-footer"], [1, "btn", "btn-primary", 3, "click"], [1, "btn", "btn-block", "btn-secondary", 3, "click"]],
      template: function CloseAccountModalComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CloseAccountModalComponent_ng_container_0_Template, 16, 15, "ng-container", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.isLoggedIn$));
        }
      },
      dependencies: [NgIf, IconComponent, SpinnerComponent, FocusDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CloseAccountModalComponent, [{
    type: Component,
    args: [{
      selector: "cx-close-account-modal",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="isLoggedIn$ | async">
  <div
    class="cx-close-account-modal"
    [cxFocus]="focusConfig"
    (esc)="dismissModal('Escape click')"
  >
    <div class="cx-close-account-modal-container">
      <div class="cx-close-account-modal-header cx-modal-header">
        <h3 class="cx-close-account-modal-title">
          {{ 'closeAccount.confirmAccountClosure' | cxTranslate }}
        </h3>
        <button
          type="button"
          class="close"
          title="{{ 'common.close' | cxTranslate }}"
          [attr.aria-label]="'common.close' | cxTranslate"
          (click)="dismissModal('Cross click')"
        >
          <span aria-hidden="true">
            <cx-icon [type]="iconTypes.CLOSE"></cx-icon>
          </span>
        </button>
      </div>

      <div *ngIf="isLoading$ | async; else loaded">
        <div class="cx-spinner">
          <cx-spinner> </cx-spinner>
        </div>
      </div>

      <ng-template #loaded>
        <div class="cx-close-account-modal-body modal-body">
          <p class="cx-confirmation">
            {{ 'closeAccount.confirmAccountClosureMessage' | cxTranslate }}
          </p>
        </div>
        <div class="cx-close-account-modal-footer cx-modal-footer">
          <button class="btn btn-primary" (click)="closeAccount()">
            {{ 'closeAccount.closeMyAccount' | cxTranslate }}
          </button>
          <button
            (click)="dismissModal('Cancel')"
            class="btn btn-block btn-secondary"
          >
            {{ 'common.cancel' | cxTranslate }}
          </button>
        </div>
      </ng-template>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: AuthService
  }, {
    type: GlobalMessageService
  }, {
    type: RoutingService
  }, {
    type: TranslationService
  }, {
    type: UserProfileFacade
  }, {
    type: LaunchDialogService
  }, {
    type: ElementRef
  }], {
    handleClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var defaultCloseDialogModalLayoutConfig = {
  launch: {
    CLOSE_ACCOUNT: {
      inline: true,
      component: CloseAccountModalComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var CloseAccountComponent = class _CloseAccountComponent {
  constructor(launchDialogService, vcr) {
    this.launchDialogService = launchDialogService;
    this.vcr = vcr;
    this.routingService = inject(RoutingService, {
      optional: true
    });
  }
  openModal() {
    const dialog = this.launchDialogService.openDialog("CLOSE_ACCOUNT", this.element, this.vcr);
    dialog?.pipe(take(1)).subscribe();
  }
  navigateTo(cxRoute) {
    this.routingService?.go({
      cxRoute
    });
  }
  static {
    this.ɵfac = function CloseAccountComponent_Factory(t) {
      return new (t || _CloseAccountComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ViewContainerRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CloseAccountComponent,
      selectors: [["cx-close-account"]],
      viewQuery: function CloseAccountComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c0, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
        }
      },
      decls: 10,
      vars: 5,
      consts: [["element", ""], [1, "col-lg-8", "col-md-9"], [1, "row", "cx-btn-group"], [1, "col-sm-6"], [4, "cxFeature"], [1, "btn", "btn-block", "btn-primary", 3, "click"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"]],
      template: function CloseAccountComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 1)(1, "div", 2)(2, "div", 3);
          ɵɵtemplate(3, CloseAccountComponent_ng_container_3_Template, 4, 3, "ng-container", 4)(4, CloseAccountComponent_ng_container_4_Template, 5, 7, "ng-container", 4);
          ɵɵelementEnd();
          ɵɵelementStart(5, "div", 3)(6, "button", 5, 0);
          ɵɵlistener("click", function CloseAccountComponent_Template_button_click_6_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.openModal());
          });
          ɵɵtext(8);
          ɵɵpipe(9, "cxTranslate");
          ɵɵelementEnd()()()();
        }
        if (rf & 2) {
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yUseButtonsForBtnLinks");
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 3, "closeAccount.closeMyAccount"), " ");
        }
      },
      dependencies: [RouterLink, FeatureDirective, BtnLikeLinkDirective, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CloseAccountComponent, [{
    type: Component,
    args: [{
      selector: "cx-close-account",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div class="col-lg-8 col-md-9">
  <div class="row cx-btn-group">
    <div class="col-sm-6">
      <!-- TODO: (CXSPA-7252) - Remove feature flag next major release -->
      <ng-container *cxFeature="'a11yUseButtonsForBtnLinks'">
        <button
          class="btn btn-block btn-secondary"
          (click)="navigateTo('home')"
        >
          {{ 'common.cancel' | cxTranslate }}
        </button>
      </ng-container>
      <ng-container *cxFeature="'!a11yUseButtonsForBtnLinks'">
        <a
          [routerLink]="{ cxRoute: 'home' } | cxUrl"
          class="btn btn-block btn-secondary"
          cxBtnLikeLink
          >{{ 'common.cancel' | cxTranslate }}</a
        >
      </ng-container>
    </div>
    <div class="col-sm-6">
      <button #element class="btn btn-block btn-primary" (click)="openModal()">
        {{ 'closeAccount.closeMyAccount' | cxTranslate }}
      </button>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: ViewContainerRef
  }], {
    element: [{
      type: ViewChild,
      args: ["element"]
    }],
    routingService: [{
      type: Optional
    }]
  });
})();
var CloseAccountModule = class _CloseAccountModule {
  static {
    this.ɵfac = function CloseAccountModule_Factory(t) {
      return new (t || _CloseAccountModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _CloseAccountModule,
      declarations: [CloseAccountComponent, CloseAccountModalComponent],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, IconModule, SpinnerModule, KeyboardFocusModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          CloseAccountComponent: {
            component: CloseAccountComponent,
            guards: [AuthGuard]
          }
        }
      }), provideDefaultConfig(defaultCloseDialogModalLayoutConfig)],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, IconModule, SpinnerModule, KeyboardFocusModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CloseAccountModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, IconModule, SpinnerModule, KeyboardFocusModule, FeaturesConfigModule, BtnLikeLinkModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          CloseAccountComponent: {
            component: CloseAccountComponent,
            guards: [AuthGuard]
          }
        }
      }), provideDefaultConfig(defaultCloseDialogModalLayoutConfig)],
      declarations: [CloseAccountComponent, CloseAccountModalComponent]
    }]
  }], null, null);
})();
var ForgotPasswordComponentService = class _ForgotPasswordComponentService {
  constructor(userPasswordService, routingService, authConfigService, globalMessage) {
    this.userPasswordService = userPasswordService;
    this.routingService = routingService;
    this.authConfigService = authConfigService;
    this.globalMessage = globalMessage;
    this.busy$ = new BehaviorSubject(false);
    this.isUpdating$ = this.busy$.pipe(tap((state) => state === true ? this.form.disable() : this.form.enable()));
    this.form = new UntypedFormGroup({
      userEmail: new UntypedFormControl("", [Validators.required, CustomFormValidators.emailValidator])
    });
  }
  /**
   * Sends an email to the user to reset the password.
   *
   * When the `ResourceOwnerPasswordFlow` is used, the user is routed
   * to the login page.
   */
  requestEmail() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    this.userPasswordService.requestForgotPasswordEmail(this.form.value.userEmail).subscribe({
      next: () => this.onSuccess(),
      error: (error) => this.onError(error)
    });
  }
  onSuccess() {
    this.globalMessage.add({
      key: "forgottenPassword.passwordResetEmailSent"
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.busy$.next(false);
    this.form.reset();
    this.redirect();
  }
  onError(_error) {
    this.busy$.next(false);
  }
  /**
   * Redirects the user back to the login page.
   *
   * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow.
   */
  redirect() {
    if (this.authConfigService.getOAuthFlow() === OAuthFlow.ResourceOwnerPasswordFlow) {
      this.routingService.go({
        cxRoute: "login"
      });
    }
  }
  static {
    this.ɵfac = function ForgotPasswordComponentService_Factory(t) {
      return new (t || _ForgotPasswordComponentService)(ɵɵinject(UserPasswordFacade), ɵɵinject(RoutingService), ɵɵinject(AuthConfigService), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ForgotPasswordComponentService,
      factory: _ForgotPasswordComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ForgotPasswordComponentService, [{
    type: Injectable
  }], () => [{
    type: UserPasswordFacade
  }, {
    type: RoutingService
  }, {
    type: AuthConfigService
  }, {
    type: GlobalMessageService
  }], null);
})();
var ForgotPasswordComponent = class _ForgotPasswordComponent {
  constructor(service) {
    this.service = service;
    this.routingService = inject(RoutingService, {
      optional: true
    });
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
  }
  onSubmit() {
    this.service.requestEmail();
  }
  navigateTo(cxRoute) {
    this.routingService?.go({
      cxRoute
    });
  }
  static {
    this.ɵfac = function ForgotPasswordComponent_Factory(t) {
      return new (t || _ForgotPasswordComponent)(ɵɵdirectiveInject(ForgotPasswordComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ForgotPasswordComponent,
      selectors: [["cx-forgot-password"]],
      decls: 18,
      vars: 20,
      consts: [["class", "overlay", 4, "ngIf"], ["class", "form-legend", 4, "cxFeature"], [3, "ngSubmit", "formGroup"], [1, "label-content"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["required", "true", "type", "email", "formControlName", "userEmail", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], [4, "cxFeature"], [1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "overlay"], [1, "form-legend"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"], [3, "translationParams", "control"], [3, "control"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"]],
      template: function ForgotPasswordComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ForgotPasswordComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 0);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, ForgotPasswordComponent_p_2_Template, 3, 3, "p", 1);
          ɵɵelementStart(3, "form", 2);
          ɵɵlistener("ngSubmit", function ForgotPasswordComponent_Template_form_ngSubmit_3_listener() {
            return ctx.onSubmit();
          });
          ɵɵelementStart(4, "label")(5, "span", 3);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵtemplate(8, ForgotPasswordComponent_abbr_8_Template, 3, 3, "abbr", 4);
          ɵɵelementEnd();
          ɵɵelement(9, "input", 5);
          ɵɵpipe(10, "cxTranslate");
          ɵɵtemplate(11, ForgotPasswordComponent_cx_form_errors_11_Template, 2, 6, "cx-form-errors", 6)(12, ForgotPasswordComponent_cx_form_errors_12_Template, 1, 1, "cx-form-errors", 7);
          ɵɵelementEnd();
          ɵɵtemplate(13, ForgotPasswordComponent_ng_container_13_Template, 4, 3, "ng-container", 8)(14, ForgotPasswordComponent_ng_container_14_Template, 5, 7, "ng-container", 8);
          ɵɵelementStart(15, "button", 9);
          ɵɵtext(16);
          ɵɵpipe(17, "cxTranslate");
          ɵɵelementEnd()();
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 12, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance();
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(7, 14, "forgottenPassword.emailAddress.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(10, 16, "forgottenPassword.emailAddress.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(17, 18, "common.submit"), " ");
        }
      },
      dependencies: [NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, RouterLink, FormErrorsComponent, SpinnerComponent, FeatureDirective, BtnLikeLinkDirective, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ForgotPasswordComponent, [{
    type: Component,
    args: [{
      selector: "cx-forgot-password",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"> </cx-spinner>
<!-- TODO: (CXSPA-5953) Remove feature flags next major -->
<p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
  {{ 'formLegend.required' | cxTranslate }}
</p>
<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <label>
    <span class="label-content"
      >{{ 'forgottenPassword.emailAddress.label' | cxTranslate }}
      <abbr
        *cxFeature="'a11yRequiredAsterisks'"
        aria-hidden="true"
        class="text-decoration-none required-asterisk"
        title="{{ 'common.required' | cxTranslate }}"
        >*</abbr
      >
    </span>
    <input
      required="true"
      type="email"
      class="form-control"
      placeholder="{{
        'forgottenPassword.emailAddress.placeholder' | cxTranslate
      }}"
      formControlName="userEmail"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'forgottenPassword.emailAddress.label' | cxTranslate,
      }"
      [control]="form.get('userEmail')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('userEmail')"
    ></cx-form-errors>
  </label>

  <!-- TODO: (CXSPA-7252) - Remove feature flag next major release -->
  <ng-container *cxFeature="'a11yUseButtonsForBtnLinks'">
    <button class="btn btn-block btn-secondary" (click)="navigateTo('login')">
      {{ 'common.cancel' | cxTranslate }}
    </button>
  </ng-container>
  <ng-container *cxFeature="'!a11yUseButtonsForBtnLinks'">
    <a
      class="btn btn-block btn-secondary"
      [routerLink]="{ cxRoute: 'login' } | cxUrl"
      cxBtnLikeLink
      >{{ 'common.cancel' | cxTranslate }}</a
    >
  </ng-container>
  <button class="btn btn-block btn-primary" [disabled]="form.disabled">
    {{ 'common.submit' | cxTranslate }}
  </button>
</form>
`
    }]
  }], () => [{
    type: ForgotPasswordComponentService
  }], {
    routingService: [{
      type: Optional
    }]
  });
})();
var ForgotPasswordModule = class _ForgotPasswordModule {
  static {
    this.ɵfac = function ForgotPasswordModule_Factory(t) {
      return new (t || _ForgotPasswordModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ForgotPasswordModule,
      declarations: [ForgotPasswordComponent],
      imports: [CommonModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ForgotPasswordComponent: {
            component: ForgotPasswordComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: ForgotPasswordComponentService,
              useClass: ForgotPasswordComponentService,
              deps: [UserPasswordFacade, RoutingService, AuthConfigService, GlobalMessageService]
            }]
          }
        }
      })],
      imports: [CommonModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ForgotPasswordModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, FeaturesConfigModule, BtnLikeLinkModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ForgotPasswordComponent: {
            component: ForgotPasswordComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: ForgotPasswordComponentService,
              useClass: ForgotPasswordComponentService,
              deps: [UserPasswordFacade, RoutingService, AuthConfigService, GlobalMessageService]
            }]
          }
        }
      })],
      declarations: [ForgotPasswordComponent]
    }]
  }], null, null);
})();
var RegisterComponentService = class _RegisterComponentService {
  constructor(userRegisterFacade, globalMessageService, fb) {
    this.userRegisterFacade = userRegisterFacade;
    this.globalMessageService = globalMessageService;
    this.fb = fb;
    this.featureConfigService = inject(FeatureConfigService);
  }
  /**
   * Register a new user.
   *
   * @param user as UserSignUp
   */
  register(user) {
    return this.userRegisterFacade.register(user);
  }
  /**
   * Returns titles that can be used for the user profiles.
   */
  getTitles() {
    return this.userRegisterFacade.getTitles();
  }
  /**
   * Show the message after successful registration.
   */
  postRegisterMessage() {
    if (this.featureConfigService.isEnabled("a11yPostRegisterSuccessMessage")) {
      this.globalMessageService.add({
        key: "register.postRegisterSuccessMessage"
      }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    } else {
      this.globalMessageService.add({
        key: "register.postRegisterMessage"
      }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
  }
  /**
   * Get if any additional consents needs to be provided during registration
   * In core feature, no additional consents are necessary during registration.
   * In integration scenarios, eg: cdc, this method will be overridden to return
   * necessary cdc consents
   */
  getAdditionalConsents() {
    return [];
  }
  /**
   * Generate form control if any additional consents that needs to be provided during registration
   * In core feature, no additional consents are necessary during registration.
   * In integration scenarios, eg: cdc, this method will be overridden to return
   * form controls for necessary cdc consents
   */
  generateAdditionalConsentsFormControl() {
    return this.fb?.array([]) ?? void 0;
  }
  static {
    this.ɵfac = function RegisterComponentService_Factory(t) {
      return new (t || _RegisterComponentService)(ɵɵinject(UserRegisterFacade), ɵɵinject(GlobalMessageService), ɵɵinject(UntypedFormBuilder));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _RegisterComponentService,
      factory: _RegisterComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RegisterComponentService, [{
    type: Injectable
  }], () => [{
    type: UserRegisterFacade
  }, {
    type: GlobalMessageService
  }, {
    type: UntypedFormBuilder
  }], null);
})();
var RegisterComponent = class _RegisterComponent {
  get additionalConsents() {
    return this.registerForm?.get("additionalConsents");
  }
  updateAdditionalConsents(event, index) {
    const {
      checked
    } = event.target;
    this.registerForm.value.additionalConsents[index] = checked;
  }
  constructor(globalMessageService, fb, router, anonymousConsentsService, anonymousConsentsConfig, authConfigService, registerComponentService) {
    this.globalMessageService = globalMessageService;
    this.fb = fb;
    this.router = router;
    this.anonymousConsentsService = anonymousConsentsService;
    this.anonymousConsentsConfig = anonymousConsentsConfig;
    this.authConfigService = authConfigService;
    this.registerComponentService = registerComponentService;
    this.featureConfigService = inject(FeatureConfigService);
    this.passwordValidators = this.featureConfigService?.isEnabled("formErrorsDescriptiveMessages") ? this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidators : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? [...CustomFormValidators.passwordValidators, CustomFormValidators.noConsecutiveCharacters] : CustomFormValidators.passwordValidators : [this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidator : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? CustomFormValidators.strongPasswordValidator : CustomFormValidators.passwordValidator];
    this.isLoading$ = new BehaviorSubject(false);
    this.subscription = new Subscription();
    this.registerForm = this.fb.group({
      titleCode: [null],
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", [Validators.required, CustomFormValidators.emailValidator]],
      password: ["", [Validators.required, ...this.passwordValidators]],
      passwordconf: ["", Validators.required],
      newsletter: new UntypedFormControl({
        value: false,
        disabled: this.isConsentRequired()
      }),
      additionalConsents: this.registerComponentService.generateAdditionalConsentsFormControl?.() ?? this.fb.array([]),
      termsandconditions: [false, Validators.requiredTrue],
      captcha: [false, Validators.requiredTrue]
    }, {
      validators: CustomFormValidators.passwordsMustMatch("password", "passwordconf")
    });
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  ngOnInit() {
    this.titles$ = this.registerComponentService.getTitles().pipe(map((titles) => {
      return titles.sort(sortTitles);
    }));
    this.subscription.add(this.globalMessageService.get().pipe(filter((messages) => !!Object.keys(messages).length)).subscribe((globalMessageEntities) => {
      const messages = globalMessageEntities && globalMessageEntities[GlobalMessageType.MSG_TYPE_ERROR];
      if (messages && messages.some((message) => message.raw === "This field is required.")) {
        this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_ERROR);
        this.globalMessageService.add({
          key: "register.titleRequired"
        }, GlobalMessageType.MSG_TYPE_ERROR);
      }
    }));
    const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent ?? "";
    this.anonymousConsent$ = combineLatest([this.anonymousConsentsService.getConsent(registerConsent), this.anonymousConsentsService.getTemplate(registerConsent)]).pipe(map(([consent, template]) => {
      return {
        consent,
        template: template?.description ? template.description : ""
      };
    }));
    this.additionalRegistrationConsents = this.registerComponentService?.getAdditionalConsents() || [];
    this.subscription.add(
      // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
      this.registerForm.get("newsletter").valueChanges.subscribe(() => {
        this.toggleAnonymousConsent();
      })
    );
  }
  submitForm() {
    if (this.registerForm.valid) {
      this.registerUser();
    } else {
      this.registerForm.markAllAsTouched();
    }
  }
  registerUser() {
    this.isLoading$.next(true);
    this.registerComponentService.register(this.collectDataFromRegisterForm(this.registerForm.value)).subscribe({
      next: () => this.onRegisterUserSuccess(),
      complete: () => this.isLoading$.next(false),
      error: () => this.isLoading$.next(false)
    });
  }
  titleSelected(title) {
    this.registerForm["controls"].titleCode.setValue(title.code);
  }
  collectDataFromRegisterForm(formData) {
    const {
      firstName,
      lastName,
      email,
      password,
      titleCode
    } = formData;
    return {
      firstName,
      lastName,
      uid: email.toLowerCase(),
      password,
      titleCode
    };
  }
  isConsentGiven(consent) {
    return this.anonymousConsentsService.isConsentGiven(consent);
  }
  isConsentRequired() {
    const requiredConsents = this.anonymousConsentsConfig?.anonymousConsents?.requiredConsents;
    const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent;
    if (requiredConsents && registerConsent) {
      return requiredConsents.includes(registerConsent);
    }
    return false;
  }
  onRegisterUserSuccess() {
    if (this.authConfigService.getOAuthFlow() === OAuthFlow.ResourceOwnerPasswordFlow) {
      this.router.go("login");
    }
    this.registerComponentService.postRegisterMessage();
  }
  toggleAnonymousConsent() {
    const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent;
    if (registerConsent) {
      if (Boolean(this.registerForm.get("newsletter").value)) {
        this.anonymousConsentsService.giveConsent(registerConsent);
      } else {
        this.anonymousConsentsService.withdrawConsent(registerConsent);
      }
    }
  }
  /**
   * Triggered via CaptchaComponent when a user confirms captcha
   */
  captchaConfirmed() {
    this.registerForm.get("captcha")?.setValue(true);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static {
    this.ɵfac = function RegisterComponent_Factory(t) {
      return new (t || _RegisterComponent)(ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(UntypedFormBuilder), ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(AnonymousConsentsService), ɵɵdirectiveInject(AnonymousConsentsConfig), ɵɵdirectiveInject(AuthConfigService), ɵɵdirectiveInject(RegisterComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _RegisterComponent,
      selectors: [["cx-register"]],
      decls: 6,
      vars: 4,
      consts: [["requiredAsterisk", ""], ["loading", ""], ["class", "cx-page-section container", 4, "ngIf", "ngIfElse"], [1, "cx-page-section", "container"], ["role", "status", 4, "cxFeature"], [1, "row", "justify-content-center"], [1, "col-md-6"], [1, "cx-section"], ["class", "form-legend", 4, "cxFeature"], [3, "ngSubmit", "formGroup"], [1, "form-group"], [1, "label-content"], ["bindLabel", "name", "bindValue", "code", "formControlName", "titleCode", "id", "title-select", 3, "clearable", "items", "placeholder", "searchable", "cxNgSelectA11y"], [3, "ngTemplateOutlet"], ["required", "true", "type", "text", "name", "firstname", "formControlName", "firstName", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "text", "name", "lastname", "formControlName", "lastName", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "email", "name", "email", "formControlName", "email", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "password", "name", "password", "formControlName", "password", "aria-describedby", "password-input-hint", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], ["id", "password-input-hint", 1, "input-hint"], ["required", "true", "type", "password", "name", "confirmpassword", "formControlName", "passwordconf", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [1, "form-check"], [4, "ngIf"], ["formArrayName", "additionalConsents", "class", "form-group", 4, "ngIf"], ["required", "true", "type", "checkbox", "name", "termsandconditions", "formControlName", "termsandconditions"], [1, "form-check-label"], ["target", "_blank", "rel", "noopener noreferrer", 3, "routerLink"], [3, "confirmed"], [3, "control"], ["type", "submit", 1, "btn", "btn-block", "btn-primary"], [1, "cx-login-link", "btn-link", 3, "routerLink"], ["role", "status"], [1, "form-legend"], [3, "translationParams", "control"], ["type", "checkbox", "name", "newsletter", "formControlName", "newsletter", 1, "form-check-input", 3, "checked"], ["formArrayName", "additionalConsents", 1, "form-group"], ["class", "form-check", 4, "ngFor", "ngForOf"], ["type", "checkbox", 3, "change", "required", "name", "formControlName"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"], [1, "cx-spinner"]],
      template: function RegisterComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, RegisterComponent_section_0_Template, 98, 98, "section", 2);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, RegisterComponent_ng_template_2_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor)(4, RegisterComponent_ng_template_4_Template, 2, 0, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const loading_r11 = ɵɵreference(5);
          ɵɵproperty("ngIf", !ɵɵpipeBind1(1, 2, ctx.isLoading$))("ngIfElse", loading_r11);
        }
      },
      dependencies: [CaptchaComponent, NgForOf, NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, CheckboxControlValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, CheckboxRequiredValidator, FormGroupDirective, FormControlName, FormArrayName, RouterLink, SpinnerComponent, FormErrorsComponent, NgSelectA11yDirective, NgSelectComponent, PasswordVisibilityToggleDirective, FeatureDirective, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RegisterComponent, [{
    type: Component,
    args: [{
      selector: "cx-register",
      template: `<section
  class="cx-page-section container"
  *ngIf="!(isLoading$ | async); else loading"
>
  <div
    *cxFeature="'!a11yRemoveStatusLoadedRole'"
    role="status"
    [attr.aria-label]="'common.loaded' | cxTranslate"
  ></div>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="cx-section">
        <!-- TODO: (CXSPA-5953) Remove feature flags next major -->
        <p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
          {{ 'formLegend.required' | cxTranslate }}
        </p>
        <form (ngSubmit)="submitForm()" [formGroup]="registerForm">
          <div class="form-group">
            <label>
              <span class="label-content">{{
                'register.titleOptional' | cxTranslate
              }}</span>
              <ng-select
                [clearable]="false"
                [items]="titles$ | async"
                [placeholder]="'register.selectTitle' | cxTranslate"
                [searchable]="false"
                bindLabel="name"
                bindValue="code"
                formControlName="titleCode"
                id="title-select"
                [cxNgSelectA11y]="{}"
              >
              </ng-select>
            </label>
          </div>

          <div class="form-group">
            <label>
              <span class="label-content"
                >{{ 'register.firstName.label' | cxTranslate }}
                <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
              ></span>
              <input
                required="true"
                class="form-control"
                type="text"
                name="firstname"
                placeholder="{{
                  'register.firstName.placeholder' | cxTranslate
                }}"
                formControlName="firstName"
              />

              <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
              <cx-form-errors
                *cxFeature="'formErrorsDescriptiveMessages'"
                [translationParams]="{
                  label: 'register.firstName.label' | cxTranslate,
                }"
                [control]="registerForm.get('firstName')"
              ></cx-form-errors>

              <cx-form-errors
                *cxFeature="'!formErrorsDescriptiveMessages'"
                [control]="registerForm.get('firstName')"
              ></cx-form-errors>
            </label>
          </div>

          <div class="form-group">
            <label>
              <span class="label-content"
                >{{ 'register.lastName.label' | cxTranslate }}
                <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
              ></span>
              <input
                required="true"
                class="form-control"
                type="text"
                name="lastname"
                placeholder="{{
                  'register.lastName.placeholder' | cxTranslate
                }}"
                formControlName="lastName"
              />

              <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
              <cx-form-errors
                *cxFeature="'formErrorsDescriptiveMessages'"
                [translationParams]="{
                  label: 'register.lastName.label' | cxTranslate,
                }"
                [control]="registerForm.get('lastName')"
              ></cx-form-errors>

              <cx-form-errors
                *cxFeature="'!formErrorsDescriptiveMessages'"
                [control]="registerForm.get('lastName')"
              ></cx-form-errors>
            </label>
          </div>

          <div class="form-group">
            <label>
              <span class="label-content"
                >{{ 'register.emailAddress.label' | cxTranslate }}
                <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
              ></span>
              <input
                required="true"
                class="form-control"
                type="email"
                name="email"
                placeholder="{{
                  'register.emailAddress.placeholder' | cxTranslate
                }}"
                formControlName="email"
              />

              <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
              <cx-form-errors
                *cxFeature="'formErrorsDescriptiveMessages'"
                [translationParams]="{
                  label: 'register.emailAddress.label' | cxTranslate,
                }"
                [control]="registerForm.get('email')"
              ></cx-form-errors>

              <cx-form-errors
                *cxFeature="'!formErrorsDescriptiveMessages'"
                [control]="registerForm.get('email')"
              ></cx-form-errors>
            </label>
          </div>

          <div class="form-group">
            <label>
              <span class="label-content"
                >{{ 'register.password.label' | cxTranslate }}
                <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
              ></span>
              <input
                required="true"
                class="form-control"
                type="password"
                name="password"
                placeholder="{{
                  'register.password.placeholder' | cxTranslate
                }}"
                formControlName="password"
                [attr.aria-label]="
                  'register.password.placeholder' | cxTranslate
                "
                aria-describedby="password-input-hint"
                cxPasswordVisibilitySwitch
              />
              <p class="input-hint" id="password-input-hint">
                {{ 'register.passwordMinRequirements' | cxTranslate }}
              </p>

              <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
              <cx-form-errors
                *cxFeature="'formErrorsDescriptiveMessages'"
                [translationParams]="{
                  label: 'register.password.label' | cxTranslate,
                }"
                [control]="registerForm.get('password')"
              ></cx-form-errors>

              <cx-form-errors
                *cxFeature="'!formErrorsDescriptiveMessages'"
                [control]="registerForm.get('password')"
              ></cx-form-errors>
            </label>
          </div>

          <div class="form-group">
            <label>
              <span class="label-content"
                >{{ 'register.confirmPassword.label' | cxTranslate }}
                <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
              ></span>
              <input
                required="true"
                class="form-control"
                type="password"
                name="confirmpassword"
                placeholder="{{
                  'register.confirmPassword.placeholder' | cxTranslate
                }}"
                formControlName="passwordconf"
                [attr.aria-label]="
                  'register.confirmPassword.placeholder' | cxTranslate
                "
                cxPasswordVisibilitySwitch
              />

              <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
              <cx-form-errors
                *cxFeature="'formErrorsDescriptiveMessages'"
                [translationParams]="{
                  label: 'register.confirmPassword.label' | cxTranslate,
                }"
                [control]="registerForm.get('passwordconf')"
              ></cx-form-errors>

              <cx-form-errors
                *cxFeature="'!formErrorsDescriptiveMessages'"
                [control]="registerForm.get('passwordconf')"
              ></cx-form-errors>
            </label>
          </div>

          <div class="form-group">
            <div class="form-check">
              <label *ngIf="anonymousConsent$ | async as anonymousConsent">
                <input
                  type="checkbox"
                  name="newsletter"
                  class="form-check-input"
                  formControlName="newsletter"
                  [checked]="isConsentGiven(anonymousConsent.consent)"
                />
                <span class="form-check-label">
                  {{ anonymousConsent.template }}
                </span>
              </label>
            </div>
          </div>

          <div
            formArrayName="additionalConsents"
            class="form-group"
            *ngIf="additionalRegistrationConsents as consents"
          >
            <div
              class="form-check"
              *ngFor="let control of additionalConsents.controls; let i = index"
            >
              <div *ngIf="consents[i]?.template?.id as id">
                <label>
                  <input
                    type="checkbox"
                    [required]="consents[i].required"
                    [name]="id"
                    (change)="updateAdditionalConsents($any($event), i)"
                    [formControlName]="i"
                  />
                  <span class="form-check-label">
                    {{ consents[i].template.description }}
                  </span>
                  <cx-form-errors [control]="control"></cx-form-errors>
                </label>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-check">
              <label>
                <input
                  required="true"
                  type="checkbox"
                  name="termsandconditions"
                  formControlName="termsandconditions"
                />
                <span class="form-check-label">
                  {{ 'register.confirmThatRead' | cxTranslate }}
                  <a
                    [routerLink]="{ cxRoute: 'termsAndConditions' } | cxUrl"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {{ 'register.termsAndConditions' | cxTranslate }}
                  </a>
                  <ng-template
                    [ngTemplateOutlet]="requiredAsterisk"
                  ></ng-template>
                </span>

                <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
                <cx-form-errors
                  *cxFeature="'formErrorsDescriptiveMessages'"
                  [translationParams]="{
                    label: 'register.termsAndConditions' | cxTranslate,
                  }"
                  [control]="registerForm.get('termsandconditions')"
                ></cx-form-errors>

                <cx-form-errors
                  *cxFeature="'!formErrorsDescriptiveMessages'"
                  [control]="registerForm.get('termsandconditions')"
                ></cx-form-errors>
              </label>
            </div>
          </div>
          <cx-captcha (confirmed)="captchaConfirmed()"></cx-captcha>
          <cx-form-errors
            [control]="registerForm.get('captcha')"
          ></cx-form-errors>
          <button type="submit" class="btn btn-block btn-primary">
            {{ 'register.register' | cxTranslate }}
          </button>
          <a
            class="cx-login-link btn-link"
            [routerLink]="{ cxRoute: 'login' } | cxUrl"
            >{{ 'register.signIn' | cxTranslate }}</a
          >
        </form>
      </div>
    </div>
  </div>
</section>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    aria-hidden="true"
    class="text-decoration-none required-asterisk"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>

<ng-template #loading>
  <div class="cx-spinner"><cx-spinner></cx-spinner></div>
</ng-template>
`
    }]
  }], () => [{
    type: GlobalMessageService
  }, {
    type: UntypedFormBuilder
  }, {
    type: RoutingService
  }, {
    type: AnonymousConsentsService
  }, {
    type: AnonymousConsentsConfig
  }, {
    type: AuthConfigService
  }, {
    type: RegisterComponentService
  }], null);
})();
var RegisterComponentModule = class _RegisterComponentModule {
  static {
    this.ɵfac = function RegisterComponentModule_Factory(t) {
      return new (t || _RegisterComponentModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _RegisterComponentModule,
      declarations: [RegisterComponent],
      imports: [CaptchaModule, CommonModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, SpinnerModule, FormErrorsModule, NgSelectA11yModule, NgSelectModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          RegisterCustomerComponent: {
            component: RegisterComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: RegisterComponentService,
              useClass: RegisterComponentService,
              deps: [UserRegisterFacade, GlobalMessageService, UntypedFormBuilder]
            }]
          }
        }
      })],
      imports: [CaptchaModule, CommonModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, SpinnerModule, FormErrorsModule, NgSelectA11yModule, NgSelectModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RegisterComponentModule, [{
    type: NgModule,
    args: [{
      imports: [CaptchaModule, CommonModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, SpinnerModule, FormErrorsModule, NgSelectA11yModule, NgSelectModule, PasswordVisibilityToggleModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          RegisterCustomerComponent: {
            component: RegisterComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: RegisterComponentService,
              useClass: RegisterComponentService,
              deps: [UserRegisterFacade, GlobalMessageService, UntypedFormBuilder]
            }]
          }
        }
      })],
      declarations: [RegisterComponent]
    }]
  }], null, null);
})();
var ResetPasswordComponentService = class _ResetPasswordComponentService {
  constructor(userPasswordService, routingService, globalMessage) {
    this.userPasswordService = userPasswordService;
    this.routingService = routingService;
    this.globalMessage = globalMessage;
    this.featureConfigService = inject(FeatureConfigService);
    this.passwordValidators = this.featureConfigService?.isEnabled("formErrorsDescriptiveMessages") ? this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidators : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? [...CustomFormValidators.passwordValidators, CustomFormValidators.noConsecutiveCharacters] : CustomFormValidators.passwordValidators : [this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidator : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? CustomFormValidators.strongPasswordValidator : CustomFormValidators.passwordValidator];
    this.busy$ = new BehaviorSubject(false);
    this.isUpdating$ = this.busy$.pipe(tap((state) => state === true ? this.form.disable() : this.form.enable()));
    this.resetToken$ = this.routingService.getRouterState().pipe(map((routerState) => routerState.state.queryParams["token"]));
    this.form = new UntypedFormGroup({
      password: new UntypedFormControl("", [Validators.required, ...this.passwordValidators]),
      passwordConfirm: new UntypedFormControl("", Validators.required)
    }, {
      validators: CustomFormValidators.passwordsMustMatch("password", "passwordConfirm")
    });
  }
  /**
   * Resets the password by the given token.
   *
   * The token has been provided during the request password flow.
   * The token is not validated on the client.
   */
  resetPassword(token) {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    const password = this.form.get("password").value;
    this.userPasswordService.reset(token, password).subscribe({
      next: () => this.onSuccess(),
      error: (error) => this.onError(error)
    });
  }
  onSuccess() {
    this.globalMessage.add({
      key: "forgottenPassword.passwordResetSuccess"
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.busy$.next(false);
    this.form.reset();
    this.redirect();
  }
  onError(error) {
    this.busy$.next(false);
    if (error instanceof HttpErrorModel) {
      (error.details ?? []).forEach((err) => {
        if (err.message) {
          this.globalMessage.add({
            raw: err.message
          }, GlobalMessageType.MSG_TYPE_ERROR);
        }
      });
    }
  }
  /**
   * Redirects the user to the login page.
   */
  redirect() {
    this.routingService.go({
      cxRoute: "login"
    });
  }
  static {
    this.ɵfac = function ResetPasswordComponentService_Factory(t) {
      return new (t || _ResetPasswordComponentService)(ɵɵinject(UserPasswordFacade), ɵɵinject(RoutingService), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ResetPasswordComponentService,
      factory: _ResetPasswordComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResetPasswordComponentService, [{
    type: Injectable
  }], () => [{
    type: UserPasswordFacade
  }, {
    type: RoutingService
  }, {
    type: GlobalMessageService
  }], null);
})();
var ResetPasswordComponent = class _ResetPasswordComponent {
  constructor(service) {
    this.service = service;
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    this.token$ = this.service.resetToken$;
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  onSubmit(token) {
    this.service.resetPassword(token);
  }
  static {
    this.ɵfac = function ResetPasswordComponent_Factory(t) {
      return new (t || _ResetPasswordComponent)(ɵɵdirectiveInject(ResetPasswordComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ResetPasswordComponent,
      selectors: [["cx-reset-password"]],
      hostAttrs: [1, "user-form"],
      decls: 6,
      vars: 6,
      consts: [["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], [3, "formGroup", "ngSubmit", 4, "ngIf"], [1, "overlay"], [3, "ngSubmit", "formGroup"], ["class", "form-legend", 4, "cxFeature"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "type", "password", "formControlName", "password", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "password", "formControlName", "passwordConfirm", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "form-legend"], [3, "translationParams", "control"], [3, "control"], ["class", "text-decoration-none required-asterisk", "aria-hidden", "true", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function ResetPasswordComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ResetPasswordComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 1);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, ResetPasswordComponent_form_2_Template, 25, 30, "form", 2);
          ɵɵpipe(3, "async");
          ɵɵtemplate(4, ResetPasswordComponent_ng_template_4_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 2, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(3, 4, ctx.token$));
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, FormErrorsComponent, SpinnerComponent, PasswordVisibilityToggleDirective, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResetPasswordComponent, [{
    type: Component,
    args: [{
      selector: "cx-reset-password",
      changeDetection: ChangeDetectionStrategy.OnPush,
      host: {
        class: "user-form"
      },
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"> </cx-spinner>

<form
  *ngIf="token$ | async as token"
  (ngSubmit)="onSubmit(token)"
  [formGroup]="form"
>
  <p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
    {{ 'formLegend.required' | cxTranslate }}
  </p>
  <label>
    <span class="label-content"
      >{{ 'register.newPassword' | cxTranslate
      }}<ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      class="form-control"
      type="password"
      placeholder="{{ 'register.password.placeholder' | cxTranslate }}"
      formControlName="password"
      [attr.aria-label]="'register.password.placeholder' | cxTranslate"
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'register.newPassword' | cxTranslate,
      }"
      [control]="form.get('password')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('password')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content"
      >{{ 'register.passwordMinRequirements' | cxTranslate
      }}<ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      class="form-control"
      type="password"
      placeholder="{{ 'register.confirmPassword.placeholder' | cxTranslate }}"
      formControlName="passwordConfirm"
      [attr.aria-label]="'register.confirmPassword.placeholder' | cxTranslate"
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'register.passwordMinRequirements' | cxTranslate,
      }"
      [control]="form.get('passwordConfirm')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('passwordConfirm')"
    ></cx-form-errors>
  </label>

  <button class="btn btn-block btn-primary" [disabled]="form.disabled">
    {{ 'register.resetPassword' | cxTranslate }}
  </button>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    class="text-decoration-none required-asterisk"
    aria-hidden="true"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: ResetPasswordComponentService
  }], null);
})();
var ResetPasswordModule = class _ResetPasswordModule {
  static {
    this.ɵfac = function ResetPasswordModule_Factory(t) {
      return new (t || _ResetPasswordModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ResetPasswordModule,
      declarations: [ResetPasswordComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ResetPasswordComponent: {
            component: ResetPasswordComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: ResetPasswordComponentService,
              useClass: ResetPasswordComponentService,
              deps: [UserPasswordFacade, RoutingService, GlobalMessageService]
            }]
          }
        }
      })],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResetPasswordModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ResetPasswordComponent: {
            component: ResetPasswordComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: ResetPasswordComponentService,
              useClass: ResetPasswordComponentService,
              deps: [UserPasswordFacade, RoutingService, GlobalMessageService]
            }]
          }
        }
      })],
      declarations: [ResetPasswordComponent]
    }]
  }], null, null);
})();
var UpdateEmailComponentService = class _UpdateEmailComponentService {
  constructor(userEmail, routingService, globalMessageService, authService, authRedirectService) {
    this.userEmail = userEmail;
    this.routingService = routingService;
    this.globalMessageService = globalMessageService;
    this.authService = authService;
    this.authRedirectService = authRedirectService;
    this.busy$ = new BehaviorSubject(false);
    this.updateSucceed$ = new Subject();
    this.isUpdating$ = this.busy$.pipe(tap((state) => state === true ? this.form.disable() : this.form.enable()));
    this.form = new UntypedFormGroup({
      email: new UntypedFormControl("", [Validators.required, CustomFormValidators.emailValidator]),
      confirmEmail: new UntypedFormControl("", [Validators.required]),
      password: new UntypedFormControl("", [Validators.required])
    }, {
      validators: CustomFormValidators.emailsMustMatch("email", "confirmEmail")
    });
  }
  save() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    const newEmail = this.form.get("confirmEmail")?.value;
    const password = this.form.get("password")?.value;
    this.userEmail.update(password, newEmail).subscribe({
      next: () => this.onSuccess(newEmail),
      error: (error) => this.onError(error)
    });
  }
  /**
   * Handles successful updating of the user email.
   */
  onSuccess(newUid) {
    this.globalMessageService.add({
      key: "updateEmailForm.emailUpdateSuccess",
      params: {
        newUid
      }
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.busy$.next(false);
    this.form.reset();
    this.updateSucceed$.next(true);
    this.authRedirectService.setRedirectUrl(this.routingService.getUrl({
      cxRoute: "home"
    }));
    this.authService.coreLogout().then(() => {
      this.routingService.go({
        cxRoute: "login"
      }, {
        state: {
          newUid
        }
      });
    });
  }
  onError(_error) {
    this.busy$.next(false);
    this.updateSucceed$.next(false);
  }
  static {
    this.ɵfac = function UpdateEmailComponentService_Factory(t) {
      return new (t || _UpdateEmailComponentService)(ɵɵinject(UserEmailFacade), ɵɵinject(RoutingService), ɵɵinject(GlobalMessageService), ɵɵinject(AuthService), ɵɵinject(AuthRedirectService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _UpdateEmailComponentService,
      factory: _UpdateEmailComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdateEmailComponentService, [{
    type: Injectable
  }], () => [{
    type: UserEmailFacade
  }, {
    type: RoutingService
  }, {
    type: GlobalMessageService
  }, {
    type: AuthService
  }, {
    type: AuthRedirectService
  }], null);
})();
var UpdateEmailComponent = class _UpdateEmailComponent {
  constructor(service) {
    this.service = service;
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  onSubmit() {
    this.service.save();
  }
  static {
    this.ɵfac = function UpdateEmailComponent_Factory(t) {
      return new (t || _UpdateEmailComponent)(ɵɵdirectiveInject(UpdateEmailComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _UpdateEmailComponent,
      selectors: [["cx-update-email"]],
      hostAttrs: [1, "user-form"],
      decls: 41,
      vars: 46,
      consts: [["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], ["class", "form-legend", 4, "cxFeature"], [3, "ngSubmit", "formGroup"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "type", "email", "name", "email", "formControlName", "email", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "email", "name", "confirmEmail", "formControlName", "confirmEmail", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "password", "name", "password", "formControlName", "password", "autocomplete", "new-password", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], [1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "overlay"], [1, "form-legend"], [3, "translationParams", "control"], [3, "control"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function UpdateEmailComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, UpdateEmailComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 1);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, UpdateEmailComponent_p_2_Template, 3, 3, "p", 2);
          ɵɵelementStart(3, "form", 3);
          ɵɵlistener("ngSubmit", function UpdateEmailComponent_Template_form_ngSubmit_3_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onSubmit());
          });
          ɵɵelementStart(4, "label")(5, "span", 4);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵtemplate(8, UpdateEmailComponent_ng_template_8_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(9, "input", 6);
          ɵɵpipe(10, "cxTranslate");
          ɵɵtemplate(11, UpdateEmailComponent_cx_form_errors_11_Template, 2, 6, "cx-form-errors", 7)(12, UpdateEmailComponent_cx_form_errors_12_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(13, "label")(14, "span", 4);
          ɵɵtext(15);
          ɵɵpipe(16, "cxTranslate");
          ɵɵtemplate(17, UpdateEmailComponent_ng_template_17_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(18, "input", 9);
          ɵɵpipe(19, "cxTranslate");
          ɵɵtemplate(20, UpdateEmailComponent_cx_form_errors_20_Template, 2, 6, "cx-form-errors", 7)(21, UpdateEmailComponent_cx_form_errors_21_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(22, "label")(23, "span", 4);
          ɵɵtext(24);
          ɵɵpipe(25, "cxTranslate");
          ɵɵtemplate(26, UpdateEmailComponent_ng_template_26_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(27, "input", 10);
          ɵɵpipe(28, "cxTranslate");
          ɵɵpipe(29, "cxTranslate");
          ɵɵtemplate(30, UpdateEmailComponent_cx_form_errors_30_Template, 2, 6, "cx-form-errors", 7)(31, UpdateEmailComponent_cx_form_errors_31_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(32, "a", 11);
          ɵɵpipe(33, "cxUrl");
          ɵɵtext(34);
          ɵɵpipe(35, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(36, "button", 12);
          ɵɵtext(37);
          ɵɵpipe(38, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵtemplate(39, UpdateEmailComponent_ng_template_39_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r3 = ɵɵreference(40);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 23, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance();
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(7, 25, "updateEmailForm.newEmailAddress.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(10, 27, "updateEmailForm.newEmailAddress.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(16, 29, "updateEmailForm.confirmNewEmailAddress.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(19, 31, "updateEmailForm.confirmNewEmailAddress.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(25, 33, "updateEmailForm.password.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(28, 35, "updateEmailForm.password.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(29, 37, "updateEmailForm.password.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("routerLink", ɵɵpipeBind1(33, 39, ɵɵpureFunction0(45, _c1)));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(35, 41, "common.cancel"), " ");
          ɵɵadvance(2);
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(38, 43, "common.save"), " ");
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, SpinnerComponent, RouterLink, FormErrorsComponent, PasswordVisibilityToggleDirective, FeatureDirective, BtnLikeLinkDirective, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdateEmailComponent, [{
    type: Component,
    args: [{
      selector: "cx-update-email",
      changeDetection: ChangeDetectionStrategy.OnPush,
      host: {
        class: "user-form"
      },
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"> </cx-spinner>
<!-- TODO: (CXSPA-5953) Remove feature flags next major -->
<p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
  {{ 'formLegend.required' | cxTranslate }}
</p>
<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <label>
    <span class="label-content"
      >{{ 'updateEmailForm.newEmailAddress.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      type="email"
      name="email"
      formControlName="email"
      placeholder="{{
        'updateEmailForm.newEmailAddress.placeholder' | cxTranslate
      }}"
      class="form-control"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updateEmailForm.newEmailAddress.label' | cxTranslate,
      }"
      [control]="form.get('email')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('email')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content"
      >{{ 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      type="email"
      name="confirmEmail"
      formControlName="confirmEmail"
      placeholder="{{
        'updateEmailForm.confirmNewEmailAddress.placeholder' | cxTranslate
      }}"
      class="form-control"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate,
      }"
      [control]="form.get('confirmEmail')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('confirmEmail')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content"
      >{{ 'updateEmailForm.password.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      type="password"
      name="password"
      formControlName="password"
      placeholder="{{ 'updateEmailForm.password.placeholder' | cxTranslate }}"
      class="form-control"
      autocomplete="new-password"
      [attr.aria-label]="'updateEmailForm.password.placeholder' | cxTranslate"
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updateEmailForm.password.label' | cxTranslate,
      }"
      [control]="form.get('password')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('password')"
    ></cx-form-errors>
  </label>

  <a
    class="btn btn-block btn-secondary"
    [routerLink]="{ cxRoute: 'home' } | cxUrl"
    cxBtnLikeLink
  >
    {{ 'common.cancel' | cxTranslate }}
  </a>

  <button class="btn btn-block btn-primary" [disabled]="form.disabled">
    {{ 'common.save' | cxTranslate }}
  </button>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    aria-hidden="true"
    class="text-decoration-none required-asterisk"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: UpdateEmailComponentService
  }], null);
})();
var MyAccountV2EmailComponent = class _MyAccountV2EmailComponent {
  constructor() {
    this.emailComponentService = inject(UpdateEmailComponentService);
    this.userProfile = inject(UserProfileFacade);
    this.form = this.emailComponentService.form;
    this.isUpdating$ = this.emailComponentService.isUpdating$;
    this.user$ = this.userProfile.get().pipe(filter((user) => Boolean(user)));
    this.globalMessageType = GlobalMessageType;
  }
  ngOnInit() {
    this.isEditing = false;
  }
  onSubmit() {
    this.emailComponentService.save();
    this.emailComponentService.updateSucceed$.subscribe((res) => {
      this.isEditing = !res;
    });
  }
  onEdit() {
    this.isEditing = true;
    this.showingAlert = true;
    this.form.reset();
  }
  cancelEdit() {
    this.isEditing = false;
  }
  closeDialogConfirmationAlert() {
    this.showingAlert = false;
  }
  static {
    this.ɵfac = function MyAccountV2EmailComponent_Factory(t) {
      return new (t || _MyAccountV2EmailComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2EmailComponent,
      selectors: [["cx-my-account-v2-email"]],
      decls: 13,
      vars: 12,
      consts: [["class", "overlay", 4, "ngIf$", "ngIf"], [1, "flex-line"], [1, "headertext"], ["class", "editButton", 3, "click", 4, "ngIf"], [4, "ngIf"], [3, "text", "type", "closeMessage", 4, "ngIf"], ["class", "email-editing-area", 4, "ngIf"], [1, "overlay"], [1, "editButton", 3, "click"], [1, "text-head"], [1, "value"], [3, "closeMessage", "text", "type"], [1, "email-editing-area"], [3, "ngSubmit", "formGroup"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], ["required", "true", "type", "email", "name", "email", "formControlName", "email", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "email", "name", "confirmEmail", "formControlName", "confirmEmail", 1, "form-control", 3, "placeholder"], [1, "label-content,", "text-head"], ["required", "true", "type", "password", "name", "password", "formControlName", "password", "autocomplete", "new-password", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [1, "btn-group"], [1, "btn", "button-cancel", "button", 3, "click"], [1, "btn", "btn-primary", "button", 3, "click", "disabled"], [3, "translationParams", "control"], [3, "control"]],
      template: function MyAccountV2EmailComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2EmailComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 0);
          ɵɵpipe(1, "async");
          ɵɵpipe(2, "async");
          ɵɵelementStart(3, "div")(4, "div", 1)(5, "label", 2);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵelementEnd();
          ɵɵtemplate(8, MyAccountV2EmailComponent_button_8_Template, 3, 3, "button", 3);
          ɵɵelementEnd();
          ɵɵelementStart(9, "div");
          ɵɵtemplate(10, MyAccountV2EmailComponent_div_10_Template, 8, 6, "div", 4);
          ɵɵelementEnd();
          ɵɵtemplate(11, MyAccountV2EmailComponent_cx_message_11_Template, 2, 4, "cx-message", 5)(12, MyAccountV2EmailComponent_div_12_Template, 40, 41, "div", 6);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 6, ctx.isUpdating$) || !ɵɵpipeBind1(2, 8, ctx.user$));
          ɵɵadvance(6);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(7, 10, "myAccountV2Email.myEmailAddress"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngIf", !ctx.isEditing);
          ɵɵadvance(2);
          ɵɵproperty("ngIf", !ctx.isEditing);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.isEditing && ctx.showingAlert);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.isEditing);
        }
      },
      dependencies: [NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, SpinnerComponent, FormErrorsComponent, PasswordVisibilityToggleDirective, FeatureDirective, MessageComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2EmailComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-email",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner
  class="overlay"
  *ngIf="(isUpdating$ | async) || !(user$ | async); $"
>
</cx-spinner>
<div>
  <div class="flex-line">
    <label class="headertext"
      >{{ 'myAccountV2Email.myEmailAddress' | cxTranslate }}
    </label>
    <button class="editButton" *ngIf="!isEditing" (click)="onEdit()">
      {{ 'common.edit' | cxTranslate }}
    </button>
  </div>
  <div>
    <div *ngIf="!isEditing">
      <div class="flex-line">
        <label class="text-head">
          {{ 'myAccountV2Email.email' | cxTranslate }}
        </label>
        <label class="value">
          {{ (user$ | async)?.uid }}
        </label>
      </div>
    </div>
  </div>
  <cx-message
    *ngIf="isEditing && showingAlert"
    [text]="'myAccountV2Email.reloginIndicator' | cxTranslate"
    [type]="globalMessageType.MSG_TYPE_INFO"
    (closeMessage)="closeDialogConfirmationAlert()"
  ></cx-message>
  <div *ngIf="isEditing" class="email-editing-area">
    <form (ngSubmit)="onSubmit()" [formGroup]="form">
      <label>
        <span class="text-head">{{
          'myAccountV2Email.emailAddress' | cxTranslate
        }}</span>
        <input
          type="text"
          class="form-control"
          [value]="(user$ | async)?.uid"
          readonly
        />
      </label>

      <label>
        <span class="text-head">{{
          'myAccountV2Email.newEmailAddress' | cxTranslate
        }}</span>
        <input
          required="true"
          type="email"
          name="email"
          formControlName="email"
          placeholder="{{ 'myAccountV2Email.emailPlaceHolder' | cxTranslate }}"
          class="form-control"
        />

        <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'updateEmailForm.newEmailAddress.label' | cxTranslate,
          }"
          [control]="form.get('email')"
        ></cx-form-errors>

        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="form.get('email')"
        ></cx-form-errors>
      </label>

      <label>
        <span class="text-head">{{
          'myAccountV2Email.confirmNewEmailAddress' | cxTranslate
        }}</span>
        <input
          required="true"
          type="email"
          name="confirmEmail"
          formControlName="confirmEmail"
          placeholder="{{ 'myAccountV2Email.emailPlaceHolder' | cxTranslate }}"
          class="form-control"
        />

        <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate,
          }"
          [control]="form.get('confirmEmail')"
        ></cx-form-errors>

        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="form.get('confirmEmail')"
        ></cx-form-errors>
      </label>

      <label>
        <span class="label-content, text-head">{{
          'myAccountV2Email.password' | cxTranslate
        }}</span>
        <input
          required="true"
          type="password"
          name="password"
          formControlName="password"
          placeholder="{{
            'myAccountV2Email.passwordPlaceHolder' | cxTranslate
          }}"
          class="form-control"
          autocomplete="new-password"
          [attr.aria-label]="
            'myAccountV2Email.passwordPlaceHolder' | cxTranslate
          "
          cxPasswordVisibilitySwitch
        />

        <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'updateEmailForm.password.label' | cxTranslate,
          }"
          [control]="form.get('password')"
        ></cx-form-errors>

        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="form.get('password')"
        ></cx-form-errors>
      </label>

      <div class="btn-group">
        <button class="btn button-cancel button" (click)="cancelEdit()">
          {{ 'common.cancel' | cxTranslate }}
        </button>
        <button
          class="btn btn-primary button"
          (click)="onSubmit()"
          [disabled]="form.disabled"
        >
          {{ 'common.save' | cxTranslate }}
        </button>
      </div>
    </form>
  </div>
</div>
`
    }]
  }], null, null);
})();
var USE_MY_ACCOUNT_V2_EMAIL = new InjectionToken("feature flag to enable enhanced UI for email related pages under My-Account", {
  providedIn: "root",
  factory: () => false
});
var myAccountV2EmailMapping = {
  cmsComponents: {
    UpdateEmailComponent: {
      component: MyAccountV2EmailComponent
    }
  }
};
var UpdateEmailModule = class _UpdateEmailModule {
  static {
    this.ɵfac = function UpdateEmailModule_Factory(t) {
      return new (t || _UpdateEmailModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UpdateEmailModule,
      declarations: [UpdateEmailComponent, MyAccountV2EmailComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, UrlModule, RouterModule, I18nModule, FormErrorsModule, PasswordVisibilityToggleModule, FeaturesConfigModule, MessageComponentModule, BtnLikeLinkModule],
      exports: [UpdateEmailComponent, MyAccountV2EmailComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          UpdateEmailComponent: {
            component: UpdateEmailComponent,
            guards: [AuthGuard],
            providers: [{
              provide: UpdateEmailComponentService,
              useClass: UpdateEmailComponentService,
              deps: [UserEmailFacade, RoutingService, GlobalMessageService, AuthService, AuthRedirectService]
            }]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_EMAIL) ? myAccountV2EmailMapping : {})],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, UrlModule, RouterModule, I18nModule, FormErrorsModule, PasswordVisibilityToggleModule, FeaturesConfigModule, MessageComponentModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdateEmailModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, UrlModule, RouterModule, I18nModule, FormErrorsModule, PasswordVisibilityToggleModule, FeaturesConfigModule, MessageComponentModule, BtnLikeLinkModule],
      declarations: [UpdateEmailComponent, MyAccountV2EmailComponent],
      exports: [UpdateEmailComponent, MyAccountV2EmailComponent],
      providers: [provideDefaultConfig({
        cmsComponents: {
          UpdateEmailComponent: {
            component: UpdateEmailComponent,
            guards: [AuthGuard],
            providers: [{
              provide: UpdateEmailComponentService,
              useClass: UpdateEmailComponentService,
              deps: [UserEmailFacade, RoutingService, GlobalMessageService, AuthService, AuthRedirectService]
            }]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_EMAIL) ? myAccountV2EmailMapping : {})]
    }]
  }], null, null);
})();
var USE_MY_ACCOUNT_V2_PASSWORD = new InjectionToken("feature flag to enable enhanced UI for Update Password related pages under My-Account", {
  providedIn: "root",
  factory: () => false
});
var UpdatePasswordComponentService = class _UpdatePasswordComponentService {
  constructor(userPasswordService, routingService, globalMessageService, authRedirectService, authService) {
    this.userPasswordService = userPasswordService;
    this.routingService = routingService;
    this.globalMessageService = globalMessageService;
    this.authRedirectService = authRedirectService;
    this.authService = authService;
    this.featureConfigService = inject(FeatureConfigService);
    this.passwordValidators = this.featureConfigService?.isEnabled("formErrorsDescriptiveMessages") ? this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidators : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? [...CustomFormValidators.passwordValidators, CustomFormValidators.noConsecutiveCharacters] : CustomFormValidators.passwordValidators : [this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidator : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? CustomFormValidators.strongPasswordValidator : CustomFormValidators.passwordValidator];
    this.busy$ = new BehaviorSubject(false);
    this.usingV2 = inject(USE_MY_ACCOUNT_V2_PASSWORD);
    this.isUpdating$ = this.busy$.pipe(tap((state) => state === true ? this.form.disable() : this.form.enable()));
    this.form = new UntypedFormGroup({
      oldPassword: new UntypedFormControl("", Validators.required),
      newPassword: new UntypedFormControl("", [Validators.required, ...this.passwordValidators]),
      newPasswordConfirm: new UntypedFormControl("", Validators.required)
    }, {
      validators: this.getPasswordValidators()
    });
  }
  /**
   * Updates the password for the user.
   */
  updatePassword() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    const oldPassword = this.form.get("oldPassword")?.value;
    const newPassword = this.form.get("newPassword")?.value;
    this.userPasswordService.update(oldPassword, newPassword).subscribe({
      next: () => this.onSuccess(),
      error: (error) => this.onError(error)
    });
  }
  onSuccess() {
    this.globalMessageService.add({
      key: this.usingV2 ? "myAccountV2PasswordForm.passwordUpdateSuccess" : "updatePasswordForm.passwordUpdateSuccess"
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.busy$.next(false);
    this.form.reset();
    this.authRedirectService?.setRedirectUrl(this.routingService.getUrl({
      cxRoute: "home"
    }));
    this.authService?.coreLogout().then(() => {
      this.routingService.go({
        cxRoute: "login"
      });
    });
  }
  onError(_error) {
    if (_error instanceof HttpErrorModel && _error.details?.[0].type === "AccessDeniedError") {
      this.globalMessageService.add({
        key: this.usingV2 ? "myAccountV2PasswordForm.accessDeniedError" : "updatePasswordForm.accessDeniedError"
      }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    this.busy$.next(false);
    this.form.reset();
  }
  // TODO: (CXSPA-8550) Remove after removing enablePasswordsCannotMatchInPasswordUpdateForm feature toggle
  getPasswordValidators() {
    const passwordMustMatchValidator = CustomFormValidators.passwordsMustMatch("newPassword", "newPasswordConfirm");
    return this.featureConfigService.isEnabled("enablePasswordsCannotMatchInPasswordUpdateForm") ? [passwordMustMatchValidator, CustomFormValidators.passwordsCannotMatch("oldPassword", "newPassword")] : [passwordMustMatchValidator];
  }
  static {
    this.ɵfac = function UpdatePasswordComponentService_Factory(t) {
      return new (t || _UpdatePasswordComponentService)(ɵɵinject(UserPasswordFacade), ɵɵinject(RoutingService), ɵɵinject(GlobalMessageService), ɵɵinject(AuthRedirectService), ɵɵinject(AuthService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _UpdatePasswordComponentService,
      factory: _UpdatePasswordComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdatePasswordComponentService, [{
    type: Injectable
  }], () => [{
    type: UserPasswordFacade
  }, {
    type: RoutingService
  }, {
    type: GlobalMessageService
  }, {
    type: AuthRedirectService
  }, {
    type: AuthService
  }], null);
})();
var UpdatePasswordComponent = class _UpdatePasswordComponent {
  constructor(service) {
    this.service = service;
    this.routingService = inject(RoutingService, {
      optional: true
    });
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  onSubmit() {
    this.service.updatePassword();
  }
  navigateTo(cxRoute) {
    this.routingService?.go({
      cxRoute
    });
  }
  static {
    this.ɵfac = function UpdatePasswordComponent_Factory(t) {
      return new (t || _UpdatePasswordComponent)(ɵɵdirectiveInject(UpdatePasswordComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _UpdatePasswordComponent,
      selectors: [["cx-update-password"]],
      hostAttrs: [1, "user-form"],
      decls: 41,
      vars: 47,
      consts: [["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], ["class", "form-legend", 4, "cxFeature"], [3, "ngSubmit", "formGroup"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "type", "password", "name", "oldPassword", "formControlName", "oldPassword", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "password", "name", "newPassword", "formControlName", "newPassword", "aria-describedby", "password-input-hint", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "password", "name", "newPasswordConfirm", "formControlName", "newPasswordConfirm", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [4, "cxFeature"], [1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "overlay"], [1, "form-legend"], [3, "translationParams", "control"], [3, "control"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function UpdatePasswordComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, UpdatePasswordComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 1);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, UpdatePasswordComponent_p_2_Template, 3, 3, "p", 2);
          ɵɵelementStart(3, "form", 3);
          ɵɵlistener("ngSubmit", function UpdatePasswordComponent_Template_form_ngSubmit_3_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onSubmit());
          });
          ɵɵelementStart(4, "label")(5, "span", 4);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵtemplate(8, UpdatePasswordComponent_ng_template_8_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(9, "input", 6);
          ɵɵpipe(10, "cxTranslate");
          ɵɵpipe(11, "cxTranslate");
          ɵɵtemplate(12, UpdatePasswordComponent_cx_form_errors_12_Template, 2, 6, "cx-form-errors", 7)(13, UpdatePasswordComponent_cx_form_errors_13_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(14, "label")(15, "span", 4);
          ɵɵtext(16);
          ɵɵpipe(17, "cxTranslate");
          ɵɵtemplate(18, UpdatePasswordComponent_ng_template_18_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(19, "input", 9);
          ɵɵpipe(20, "cxTranslate");
          ɵɵpipe(21, "cxTranslate");
          ɵɵtemplate(22, UpdatePasswordComponent_cx_form_errors_22_Template, 2, 6, "cx-form-errors", 7)(23, UpdatePasswordComponent_cx_form_errors_23_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(24, "label")(25, "span", 4);
          ɵɵtext(26);
          ɵɵpipe(27, "cxTranslate");
          ɵɵtemplate(28, UpdatePasswordComponent_ng_template_28_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(29, "input", 10);
          ɵɵpipe(30, "cxTranslate");
          ɵɵpipe(31, "cxTranslate");
          ɵɵtemplate(32, UpdatePasswordComponent_cx_form_errors_32_Template, 2, 6, "cx-form-errors", 7)(33, UpdatePasswordComponent_cx_form_errors_33_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵtemplate(34, UpdatePasswordComponent_ng_container_34_Template, 4, 3, "ng-container", 11)(35, UpdatePasswordComponent_ng_container_35_Template, 5, 7, "ng-container", 11);
          ɵɵelementStart(36, "button", 12);
          ɵɵtext(37);
          ɵɵpipe(38, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵtemplate(39, UpdatePasswordComponent_ng_template_39_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r4 = ɵɵreference(40);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 25, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance();
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(7, 27, "updatePasswordForm.oldPassword.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r4);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(10, 29, "updatePasswordForm.oldPassword.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(11, 31, "updatePasswordForm.oldPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(17, 33, "updatePasswordForm.newPassword.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r4);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(20, 35, "updatePasswordForm.newPassword.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(21, 37, "updatePasswordForm.newPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(27, 39, "updatePasswordForm.confirmPassword.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r4);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(30, 41, "updatePasswordForm.confirmPassword.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(31, 43, "updatePasswordForm.confirmPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(38, 45, "common.save"), " ");
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, SpinnerComponent, FormErrorsComponent, RouterLink, PasswordVisibilityToggleDirective, FeatureDirective, BtnLikeLinkDirective, AsyncPipe, TranslatePipe, UrlPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdatePasswordComponent, [{
    type: Component,
    args: [{
      selector: "cx-update-password",
      changeDetection: ChangeDetectionStrategy.OnPush,
      host: {
        class: "user-form"
      },
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"> </cx-spinner>
<!-- TODO: (CXSPA-5953) Remove feature flags next major -->
<p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
  {{ 'formLegend.required' | cxTranslate }}
</p>
<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <label>
    <span class="label-content"
      >{{ 'updatePasswordForm.oldPassword.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      class="form-control"
      type="password"
      name="oldPassword"
      placeholder="{{
        'updatePasswordForm.oldPassword.placeholder' | cxTranslate
      }}"
      formControlName="oldPassword"
      [attr.aria-label]="
        'updatePasswordForm.oldPassword.placeholder' | cxTranslate
      "
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updatePasswordForm.oldPassword.label' | cxTranslate,
      }"
      [control]="form.get('oldPassword')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('oldPassword')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content"
      >{{ 'updatePasswordForm.newPassword.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      class="form-control"
      type="password"
      name="newPassword"
      placeholder="{{
        'updatePasswordForm.newPassword.placeholder' | cxTranslate
      }}"
      formControlName="newPassword"
      [attr.aria-label]="
        'updatePasswordForm.newPassword.placeholder' | cxTranslate
      "
      aria-describedby="password-input-hint"
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updatePasswordForm.newPassword.label' | cxTranslate,
      }"
      [control]="form.get('newPassword')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('newPassword')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content"
      >{{ 'updatePasswordForm.confirmPassword.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      class="form-control"
      type="password"
      name="newPasswordConfirm"
      placeholder="{{
        'updatePasswordForm.confirmPassword.placeholder' | cxTranslate
      }}"
      formControlName="newPasswordConfirm"
      [attr.aria-label]="
        'updatePasswordForm.confirmPassword.placeholder' | cxTranslate
      "
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updatePasswordForm.confirmPassword.label' | cxTranslate,
      }"
      [control]="form.get('newPasswordConfirm')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('newPasswordConfirm')"
    ></cx-form-errors>
  </label>

  <!-- TODO: (CXSPA-7252) - Remove feature flag next major release -->
  <ng-container *cxFeature="'a11yUseButtonsForBtnLinks'">
    <button class="btn btn-block btn-secondary" (click)="navigateTo('home')">
      {{ 'common.cancel' | cxTranslate }}
    </button>
  </ng-container>
  <ng-container *cxFeature="'!a11yUseButtonsForBtnLinks'">
    <a
      [routerLink]="{ cxRoute: 'home' } | cxUrl"
      class="btn btn-block btn-secondary"
      cxBtnLikeLink
      >{{ 'common.cancel' | cxTranslate }}</a
    >
  </ng-container>

  <button class="btn btn-block btn-primary" [disabled]="form.disabled">
    {{ 'common.save' | cxTranslate }}
  </button>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    aria-hidden="true"
    class="text-decoration-none required-asterisk"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: UpdatePasswordComponentService
  }], {
    routingService: [{
      type: Optional
    }]
  });
})();
var MyAccountV2PasswordComponent = class _MyAccountV2PasswordComponent {
  constructor() {
    this.service = inject(UpdatePasswordComponentService);
    this.showingAlert = true;
    this.globalMessageType = GlobalMessageType;
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  onSubmit() {
    this.service.updatePassword();
  }
  onCancel() {
    this.oldPassword = "";
    this.newPassword = "";
    this.newPasswordConfirm = "";
  }
  closeDialogConfirmationAlert() {
    this.showingAlert = false;
  }
  static {
    this.ɵfac = function MyAccountV2PasswordComponent_Factory(t) {
      return new (t || _MyAccountV2PasswordComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2PasswordComponent,
      selectors: [["cx-my-account-v2-password"]],
      decls: 41,
      vars: 51,
      consts: [["class", "overlay", 4, "ngIf"], [3, "ngSubmit", "formGroup"], [1, "myaccount-password-header"], [3, "text", "type", "closeMessage", 4, "ngIf"], [1, "myaccount-label-padding"], [1, "label-content", "myaccount-password-label"], ["required", "true", "type", "password", "name", "oldPassword", "formControlName", "oldPassword", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "ngModelChange", "ngModel", "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "password", "name", "newPassword", "formControlName", "newPassword", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "ngModelChange", "ngModel", "placeholder"], ["required", "true", "type", "password", "name", "newPasswordConfirm", "formControlName", "newPasswordConfirm", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "ngModelChange", "ngModel", "placeholder"], [1, "password-btn-group"], [1, "btn", "myaccount-password-button", "myaccount-password-button-cancel", 3, "click"], [1, "btn", "btn-primary", "myaccount-password-button", 3, "disabled"], [1, "overlay"], [3, "closeMessage", "text", "type"], [3, "translationParams", "control"], [3, "control"]],
      template: function MyAccountV2PasswordComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2PasswordComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 0);
          ɵɵpipe(1, "async");
          ɵɵelementStart(2, "form", 1);
          ɵɵlistener("ngSubmit", function MyAccountV2PasswordComponent_Template_form_ngSubmit_2_listener() {
            return ctx.onSubmit();
          });
          ɵɵelementStart(3, "label", 2);
          ɵɵtext(4);
          ɵɵpipe(5, "cxTranslate");
          ɵɵelementEnd();
          ɵɵtemplate(6, MyAccountV2PasswordComponent_cx_message_6_Template, 2, 4, "cx-message", 3);
          ɵɵelementStart(7, "label", 4)(8, "span", 5);
          ɵɵtext(9);
          ɵɵpipe(10, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(11, "input", 6);
          ɵɵpipe(12, "cxTranslate");
          ɵɵpipe(13, "cxTranslate");
          ɵɵtwoWayListener("ngModelChange", function MyAccountV2PasswordComponent_Template_input_ngModelChange_11_listener($event) {
            ɵɵtwoWayBindingSet(ctx.oldPassword, $event) || (ctx.oldPassword = $event);
            return $event;
          });
          ɵɵelementEnd();
          ɵɵtemplate(14, MyAccountV2PasswordComponent_cx_form_errors_14_Template, 2, 6, "cx-form-errors", 7)(15, MyAccountV2PasswordComponent_cx_form_errors_15_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(16, "label", 4)(17, "span", 5);
          ɵɵtext(18);
          ɵɵpipe(19, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(20, "input", 9);
          ɵɵpipe(21, "cxTranslate");
          ɵɵpipe(22, "cxTranslate");
          ɵɵtwoWayListener("ngModelChange", function MyAccountV2PasswordComponent_Template_input_ngModelChange_20_listener($event) {
            ɵɵtwoWayBindingSet(ctx.newPassword, $event) || (ctx.newPassword = $event);
            return $event;
          });
          ɵɵelementEnd();
          ɵɵtemplate(23, MyAccountV2PasswordComponent_cx_form_errors_23_Template, 2, 6, "cx-form-errors", 7)(24, MyAccountV2PasswordComponent_cx_form_errors_24_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(25, "label", 4)(26, "span", 5);
          ɵɵtext(27);
          ɵɵpipe(28, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(29, "input", 10);
          ɵɵpipe(30, "cxTranslate");
          ɵɵpipe(31, "cxTranslate");
          ɵɵtwoWayListener("ngModelChange", function MyAccountV2PasswordComponent_Template_input_ngModelChange_29_listener($event) {
            ɵɵtwoWayBindingSet(ctx.newPasswordConfirm, $event) || (ctx.newPasswordConfirm = $event);
            return $event;
          });
          ɵɵelementEnd();
          ɵɵtemplate(32, MyAccountV2PasswordComponent_cx_form_errors_32_Template, 2, 6, "cx-form-errors", 7)(33, MyAccountV2PasswordComponent_cx_form_errors_33_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(34, "div", 11)(35, "button", 12);
          ɵɵlistener("click", function MyAccountV2PasswordComponent_Template_button_click_35_listener() {
            return ctx.onCancel();
          });
          ɵɵtext(36);
          ɵɵpipe(37, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(38, "button", 13);
          ɵɵtext(39);
          ɵɵpipe(40, "cxTranslate");
          ɵɵelementEnd()()();
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 25, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance(2);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(5, 27, "myAccountV2PasswordForm.newPasswordTitle"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ctx.showingAlert);
          ɵɵadvance(3);
          ɵɵtextInterpolate(ɵɵpipeBind1(10, 29, "myAccountV2PasswordForm.oldPassword.label"));
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(12, 31, "myAccountV2PasswordForm.oldPassword.placeholder"));
          ɵɵtwoWayProperty("ngModel", ctx.oldPassword);
          ɵɵattribute("aria-label", ɵɵpipeBind1(13, 33, "myAccountV2PasswordForm.oldPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate(ɵɵpipeBind1(19, 35, "myAccountV2PasswordForm.newPassword.label"));
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(21, 37, "myAccountV2PasswordForm.newPassword.placeholder"));
          ɵɵtwoWayProperty("ngModel", ctx.newPassword);
          ɵɵattribute("aria-label", ɵɵpipeBind1(22, 39, "myAccountV2PasswordForm.newPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate(ɵɵpipeBind1(28, 41, "myAccountV2PasswordForm.confirmPassword.label"));
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(30, 43, "myAccountV2PasswordForm.confirmPassword.placeholder"));
          ɵɵtwoWayProperty("ngModel", ctx.newPasswordConfirm);
          ɵɵattribute("aria-label", ɵɵpipeBind1(31, 45, "myAccountV2PasswordForm.confirmPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(37, 47, "common.cancel"), " ");
          ɵɵadvance(2);
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(40, 49, "common.save"), " ");
        }
      },
      dependencies: [NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, SpinnerComponent, FormErrorsComponent, PasswordVisibilityToggleDirective, FeatureDirective, MessageComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2PasswordComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-password",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"> </cx-spinner>

<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <label class="myaccount-password-header"
    >{{ 'myAccountV2PasswordForm.newPasswordTitle' | cxTranslate }}
  </label>

  <cx-message
    *ngIf="showingAlert"
    [text]="'myAccountV2PasswordForm.reloginIndicator' | cxTranslate"
    [type]="globalMessageType.MSG_TYPE_INFO"
    (closeMessage)="closeDialogConfirmationAlert()"
  >
  </cx-message>

  <label class="myaccount-label-padding">
    <span class="label-content myaccount-password-label">{{
      'myAccountV2PasswordForm.oldPassword.label' | cxTranslate
    }}</span>
    <input
      required="true"
      class="form-control"
      [(ngModel)]="oldPassword"
      type="password"
      name="oldPassword"
      placeholder="{{
        'myAccountV2PasswordForm.oldPassword.placeholder' | cxTranslate
      }}"
      formControlName="oldPassword"
      [attr.aria-label]="
        'myAccountV2PasswordForm.oldPassword.placeholder' | cxTranslate
      "
      cxPasswordVisibilitySwitch
    />
    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updatePasswordForm.oldPassword.label' | cxTranslate,
      }"
      [control]="form.get('oldPassword')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('oldPassword')"
    ></cx-form-errors>
  </label>

  <label class="myaccount-label-padding">
    <span class="label-content myaccount-password-label">{{
      'myAccountV2PasswordForm.newPassword.label' | cxTranslate
    }}</span>
    <input
      required="true"
      class="form-control"
      [(ngModel)]="newPassword"
      type="password"
      name="newPassword"
      placeholder="{{
        'myAccountV2PasswordForm.newPassword.placeholder' | cxTranslate
      }}"
      formControlName="newPassword"
      [attr.aria-label]="
        'myAccountV2PasswordForm.newPassword.placeholder' | cxTranslate
      "
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updatePasswordForm.newPassword.label' | cxTranslate,
      }"
      [control]="form.get('newPassword')"
    ></cx-form-errors>
    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('newPassword')"
    ></cx-form-errors>
  </label>

  <label class="myaccount-label-padding">
    <span class="label-content myaccount-password-label">{{
      'myAccountV2PasswordForm.confirmPassword.label' | cxTranslate
    }}</span>
    <input
      required="true"
      class="form-control"
      [(ngModel)]="newPasswordConfirm"
      type="password"
      name="newPasswordConfirm"
      placeholder="{{
        'myAccountV2PasswordForm.confirmPassword.placeholder' | cxTranslate
      }}"
      formControlName="newPasswordConfirm"
      [attr.aria-label]="
        'myAccountV2PasswordForm.confirmPassword.placeholder' | cxTranslate
      "
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updatePasswordForm.confirmPassword.label' | cxTranslate,
      }"
      [control]="form.get('newPasswordConfirm')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('newPasswordConfirm')"
    ></cx-form-errors>
  </label>

  <div class="password-btn-group">
    <button
      class="btn myaccount-password-button myaccount-password-button-cancel"
      (click)="onCancel()"
    >
      {{ 'common.cancel' | cxTranslate }}
    </button>
    <button
      class="btn btn-primary myaccount-password-button"
      [disabled]="form.disabled"
    >
      {{ 'common.save' | cxTranslate }}
    </button>
  </div>
</form>
`
    }]
  }], () => [], null);
})();
var myAccountV2PasswordMapping = {
  cmsComponents: {
    UpdatePasswordComponent: {
      component: MyAccountV2PasswordComponent
    }
  }
};
var UpdatePasswordModule = class _UpdatePasswordModule {
  static {
    this.ɵfac = function UpdatePasswordModule_Factory(t) {
      return new (t || _UpdatePasswordModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UpdatePasswordModule,
      declarations: [UpdatePasswordComponent, MyAccountV2PasswordComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, I18nModule, FormErrorsModule, UrlModule, RouterModule, PasswordVisibilityToggleModule, FeaturesConfigModule, MessageComponentModule, BtnLikeLinkModule],
      exports: [UpdatePasswordComponent, MyAccountV2PasswordComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          UpdatePasswordComponent: {
            component: UpdatePasswordComponent,
            guards: [AuthGuard],
            providers: [{
              provide: UpdatePasswordComponentService,
              useClass: UpdatePasswordComponentService,
              deps: [UserPasswordFacade, RoutingService, GlobalMessageService, AuthRedirectService, AuthService]
            }]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PASSWORD) ? myAccountV2PasswordMapping : {})],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, I18nModule, FormErrorsModule, UrlModule, RouterModule, PasswordVisibilityToggleModule, FeaturesConfigModule, MessageComponentModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdatePasswordModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, I18nModule, FormErrorsModule, UrlModule, RouterModule, PasswordVisibilityToggleModule, FeaturesConfigModule, MessageComponentModule, BtnLikeLinkModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          UpdatePasswordComponent: {
            component: UpdatePasswordComponent,
            guards: [AuthGuard],
            providers: [{
              provide: UpdatePasswordComponentService,
              useClass: UpdatePasswordComponentService,
              deps: [UserPasswordFacade, RoutingService, GlobalMessageService, AuthRedirectService, AuthService]
            }]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PASSWORD) ? myAccountV2PasswordMapping : {})],
      declarations: [UpdatePasswordComponent, MyAccountV2PasswordComponent],
      exports: [UpdatePasswordComponent, MyAccountV2PasswordComponent]
    }]
  }], null, null);
})();
var UpdateProfileComponentService = class _UpdateProfileComponentService {
  constructor(userProfile, globalMessageService) {
    this.userProfile = userProfile;
    this.globalMessageService = globalMessageService;
    this.user$ = this.userProfile.get().pipe(filter((user) => Boolean(user)));
    this.busy$ = new BehaviorSubject(false);
    this.updateSucceed$ = new Subject();
    this.isUpdating$ = this.user$.pipe(tap((user) => this.form.patchValue(user)), switchMap((_user) => this.busy$), tap((state) => state === true ? this.form.disable() : this.form.enable()));
    this.titles$ = this.userProfile.getTitles();
    this.form = new UntypedFormGroup({
      customerId: new UntypedFormControl(""),
      titleCode: new UntypedFormControl(""),
      firstName: new UntypedFormControl("", Validators.required),
      lastName: new UntypedFormControl("", Validators.required)
    });
  }
  /**
   * Updates the user's details and handles the UI.
   */
  updateProfile() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    this.userProfile.update(this.form.value).subscribe({
      next: () => this.onSuccess(),
      error: (error) => this.onError(error)
    });
  }
  onSuccess() {
    this.globalMessageService.add({
      key: "updateProfileForm.profileUpdateSuccess"
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.busy$.next(false);
    this.form.reset();
    this.updateSucceed$.next(true);
  }
  onError(_error) {
    this.busy$.next(false);
    this.updateSucceed$.next(false);
  }
  static {
    this.ɵfac = function UpdateProfileComponentService_Factory(t) {
      return new (t || _UpdateProfileComponentService)(ɵɵinject(UserProfileFacade), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _UpdateProfileComponentService,
      factory: _UpdateProfileComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdateProfileComponentService, [{
    type: Injectable
  }], () => [{
    type: UserProfileFacade
  }, {
    type: GlobalMessageService
  }], null);
})();
var UpdateProfileComponent = class _UpdateProfileComponent {
  constructor(service) {
    this.service = service;
    this.routingService = inject(RoutingService, {
      optional: true
    });
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    this.titles$ = this.service.titles$;
  }
  onSubmit() {
    this.service.updateProfile();
  }
  navigateTo(cxRoute) {
    this.routingService?.go({
      cxRoute
    });
  }
  static {
    this.ɵfac = function UpdateProfileComponent_Factory(t) {
      return new (t || _UpdateProfileComponent)(ɵɵdirectiveInject(UpdateProfileComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _UpdateProfileComponent,
      selectors: [["cx-update-profile"]],
      hostAttrs: [1, "user-form"],
      decls: 44,
      vars: 47,
      consts: [["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], ["class", "form-legend", 4, "cxFeature"], [3, "ngSubmit", "formGroup"], [1, "label-content"], ["formControlName", "titleCode", "id", "title-select", 3, "clearable", "searchable", "cxNgSelectA11y"], [3, "value", 4, "ngFor", "ngForOf"], [3, "ngTemplateOutlet"], ["required", "true", "type", "text", "name", "firstName", "formControlName", "firstName", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "text", "name", "lastName", "formControlName", "lastName", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "text", "name", "customerId", "formControlName", "customerId", "readonly", "", 1, "form-control"], [4, "cxFeature"], [1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "overlay"], [1, "form-legend"], [3, "value"], [3, "translationParams", "control"], [3, "control"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function UpdateProfileComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, UpdateProfileComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 1);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, UpdateProfileComponent_p_2_Template, 3, 3, "p", 2);
          ɵɵelementStart(3, "form", 3);
          ɵɵlistener("ngSubmit", function UpdateProfileComponent_Template_form_ngSubmit_3_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onSubmit());
          });
          ɵɵelementStart(4, "label")(5, "span", 4);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(8, "ng-select", 5);
          ɵɵpipe(9, "cxTranslate");
          ɵɵtemplate(10, UpdateProfileComponent_ng_option_10_Template, 2, 2, "ng-option", 6);
          ɵɵpipe(11, "async");
          ɵɵelementEnd()();
          ɵɵelementStart(12, "label")(13, "span", 4);
          ɵɵtext(14);
          ɵɵpipe(15, "cxTranslate");
          ɵɵtemplate(16, UpdateProfileComponent_ng_template_16_Template, 0, 0, "ng-template", 7);
          ɵɵelementEnd();
          ɵɵelement(17, "input", 8);
          ɵɵpipe(18, "cxTranslate");
          ɵɵtemplate(19, UpdateProfileComponent_cx_form_errors_19_Template, 2, 6, "cx-form-errors", 9)(20, UpdateProfileComponent_cx_form_errors_20_Template, 1, 1, "cx-form-errors", 10);
          ɵɵelementEnd();
          ɵɵelementStart(21, "label")(22, "span", 4);
          ɵɵtext(23);
          ɵɵpipe(24, "cxTranslate");
          ɵɵtemplate(25, UpdateProfileComponent_ng_template_25_Template, 0, 0, "ng-template", 7);
          ɵɵelementEnd();
          ɵɵelement(26, "input", 11);
          ɵɵpipe(27, "cxTranslate");
          ɵɵtemplate(28, UpdateProfileComponent_cx_form_errors_28_Template, 2, 6, "cx-form-errors", 9)(29, UpdateProfileComponent_cx_form_errors_29_Template, 1, 1, "cx-form-errors", 10);
          ɵɵelementEnd();
          ɵɵelementStart(30, "label")(31, "span", 4);
          ɵɵtext(32);
          ɵɵpipe(33, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelement(34, "input", 12);
          ɵɵtemplate(35, UpdateProfileComponent_cx_form_errors_35_Template, 2, 6, "cx-form-errors", 9)(36, UpdateProfileComponent_cx_form_errors_36_Template, 1, 1, "cx-form-errors", 10);
          ɵɵelementEnd();
          ɵɵtemplate(37, UpdateProfileComponent_ng_container_37_Template, 4, 3, "ng-container", 13)(38, UpdateProfileComponent_ng_container_38_Template, 5, 7, "ng-container", 13);
          ɵɵelementStart(39, "button", 14);
          ɵɵtext(40);
          ɵɵpipe(41, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵtemplate(42, UpdateProfileComponent_ng_template_42_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r5 = ɵɵreference(43);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 25, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance();
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance(3);
          ɵɵtextInterpolate(ɵɵpipeBind1(7, 27, "updateProfileForm.title"));
          ɵɵadvance(2);
          ɵɵproperty("clearable", false)("searchable", false)("cxNgSelectA11y", ɵɵpureFunction1(45, _c6, ɵɵpipeBind1(9, 29, "updateProfileForm.title")));
          ɵɵadvance(2);
          ɵɵproperty("ngForOf", ɵɵpipeBind1(11, 31, ctx.titles$));
          ɵɵadvance(4);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(15, 33, "updateProfileForm.firstName.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(18, 35, "updateProfileForm.firstName.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(24, 37, "updateProfileForm.lastName.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(27, 39, "updateProfileForm.lastName.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate(ɵɵpipeBind1(33, 41, "updateProfileForm.customerId"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(41, 43, "common.save"), " ");
        }
      },
      dependencies: [NgForOf, NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, SpinnerComponent, FormErrorsComponent, RouterLink, NgSelectComponent, NgOptionComponent, NgSelectA11yDirective, FeatureDirective, BtnLikeLinkDirective, AsyncPipe, TranslatePipe, UrlPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdateProfileComponent, [{
    type: Component,
    args: [{
      selector: "cx-update-profile",
      changeDetection: ChangeDetectionStrategy.OnPush,
      host: {
        class: "user-form"
      },
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"> </cx-spinner>
<!-- TODO: (CXSPA-5953) Remove feature flags next major -->
<p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
  {{ 'formLegend.required' | cxTranslate }}
</p>
<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <label>
    <span class="label-content">{{
      'updateProfileForm.title' | cxTranslate
    }}</span>
    <ng-select
      [clearable]="false"
      [searchable]="false"
      formControlName="titleCode"
      id="title-select"
      [cxNgSelectA11y]="{
        ariaLabel: 'updateProfileForm.title' | cxTranslate,
      }"
    >
      <ng-option *ngFor="let title of titles$ | async" [value]="title.code">{{
        title.name
      }}</ng-option>
    </ng-select>
  </label>
  <label>
    <span class="label-content"
      >{{ 'updateProfileForm.firstName.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      type="text"
      class="form-control"
      name="firstName"
      placeholder="{{
        'updateProfileForm.firstName.placeholder' | cxTranslate
      }}"
      formControlName="firstName"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updateProfileForm.firstName.label' | cxTranslate,
      }"
      [control]="form.get('firstName')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('firstName')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content"
      >{{ 'updateProfileForm.lastName.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
    ></span>
    <input
      required="true"
      type="text"
      class="form-control"
      name="lastName"
      placeholder="{{ 'updateProfileForm.lastName.placeholder' | cxTranslate }}"
      formControlName="lastName"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updateProfileForm.lastName.label' | cxTranslate,
      }"
      [control]="form.get('lastName')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('lastName')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content">{{
      'updateProfileForm.customerId' | cxTranslate
    }}</span>
    <input
      required="true"
      type="text"
      class="form-control"
      name="customerId"
      formControlName="customerId"
      readonly
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'updateProfileForm.customerId' | cxTranslate,
      }"
      [control]="form.get('customerId')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('customerId')"
    ></cx-form-errors>
  </label>

  <!-- TODO: (CXSPA-7252) - Remove feature flag next major release -->
  <ng-container *cxFeature="'a11yUseButtonsForBtnLinks'">
    <button class="btn btn-block btn-secondary" (click)="navigateTo('home')">
      {{ 'common.cancel' | cxTranslate }}
    </button>
  </ng-container>
  <ng-container *cxFeature="'!a11yUseButtonsForBtnLinks'">
    <a
      [routerLink]="{ cxRoute: 'home' } | cxUrl"
      class="btn btn-block btn-secondary"
      cxBtnLikeLink
      >{{ 'common.cancel' | cxTranslate }}</a
    >
  </ng-container>

  <button class="btn btn-block btn-primary" [disabled]="form.disabled">
    {{ 'common.save' | cxTranslate }}
  </button>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    aria-hidden="true"
    class="text-decoration-none required-asterisk"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: UpdateProfileComponentService
  }], {
    routingService: [{
      type: Optional
    }]
  });
})();
var MyAccountV2ProfileComponent = class _MyAccountV2ProfileComponent {
  constructor() {
    this.service = inject(UpdateProfileComponentService);
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    this.titles$ = this.service.titles$;
    this.user$ = this.service.user$;
  }
  ngOnInit() {
    this.isEditing = false;
  }
  onSubmit() {
    this.service.updateProfile();
    this.service.updateSucceed$.subscribe((res) => {
      this.isEditing = !res;
    });
  }
  cancelEdit() {
    this.isEditing = false;
    this.form.setValue(this.originalEditValue);
  }
  onEdit() {
    this.isEditing = true;
    this.originalEditValue = this.form.value;
  }
  static {
    this.ɵfac = function MyAccountV2ProfileComponent_Factory(t) {
      return new (t || _MyAccountV2ProfileComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2ProfileComponent,
      selectors: [["cx-my-account-v2-profile"]],
      decls: 12,
      vars: 11,
      consts: [["class", "overlay", 4, "ngIf"], [1, "flex-line"], [1, "headertext"], ["class", "editButton", 3, "click", 4, "ngIf"], [4, "ngIf"], ["class", "myaccount-editing-area", 4, "ngIf"], [1, "overlay"], [1, "editButton", 3, "click"], [1, "text-head"], [1, "value"], [1, "myaccount-editing-area"], [3, "ngSubmit", "formGroup"], [1, "label-content,", "text-head"], ["formControlName", "titleCode", "id", "title-select", 3, "clearable", "searchable", "cxNgSelectA11y"], [3, "value", 4, "ngFor", "ngForOf"], ["required", "true", "type", "text", "name", "firstName", "formControlName", "firstName", 1, "form-control"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "text", "name", "lastName", "formControlName", "lastName", 1, "form-control"], ["required", "true", "type", "text", "name", "customerId", "formControlName", "customerId", "readonly", "", 1, "form-control"], [1, "btn-group"], [1, "btn", "button-cancel", "button", 3, "click"], [1, "btn", "btn-primary", "button", 3, "click", "disabled"], [3, "value"], [3, "translationParams", "control"], [3, "control"]],
      template: function MyAccountV2ProfileComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2ProfileComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 0);
          ɵɵpipe(1, "async");
          ɵɵpipe(2, "async");
          ɵɵelementStart(3, "div")(4, "div")(5, "div", 1)(6, "label", 2);
          ɵɵtext(7);
          ɵɵpipe(8, "cxTranslate");
          ɵɵelementEnd();
          ɵɵtemplate(9, MyAccountV2ProfileComponent_button_9_Template, 3, 3, "button", 3);
          ɵɵelementEnd()();
          ɵɵtemplate(10, MyAccountV2ProfileComponent_div_10_Template, 23, 21, "div", 4)(11, MyAccountV2ProfileComponent_div_11_Template, 38, 36, "div", 5);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 5, ctx.isUpdating$) || !ɵɵpipeBind1(2, 7, ctx.user$));
          ɵɵadvance(7);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(8, 9, "myAccountV2UserProfile.myInformation"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngIf", !ctx.isEditing);
          ɵɵadvance();
          ɵɵproperty("ngIf", !ctx.isEditing);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.isEditing);
        }
      },
      dependencies: [NgForOf, NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, SpinnerComponent, FormErrorsComponent, NgSelectComponent, NgOptionComponent, NgSelectA11yDirective, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2ProfileComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-profile",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner class="overlay" *ngIf="(isUpdating$ | async) || !(user$ | async)">
</cx-spinner>
<div>
  <div>
    <div class="flex-line">
      <label class="headertext"
        >{{ 'myAccountV2UserProfile.myInformation' | cxTranslate }}
      </label>
      <button class="editButton" *ngIf="!isEditing" (click)="onEdit()">
        {{ 'common.edit' | cxTranslate }}
      </button>
    </div>
  </div>
  <div *ngIf="!isEditing">
    <div class="flex-line">
      <label class="text-head">
        {{ 'myAccountV2UserProfile.title' | cxTranslate }}
      </label>
      <label class="value">
        {{ (user$ | async)?.title }}
      </label>
    </div>
    <div class="flex-line">
      <label class="text-head">
        {{ 'myAccountV2UserProfile.name' | cxTranslate }}
      </label>
      <label class="value">
        {{ (user$ | async)?.firstName }} {{ (user$ | async)?.lastName }}
      </label>
    </div>
    <div class="flex-line">
      <label class="text-head">
        {{ 'myAccountV2UserProfile.customerId' | cxTranslate }}
      </label>
      <label class="value">
        {{ (user$ | async)?.customerId }}
      </label>
    </div>
  </div>
  <div *ngIf="isEditing" class="myaccount-editing-area">
    <form (ngSubmit)="onSubmit()" [formGroup]="form">
      <label>
        <span class="label-content, text-head">{{
          'myAccountV2UserProfile.title' | cxTranslate
        }}</span>
        <ng-select
          [clearable]="false"
          [searchable]="false"
          formControlName="titleCode"
          id="title-select"
          [cxNgSelectA11y]="{
            ariaLabel: 'myAccountV2UserProfile.title' | cxTranslate,
          }"
        >
          <ng-option
            *ngFor="let title of titles$ | async"
            [value]="title.code"
            >{{ title.name }}</ng-option
          >
        </ng-select>
      </label>
      <label>
        <span class="label-content, text-head">{{
          'myAccountV2UserProfile.firstName' | cxTranslate
        }}</span>
        <input
          required="true"
          type="text"
          class="form-control"
          name="firstName"
          formControlName="firstName"
        />
        <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'updateProfileForm.firstName.label' | cxTranslate,
          }"
          [control]="form.get('firstName')"
        ></cx-form-errors>

        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="form.get('firstName')"
        ></cx-form-errors>
      </label>

      <label>
        <span class="label-content, text-head">{{
          'myAccountV2UserProfile.lastName' | cxTranslate
        }}</span>
        <input
          required="true"
          type="text"
          class="form-control"
          name="lastName"
          formControlName="lastName"
        />
        <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'updateProfileForm.lastName.label' | cxTranslate,
          }"
          [control]="form.get('lastName')"
        ></cx-form-errors>

        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="form.get('lastName')"
        ></cx-form-errors>
      </label>

      <label>
        <span class="label-content, text-head">{{
          'myAccountV2UserProfile.customerId' | cxTranslate
        }}</span>
        <input
          required="true"
          type="text"
          class="form-control"
          name="customerId"
          formControlName="customerId"
          readonly
        />
        <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'updateProfileForm.customerId' | cxTranslate,
          }"
          [control]="form.get('customerId')"
        ></cx-form-errors>

        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="form.get('customerId')"
        ></cx-form-errors>
      </label>
    </form>

    <div class="btn-group">
      <button class="btn button-cancel button" (click)="cancelEdit()">
        {{ 'common.cancel' | cxTranslate }}
      </button>
      <button
        class="btn btn-primary button"
        (click)="onSubmit()"
        [disabled]="form.disabled"
      >
        {{ 'common.save' | cxTranslate }}
      </button>
    </div>
  </div>
</div>
`
    }]
  }], null, null);
})();
var USE_MY_ACCOUNT_V2_PROFILE = new InjectionToken("feature flag to enable enhanced UI for profile related pages under My-Account", {
  providedIn: "root",
  factory: () => false
});
var myAccountV2ProfileMapping = {
  cmsComponents: {
    UpdateProfileComponent: {
      component: MyAccountV2ProfileComponent
    }
  }
};
var UpdateProfileModule = class _UpdateProfileModule {
  static {
    this.ɵfac = function UpdateProfileModule_Factory(t) {
      return new (t || _UpdateProfileModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UpdateProfileModule,
      declarations: [UpdateProfileComponent, MyAccountV2ProfileComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, I18nModule, FormErrorsModule, RouterModule, UrlModule, NgSelectModule, NgSelectA11yModule, FeaturesConfigModule, BtnLikeLinkModule],
      exports: [UpdateProfileComponent, MyAccountV2ProfileComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          UpdateProfileComponent: {
            component: UpdateProfileComponent,
            guards: [AuthGuard],
            providers: [{
              provide: UpdateProfileComponentService,
              useClass: UpdateProfileComponentService,
              deps: [UserProfileFacade, GlobalMessageService]
            }]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PROFILE) ? myAccountV2ProfileMapping : {})],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, I18nModule, FormErrorsModule, RouterModule, UrlModule, NgSelectModule, NgSelectA11yModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpdateProfileModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, ReactiveFormsModule, SpinnerModule, I18nModule, FormErrorsModule, RouterModule, UrlModule, NgSelectModule, NgSelectA11yModule, FeaturesConfigModule, BtnLikeLinkModule],
      declarations: [UpdateProfileComponent, MyAccountV2ProfileComponent],
      exports: [UpdateProfileComponent, MyAccountV2ProfileComponent],
      providers: [provideDefaultConfig({
        cmsComponents: {
          UpdateProfileComponent: {
            component: UpdateProfileComponent,
            guards: [AuthGuard],
            providers: [{
              provide: UpdateProfileComponentService,
              useClass: UpdateProfileComponentService,
              deps: [UserProfileFacade, GlobalMessageService]
            }]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PROFILE) ? myAccountV2ProfileMapping : {})]
    }]
  }], null, null);
})();
var AddressBookComponentService = class _AddressBookComponentService {
  constructor(userAddressService) {
    this.userAddressService = userAddressService;
  }
  getAddresses() {
    return this.userAddressService.getAddresses();
  }
  getAddressesStateLoading() {
    return this.userAddressService.getAddressesLoading();
  }
  loadAddresses() {
    this.userAddressService.loadAddresses();
  }
  addUserAddress(address) {
    this.userAddressService.addUserAddress(address);
  }
  updateUserAddress(addressId, address) {
    this.userAddressService.updateUserAddress(addressId, address);
  }
  setAddressAsDefault(addressId) {
    this.userAddressService.setAddressAsDefault(addressId);
  }
  deleteUserAddress(addressId) {
    this.userAddressService.deleteUserAddress(addressId);
  }
  static {
    this.ɵfac = function AddressBookComponentService_Factory(t) {
      return new (t || _AddressBookComponentService)(ɵɵinject(UserAddressService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _AddressBookComponentService,
      factory: _AddressBookComponentService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AddressBookComponentService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: UserAddressService
  }], null);
})();
var AddressFormComponent = class _AddressFormComponent {
  constructor(fb, userAddressService, globalMessageService, translation, launchDialogService, userProfileFacade) {
    this.fb = fb;
    this.userAddressService = userAddressService;
    this.globalMessageService = globalMessageService;
    this.translation = translation;
    this.launchDialogService = launchDialogService;
    this.userProfileFacade = userProfileFacade;
    this.selectedCountry$ = new BehaviorSubject("");
    this.setAsDefaultField = true;
    this.showCancelBtn = true;
    this.submitAddress = new EventEmitter();
    this.backToAddress = new EventEmitter();
    this.subscription = new Subscription();
    this.addressForm = this.fb.group({
      country: this.fb.group({
        isocode: [null, Validators.required]
      }),
      titleCode: [""],
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      line1: ["", Validators.required],
      line2: [""],
      town: ["", Validators.required],
      region: this.fb.group({
        isocode: [null, Validators.required]
      }),
      postalCode: ["", Validators.required],
      phone: "",
      cellphone: "",
      defaultAddress: [false]
    });
  }
  ngOnInit() {
    this.countries$ = this.countries || this.userAddressService.getDeliveryCountries().pipe(tap((countries) => {
      if (Object.keys(countries).length === 0) {
        this.userAddressService.loadDeliveryCountries();
      }
    }));
    this.titles$ = this.getTitles();
    this.regions$ = this.selectedCountry$.pipe(switchMap((country) => this.userAddressService.getRegions(country)), tap((regions) => {
      const regionControl = this.addressForm.get("region.isocode");
      if (regions && regions.length > 0) {
        regionControl?.enable();
      } else {
        regionControl?.disable();
      }
    }));
    if (this.addressData && Object.keys(this.addressData).length !== 0) {
      this.addressForm.patchValue(this.addressData);
      this.countrySelected(this.addressData.country);
      if (this.addressData.region) {
        this.regionSelected(this.addressData.region);
      }
    }
    this.addresses$ = this.userAddressService.getAddresses();
  }
  getTitles() {
    return combineLatest([this.translation.translate("addressForm.defaultTitle"), this.userProfileFacade.getTitles()]).pipe(map(([noneTitleText, titles]) => {
      const noneTitle = {
        code: "",
        name: noneTitleText
      };
      titles.sort(sortTitles);
      return [noneTitle, ...titles];
    }));
  }
  handleAddressVerificationResults(results) {
    if (results.decision === "ACCEPT") {
      this.submitAddress.emit(this.addressForm.value);
    } else if (results.decision === "REJECT") {
      if (results.errors?.errors.some((error) => error.subject === "titleCode")) {
        this.globalMessageService.add({
          key: "addressForm.titleRequired"
        }, GlobalMessageType.MSG_TYPE_ERROR);
      } else {
        this.globalMessageService.add({
          key: "addressForm.invalidAddress"
        }, GlobalMessageType.MSG_TYPE_ERROR);
      }
    } else if (results.decision === "REVIEW") {
      this.openSuggestedAddress(results);
    }
  }
  countrySelected(country) {
    this.addressForm.get("country")?.get("isocode")?.setValue(country?.isocode);
    this.selectedCountry$.next(country?.isocode ?? "");
  }
  regionSelected(region) {
    this.addressForm.get("region")?.get("isocode")?.setValue(region.isocode);
  }
  toggleDefaultAddress() {
    this.addressForm["controls"].defaultAddress.setValue(this.addressForm.value.defaultAddress);
  }
  back() {
    this.backToAddress.emit();
  }
  verifyAddress() {
    if (this.addressForm.valid) {
      const regionControl = this.addressForm.get("region");
      const isocode = regionControl?.value?.isocode;
      if (isocode) {
        this.regions$.pipe(take(1)).subscribe((regions) => {
          if (regions.length) {
            const selectedRegion = regions.find((region) => region.isocode === isocode);
            regionControl?.patchValue({
              isocodeShort: selectedRegion?.isocodeShort
            });
          } else {
            regionControl?.reset();
          }
        });
      }
      if (this.addressForm.dirty) {
        this.subscription.add(this.userAddressService.verifyAddress(this.addressForm.value).subscribe((value) => {
          this.handleAddressVerificationResults(value);
        }));
      } else {
        this.submitAddress.emit(void 0);
      }
    } else {
      this.addressForm.markAllAsTouched();
      this.globalMessageService.add({
        key: "formErrors.globalMessage"
      }, GlobalMessageType.MSG_TYPE_ASSISTIVE);
    }
  }
  openSuggestedAddress(results) {
    this.launchDialogService.openDialogAndSubscribe("SUGGESTED_ADDRESSES", this.element, {
      enteredAddress: this.addressForm.value,
      suggestedAddresses: results.suggestedAddresses
    });
    this.subscription.add(this.launchDialogService.dialogClose.pipe(filter((result) => Boolean(result))).subscribe((result) => {
      if (typeof result === "object") {
        const address = __spreadProps(__spreadValues({}, result), {
          titleCode: this.addressForm.value.titleCode,
          phone: this.addressForm.value.phone,
          selected: true
        });
        this.submitAddress.emit(address);
      }
    }));
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static {
    this.ɵfac = function AddressFormComponent_Factory(t) {
      return new (t || _AddressFormComponent)(ɵɵdirectiveInject(UntypedFormBuilder), ɵɵdirectiveInject(UserAddressService), ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(UserProfileFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AddressFormComponent,
      selectors: [["cx-address-form"]],
      viewQuery: function AddressFormComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c7, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
        }
      },
      inputs: {
        addressData: "addressData",
        actionBtnLabel: "actionBtnLabel",
        cancelBtnLabel: "cancelBtnLabel",
        setAsDefaultField: "setAsDefaultField",
        showTitleCode: "showTitleCode",
        showCancelBtn: "showCancelBtn",
        countries: "countries"
      },
      outputs: {
        submitAddress: "submitAddress",
        backToAddress: "backToAddress"
      },
      decls: 93,
      vars: 79,
      consts: [["submit", ""], ["requiredAsterisk", ""], ["class", "form-legend", 4, "cxFeature"], [3, "ngSubmit", "formGroup"], ["formGroupName", "country", 1, "form-group"], [4, "ngIf"], ["class", "form-group", 4, "ngIf"], [1, "form-group"], [1, "label-content", "required"], [3, "ngTemplateOutlet"], ["required", "true", "type", "text", "formControlName", "firstName", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "text", "formControlName", "lastName", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "text", "formControlName", "line1", 1, "form-control", 3, "placeholder"], [1, "label-content"], ["type", "text", "formControlName", "line2", 1, "form-control", 3, "placeholder"], [1, "row"], [1, "form-group", "col-sm-6"], ["required", "true", "type", "text", "formControlName", "town", 1, "form-control", 3, "placeholder"], ["required", "true", "type", "text", "formControlName", "postalCode", 1, "form-control", 3, "placeholder"], ["formGroupName", "region", 4, "ngIf"], [1, "form-group", "col-md-6"], ["type", "tel", "formControlName", "phone", 1, "form-control", 3, "placeholder"], ["type", "tel", "formControlName", "cellphone", 1, "form-control", 3, "placeholder"], [1, "cx-address-form-btns"], ["class", "col-md-13 col-lg-6", 4, "ngIf"], [1, "col-md-13", "col-lg-6"], ["type", "submit", 1, "btn", "btn-block", "btn-primary"], [1, "form-legend"], ["id", "country-select", "formControlName", "isocode", "bindLabel", "name", "bindValue", "isocode", 1, "country-select", 3, "change", "inputAttrs", "searchable", "clearable", "items", "placeholder", "cxNgSelectA11y"], [3, "translationParams", "control"], [3, "control"], ["id", "title-select", "formControlName", "titleCode", "bindLabel", "name", "bindValue", "code", 3, "searchable", "clearable", "items", "placeholder", "cxNgSelectA11y"], ["formGroupName", "region"], ["formControlName", "isocode", "id", "region-select", 1, "region-select", 3, "inputAttrs", "searchable", "clearable", "items", "bindLabel", "bindValue", "placeholder", "cxNgSelectA11y"], [1, "form-check"], ["type", "checkbox", "formControlName", "defaultAddress", 1, "form-check-input", 3, "change"], [1, "form-check-label"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function AddressFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, AddressFormComponent_p_0_Template, 3, 3, "p", 2);
          ɵɵelementStart(1, "form", 3);
          ɵɵlistener("ngSubmit", function AddressFormComponent_Template_form_ngSubmit_1_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.verifyAddress());
          });
          ɵɵelementStart(2, "div", 4);
          ɵɵtemplate(3, AddressFormComponent_ng_container_3_Template, 2, 1, "ng-container", 5);
          ɵɵpipe(4, "async");
          ɵɵelementEnd();
          ɵɵtemplate(5, AddressFormComponent_div_5_Template, 3, 3, "div", 6);
          ɵɵelementStart(6, "div", 7)(7, "label")(8, "span", 8);
          ɵɵtext(9);
          ɵɵpipe(10, "cxTranslate");
          ɵɵtemplate(11, AddressFormComponent_ng_template_11_Template, 0, 0, "ng-template", 9);
          ɵɵelementEnd();
          ɵɵelement(12, "input", 10);
          ɵɵpipe(13, "cxTranslate");
          ɵɵtemplate(14, AddressFormComponent_cx_form_errors_14_Template, 2, 6, "cx-form-errors", 11)(15, AddressFormComponent_cx_form_errors_15_Template, 1, 1, "cx-form-errors", 12);
          ɵɵelementEnd()();
          ɵɵelementStart(16, "div", 7)(17, "label")(18, "span", 8);
          ɵɵtext(19);
          ɵɵpipe(20, "cxTranslate");
          ɵɵtemplate(21, AddressFormComponent_ng_template_21_Template, 0, 0, "ng-template", 9);
          ɵɵelementEnd();
          ɵɵelement(22, "input", 13);
          ɵɵpipe(23, "cxTranslate");
          ɵɵtemplate(24, AddressFormComponent_cx_form_errors_24_Template, 2, 6, "cx-form-errors", 11)(25, AddressFormComponent_cx_form_errors_25_Template, 1, 1, "cx-form-errors", 12);
          ɵɵelementEnd()();
          ɵɵelementStart(26, "div", 7)(27, "label")(28, "span", 8);
          ɵɵtext(29);
          ɵɵpipe(30, "cxTranslate");
          ɵɵtemplate(31, AddressFormComponent_ng_template_31_Template, 0, 0, "ng-template", 9);
          ɵɵelementEnd();
          ɵɵelement(32, "input", 14);
          ɵɵpipe(33, "cxTranslate");
          ɵɵtemplate(34, AddressFormComponent_cx_form_errors_34_Template, 2, 6, "cx-form-errors", 11)(35, AddressFormComponent_cx_form_errors_35_Template, 1, 1, "cx-form-errors", 12);
          ɵɵelementEnd()();
          ɵɵelementStart(36, "div", 7)(37, "label")(38, "span", 15);
          ɵɵtext(39);
          ɵɵpipe(40, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelement(41, "input", 16);
          ɵɵpipe(42, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(43, "div", 17)(44, "div", 18)(45, "label")(46, "span", 8);
          ɵɵtext(47);
          ɵɵpipe(48, "cxTranslate");
          ɵɵtemplate(49, AddressFormComponent_ng_template_49_Template, 0, 0, "ng-template", 9);
          ɵɵelementEnd();
          ɵɵelement(50, "input", 19);
          ɵɵpipe(51, "cxTranslate");
          ɵɵtemplate(52, AddressFormComponent_cx_form_errors_52_Template, 2, 6, "cx-form-errors", 11)(53, AddressFormComponent_cx_form_errors_53_Template, 1, 1, "cx-form-errors", 12);
          ɵɵelementEnd()();
          ɵɵelementStart(54, "div", 18)(55, "label")(56, "span", 8);
          ɵɵtext(57);
          ɵɵpipe(58, "cxTranslate");
          ɵɵtemplate(59, AddressFormComponent_ng_template_59_Template, 0, 0, "ng-template", 9);
          ɵɵelementEnd();
          ɵɵelement(60, "input", 20);
          ɵɵpipe(61, "cxTranslate");
          ɵɵtemplate(62, AddressFormComponent_cx_form_errors_62_Template, 2, 6, "cx-form-errors", 11)(63, AddressFormComponent_cx_form_errors_63_Template, 1, 1, "cx-form-errors", 12);
          ɵɵelementEnd()();
          ɵɵtemplate(64, AddressFormComponent_ng_container_64_Template, 2, 1, "ng-container", 21);
          ɵɵpipe(65, "async");
          ɵɵelementEnd();
          ɵɵelementStart(66, "div", 17)(67, "div", 22)(68, "label")(69, "span", 15);
          ɵɵtext(70);
          ɵɵpipe(71, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelement(72, "input", 23);
          ɵɵpipe(73, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(74, "div", 22)(75, "label")(76, "span", 15);
          ɵɵtext(77);
          ɵɵpipe(78, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelement(79, "input", 24);
          ɵɵpipe(80, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵtemplate(81, AddressFormComponent_div_81_Template, 7, 3, "div", 6);
          ɵɵpipe(82, "async");
          ɵɵelementStart(83, "div", 25)(84, "div", 17);
          ɵɵtemplate(85, AddressFormComponent_div_85_Template, 4, 3, "div", 26);
          ɵɵelementStart(86, "div", 27)(87, "button", 28, 0);
          ɵɵtext(89);
          ɵɵpipe(90, "cxTranslate");
          ɵɵelementEnd()()()()();
          ɵɵtemplate(91, AddressFormComponent_ng_template_91_Template, 1, 1, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          let tmp_38_0;
          const requiredAsterisk_r5 = ɵɵreference(92);
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance();
          ɵɵproperty("formGroup", ctx.addressForm);
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(4, 39, ctx.countries$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ctx.showTitleCode);
          ɵɵadvance(4);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(10, 41, "addressForm.firstName.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(13, 43, "addressForm.firstName.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(4);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(20, 45, "addressForm.lastName.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(23, 47, "addressForm.lastName.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(4);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(30, 49, "addressForm.address1"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(33, 51, "addressForm.streetAddress"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(4);
          ɵɵtextInterpolate(ɵɵpipeBind1(40, 53, "addressForm.address2"));
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(42, 55, "addressForm.aptSuite"));
          ɵɵadvance(6);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(48, 57, "addressForm.city.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(51, 59, "addressForm.city.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(4);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(58, 61, "addressForm.zipCode.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r5);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(61, 63, "addressForm.zipCode.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("ngIf", ɵɵpipeBind1(65, 65, ctx.regions$));
          ɵɵadvance(6);
          ɵɵtextInterpolate(ɵɵpipeBind1(71, 67, "addressForm.phoneNumber.label"));
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(73, 69, "addressForm.phoneNumber.placeholder"));
          ɵɵadvance(5);
          ɵɵtextInterpolate(ɵɵpipeBind1(78, 71, "addressForm.cellphone.label"));
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(80, 73, "addressForm.cellphone.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ((tmp_38_0 = ɵɵpipeBind1(82, 75, ctx.addresses$)) == null ? null : tmp_38_0.length) && ctx.setAsDefaultField);
          ɵɵadvance(4);
          ɵɵproperty("ngIf", ctx.showCancelBtn);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ctx.actionBtnLabel || ɵɵpipeBind1(90, 77, "common.continue"), " ");
        }
      },
      dependencies: [NgSelectA11yDirective, NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, CheckboxControlValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, FormGroupName, NgSelectComponent, FormErrorsComponent, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AddressFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-address-form",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<!-- TODO: (CXSPA-5953) Remove feature flags next major -->
<p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
  {{ 'formLegend.required' | cxTranslate }}
</p>
<form (ngSubmit)="verifyAddress()" [formGroup]="addressForm">
  <div class="form-group" formGroupName="country">
    <ng-container *ngIf="countries$ | async as countries">
      <div *ngIf="countries.length !== 0">
        <label>
          <span class="label-content required"
            >{{ 'addressForm.country' | cxTranslate }}
            <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
          </span>
          <ng-select
            [inputAttrs]="{ required: 'true' }"
            class="country-select"
            id="country-select"
            formControlName="isocode"
            [searchable]="true"
            [clearable]="false"
            [items]="countries"
            bindLabel="name"
            bindValue="isocode"
            placeholder="{{ 'addressForm.selectOne' | cxTranslate }}"
            (change)="countrySelected($event)"
            [cxNgSelectA11y]="{
              ariaLabel: 'addressForm.country' | cxTranslate,
            }"
          >
          </ng-select>
          <cx-form-errors
            *cxFeature="'formErrorsDescriptiveMessages'"
            [translationParams]="{
              label: 'addressForm.country' | cxTranslate,
            }"
            [control]="addressForm.get('country.isocode')"
          ></cx-form-errors>
          <cx-form-errors
            *cxFeature="'!formErrorsDescriptiveMessages'"
            [control]="addressForm.get('country.isocode')"
          ></cx-form-errors>
        </label>
      </div>
    </ng-container>
  </div>
  <div class="form-group" *ngIf="showTitleCode">
    <ng-container *ngIf="titles$ | async as titles">
      <div *ngIf="titles.length !== 0">
        <label>
          <span class="label-content required">{{
            'addressForm.titleOptional' | cxTranslate
          }}</span>
          <ng-select
            id="title-select"
            formControlName="titleCode"
            [searchable]="true"
            [clearable]="false"
            [items]="titles"
            bindLabel="name"
            bindValue="code"
            [placeholder]="'addressForm.title' | cxTranslate"
            [cxNgSelectA11y]="{
              ariaLabel: 'addressForm.title' | cxTranslate,
            }"
          >
          </ng-select>
        </label>
      </div>
    </ng-container>
  </div>
  <div class="form-group">
    <label>
      <span class="label-content required"
        >{{ 'addressForm.firstName.label' | cxTranslate }}
        <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
      ></span>
      <input
        required="true"
        class="form-control"
        type="text"
        placeholder="{{ 'addressForm.firstName.placeholder' | cxTranslate }}"
        formControlName="firstName"
      />
      <cx-form-errors
        *cxFeature="'formErrorsDescriptiveMessages'"
        [translationParams]="{
          label: 'addressForm.firstName.label' | cxTranslate,
        }"
        [control]="addressForm.get('firstName')"
      ></cx-form-errors>
      <cx-form-errors
        *cxFeature="'!formErrorsDescriptiveMessages'"
        [control]="addressForm.get('firstName')"
      ></cx-form-errors>
    </label>
  </div>
  <div class="form-group">
    <label>
      <span class="label-content required"
        >{{ 'addressForm.lastName.label' | cxTranslate }}
        <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
      ></span>
      <input
        required="true"
        type="text"
        class="form-control"
        placeholder="{{ 'addressForm.lastName.placeholder' | cxTranslate }}"
        formControlName="lastName"
      />
      <cx-form-errors
        *cxFeature="'formErrorsDescriptiveMessages'"
        [translationParams]="{
          label: 'addressForm.lastName.label' | cxTranslate,
        }"
        [control]="addressForm.get('lastName')"
      ></cx-form-errors>
      <cx-form-errors
        *cxFeature="'!formErrorsDescriptiveMessages'"
        [control]="addressForm.get('lastName')"
      ></cx-form-errors>
    </label>
  </div>
  <div class="form-group">
    <label>
      <span class="label-content required"
        >{{ 'addressForm.address1' | cxTranslate }}
        <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
      ></span>
      <input
        required="true"
        type="text"
        class="form-control"
        placeholder="{{ 'addressForm.streetAddress' | cxTranslate }}"
        formControlName="line1"
      />
      <cx-form-errors
        *cxFeature="'formErrorsDescriptiveMessages'"
        [translationParams]="{
          label: 'addressForm.address1' | cxTranslate,
        }"
        [control]="addressForm.get('line1')"
      ></cx-form-errors>
      <cx-form-errors
        *cxFeature="'!formErrorsDescriptiveMessages'"
        [control]="addressForm.get('line1')"
      ></cx-form-errors>
    </label>
  </div>
  <div class="form-group">
    <label>
      <span class="label-content">{{
        'addressForm.address2' | cxTranslate
      }}</span>
      <input
        type="text"
        class="form-control"
        placeholder="{{ 'addressForm.aptSuite' | cxTranslate }}"
        formControlName="line2"
      />
    </label>
  </div>
  <div class="row">
    <div class="form-group col-sm-6">
      <label>
        <span class="label-content required"
          >{{ 'addressForm.city.label' | cxTranslate }}
          <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
        ></span>
        <input
          required="true"
          type="text"
          class="form-control"
          placeholder="{{ 'addressForm.city.placeholder' | cxTranslate }}"
          formControlName="town"
        />
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'addressForm.city.label' | cxTranslate,
          }"
          [control]="addressForm.get('town')"
        ></cx-form-errors>
        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="addressForm.get('town')"
        ></cx-form-errors>
      </label>
    </div>
    <div class="form-group col-sm-6">
      <label>
        <span class="label-content required"
          >{{ 'addressForm.zipCode.label' | cxTranslate }}
          <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
        ></span>
        <input
          required="true"
          type="text"
          class="form-control"
          placeholder="{{ 'addressForm.zipCode.placeholder' | cxTranslate }}"
          formControlName="postalCode"
        />
        <cx-form-errors
          *cxFeature="'formErrorsDescriptiveMessages'"
          [translationParams]="{
            label: 'addressForm.zipCode.label' | cxTranslate,
          }"
          [control]="addressForm.get('postalCode')"
        ></cx-form-errors>
        <cx-form-errors
          *cxFeature="'!formErrorsDescriptiveMessages'"
          [control]="addressForm.get('postalCode')"
        ></cx-form-errors>
      </label>
    </div>
    <ng-container *ngIf="regions$ | async as regions" formGroupName="region">
      <ng-container *ngIf="regions.length !== 0">
        <div class="form-group col-md-6">
          <label>
            <span class="label-content required"
              >{{ 'addressForm.state' | cxTranslate }}
              <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template
            ></span>
            <ng-select
              [inputAttrs]="{ required: 'true' }"
              class="region-select"
              formControlName="isocode"
              [searchable]="true"
              [clearable]="false"
              [items]="regions"
              bindLabel="{{ regions[0].name ? 'name' : 'isocode' }}"
              bindValue="{{ regions[0].name ? 'isocode' : 'region' }}"
              placeholder="{{ 'addressForm.selectOne' | cxTranslate }}"
              id="region-select"
              [cxNgSelectA11y]="{
                ariaLabel: 'addressForm.state' | cxTranslate,
              }"
            >
            </ng-select>
            <cx-form-errors
              [control]="addressForm.get('region.isocode')"
            ></cx-form-errors>
          </label>
        </div>
      </ng-container>
    </ng-container>
  </div>

  <div class="row">
    <div class="form-group col-md-6">
      <label>
        <span class="label-content">{{
          'addressForm.phoneNumber.label' | cxTranslate
        }}</span>
        <input
          type="tel"
          class="form-control"
          placeholder="{{
            'addressForm.phoneNumber.placeholder' | cxTranslate
          }}"
          formControlName="phone"
        />
      </label>
    </div>
    <div class="form-group col-md-6">
      <label>
        <span class="label-content">{{
          'addressForm.cellphone.label' | cxTranslate
        }}</span>
        <input
          type="tel"
          class="form-control"
          placeholder="{{ 'addressForm.cellphone.placeholder' | cxTranslate }}"
          formControlName="cellphone"
        />
      </label>
    </div>
  </div>

  <div
    class="form-group"
    *ngIf="(addresses$ | async)?.length && setAsDefaultField"
  >
    <div class="form-check">
      <label>
        <input
          type="checkbox"
          class="form-check-input"
          formControlName="defaultAddress"
          (change)="toggleDefaultAddress()"
        />
        <span class="form-check-label">{{
          'addressForm.setAsDefault' | cxTranslate
        }}</span>
      </label>
    </div>
  </div>
  <div class="cx-address-form-btns">
    <div class="row">
      <div class="col-md-13 col-lg-6" *ngIf="showCancelBtn">
        <button class="btn btn-block btn-secondary" (click)="back()">
          {{ cancelBtnLabel || ('addressForm.chooseAddress' | cxTranslate) }}
        </button>
      </div>
      <div class="col-md-13 col-lg-6">
        <button #submit class="btn btn-block btn-primary" type="submit">
          {{ actionBtnLabel || ('common.continue' | cxTranslate) }}
        </button>
      </div>
    </div>
  </div>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    aria-hidden="true"
    class="text-decoration-none required-asterisk"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: UntypedFormBuilder
  }, {
    type: UserAddressService
  }, {
    type: GlobalMessageService
  }, {
    type: TranslationService
  }, {
    type: LaunchDialogService
  }, {
    type: UserProfileFacade
  }], {
    addressData: [{
      type: Input
    }],
    actionBtnLabel: [{
      type: Input
    }],
    cancelBtnLabel: [{
      type: Input
    }],
    setAsDefaultField: [{
      type: Input
    }],
    showTitleCode: [{
      type: Input
    }],
    showCancelBtn: [{
      type: Input
    }],
    countries: [{
      type: Input
    }],
    submitAddress: [{
      type: Output
    }],
    backToAddress: [{
      type: Output
    }],
    element: [{
      type: ViewChild,
      args: ["submit"]
    }]
  });
})();
var AddressBookComponent = class _AddressBookComponent {
  constructor(service, translation, globalMessageService) {
    this.service = service;
    this.translation = translation;
    this.globalMessageService = globalMessageService;
    this.showAddAddressForm = false;
    this.showEditAddressForm = false;
  }
  ngOnInit() {
    this.addresses$ = this.service.getAddresses();
    this.addressesStateLoading$ = this.service.getAddressesStateLoading();
    this.service.loadAddresses();
  }
  addAddressButtonHandle() {
    this.showEditAddressForm = false;
    this.showAddAddressForm = true;
  }
  editAddressButtonHandle(address) {
    this.showAddAddressForm = false;
    this.showEditAddressForm = true;
    this.currentAddress = address;
  }
  addAddressSubmit(address) {
    this.showAddAddressForm = false;
    this.service.addUserAddress(address);
  }
  addAddressCancel() {
    this.showAddAddressForm = false;
  }
  editAddressSubmit(address) {
    this.showEditAddressForm = false;
    if (address && this.currentAddress["id"]) {
      this.service.updateUserAddress(this.currentAddress["id"], address);
    }
  }
  editAddressCancel() {
    this.showEditAddressForm = false;
  }
  getCardContent(address) {
    return combineLatest([this.translation.translate("addressCard.default"), this.translation.translate("addressCard.setAsDefault"), this.translation.translate("common.delete"), this.translation.translate("common.edit"), this.translation.translate("addressBook.areYouSureToDeleteAddress"), this.translation.translate("addressCard.phoneNumber"), this.translation.translate("addressCard.mobileNumber")]).pipe(map(([defaultText, setAsDefaultText, textDelete, textEdit, textVerifyDeleteMsg, textPhone, textMobile]) => {
      let region = "";
      if (address.region && address.region.isocode) {
        region = address.region.isocode + ", ";
      }
      const actions = [];
      if (!address.defaultAddress) {
        actions.push({
          name: setAsDefaultText,
          event: "default"
        });
      }
      actions.push({
        name: textEdit,
        event: "edit"
      });
      actions.push({
        name: textDelete,
        event: "delete"
      });
      const numbers = getAddressNumbers(address, textPhone, textMobile);
      return {
        role: "application",
        textBold: address.firstName + " " + address.lastName,
        text: [address.line1, address.line2, address.town + ", " + region + address.country?.isocode, address.postalCode, numbers],
        actions,
        header: address.defaultAddress ? `✓ ${defaultText}` : "",
        deleteMsg: textVerifyDeleteMsg,
        label: address.defaultAddress ? "addressBook.defaultDeliveryAddress" : "addressBook.additionalDeliveryAddress"
      };
    }));
  }
  setAddressAsDefault(address) {
    this.service.setAddressAsDefault(address.id ?? "");
    this.globalMessageService.add({
      key: "addressMessages.setAsDefaultSuccessfully",
      params: {
        streetAddress: address.line1
      }
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
  }
  deleteAddress(addressId) {
    this.service.deleteUserAddress(addressId);
  }
  setEdit(addressId) {
    if (this.editCard !== addressId) {
      this.editCard = addressId;
    } else {
      this.deleteAddress(addressId);
    }
  }
  cancelCard() {
    this.editCard = null;
  }
  static {
    this.ɵfac = function AddressBookComponent_Factory(t) {
      return new (t || _AddressBookComponent)(ɵɵdirectiveInject(AddressBookComponentService), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(GlobalMessageService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AddressBookComponent,
      selectors: [["cx-address-book"]],
      decls: 8,
      vars: 7,
      consts: [["loading", ""], [1, "cx-section"], [4, "ngIf"], [1, "row"], [1, "col-md-6"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["class", "row cx-address-deck", 4, "ngIf", "ngIfElse"], [1, "row", "cx-address-deck"], ["role", "status", 4, "cxFeature"], ["class", "col-md-6 cx-address-card", 4, "ngFor", "ngForOf"], ["role", "status"], [1, "col-md-6", "cx-address-card"], [3, "editCard", "setDefaultCard", "deleteCard", "cancelCard", "index", "border", "fitToContainer", "content", "editMode"], [1, "cx-section-msg"], [1, "cx-form", 3, "submitAddress", "backToAddress", "cancelCard", "showTitleCode", "showCancelBtn", "actionBtnLabel", "cancelBtnLabel", "setAsDefaultField"], [3, "submitAddress", "backToAddress", "showTitleCode", "actionBtnLabel", "cancelBtnLabel", "addressData"], [1, "col-md-12", "cx-address-spinner"]],
      template: function AddressBookComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 1);
          ɵɵtemplate(1, AddressBookComponent_ng_container_1_Template, 8, 7, "ng-container", 2);
          ɵɵpipe(2, "async");
          ɵɵtemplate(3, AddressBookComponent_ng_container_3_Template, 10, 16, "ng-container", 2);
          ɵɵpipe(4, "async");
          ɵɵtemplate(5, AddressBookComponent_ng_container_5_Template, 8, 11, "ng-container", 2);
          ɵɵelementEnd();
          ɵɵtemplate(6, AddressBookComponent_ng_template_6_Template, 2, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          let tmp_1_0;
          let tmp_2_0;
          ɵɵadvance();
          ɵɵproperty("ngIf", ((tmp_1_0 = ɵɵpipeBind1(2, 3, ctx.addresses$)) == null ? null : tmp_1_0.length) && !(ctx.showAddAddressForm || ctx.showEditAddressForm));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", (!((tmp_2_0 = ɵɵpipeBind1(4, 5, ctx.addresses$)) == null ? null : tmp_2_0.length) || ctx.showAddAddressForm) && !ctx.showEditAddressForm);
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ctx.showEditAddressForm);
        }
      },
      dependencies: [NgForOf, NgIf, CardComponent, AddressFormComponent, SpinnerComponent, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AddressBookComponent, [{
    type: Component,
    args: [{
      selector: "cx-address-book",
      template: `<div class="cx-section">
  <ng-container
    *ngIf="
      (addresses$ | async)?.length &&
      !(showAddAddressForm || showEditAddressForm)
    "
  >
    <div class="row">
      <div class="col-md-6">
        <button
          class="btn btn-block btn-secondary"
          (click)="addAddressButtonHandle()"
        >
          {{ 'addressBook.addNewAddress' | cxTranslate }}
        </button>
      </div>
    </div>

    <div
      class="row cx-address-deck"
      *ngIf="!(addressesStateLoading$ | async); else loading"
    >
      <div
        *cxFeature="'!a11yRemoveStatusLoadedRole'"
        role="status"
        [attr.aria-label]="'common.loaded' | cxTranslate"
      ></div>
      <div
        *ngFor="let address of addresses$ | async; let i = index"
        class="col-md-6 cx-address-card"
      >
        <cx-card
          [index]="i"
          [border]="true"
          [fitToContainer]="true"
          [content]="getCardContent(address) | async"
          (editCard)="editAddressButtonHandle(address)"
          (setDefaultCard)="setAddressAsDefault(address)"
          (deleteCard)="setEdit(address.id ?? '')"
          [editMode]="address.id === editCard"
          (cancelCard)="cancelCard()"
        ></cx-card>
      </div>
    </div>
  </ng-container>

  <ng-container
    *ngIf="
      (!(addresses$ | async)?.length || showAddAddressForm) &&
      !showEditAddressForm
    "
  >
    <section>
      <h2 class="cx-section-msg">
        {{ 'addressBook.addNewDeliveryAddress' | cxTranslate }}
      </h2>
      <cx-address-form
        class="cx-form"
        [showTitleCode]="true"
        [showCancelBtn]="!((addresses$ | async)?.length === 0)"
        actionBtnLabel="{{ 'addressBook.addAddress' | cxTranslate }}"
        cancelBtnLabel="{{ 'addressBook.backToAddressList' | cxTranslate }}"
        [setAsDefaultField]="!((addresses$ | async)?.length === 0)"
        (submitAddress)="addAddressSubmit($event)"
        (backToAddress)="addAddressCancel()"
        (cancelCard)="cancelCard()"
      ></cx-address-form>
    </section>
  </ng-container>

  <ng-container *ngIf="showEditAddressForm">
    <section>
      <h2 class="cx-section-msg">
        {{ 'addressBook.editDeliveryAddress' | cxTranslate }}
      </h2>
      <cx-address-form
        [showTitleCode]="true"
        actionBtnLabel="{{ 'addressBook.updateAddress' | cxTranslate }}"
        cancelBtnLabel="{{ 'addressBook.backToAddressList' | cxTranslate }}"
        [addressData]="currentAddress"
        (submitAddress)="editAddressSubmit($event)"
        (backToAddress)="editAddressCancel()"
      ></cx-address-form>
    </section>
  </ng-container>
</div>

<ng-template #loading>
  <div class="col-md-12 cx-address-spinner">
    <cx-spinner></cx-spinner>
  </div>
</ng-template>
`
    }]
  }], () => [{
    type: AddressBookComponentService
  }, {
    type: TranslationService
  }, {
    type: GlobalMessageService
  }], null);
})();
var SuggestedAddressDialogComponent = class _SuggestedAddressDialogComponent {
  handleClick(event) {
    if (event.target.tagName === this.el.nativeElement.tagName) {
      this.closeModal("Cross click");
    }
  }
  constructor(launchDialogService, el) {
    this.launchDialogService = launchDialogService;
    this.el = el;
    this.iconTypes = ICON_TYPE;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: "button",
      focusOnEscape: true
    };
    this.data$ = this.launchDialogService.data$;
    useFeatureStyles("a11yExpandedFocusIndicator");
  }
  ngOnInit() {
    this.data$.pipe(take(1)).subscribe((data) => this.setSelectedAddress(data));
  }
  closeModal(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  setSelectedAddress(data) {
    this.selectedAddress = data.suggestedAddresses?.length ? data.suggestedAddresses[0] : data.enteredAddress;
  }
  static {
    this.ɵfac = function SuggestedAddressDialogComponent_Factory(t) {
      return new (t || _SuggestedAddressDialogComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ElementRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _SuggestedAddressDialogComponent,
      selectors: [["cx-suggested-addresses-dialog"]],
      hostBindings: function SuggestedAddressDialogComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          ɵɵlistener("click", function SuggestedAddressDialogComponent_click_HostBindingHandler($event) {
            return ctx.handleClick($event);
          });
        }
      },
      decls: 3,
      vars: 4,
      consts: [["role", "dialog", "aria-labelledby", "dialogTitle", 1, "cx-suggested-addresses-dialog", 3, "esc", "cxFocus"], ["class", "cx-suggested-addresses-container", 4, "ngIf"], [1, "cx-suggested-addresses-container"], [1, "cx-suggested-addresses-header", "cx-modal-header"], ["id", "dialogTitle", "class", "cx-suggested-addresses-title", 4, "cxFeature"], ["type", "button", 1, "close", 3, "click", "title"], ["aria-hidden", "true"], [3, "type"], ["ngForm", "", 1, "cx-suggested-addresses-body"], [1, "cx-dialog-info"], [1, "cx-dialog-options"], ["class", "form-check", 4, "ngFor", "ngForOf"], [1, "form-check"], ["type", "radio", "name", "selectedAddress", "id", "suggested-addresses--entered", 1, "form-check-input", 3, "ngModelChange", "ngModel", "value"], ["for", "suggested-addresses--entered", 1, "form-check-label", "cx-dialog-label"], [1, "cx-dialog-entered"], [1, "cx-card-container"], [1, "cx-card-label"], [1, "cx-suggested-addresses-footer", "cx-modal-footer"], [1, "row"], [1, "cx-dialog-actions", "col-sm-12", "col-md-12", "col-lg-6", "offset-lg-6"], [1, "btn", "btn-secondary", "cx-dialog-buttons", 3, "click"], ["cxAutoFocus", "", 1, "btn", "btn-primary", "cx-dialog-buttons", 3, "click"], ["id", "dialogTitle", 1, "cx-suggested-addresses-title"], ["type", "radio", "name", "selectedAddress", 1, "form-check-input", 3, "ngModelChange", "ngModel", "value", "id"], [1, "form-check-label", "cx-dialog-label", 3, "for"], [1, "cx-dialog-suggested"]],
      template: function SuggestedAddressDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵlistener("esc", function SuggestedAddressDialogComponent_Template_div_esc_0_listener() {
            return ctx.closeModal("Escape clicked");
          });
          ɵɵtemplate(1, SuggestedAddressDialogComponent_div_1_Template, 44, 34, "div", 1);
          ɵɵpipe(2, "async");
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance();
          ɵɵproperty("ngIf", ɵɵpipeBind1(2, 2, ctx.data$));
        }
      },
      dependencies: [NgForOf, NgIf, DefaultValueAccessor, RadioControlValueAccessor, NgControlStatus, NgControlStatusGroup, NgModel, NgForm, IconComponent, FocusDirective, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SuggestedAddressDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-suggested-addresses-dialog",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div
  class="cx-suggested-addresses-dialog"
  role="dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal('Escape clicked')"
  aria-labelledby="dialogTitle"
>
  <div *ngIf="data$ | async as data" class="cx-suggested-addresses-container">
    <div class="cx-suggested-addresses-header cx-modal-header">
      <h3
        *cxFeature="'a11yDialogsHeading'"
        id="dialogTitle"
        class="cx-suggested-addresses-title"
      >
        {{ 'addressSuggestion.verifyYourAddress' | cxTranslate }}
      </h3>
      <div
        *cxFeature="'!a11yDialogsHeading'"
        id="dialogTitle"
        class="cx-suggested-addresses-title"
      >
        {{ 'addressSuggestion.verifyYourAddress' | cxTranslate }}
      </div>
      <button
        type="button"
        class="close"
        title="{{ 'common.close' | cxTranslate }}"
        [attr.aria-label]="'common.close' | cxTranslate"
        (click)="closeModal('Cross click')"
      >
        <span aria-hidden="true">
          <cx-icon [type]="iconTypes.CLOSE"></cx-icon>
        </span>
      </button>
    </div>
    <div class="cx-suggested-addresses-body" ngForm>
      <div class="cx-dialog-info">
        <p>
          {{ 'addressSuggestion.ensureAccuracySuggestChange' | cxTranslate }}
          {{ 'addressSuggestion.chooseAddressToUse' | cxTranslate }}
        </p>
      </div>

      <div class="cx-dialog-options">
        <div
          class="form-check"
          *ngFor="
            let suggestedAddress of data.suggestedAddresses;
            let i = index
          "
        >
          <input
            class="form-check-input"
            type="radio"
            name="selectedAddress"
            [(ngModel)]="selectedAddress"
            [value]="suggestedAddress"
            [id]="'suggested-addresses--suggested-' + i"
          />
          <label
            class="form-check-label cx-dialog-label"
            [for]="'suggested-addresses--suggested-' + i"
          >
            {{ 'addressSuggestion.suggestedAddress' | cxTranslate }}
            {{ data.suggestedAddresses.length > 1 ? i + 1 : null }}
          </label>
          <div class="cx-dialog-suggested">
            <div class="cx-card-container">
              <div class="cx-card-label">{{ suggestedAddress?.firstName }}</div>
              <div class="cx-card-label">{{ suggestedAddress?.lastName }}</div>
              <div class="cx-card-label">{{ suggestedAddress?.line1 }}</div>
              <div class="cx-card-label">
                <span>{{ suggestedAddress?.line2 }}</span>
              </div>
              <div class="cx-card-label">{{ suggestedAddress?.town }}</div>
              <div class="cx-card-label">
                {{ suggestedAddress?.region?.isocode }}
              </div>
              <div class="cx-card-label">
                {{ suggestedAddress?.postalCode }}
              </div>
            </div>
          </div>
        </div>
        <div class="form-check">
          <input
            class="form-check-input"
            type="radio"
            name="selectedAddress"
            [(ngModel)]="selectedAddress"
            [value]="data.enteredAddress"
            id="suggested-addresses--entered"
          />
          <label
            class="form-check-label cx-dialog-label"
            for="suggested-addresses--entered"
          >
            {{ 'addressSuggestion.enteredAddress' | cxTranslate }}
          </label>
          <div class="cx-dialog-entered">
            <div class="cx-card-container">
              <div class="cx-card-label">
                {{ data.enteredAddress?.firstName }}
                {{ data.enteredAddress?.lastName }}
              </div>
              <div class="cx-card-label">{{ data.enteredAddress?.line1 }}</div>
              <div class="cx-card-label">
                <span>{{ data.enteredAddress?.line2 }}</span>
              </div>
              <div class="cx-card-label">
                {{ data.enteredAddress?.town }}
                {{ data.enteredAddress?.region?.isocode }}
              </div>
              <div class="cx-card-label">
                {{ data.enteredAddress?.postalCode }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="cx-suggested-addresses-footer cx-modal-footer">
      <div class="row">
        <div class="cx-dialog-actions col-sm-12 col-md-12 col-lg-6 offset-lg-6">
          <button
            class="btn btn-secondary cx-dialog-buttons"
            (click)="closeModal('Edit address')"
          >
            {{ 'addressSuggestion.editAddress' | cxTranslate }}
          </button>
          <button
            cxAutoFocus
            class="btn btn-primary cx-dialog-buttons"
            (click)="closeModal(selectedAddress)"
          >
            {{ 'addressSuggestion.saveAddress' | cxTranslate }}
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: ElementRef
  }], {
    handleClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var AddressFormModule = class _AddressFormModule {
  static {
    this.ɵfac = function AddressFormModule_Factory(t) {
      return new (t || _AddressFormModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AddressFormModule,
      declarations: [AddressFormComponent, SuggestedAddressDialogComponent],
      imports: [NgSelectA11yModule, CommonModule, ReactiveFormsModule, FormsModule, RouterModule, NgSelectModule, IconModule, I18nModule, FormErrorsModule, KeyboardFocusModule, FeaturesConfigModule],
      exports: [AddressFormComponent, SuggestedAddressDialogComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [NgSelectA11yModule, CommonModule, ReactiveFormsModule, FormsModule, RouterModule, NgSelectModule, IconModule, I18nModule, FormErrorsModule, KeyboardFocusModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AddressFormModule, [{
    type: NgModule,
    args: [{
      imports: [NgSelectA11yModule, CommonModule, ReactiveFormsModule, FormsModule, RouterModule, NgSelectModule, IconModule, I18nModule, FormErrorsModule, KeyboardFocusModule, FeaturesConfigModule],
      declarations: [AddressFormComponent, SuggestedAddressDialogComponent],
      exports: [AddressFormComponent, SuggestedAddressDialogComponent]
    }]
  }], null, null);
})();
var defaultSuggestedAddressesDialogLayoutConfig = {
  launch: {
    SUGGESTED_ADDRESSES: {
      inlineRoot: true,
      component: SuggestedAddressDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var AddressBookModule = class _AddressBookModule {
  static {
    this.ɵfac = function AddressBookModule_Factory(t) {
      return new (t || _AddressBookModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AddressBookModule,
      declarations: [AddressBookComponent],
      imports: [CommonModule, CardModule, AddressFormModule, SpinnerModule, I18nModule, FeaturesConfigModule],
      exports: [AddressBookComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          AccountAddressBookComponent: {
            component: AddressBookComponent,
            guards: [AuthGuard]
          }
        }
      }), provideDefaultConfig(defaultSuggestedAddressesDialogLayoutConfig), UserAddressService],
      imports: [CommonModule, CardModule, AddressFormModule, SpinnerModule, I18nModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AddressBookModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, CardModule, AddressFormModule, SpinnerModule, I18nModule, FeaturesConfigModule],
      declarations: [AddressBookComponent],
      exports: [AddressBookComponent],
      providers: [provideDefaultConfig({
        cmsComponents: {
          AccountAddressBookComponent: {
            component: AddressBookComponent,
            guards: [AuthGuard]
          }
        }
      }), provideDefaultConfig(defaultSuggestedAddressesDialogLayoutConfig), UserAddressService]
    }]
  }], null, null);
})();
var UserProfileComponentsModule = class _UserProfileComponentsModule {
  static {
    this.ɵfac = function UserProfileComponentsModule_Factory(t) {
      return new (t || _UserProfileComponentsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UserProfileComponentsModule,
      imports: [RegisterComponentModule, UpdateProfileModule, UpdateEmailModule, UpdatePasswordModule, ForgotPasswordModule, ResetPasswordModule, CloseAccountModule, AddressBookModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [RegisterComponentModule, UpdateProfileModule, UpdateEmailModule, UpdatePasswordModule, ForgotPasswordModule, ResetPasswordModule, CloseAccountModule, AddressBookModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserProfileComponentsModule, [{
    type: NgModule,
    args: [{
      imports: [RegisterComponentModule, UpdateProfileModule, UpdateEmailModule, UpdatePasswordModule, ForgotPasswordModule, ResetPasswordModule, CloseAccountModule, AddressBookModule]
    }]
  }], null, null);
})();

export {
  AddressFormComponent,
  AddressFormModule,
  UserProfileComponentsModule
};
//# sourceMappingURL=chunk-AGFFIPIK.js.map
