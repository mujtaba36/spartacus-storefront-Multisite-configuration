import {
  SavedCartFacade
} from "./chunk-PCLFPLW5.js";
import {
  AsmAdapter,
  AsmCoreModule,
  AsmService,
  CUSTOMER_LISTS_NORMALIZER,
  CUSTOMER_SEARCH_PAGE_NORMALIZER
} from "./chunk-ZQAKWWSH.js";
import {
  ActiveCartFacade,
  MultiCartFacade
} from "./chunk-DJP5CYBU.js";
import {
  AsmDialogActionType
} from "./chunk-X2YZRGIK.js";
import {
  ASM_ENABLED_LOCAL_STORAGE_KEY,
  AsmBindCartFacade,
  AsmConfig,
  AsmCreateCustomerFacade,
  AsmCustomerListFacade,
  AsmDeepLinkService,
  AsmEnablerService,
  CsAgentAuthService,
  CustomerListColumnActionType
} from "./chunk-GRW6AQYT.js";
import {
  UserAccountFacade
} from "./chunk-SPYT22X6.js";
import {
  BREAKPOINT,
  BreakpointService,
  CustomFormValidators,
  DIALOG_TYPE,
  DefaultValueAccessor,
  DirectionMode,
  DirectionService,
  FocusDirective,
  FormBuilder,
  FormControl,
  FormControlDirective,
  FormControlName,
  FormErrorsComponent,
  FormErrorsModule,
  FormGroupDirective,
  FormsModule,
  ICON_TYPE,
  IconComponent,
  IconModule,
  KeyboardFocusModule,
  LaunchDialogService,
  MessageComponent,
  MessageComponentModule,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  NgSelectA11yDirective,
  NgSelectA11yModule,
  NgSelectComponent,
  NgSelectModule,
  PaginationComponent,
  PaginationModule,
  PasswordVisibilityToggleDirective,
  PasswordVisibilityToggleModule,
  ReactiveFormsModule,
  RequiredValidator,
  SortingComponent,
  SortingModule,
  SpinnerComponent,
  SpinnerModule,
  UntypedFormBuilder,
  UntypedFormControl,
  Validators,
  ɵNgNoValidate
} from "./chunk-FIMZ5LIU.js";
import {
  AuthService,
  BaseSiteService,
  ConverterService,
  FeatureConfigService,
  FeatureDirective,
  FeatureModulesService,
  FeaturesConfigModule,
  GlobalMessageService,
  GlobalMessageType,
  I18nModule,
  InterceptorUtil,
  LoggerService,
  OCC_CART_ID_CURRENT,
  OccConfig,
  OccEndpointsService,
  RoutingService,
  TranslatePipe,
  TranslationService,
  USE_CUSTOMER_SUPPORT_AGENT_TOKEN,
  UserIdService,
  WindowRef,
  normalizeHttpError,
  provideDefaultConfig,
  useFeatureStyles
} from "./chunk-CJWHFW34.js";
import "./chunk-OIYGDMWQ.js";
import "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import {
  AsyncPipe,
  CommonModule,
  HttpClient,
  HttpHeaders,
  HttpParams,
  NgClass,
  NgForOf,
  NgIf,
  NgTemplateOutlet
} from "./chunk-XWT3SXR6.js";
import {
  BehaviorSubject,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EMPTY,
  EventEmitter,
  HostBinding,
  Injectable,
  Input,
  NEVER,
  NgModule,
  Output,
  Pipe,
  Subscription,
  ViewChild,
  ViewChildren,
  catchError,
  combineLatest,
  concatMap,
  debounceTime,
  defer,
  distinctUntilChanged,
  filter,
  finalize,
  first,
  iif,
  inject,
  map,
  of,
  setClassMetadata,
  shareReplay,
  switchMap,
  take,
  tap,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdefinePipe,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵresolveDocument,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-JMCPXHNJ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/asm/fesm2022/spartacus-asm-components.mjs
function AsmSaveCartDialogComponent_ng_container_7_cx_message_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 17);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function AsmSaveCartDialogComponent_ng_container_7_cx_message_2_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.closeDialogAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "asm.saveCart.dialog.saveInfo"))("type", ctx_r2.globalMessageType.MSG_TYPE_INFO);
  }
}
function AsmSaveCartDialogComponent_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 15);
    ɵɵtemplate(2, AsmSaveCartDialogComponent_ng_container_7_cx_message_2_Template, 2, 4, "cx-message", 16);
    ɵɵpipe(3, "async");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(3, 1, ctx_r2.showDialogAlert$));
  }
}
function AsmSaveCartDialogComponent_ng_template_8_cx_message_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 17);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function AsmSaveCartDialogComponent_ng_template_8_cx_message_1_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.closeDialogAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "asm.saveCart.dialog.disableInfo"))("type", ctx_r2.globalMessageType.MSG_TYPE_WARNING);
  }
}
function AsmSaveCartDialogComponent_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵtemplate(1, AsmSaveCartDialogComponent_ng_template_8_cx_message_1_Template, 2, 4, "cx-message", 16);
    ɵɵpipe(2, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 1, ctx_r2.showDialogAlert$));
  }
}
function AsmSaveCartDialogComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 9);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.saveCart.dialog.row.qtyFull"), " ");
  }
}
function AsmSaveCartDialogComponent_div_19_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 9);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.saveCart.dialog.row.qty"), " ");
  }
}
var _c0 = ["bindToCart"];
var _c1 = ["saveInactiveCart"];
var _c2 = (a0, a1) => ({
  "cx-asm-assignCart": a0,
  "cx-asm-assignCart-input-show-no-button": a1
});
function AsmBindCartComponent_button_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 9);
    ɵɵpipe(1, "cxTranslate");
    ɵɵpipe(2, "cxTranslate");
    ɵɵlistener("click", function AsmBindCartComponent_button_10_Template_button_click_0_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r3 = ɵɵnextContext();
      return ɵɵresetView(ctx_r3.clearText());
    });
    ɵɵelement(3, "cx-icon", 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵclassProp("visible", (ctx_r3.cartId.value == null ? null : ctx_r3.cartId.value.length) > 0);
    ɵɵattribute("title", ɵɵpipeBind1(1, 4, "asm.bindCart.resetCartId"))("aria-label", ɵɵpipeBind1(2, 6, "asm.bindCart.resetCartId"));
  }
}
function AsmBindCartComponent_button_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 11, 1);
    ɵɵpipe(2, "async");
    ɵɵpipe(3, "async");
    ɵɵpipe(4, "async");
    ɵɵlistener("click", function AsmBindCartComponent_button_11_Template_button_click_0_listener() {
      ɵɵrestoreView(_r5);
      const ctx_r3 = ɵɵnextContext();
      return ɵɵresetView(ctx_r3.bindCartToCustomer());
    });
    ɵɵelementStart(5, "span");
    ɵɵpipe(6, "async");
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(9, "cx-dot-spinner");
    ɵɵpipe(10, "async");
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵclassProp("cx-asm-active", ɵɵpipeBind1(2, 9, ctx_r3.valid$))("cx-bind-loading", ɵɵpipeBind1(3, 11, ctx_r3.loading$));
    ɵɵproperty("disabled", !ɵɵpipeBind1(4, 13, ctx_r3.valid$));
    ɵɵadvance(5);
    ɵɵattribute("aria-hidden", ɵɵpipeBind1(6, 15, ctx_r3.loading$));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(8, 17, "asm.bindCart.bindCartToCustomer"), " ");
    ɵɵadvance(2);
    ɵɵattribute("aria-hidden", !ɵɵpipeBind1(10, 19, ctx_r3.loading$))("aria-label", ɵɵpipeBind1(11, 21, "common.loading"));
  }
}
function AsmBindCartComponent_button_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 12, 2);
    ɵɵpipe(2, "async");
    ɵɵlistener("click", function AsmBindCartComponent_button_13_Template_button_click_0_listener() {
      ɵɵrestoreView(_r6);
      const ctx_r3 = ɵɵnextContext();
      return ɵɵresetView(ctx_r3.onSaveInactiveCart());
    });
    ɵɵelementStart(3, "span");
    ɵɵpipe(4, "async");
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(7, "cx-dot-spinner");
    ɵɵpipe(8, "async");
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵclassProp("cx-bind-loading", ɵɵpipeBind1(2, 6, ctx_r3.loading$));
    ɵɵadvance(3);
    ɵɵattribute("aria-hidden", ɵɵpipeBind1(4, 8, ctx_r3.loading$));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 10, "asm.saveCart.saveCartBtn"), " ");
    ɵɵadvance(2);
    ɵɵattribute("aria-hidden", !ɵɵpipeBind1(8, 12, ctx_r3.loading$))("aria-label", ɵɵpipeBind1(9, 14, "common.loading"));
  }
}
function AsmCreateCustomerFormComponent_cx_message_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 14);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function AsmCreateCustomerFormComponent_cx_message_10_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.closeDialogInfoAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "asm.createCustomerForm.createAccountAlert"))("type", ctx_r2.globalMessageType.MSG_TYPE_INFO);
  }
}
function AsmCreateCustomerFormComponent_ng_container_11_cx_message_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 14);
    ɵɵlistener("closeMessage", function AsmCreateCustomerFormComponent_ng_container_11_cx_message_1_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r4);
      const i_r5 = ɵɵnextContext().index;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.closeDialogBackendErroAlert(i_r5));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const errorMessage_r6 = ɵɵnextContext().$implicit;
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("text", errorMessage_r6)("type", ctx_r2.globalMessageType.MSG_TYPE_ERROR);
  }
}
function AsmCreateCustomerFormComponent_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, AsmCreateCustomerFormComponent_ng_container_11_cx_message_1_Template, 1, 2, "cx-message", 8);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const i_r5 = ctx.index;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.showDialogBackendErrorAlerts[i_r5]);
  }
}
function AsmCreateCustomerFormComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 15)(2, "label")(3, "span", 16);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(6, "input", 17);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelement(8, "cx-form-errors", 18);
    ɵɵelementEnd()();
    ɵɵelementStart(9, "div", 15)(10, "label")(11, "span", 16);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(14, "input", 19);
    ɵɵpipe(15, "cxTranslate");
    ɵɵelement(16, "cx-form-errors", 18);
    ɵɵelementEnd()();
    ɵɵelementStart(17, "div", 15)(18, "label")(19, "span", 16);
    ɵɵtext(20);
    ɵɵpipe(21, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(22, "input", 20);
    ɵɵpipe(23, "cxTranslate");
    ɵɵelement(24, "cx-form-errors", 18);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 9, "asm.createCustomerForm.firstName.label"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(7, 11, "asm.createCustomerForm.firstName.placeholder"));
    ɵɵadvance(2);
    ɵɵproperty("control", ctx_r2.registerForm.get("firstName"));
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(13, 13, "asm.createCustomerForm.lastName.label"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(15, 15, "asm.createCustomerForm.lastName.placeholder"));
    ɵɵadvance(2);
    ɵɵproperty("control", ctx_r2.registerForm.get("lastName"));
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(21, 17, "asm.createCustomerForm.emailAddress.label"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(23, 19, "asm.createCustomerForm.emailAddress.placeholder"));
    ɵɵadvance(2);
    ɵɵproperty("control", ctx_r2.registerForm.get("email"));
  }
}
function AsmCreateCustomerFormComponent_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 21);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
var _c3 = (a0) => ({
  label: a0
});
function CSAgentLoginFormComponent_form_0_cx_form_errors_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 9);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c3, ɵɵpipeBind1(1, 2, "asm.loginForm.userId.label")))("control", ctx_r1.csAgentLoginForm.get("userId"));
  }
}
function CSAgentLoginFormComponent_form_0_cx_form_errors_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 10);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.csAgentLoginForm.get("userId"));
  }
}
function CSAgentLoginFormComponent_form_0_cx_form_errors_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 9);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c3, ɵɵpipeBind1(1, 2, "asm.loginForm.password.label")))("control", ctx_r1.csAgentLoginForm.get("password"));
  }
}
function CSAgentLoginFormComponent_form_0_cx_form_errors_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 10);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.csAgentLoginForm.get("password"));
  }
}
function CSAgentLoginFormComponent_form_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "form", 2);
    ɵɵlistener("ngSubmit", function CSAgentLoginFormComponent_form_0_Template_form_ngSubmit_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵelementStart(1, "span", 3);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "label");
    ɵɵelement(5, "input", 4);
    ɵɵpipe(6, "cxTranslate");
    ɵɵtemplate(7, CSAgentLoginFormComponent_form_0_cx_form_errors_7_Template, 2, 6, "cx-form-errors", 5)(8, CSAgentLoginFormComponent_form_0_cx_form_errors_8_Template, 1, 1, "cx-form-errors", 6);
    ɵɵelementEnd();
    ɵɵelementStart(9, "span", 3);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(12, "label");
    ɵɵelement(13, "input", 7);
    ɵɵpipe(14, "cxTranslate");
    ɵɵtemplate(15, CSAgentLoginFormComponent_form_0_cx_form_errors_15_Template, 2, 6, "cx-form-errors", 5)(16, CSAgentLoginFormComponent_form_0_cx_form_errors_16_Template, 1, 1, "cx-form-errors", 6);
    ɵɵelementEnd();
    ɵɵelementStart(17, "button", 8);
    ɵɵtext(18);
    ɵɵpipe(19, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("formGroup", ctx_r1.csAgentLoginForm);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 10, "asm.loginForm.userId.label"), " ");
    ɵɵadvance(3);
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 12, "asm.loginForm.userId.label"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 14, "asm.loginForm.password.label"), " ");
    ɵɵadvance(3);
    ɵɵattribute("aria-label", ɵɵpipeBind1(14, 16, "asm.loginForm.password.label"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 18, "asm.loginForm.submit"), " ");
  }
}
function CSAgentLoginFormComponent_cx_dot_spinner_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-dot-spinner", 11);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loading"));
  }
}
var _c4 = ["resultList"];
var _c5 = ["searchTerm"];
var _c6 = ["searchOrder"];
var _c7 = ["createCustomerLink"];
var _c8 = ["searchResultItem"];
function CustomerSelectionComponent_form_0_div_9_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 15)(1, "div", 16)(2, "div", 17)(3, "span", 18);
    ɵɵelement(4, "cx-icon", 19);
    ɵɵelementEnd();
    ɵɵelementStart(5, "span", 20);
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(8, "span", 21, 3);
    ɵɵlistener("click", function CustomerSelectionComponent_form_0_div_9_div_2_Template_span_click_8_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.createCustomer());
    });
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    ɵɵadvance(6);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(7, 2, "asm.customerSearch.noCustomerMatchResult"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 4, "asm.customerSearch.createCustomer"), " ");
  }
}
function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 24, 4);
    ɵɵlistener("keydown.arrowup", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_arrowup_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusPreviousChild($event));
    })("keydown.arrowdown", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_arrowdown_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusNextChild($event));
    })("keydown.arrowright", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_arrowright_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.arrowleft", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_arrowleft_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.enter", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_enter_0_listener($event) {
      const result_r5 = ɵɵrestoreView(_r4).$implicit;
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.selectCustomerFromList($event, result_r5));
    })("keydown.escape", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_escape_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.closeResults($event));
    })("keydown.home", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_home_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.end", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_keydown_end_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("click", function CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template_button_click_0_listener($event) {
      const result_r5 = ɵɵrestoreView(_r4).$implicit;
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.selectCustomerFromList($event, result_r5));
    });
    ɵɵelementStart(2, "div", 25);
    ɵɵtext(3);
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 26)(5, "span");
    ɵɵtext(6);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const result_r5 = ctx.$implicit;
    const i_r6 = ctx.index;
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵclassProp("active", ctx_r1.activeFocusedButtonIndex === i_r6);
    ɵɵproperty("tabindex", ctx_r1.activeFocusedButtonIndex === i_r6 ? 0 : -1);
    ɵɵattribute("aria-selected", ctx_r1.activeFocusedButtonIndex === i_r6);
    ɵɵadvance(3);
    ɵɵtextInterpolate(result_r5.name);
    ɵɵadvance(3);
    ɵɵtextInterpolate(result_r5.uid);
  }
}
function CustomerSelectionComponent_form_0_div_9_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵtemplate(1, CustomerSelectionComponent_form_0_div_9_div_3_button_1_Template, 7, 6, "button", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const results_r7 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("ngForOf", results_r7.entries);
  }
}
function CustomerSelectionComponent_form_0_div_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", null, 2);
    ɵɵtemplate(2, CustomerSelectionComponent_form_0_div_9_div_2_Template, 12, 6, "div", 14)(3, CustomerSelectionComponent_form_0_div_9_div_3_Template, 2, 1, "div", 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const results_r7 = ctx.ngIf;
    ɵɵnextContext();
    const searchTerm_r8 = ɵɵreference(6);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isNoResultMessageInfoVisible(results_r7, ctx_r1.searchByCustomer, searchTerm_r8));
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.isSearchResultsVisible(results_r7, ctx_r1.searchByCustomer));
  }
}
function CustomerSelectionComponent_form_0_div_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵelement(1, "cx-dot-spinner", 27);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 1, "common.loading"));
  }
}
function CustomerSelectionComponent_form_0_div_20_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15)(1, "div", 16)(2, "div", 17)(3, "span", 18);
    ɵɵelement(4, "cx-icon", 19);
    ɵɵelementEnd();
    ɵɵelementStart(5, "span", 20);
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    ɵɵadvance(6);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 1, "asm.customerSearch.noOrderMatchResult"), " ");
  }
}
function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 24, 4);
    ɵɵlistener("keydown.arrowup", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_arrowup_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusPreviousChild($event));
    })("keydown.arrowdown", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_arrowdown_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusNextChild($event));
    })("keydown.arrowright", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_arrowright_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusOrderSearchInputText($event));
    })("keydown.arrowleft", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_arrowleft_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusOrderSearchInputText($event));
    })("keydown.enter", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_enter_0_listener($event) {
      const result_r10 = ɵɵrestoreView(_r9).$implicit;
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.selectCustomerFromList($event, result_r10));
    })("keydown.escape", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_escape_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.closeOrderSearchResults($event));
    })("keydown.home", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_home_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusOrderSearchInputText($event));
    })("keydown.end", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_keydown_end_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.focusOrderSearchInputText($event));
    })("click", function CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template_button_click_0_listener($event) {
      const result_r10 = ɵɵrestoreView(_r9).$implicit;
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.selectCustomerFromList($event, result_r10));
    });
    ɵɵelementStart(2, "div", 25);
    ɵɵtext(3);
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 26)(5, "span");
    ɵɵtext(6);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const result_r10 = ctx.$implicit;
    const i_r11 = ctx.index;
    ɵɵnextContext(3);
    const searchOrder_r12 = ɵɵreference(17);
    const ctx_r1 = ɵɵnextContext();
    ɵɵclassProp("active", ctx_r1.activeFocusedButtonIndex === i_r11);
    ɵɵproperty("tabindex", ctx_r1.activeFocusedButtonIndex === i_r11 ? 0 : -1);
    ɵɵattribute("aria-selected", ctx_r1.activeFocusedButtonIndex === i_r11);
    ɵɵadvance(3);
    ɵɵtextInterpolate(searchOrder_r12.value);
    ɵɵadvance(3);
    ɵɵtextInterpolate(result_r10.name);
  }
}
function CustomerSelectionComponent_form_0_div_20_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵtemplate(1, CustomerSelectionComponent_form_0_div_20_div_3_button_1_Template, 7, 6, "button", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const results_r13 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("ngForOf", results_r13.entries);
  }
}
function CustomerSelectionComponent_form_0_div_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", null, 2);
    ɵɵtemplate(2, CustomerSelectionComponent_form_0_div_20_div_2_Template, 8, 3, "div", 14)(3, CustomerSelectionComponent_form_0_div_20_div_3_Template, 2, 1, "div", 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const results_r13 = ctx.ngIf;
    ɵɵnextContext();
    const searchOrder_r12 = ɵɵreference(17);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isNoResultMessageInfoVisible(results_r13, ctx_r1.searchByOrder, searchOrder_r12));
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.isSearchResultsVisible(results_r13, ctx_r1.searchByOrder));
  }
}
function CustomerSelectionComponent_form_0_div_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵelement(1, "cx-dot-spinner", 27);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 1, "common.loading"));
  }
}
function CustomerSelectionComponent_form_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "form", 7);
    ɵɵlistener("ngSubmit", function CustomerSelectionComponent_form_0_Template_form_ngSubmit_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵelementStart(1, "span", 8);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "label")(5, "input", 9, 0);
    ɵɵpipe(7, "cxTranslate");
    ɵɵpipe(8, "cxTranslate");
    ɵɵlistener("keydown.arrowdown", function CustomerSelectionComponent_form_0_Template_input_keydown_arrowdown_5_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.focusFirstItem($event));
    })("keydown.end", function CustomerSelectionComponent_form_0_Template_input_keydown_end_5_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.setSelectionEnd($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(9, CustomerSelectionComponent_form_0_div_9_Template, 4, 2, "div", 10);
    ɵɵpipe(10, "async");
    ɵɵtemplate(11, CustomerSelectionComponent_form_0_div_11_Template, 3, 3, "div", 11);
    ɵɵelementEnd();
    ɵɵelementStart(12, "span", 8);
    ɵɵtext(13);
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(15, "label")(16, "input", 12, 1);
    ɵɵpipe(18, "cxTranslate");
    ɵɵpipe(19, "cxTranslate");
    ɵɵlistener("keydown.arrowdown", function CustomerSelectionComponent_form_0_Template_input_keydown_arrowdown_16_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.focusFirstItem($event));
    })("keydown.end", function CustomerSelectionComponent_form_0_Template_input_keydown_end_16_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.setOrderSearchSelectionEnd($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(20, CustomerSelectionComponent_form_0_div_20_Template, 4, 2, "div", 10);
    ɵɵpipe(21, "async");
    ɵɵtemplate(22, CustomerSelectionComponent_form_0_div_22_Template, 3, 3, "div", 11);
    ɵɵelementEnd();
    ɵɵelementStart(23, "button", 13);
    ɵɵtext(24);
    ɵɵpipe(25, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("formGroup", ctx_r1.customerSelectionForm);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 15, "asm.customerSearch.customer"));
    ɵɵadvance(3);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(7, 17, "asm.customerSearch.searchCustomer.label"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(8, 19, "asm.customerSearch.searchCustomer.label"));
    ɵɵadvance(4);
    ɵɵproperty("ngIf", ɵɵpipeBind1(10, 21, ctx_r1.searchResults));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isLoading && ctx_r1.searchByCustomer);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(14, 23, "asm.customerSearch.orderID"));
    ɵɵadvance(3);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(18, 25, "asm.customerSearch.searchOrder.label"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(19, 27, "asm.customerSearch.searchOrder.label"));
    ɵɵadvance(4);
    ɵɵproperty("ngIf", ɵɵpipeBind1(21, 29, ctx_r1.searchResults));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isLoading && ctx_r1.searchByOrder);
    ɵɵadvance();
    ɵɵclassProp("active", ctx_r1.selectedCustomer);
    ɵɵproperty("disabled", !ctx_r1.selectedCustomer);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(25, 31, "asm.customerSearch.submit"), " ");
  }
}
function CustomerSelectionComponent_div_1_cx_form_errors_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 31);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c3, ɵɵpipeBind1(1, 2, "asm.customerSearch.searchTerm.label")))("control", ctx_r1.customerSelectionForm.get("searchTerm"));
  }
}
function CustomerSelectionComponent_div_1_cx_form_errors_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 32);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("control", ctx_r1.customerSelectionForm.get("searchTerm"));
  }
}
function CustomerSelectionComponent_div_1_div_12_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 24, 4);
    ɵɵlistener("keydown.arrowup", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_arrowup_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusPreviousChild($event));
    })("keydown.arrowdown", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_arrowdown_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusNextChild($event));
    })("keydown.arrowright", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_arrowright_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.arrowleft", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_arrowleft_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.enter", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_enter_0_listener($event) {
      const result_r16 = ɵɵrestoreView(_r15).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.selectCustomerFromList($event, result_r16));
    })("keydown.escape", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_escape_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.closeResults($event));
    })("keydown.home", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_home_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.end", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_keydown_end_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("click", function CustomerSelectionComponent_div_1_div_12_button_2_Template_button_click_0_listener($event) {
      const result_r16 = ɵɵrestoreView(_r15).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.selectCustomerFromList($event, result_r16));
    });
    ɵɵelementStart(2, "span", 25);
    ɵɵtext(3);
    ɵɵelementEnd();
    ɵɵelementStart(4, "span", 26);
    ɵɵtext(5);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const result_r16 = ctx.$implicit;
    const i_r17 = ctx.index;
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵclassProp("active", ctx_r1.activeFocusedButtonIndex === i_r17);
    ɵɵproperty("tabindex", ctx_r1.activeFocusedButtonIndex === i_r17 ? 0 : -1);
    ɵɵattribute("aria-selected", ctx_r1.activeFocusedButtonIndex === i_r17);
    ɵɵadvance(3);
    ɵɵtextInterpolate(result_r16.name);
    ɵɵadvance(2);
    ɵɵtextInterpolate(result_r16.uid);
  }
}
function CustomerSelectionComponent_div_1_div_12_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 34, 4);
    ɵɵlistener("click", function CustomerSelectionComponent_div_1_div_12_button_3_Template_button_click_0_listener() {
      ɵɵrestoreView(_r18);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.createCustomer());
    })("keydown.escape", function CustomerSelectionComponent_div_1_div_12_button_3_Template_button_keydown_escape_0_listener($event) {
      ɵɵrestoreView(_r18);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.closeResults($event));
    })("keydown.arrowright", function CustomerSelectionComponent_div_1_div_12_button_3_Template_button_keydown_arrowright_0_listener($event) {
      ɵɵrestoreView(_r18);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.arrowleft", function CustomerSelectionComponent_div_1_div_12_button_3_Template_button_keydown_arrowleft_0_listener($event) {
      ɵɵrestoreView(_r18);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.home", function CustomerSelectionComponent_div_1_div_12_button_3_Template_button_keydown_home_0_listener($event) {
      ɵɵrestoreView(_r18);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    })("keydown.end", function CustomerSelectionComponent_div_1_div_12_button_3_Template_button_keydown_end_0_listener($event) {
      ɵɵrestoreView(_r18);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.focusInputText($event));
    });
    ɵɵelementStart(2, "span");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "span", 35, 3);
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵclassProp("active", ctx_r1.activeFocusedButtonIndex === 0);
    ɵɵattribute("aria-selected", ctx_r1.activeFocusedButtonIndex === 0);
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 5, "asm.customerSearch.noMatchResult"));
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(8, 7, "asm.customerSearch.createCustomer"));
  }
}
function CustomerSelectionComponent_div_1_div_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22, 2);
    ɵɵtemplate(2, CustomerSelectionComponent_div_1_div_12_button_2_Template, 6, 6, "button", 23)(3, CustomerSelectionComponent_div_1_div_12_button_3_Template, 9, 9, "button", 33);
    ɵɵpipe(4, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const results_r19 = ctx.ngIf;
    ɵɵnextContext();
    const searchTerm_r20 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", results_r19.entries);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ɵɵpipeBind1(4, 2, ctx_r1.searchResultsLoading$) && searchTerm_r20.value.length >= 3 && !!results_r19.entries && results_r19.entries.length <= 0);
  }
}
function CustomerSelectionComponent_div_1_div_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵelement(1, "cx-dot-spinner", 27);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 1, "common.loading"));
  }
}
function CustomerSelectionComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div")(1, "form", 7);
    ɵɵlistener("ngSubmit", function CustomerSelectionComponent_div_1_Template_form_ngSubmit_1_listener() {
      ɵɵrestoreView(_r14);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onSubmit());
    });
    ɵɵelementStart(2, "label")(3, "input", 9, 0);
    ɵɵpipe(5, "cxTranslate");
    ɵɵpipe(6, "cxTranslate");
    ɵɵlistener("keydown.arrowdown", function CustomerSelectionComponent_div_1_Template_input_keydown_arrowdown_3_listener($event) {
      ɵɵrestoreView(_r14);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.focusFirstItem($event));
    })("keydown.end", function CustomerSelectionComponent_div_1_Template_input_keydown_end_3_listener($event) {
      ɵɵrestoreView(_r14);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.setSelectionEnd($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(7, CustomerSelectionComponent_div_1_cx_form_errors_7_Template, 2, 6, "cx-form-errors", 28)(8, CustomerSelectionComponent_div_1_cx_form_errors_8_Template, 1, 1, "cx-form-errors", 29);
    ɵɵelementEnd();
    ɵɵelementStart(9, "button", 30);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵtemplate(12, CustomerSelectionComponent_div_1_div_12_Template, 5, 4, "div", 11);
    ɵɵpipe(13, "async");
    ɵɵtemplate(14, CustomerSelectionComponent_div_1_div_14_Template, 3, 3, "div", 11);
    ɵɵpipe(15, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("formGroup", ctx_r1.customerSelectionForm);
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(5, 10, "asm.customerSearch.searchTerm.label"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 12, "asm.customerSearch.searchTerm.label"));
    ɵɵadvance(4);
    ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
    ɵɵadvance();
    ɵɵclassProp("active", ctx_r1.selectedCustomer);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 14, "asm.customerSearch.submit"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(13, 16, ctx_r1.searchResults));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(15, 18, ctx_r1.searchResultsLoading$));
  }
}
var _c9 = ["asmCustomer360Launcher"];
function CustomerEmulationComponent_ng_container_0_button_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 7, 0);
    ɵɵlistener("click", function CustomerEmulationComponent_ng_container_0_button_7_Template_button_click_0_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.openAsmCustomer360());
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "asm.asmCustomer360ViewButton"), " ");
  }
}
function CustomerEmulationComponent_ng_container_0_button_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 7, 0);
    ɵɵlistener("click", function CustomerEmulationComponent_ng_container_0_button_8_Template_button_click_0_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.openAsmCustomer360());
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "asm.asmCustomer360Button"), " ");
  }
}
function CustomerEmulationComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2)(2, "label", 3);
    ɵɵtext(3);
    ɵɵelementEnd();
    ɵɵelementStart(4, "label", 4);
    ɵɵtext(5);
    ɵɵelementEnd()();
    ɵɵelement(6, "cx-asm-bind-cart");
    ɵɵtemplate(7, CustomerEmulationComponent_ng_container_0_button_7_Template, 4, 3, "button", 5)(8, CustomerEmulationComponent_ng_container_0_button_8_Template, 4, 3, "button", 5);
    ɵɵelementStart(9, "button", 6);
    ɵɵlistener("click", function CustomerEmulationComponent_ng_container_0_Template_button_click_9_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.logoutCustomer());
    });
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵtextInterpolate(ctx_r2.customer == null ? null : ctx_r2.customer.name);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r2.customer == null ? null : ctx_r2.customer.uid);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r2.isAsmCustomer360Configured && ctx_r2.customer && ctx_r2.isShowStyleChangesInASM);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.isAsmCustomer360Configured && ctx_r2.customer && !ctx_r2.isShowStyleChangesInASM);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 5, "asm.endSession"), " ");
  }
}
function AsmToggleUiComponent_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 3);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.toggleUi.collapse"), " ");
  }
}
function AsmToggleUiComponent_span_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 3);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.toggleUi.expand"), " ");
  }
}
var _c10 = ["customerListLink"];
var _c11 = ["addNewCustomerLink"];
function AsmMainUiComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 15)(1, "a", 16, 0);
    ɵɵlistener("click", function AsmMainUiComponent_div_15_Template_a_click_1_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.showCustomList());
    });
    ɵɵelement(3, "cx-icon", 10);
    ɵɵelementStart(4, "span");
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵproperty("type", ctx_r1.iconTypes.USER_FRIENDS);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(6, 2, "asm.customers"));
  }
}
function AsmMainUiComponent_cx_asm_session_timer_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-asm-session-timer");
  }
}
function AsmMainUiComponent_button_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 17);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("click", function AsmMainUiComponent_button_20_Template_button_click_0_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.hideUi());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "asm.hideUi"));
  }
}
function AsmMainUiComponent_button_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 18);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("click", function AsmMainUiComponent_button_23_Template_button_click_0_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.logout());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "asm.logout"));
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_customer_emulation_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-customer-emulation");
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 21);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_2_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.closeDialogConfirmationAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "asm.createCustomerSuccessfullyAlert"))("type", ctx_r1.globalMessageType.MSG_TYPE_CONFIRMATION);
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 21);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_3_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r6);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.closeDeeplinkCartInfoAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, ctx_r1.deeplinkCartAlertKey))("type", ctx_r1.globalMessageType.MSG_TYPE_INFO);
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-message", 21);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("closeMessage", function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_5_Template_cx_message_closeMessage_0_listener() {
      ɵɵrestoreView(_r7);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.closeCustomerEmulationInfoAlert());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵproperty("text", ɵɵpipeBind1(1, 2, "asm.startCustomerEmulationAlertInfo"))("type", ctx_r1.globalMessageType.MSG_TYPE_INFO);
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_customer_emulation_1_Template, 1, 0, "cx-customer-emulation", 12)(2, AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_2_Template, 2, 4, "cx-message", 20)(3, AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_3_Template, 2, 4, "cx-message", 20);
    ɵɵpipe(4, "async");
    ɵɵtemplate(5, AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_cx_message_5_Template, 2, 4, "cx-message", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const notCollapsed_r8 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", notCollapsed_r8);
    ɵɵadvance();
    ɵɵproperty("ngIf", notCollapsed_r8 && ctx_r1.showCreateCustomerSuccessfullyAlert);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(4, 4, ctx_r1.showDeeplinkCartInfoAlert$));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", notCollapsed_r8 && ctx_r1.showCustomerEmulationInfoAlert);
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_template_3_cx_customer_selection_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-customer-selection", 23);
    ɵɵlistener("submitEvent", function AsmMainUiComponent_ng_container_25_ng_container_1_ng_template_3_cx_customer_selection_0_Template_cx_customer_selection_submitEvent_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.startCustomerEmulationSession($event, $event.parameters));
    });
    ɵɵelementEnd();
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, AsmMainUiComponent_ng_container_25_ng_container_1_ng_template_3_cx_customer_selection_0_Template, 1, 0, "cx-customer-selection", 22);
  }
  if (rf & 2) {
    const notCollapsed_r8 = ɵɵnextContext(2).ngIf;
    ɵɵproperty("ngIf", notCollapsed_r8);
  }
}
function AsmMainUiComponent_ng_container_25_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, AsmMainUiComponent_ng_container_25_ng_container_1_ng_container_1_Template, 6, 6, "ng-container", 19);
    ɵɵpipe(2, "async");
    ɵɵtemplate(3, AsmMainUiComponent_ng_container_25_ng_container_1_ng_template_3_Template, 1, 1, "ng-template", null, 2, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const showCustomerSelection_r10 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 2, ctx_r1.customer$))("ngIfElse", showCustomerSelection_r10);
  }
}
function AsmMainUiComponent_ng_container_25_ng_template_3_cx_csagent_login_form_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-csagent-login-form", 25);
    ɵɵpipe(1, "async");
    ɵɵlistener("submitEvent", function AsmMainUiComponent_ng_container_25_ng_template_3_cx_csagent_login_form_0_Template_cx_csagent_login_form_submitEvent_0_listener($event) {
      ɵɵrestoreView(_r11);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.loginCustomerSupportAgent($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵproperty("csAgentTokenLoading", ɵɵpipeBind1(1, 1, ctx_r1.csAgentTokenLoading$));
  }
}
function AsmMainUiComponent_ng_container_25_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, AsmMainUiComponent_ng_container_25_ng_template_3_cx_csagent_login_form_0_Template, 2, 3, "cx-csagent-login-form", 24);
  }
  if (rf & 2) {
    const notCollapsed_r8 = ɵɵnextContext().ngIf;
    ɵɵproperty("ngIf", notCollapsed_r8);
  }
}
function AsmMainUiComponent_ng_container_25_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, AsmMainUiComponent_ng_container_25_ng_container_1_Template, 5, 4, "ng-container", 19);
    ɵɵpipe(2, "async");
    ɵɵtemplate(3, AsmMainUiComponent_ng_container_25_ng_template_3_Template, 1, 1, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const showLoginForm_r12 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 2, ctx_r1.customerSupportAgentLoggedIn$))("ngIfElse", showLoginForm_r12);
  }
}
var _c12 = (a0, a1) => ({
  customerA: a0,
  customerB: a1
});
var _c13 = (a0) => ({
  customerListsPage: a0
});
var _c14 = (a0) => ({
  customerSearchPage: a0
});
var _c15 = (a0, a1) => ({
  customerEntry: a0,
  column: a1,
  showHeader: false
});
var _c16 = (a0, a1) => ({
  customerEntry: a0,
  column: a1,
  showHeader: true
});
var _c17 = (a0, a1) => ({
  column: a0,
  customerEntry: a1
});
var _c18 = (a0) => ({
  count: a0
});
var _c19 = (a0) => ({
  ariaLabel: a0,
  ariaControls: "asm-cusomer-list-table"
});
function CustomerListComponent_10_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_10_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_11_4_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_11_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_11_4_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_11_5_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_11_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_11_5_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_11_9_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_11_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_11_9_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_11_10_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_11_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_11_10_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 24);
    ɵɵpipe(1, "async");
    ɵɵelementStart(2, "div", 25);
    ɵɵpipe(3, "async");
    ɵɵtemplate(4, CustomerListComponent_div_11_4_Template, 1, 0, null, 26)(5, CustomerListComponent_div_11_5_Template, 1, 0, null, 26);
    ɵɵpipe(6, "async");
    ɵɵelementEnd();
    ɵɵelementStart(7, "div", 27);
    ɵɵpipe(8, "async");
    ɵɵtemplate(9, CustomerListComponent_div_11_9_Template, 1, 0, null, 14)(10, CustomerListComponent_div_11_10_Template, 1, 0, null, 14);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const customerListsPage_r2 = ctx.ngIf;
    const ctx_r2 = ɵɵnextContext();
    const search_r4 = ɵɵreference(35);
    const total_r5 = ɵɵreference(37);
    const sort_r6 = ɵɵreference(39);
    const groupSelector_r7 = ɵɵreference(43);
    ɵɵclassProp("tablet-mobile", ɵɵpipeBind1(1, 12, ctx_r2.breakpoint$) !== ctx_r2.BREAKPOINT.md);
    ɵɵadvance(2);
    ɵɵclassProp("mobile", ɵɵpipeBind1(3, 14, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.xs);
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", groupSelector_r7)("ngTemplateOutletContext", ɵɵpureFunction1(20, _c13, customerListsPage_r2));
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", total_r5)("ngTemplateOutletContext", ɵɵpureFunction1(22, _c14, ɵɵpipeBind1(6, 16, ctx_r2.customerSearchPage$)));
    ɵɵadvance(2);
    ɵɵclassProp("mobile", ɵɵpipeBind1(8, 18, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.xs);
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", sort_r6);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", search_r4);
  }
}
function CustomerListComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 28);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.customerList.noLists"), " ");
  }
}
function CustomerListComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 28);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.customerList.listsError"), " ");
  }
}
function CustomerListComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 28);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "generalErrors.pageFailure"), " ");
  }
}
function CustomerListComponent_cx_spinner_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner");
  }
}
function CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.customerList.tableHeader.customerName"), " ");
  }
}
function CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.customerList.tableHeader.emailId"), " ");
  }
}
function CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const column_r8 = ɵɵnextContext(2).$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, column_r8.headerLocalizationKey), " ");
  }
}
function CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_ng_container_1_Template, 3, 3, "ng-container", 20)(2, CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_ng_container_2_Template, 3, 3, "ng-container", 20)(3, CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_ng_container_3_Template, 3, 3, "ng-container", 20);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const column_r8 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵproperty("ngIf", column_r8.headerLocalizationKey === "asm.customerList.tableHeader.customer");
    ɵɵadvance();
    ɵɵproperty("ngIf", column_r8.headerLocalizationKey === "asm.customerList.tableHeader.email");
    ɵɵadvance();
    ɵɵproperty("ngIf", column_r8.headerLocalizationKey !== "asm.customerList.tableHeader.customer" && column_r8.headerLocalizationKey !== "asm.customerList.tableHeader.email");
  }
}
function CustomerListComponent_div_22_table_1_thead_4_th_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "th", 36);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_thead_4_th_2_span_1_Template, 4, 3, "span", 20);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const column_r8 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("ngIf", column_r8.headerLocalizationKey && column_r8.headerLocalizationKey !== "hideHeaders");
  }
}
function CustomerListComponent_div_22_table_1_thead_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead")(1, "tr", 34);
    ɵɵtemplate(2, CustomerListComponent_div_22_table_1_thead_4_th_2_Template, 2, 1, "th", 35);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r2.customerListConfig == null ? null : ctx_r2.customerListConfig.columns);
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_1_td_1_1_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_1_td_1_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_22_table_1_tr_7_ng_container_1_td_1_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_1_td_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 39);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_1_td_1_1_Template, 1, 0, null, 26);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const column_r9 = ctx.$implicit;
    const customerEntry_r10 = ɵɵnextContext(2).$implicit;
    ɵɵnextContext(3);
    const cell_r11 = ɵɵreference(31);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", cell_r11)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c15, customerEntry_r10, column_r9));
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_1_td_1_Template, 2, 5, "td", 38);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r2.customerListConfig == null ? null : ctx_r2.customerListConfig.columns);
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_ng_container_1_1_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_ng_container_1_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_ng_container_1_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_ng_container_1_1_Template, 1, 0, null, 26);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const column_r12 = ɵɵnextContext().$implicit;
    const customerEntry_r10 = ɵɵnextContext(2).$implicit;
    ɵɵnextContext(3);
    const cell_r11 = ɵɵreference(31);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", cell_r11)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c16, customerEntry_r10, column_r12));
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_ng_container_1_Template, 2, 5, "ng-container", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const even_r13 = ctx.even;
    ɵɵadvance();
    ɵɵproperty("ngIf", even_r13);
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_ng_container_1_1_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_ng_container_1_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_ng_container_1_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_ng_container_1_1_Template, 1, 0, null, 26);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const column_r14 = ɵɵnextContext().$implicit;
    const customerEntry_r10 = ɵɵnextContext(2).$implicit;
    ɵɵnextContext(3);
    const cell_r11 = ɵɵreference(31);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", cell_r11)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c16, customerEntry_r10, column_r14));
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_ng_container_1_Template, 2, 5, "ng-container", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const odd_r15 = ctx.odd;
    ɵɵadvance();
    ɵɵproperty("ngIf", odd_r15);
  }
}
function CustomerListComponent_div_22_table_1_tr_7_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "td", 40);
    ɵɵtemplate(2, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_2_Template, 2, 1, "ng-container", 41);
    ɵɵelementEnd();
    ɵɵelementStart(3, "td", 40);
    ɵɵtemplate(4, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_ng_container_4_Template, 2, 1, "ng-container", 41);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(4);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r2.customerListConfig == null ? null : ctx_r2.customerListConfig.columns);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r2.customerListConfig == null ? null : ctx_r2.customerListConfig.columns);
  }
}
function CustomerListComponent_div_22_table_1_tr_7_td_5_ng_container_1_1_ng_template_0_Template(rf, ctx) {
}
function CustomerListComponent_div_22_table_1_tr_7_td_5_ng_container_1_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_div_22_table_1_tr_7_td_5_ng_container_1_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CustomerListComponent_div_22_table_1_tr_7_td_5_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_td_5_ng_container_1_1_Template, 1, 0, null, 26);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const column_r16 = ctx.$implicit;
    const customerEntry_r10 = ɵɵnextContext(2).$implicit;
    ɵɵnextContext(3);
    const cell_r11 = ɵɵreference(31);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", cell_r11)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c16, customerEntry_r10, column_r16));
  }
}
function CustomerListComponent_div_22_table_1_tr_7_td_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 40);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_td_5_ng_container_1_Template, 2, 5, "ng-container", 41);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r2.customerListConfig == null ? null : ctx_r2.customerListConfig.columns);
  }
}
function CustomerListComponent_div_22_table_1_tr_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tr", 34);
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_tr_7_ng_container_1_Template, 2, 1, "ng-container", 20);
    ɵɵpipe(2, "async");
    ɵɵtemplate(3, CustomerListComponent_div_22_table_1_tr_7_ng_container_3_Template, 5, 2, "ng-container", 20);
    ɵɵpipe(4, "async");
    ɵɵtemplate(5, CustomerListComponent_div_22_table_1_tr_7_td_5_Template, 2, 1, "td", 37);
    ɵɵpipe(6, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 3, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.md);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(4, 5, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.sm);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(6, 7, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.xs);
  }
}
function CustomerListComponent_div_22_table_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "table", 31)(1, "caption", 32);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(4, CustomerListComponent_div_22_table_1_thead_4_Template, 3, 1, "thead", 20);
    ɵɵpipe(5, "async");
    ɵɵelementStart(6, "tbody");
    ɵɵtemplate(7, CustomerListComponent_div_22_table_1_tr_7_Template, 7, 9, "tr", 33);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const customerSearchPage_r17 = ɵɵnextContext().ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 3, "asm.customerList.title"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(5, 5, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.md);
    ɵɵadvance(3);
    ɵɵproperty("ngForOf", customerSearchPage_r17 == null ? null : customerSearchPage_r17.entries);
  }
}
function CustomerListComponent_div_22_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 42);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.customerList.noCustomers"), " ");
  }
}
function CustomerListComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, CustomerListComponent_div_22_table_1_Template, 8, 7, "table", 29)(2, CustomerListComponent_div_22_div_2_Template, 3, 3, "div", 30);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const customerSearchPage_r17 = ctx.ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.loaded);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(customerSearchPage_r17 == null ? null : customerSearchPage_r17.entries.length));
  }
}
function CustomerListComponent_div_24_div_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div")(1, "cx-pagination", 44);
    ɵɵlistener("viewPageEvent", function CustomerListComponent_div_24_div_4_Template_cx_pagination_viewPageEvent_1_listener($event) {
      ɵɵrestoreView(_r18);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.changePage($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const customerSearchPage_r19 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("pagination", customerSearchPage_r19.pagination);
  }
}
function CustomerListComponent_div_24_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 43);
    ɵɵpipe(1, "async");
    ɵɵelementStart(2, "div", 27);
    ɵɵpipe(3, "async");
    ɵɵtemplate(4, CustomerListComponent_div_24_div_4_Template, 2, 1, "div", 20);
    ɵɵpipe(5, "async");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassProp("asm-mobile-pagination", ɵɵpipeBind1(1, 5, ctx_r2.breakpoint$) !== ctx_r2.BREAKPOINT.md);
    ɵɵadvance(2);
    ɵɵclassProp("mobile", ɵɵpipeBind1(3, 7, ctx_r2.breakpoint$) === ctx_r2.BREAKPOINT.xs);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(5, 9, ctx_r2.customerSearchPage$));
  }
}
function CustomerListComponent_ng_template_30_div_0_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 50);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const column_r20 = ɵɵnextContext(2).column;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, column_r20.headerLocalizationKey), " ");
  }
}
function CustomerListComponent_ng_template_30_div_0_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CustomerListComponent_ng_template_30_div_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CustomerListComponent_ng_template_30_div_0_ng_container_2_ng_container_1_Template, 1, 0, "ng-container", 26);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r20 = ɵɵnextContext(2);
    const customerEntry_r22 = ctx_r20.customerEntry;
    const column_r20 = ctx_r20.column;
    ɵɵnextContext();
    const cellContent_r23 = ɵɵreference(33);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", cellContent_r23)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c17, column_r20, customerEntry_r22));
  }
}
function CustomerListComponent_ng_template_30_div_0_div_3_img_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "img", 54);
    ɵɵpipe(1, "cxTranslate");
    ɵɵpipe(2, "cxTranslate");
  }
  if (rf & 2) {
    const customerEntry_r22 = ɵɵnextContext(3).customerEntry;
    const ctx_r2 = ɵɵnextContext();
    ɵɵpropertyInterpolate("alt", ɵɵpipeBind1(1, 3, "asm.mainLogoLabel"));
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(2, 5, "asm.mainLogoLabel"));
    ɵɵattribute("src", (ctx_r2.occConfig == null ? null : ctx_r2.occConfig.backend == null ? null : ctx_r2.occConfig.backend.occ == null ? null : ctx_r2.occConfig.backend.occ.baseUrl) + (customerEntry_r22 == null ? null : customerEntry_r22.userAvatar == null ? null : customerEntry_r22.userAvatar.url), ɵɵsanitizeUrl);
  }
}
function CustomerListComponent_ng_template_30_div_0_div_3_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 55);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const customerEntry_r22 = ɵɵnextContext(3).customerEntry;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r2.getBadgeText(customerEntry_r22), " ");
  }
}
function CustomerListComponent_ng_template_30_div_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 51);
    ɵɵtemplate(1, CustomerListComponent_ng_template_30_div_0_div_3_img_1_Template, 3, 7, "img", 52)(2, CustomerListComponent_ng_template_30_div_0_div_3_div_2_Template, 2, 1, "div", 53);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const customerEntry_r22 = ɵɵnextContext(2).customerEntry;
    ɵɵadvance();
    ɵɵproperty("ngIf", customerEntry_r22 == null ? null : customerEntry_r22.userAvatar == null ? null : customerEntry_r22.userAvatar.url);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(customerEntry_r22 == null ? null : customerEntry_r22.userAvatar == null ? null : customerEntry_r22.userAvatar.url));
  }
}
function CustomerListComponent_ng_template_30_div_0_button_4_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CustomerListComponent_ng_template_30_div_0_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 56);
    ɵɵpipe(1, "cxTranslate");
    ɵɵpipe(2, "cxTranslate");
    ɵɵlistener("click", function CustomerListComponent_ng_template_30_div_0_button_4_Template_button_click_0_listener() {
      ɵɵrestoreView(_r24);
      const ctx_r20 = ɵɵnextContext(2);
      const customerEntry_r22 = ctx_r20.customerEntry;
      const column_r20 = ctx_r20.column;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.startColumnAction(customerEntry_r22, column_r20.actionType));
    });
    ɵɵtemplate(3, CustomerListComponent_ng_template_30_div_0_button_4_ng_container_3_Template, 1, 0, "ng-container", 26);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_17_0;
    let tmp_18_0;
    const ctx_r20 = ɵɵnextContext(2);
    const customerEntry_r22 = ctx_r20.customerEntry;
    const column_r20 = ctx_r20.column;
    const ctx_r2 = ɵɵnextContext();
    const cellContent_r23 = ɵɵreference(33);
    ɵɵclassMap((column_r20.actionType === "ACTIVE_CART" ? "cx-cart " : "") + (column_r20.actionType !== "START_SESSION" ? "cx-action-disable" : ""));
    ɵɵproperty("disabled", ctx_r2.isRequired(customerEntry_r22, column_r20.actionType));
    ɵɵattribute("title", column_r20.icon ? ɵɵpipeBind1(1, 7, (tmp_17_0 = column_r20.icon.captionLocalizationKey) !== null && tmp_17_0 !== void 0 ? tmp_17_0 : column_r20.headerLocalizationKey) : void 0)("aria-label", column_r20.icon ? ɵɵpipeBind1(2, 9, (tmp_18_0 = column_r20.icon.captionLocalizationKey) !== null && tmp_18_0 !== void 0 ? tmp_18_0 : column_r20.headerLocalizationKey) : void 0);
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", cellContent_r23)("ngTemplateOutletContext", ɵɵpureFunction2(11, _c17, column_r20, customerEntry_r22));
  }
}
function CustomerListComponent_ng_template_30_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 46);
    ɵɵtemplate(1, CustomerListComponent_ng_template_30_div_0_span_1_Template, 3, 3, "span", 47)(2, CustomerListComponent_ng_template_30_div_0_ng_container_2_Template, 2, 5, "ng-container", 20)(3, CustomerListComponent_ng_template_30_div_0_div_3_Template, 3, 2, "div", 48)(4, CustomerListComponent_ng_template_30_div_0_button_4_Template, 4, 14, "button", 49);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r20 = ɵɵnextContext();
    const column_r20 = ctx_r20.column;
    const showHeader_r25 = ctx_r20.showHeader;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", showHeader_r25);
    ɵɵadvance();
    ɵɵproperty("ngIf", !column_r20.actionType);
    ɵɵadvance();
    ɵɵproperty("ngIf", (ctx_r2.customerListConfig == null ? null : ctx_r2.customerListConfig.showAvatar) && (column_r20 == null ? null : column_r20.actionType) === (ctx_r2.customerListColumnActionType == null ? null : ctx_r2.customerListColumnActionType.START_SESSION));
    ɵɵadvance();
    ɵɵproperty("ngIf", column_r20.actionType);
  }
}
function CustomerListComponent_ng_template_30_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_ng_template_30_div_0_Template, 5, 4, "div", 45);
  }
  if (rf & 2) {
    const column_r20 = ctx.column;
    ɵɵproperty("ngIf", column_r20.headerLocalizationKey !== "hideHeaders");
  }
}
function CustomerListComponent_ng_template_32_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r25 = ɵɵnextContext();
    const customerEntry_r27 = ctx_r25.customerEntry;
    const column_r28 = ctx_r25.column;
    ɵɵadvance();
    ɵɵtextInterpolate((column_r28.renderer == null ? null : column_r28.renderer(customerEntry_r27)) || "");
  }
}
function CustomerListComponent_ng_template_32_cx_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-icon", 58);
    ɵɵpipe(1, "cxTranslate");
    ɵɵpipe(2, "cxTranslate");
  }
  if (rf & 2) {
    let tmp_15_0;
    let tmp_16_0;
    const ctx_r25 = ɵɵnextContext();
    const customerEntry_r27 = ctx_r25.customerEntry;
    const column_r28 = ctx_r25.column;
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassProp("cx-action-color", column_r28.actionType && !ctx_r2.isRequired(customerEntry_r27, column_r28.actionType));
    ɵɵproperty("type", column_r28.icon.symbol);
    ɵɵattribute("title", !column_r28.actionType ? ɵɵpipeBind1(1, 5, (tmp_15_0 = column_r28.icon.captionLocalizationKey) !== null && tmp_15_0 !== void 0 ? tmp_15_0 : column_r28.headerLocalizationKey) : void 0)("aria-label", !column_r28.actionType ? ɵɵpipeBind1(2, 7, (tmp_16_0 = column_r28.icon.captionLocalizationKey) !== null && tmp_16_0 !== void 0 ? tmp_16_0 : column_r28.headerLocalizationKey) : void 0);
  }
}
function CustomerListComponent_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, CustomerListComponent_ng_template_32_span_1_Template, 2, 1, "span", 20)(2, CustomerListComponent_ng_template_32_cx_icon_2_Template, 3, 9, "cx-icon", 57);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const column_r28 = ctx.column;
    ɵɵadvance();
    ɵɵproperty("ngIf", !column_r28.icon);
    ɵɵadvance();
    ɵɵproperty("ngIf", column_r28.icon);
  }
}
function CustomerListComponent_ng_template_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 59)(1, "input", 60);
    ɵɵpipe(2, "cxTranslate");
    ɵɵpipe(3, "cxTranslate");
    ɵɵlistener("keyup", function CustomerListComponent_ng_template_34_Template_input_keyup_1_listener($event) {
      ɵɵrestoreView(_r29);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onKey($event));
    });
    ɵɵelementEnd();
    ɵɵelementStart(4, "cx-icon", 61);
    ɵɵpipe(5, "cxTranslate");
    ɵɵpipe(6, "cxTranslate");
    ɵɵlistener("click", function CustomerListComponent_ng_template_34_Template_cx_icon_click_4_listener() {
      ɵɵrestoreView(_r29);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.searchCustomers());
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(2, 6, "asm.customerList.searchBox"));
    ɵɵproperty("formControl", ctx_r2.searchBox);
    ɵɵattribute("aria-label", ɵɵpipeBind1(3, 8, "asm.customerList.enterSearchBox"));
    ɵɵadvance(3);
    ɵɵproperty("type", ctx_r2.iconTypes.SEARCH)("title", ɵɵpipeBind1(5, 10, "storeFinder.searchNearestStores"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 12, "storeFinder.searchNearestStores"));
  }
}
function CustomerListComponent_ng_template_36_span_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const customerSearchPage_r30 = ɵɵnextContext(2).customerSearchPage;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(2, 1, "asm.customerList.noOfCustomers", ɵɵpureFunction1(4, _c18, customerSearchPage_r30 == null ? null : customerSearchPage_r30.pagination == null ? null : customerSearchPage_r30.pagination.totalResults)), " ");
  }
}
function CustomerListComponent_ng_template_36_span_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "asm.customerList.oneCustomer"), " ");
  }
}
function CustomerListComponent_ng_template_36_span_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 63);
    ɵɵtemplate(1, CustomerListComponent_ng_template_36_span_0_ng_container_1_Template, 3, 6, "ng-container", 20)(2, CustomerListComponent_ng_template_36_span_0_ng_container_2_Template, 3, 3, "ng-container", 20);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const customerSearchPage_r30 = ɵɵnextContext().customerSearchPage;
    ɵɵadvance();
    ɵɵproperty("ngIf", (customerSearchPage_r30 == null ? null : customerSearchPage_r30.pagination == null ? null : customerSearchPage_r30.pagination.totalResults) > 1);
    ɵɵadvance();
    ɵɵproperty("ngIf", (customerSearchPage_r30 == null ? null : customerSearchPage_r30.pagination == null ? null : customerSearchPage_r30.pagination.totalResults) === 1);
  }
}
function CustomerListComponent_ng_template_36_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CustomerListComponent_ng_template_36_span_0_Template, 3, 2, "span", 62);
  }
  if (rf & 2) {
    const customerSearchPage_r30 = ctx.customerSearchPage;
    ɵɵproperty("ngIf", customerSearchPage_r30 == null ? null : customerSearchPage_r30.pagination == null ? null : customerSearchPage_r30.pagination.totalResults);
  }
}
function CustomerListComponent_ng_template_38_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 67);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate(ɵɵpipeBind1(2, 1, "asm.customerList.tableSort.sortBy"));
  }
}
function CustomerListComponent_ng_template_38_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 32);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate(ɵɵpipeBind1(2, 1, "asm.customerList.tableSort.sortBy"));
  }
}
function CustomerListComponent_ng_template_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "label");
    ɵɵtemplate(1, CustomerListComponent_ng_template_38_span_1_Template, 3, 3, "span", 64)(2, CustomerListComponent_ng_template_38_span_2_Template, 3, 3, "span", 65);
    ɵɵelementStart(3, "cx-sorting", 66);
    ɵɵpipe(4, "cxTranslate");
    ɵɵpipe(5, "async");
    ɵɵlistener("sortListEvent", function CustomerListComponent_ng_template_38_Template_cx_sorting_sortListEvent_3_listener($event) {
      ɵɵrestoreView(_r31);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.changeSortCode($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yShowLabelOfSelect");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yShowLabelOfSelect");
    ɵɵadvance();
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(4, 7, "asm.customerList.tableSort.sortBy"));
    ɵɵproperty("sortOptions", ctx_r2.sorts)("sortLabels", ɵɵpipeBind1(5, 9, ctx_r2.getSortLabels()))("selectedOption", ctx_r2.sortCode)("ariaLabel", ctx_r2.sortCode);
  }
}
function CustomerListComponent_ng_template_40_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 71);
    ɵɵlistener("click", function CustomerListComponent_ng_template_40_button_4_Template_button_click_0_listener() {
      ɵɵrestoreView(_r32);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.goToPreviousPage());
    });
    ɵɵelement(1, "cx-icon", 72);
    ɵɵelementStart(2, "span");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("disabled", ctx_r2.currentPage === 0 || !ctx_r2.loaded);
    ɵɵadvance();
    ɵɵproperty("type", ctx_r2.iconTypes.CARET_LEFT);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 3, "asm.customerList.page.previous"));
  }
}
function CustomerListComponent_ng_template_40_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 73);
    ɵɵlistener("click", function CustomerListComponent_ng_template_40_button_5_Template_button_click_0_listener() {
      ɵɵrestoreView(_r33);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.goToNextPage());
    });
    ɵɵelementStart(1, "span");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(4, "cx-icon", 74);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("disabled", ctx_r2.currentPage === ctx_r2.maxPage || !ctx_r2.loaded);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 3, "asm.customerList.page.next"));
    ɵɵadvance(2);
    ɵɵproperty("type", ctx_r2.iconTypes.CARET_RIGHT);
  }
}
function CustomerListComponent_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 68)(1, "div");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(4, CustomerListComponent_ng_template_40_button_4_Template, 5, 5, "button", 69)(5, CustomerListComponent_ng_template_40_button_5_Template, 5, 5, "button", 70);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(3, 3, "asm.customerList.page.page", ɵɵpureFunction1(6, _c18, ctx_r2.currentPage + 1)), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r2.maxPage > 0);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.maxPage > 0);
  }
}
function CustomerListComponent_ng_template_42_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 67);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate(ɵɵpipeBind1(2, 1, "asm.customerList.title"));
  }
}
function CustomerListComponent_ng_template_42_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 32);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate(ɵɵpipeBind1(2, 1, "asm.customerList.title"));
  }
}
function CustomerListComponent_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "label");
    ɵɵtemplate(1, CustomerListComponent_ng_template_42_span_1_Template, 3, 3, "span", 64)(2, CustomerListComponent_ng_template_42_span_2_Template, 3, 3, "span", 65);
    ɵɵelementStart(3, "ng-select", 75);
    ɵɵlistener("change", function CustomerListComponent_ng_template_42_Template_ng_select_change_3_listener() {
      ɵɵrestoreView(_r34);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onChangeCustomerGroup());
    });
    ɵɵtwoWayListener("ngModelChange", function CustomerListComponent_ng_template_42_Template_ng_select_ngModelChange_3_listener($event) {
      ɵɵrestoreView(_r34);
      const ctx_r2 = ɵɵnextContext();
      ɵɵtwoWayBindingSet(ctx_r2.selectedUserGroupId, $event) || (ctx_r2.selectedUserGroupId = $event);
      return ɵɵresetView($event);
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const customerListsPage_r35 = ctx.customerListsPage;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yShowLabelOfSelect");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yShowLabelOfSelect");
    ɵɵadvance();
    ɵɵproperty("searchable", false)("clearable", false)("tabIndex", 0);
    ɵɵtwoWayProperty("ngModel", ctx_r2.selectedUserGroupId);
    ɵɵproperty("items", customerListsPage_r35 == null ? null : customerListsPage_r35.userGroups)("cxNgSelectA11y", ɵɵpureFunction1(8, _c19, ctx_r2.getGroupName(customerListsPage_r35, ctx_r2.selectedUserGroupId)));
  }
}
function CustomerListComponent_ng_template_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r36 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 76);
    ɵɵpipe(1, "cxTranslate");
    ɵɵpipe(2, "cxTranslate");
    ɵɵlistener("click", function CustomerListComponent_ng_template_44_Template_button_click_0_listener() {
      ɵɵrestoreView(_r36);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.closeModal("Cross click"));
    });
    ɵɵelementStart(3, "span", 77);
    ɵɵelement(4, "cx-icon", 58);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 3, "common.close"));
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 5, "common.close"));
    ɵɵadvance(4);
    ɵɵproperty("type", ctx_r2.iconTypes.CLOSE);
  }
}
function CustomerListComponent_ng_template_46_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 78);
    ɵɵlistener("click", function CustomerListComponent_ng_template_46_Template_button_click_0_listener() {
      ɵɵrestoreView(_r37);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.createCustomer());
    });
    ɵɵelement(1, "cx-icon", 58);
    ɵɵelementStart(2, "span");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("type", ctx_r2.iconTypes.USER_PLUS);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 2, "asm.customerList.createCustomer"));
  }
}
var BIND_CART_DIALOG_ACTION;
(function(BIND_CART_DIALOG_ACTION2) {
  BIND_CART_DIALOG_ACTION2["CANCEL"] = "CANCEL";
  BIND_CART_DIALOG_ACTION2["REPLACE"] = "REPLACE";
})(BIND_CART_DIALOG_ACTION || (BIND_CART_DIALOG_ACTION = {}));
var AsmBindCartDialogComponent = class _AsmBindCartDialogComponent {
  constructor(launchDialogService) {
    this.launchDialogService = launchDialogService;
    this.BIND_CART_ACTION = BIND_CART_DIALOG_ACTION;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
  }
  closeModal(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  static {
    this.ɵfac = function AsmBindCartDialogComponent_Factory(t) {
      return new (t || _AsmBindCartDialogComponent)(ɵɵdirectiveInject(LaunchDialogService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmBindCartDialogComponent,
      selectors: [["cx-asm-bind-cart-dialog"]],
      decls: 20,
      vars: 19,
      consts: [["role", "dialog", "aria-labelledby", "asm-bind-cart-dialog-title", 1, "cx-asm-bind-cart-dialog", "cx-modal-container", "cx-asm-dialog", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], ["id", "asm-bind-cart-dialog-title", 1, "title", "modal-title"], [1, "cx-dialog-body", "modal-body"], [1, "cx-dialog-row"], [1, "cx-dialog-item"], [1, "cx-dialog-footer", "modal-footer"], ["type", "button", 1, "btn", "btn-primary", 3, "click"], ["type", "button", 1, "btn", "btn-secondary", 3, "click"]],
      template: function AsmBindCartDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵlistener("esc", function AsmBindCartDialogComponent_Template_div_esc_0_listener() {
            return ctx.closeModal(ctx.BIND_CART_ACTION.CANCEL);
          });
          ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "h2", 3);
          ɵɵtext(4);
          ɵɵpipe(5, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(6, "div", 4)(7, "div", 5)(8, "div", 6);
          ɵɵtext(9);
          ɵɵpipe(10, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵelementStart(11, "div", 7)(12, "button", 8);
          ɵɵpipe(13, "cxTranslate");
          ɵɵlistener("click", function AsmBindCartDialogComponent_Template_button_click_12_listener() {
            return ctx.closeModal(ctx.BIND_CART_ACTION.REPLACE);
          });
          ɵɵtext(14);
          ɵɵpipe(15, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(16, "button", 9);
          ɵɵpipe(17, "cxTranslate");
          ɵɵlistener("click", function AsmBindCartDialogComponent_Template_button_click_16_listener() {
            return ctx.closeModal(ctx.BIND_CART_ACTION.CANCEL);
          });
          ɵɵtext(18);
          ɵɵpipe(19, "cxTranslate");
          ɵɵelementEnd()()()();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 7, "asm.bindCart.dialog.title"), " ");
          ɵɵadvance(5);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 9, "asm.bindCart.dialog.body"), " ");
          ɵɵadvance(3);
          ɵɵattribute("aria-label", ɵɵpipeBind1(13, 11, "asm.bindCart.dialog.actions.replace"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(15, 13, "asm.bindCart.dialog.actions.replace"), " ");
          ɵɵadvance(2);
          ɵɵattribute("aria-label", ɵɵpipeBind1(17, 15, "common.cancel"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 17, "common.cancel"), " ");
        }
      },
      dependencies: [FocusDirective, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmBindCartDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-bind-cart-dialog",
      template: `<div
  class="cx-asm-bind-cart-dialog cx-modal-container cx-asm-dialog"
  role="dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal(BIND_CART_ACTION.CANCEL)"
  aria-labelledby="asm-bind-cart-dialog-title"
>
  <div class="cx-modal-content">
    <!-- Modal Header -->
    <div class="cx-dialog-header modal-header">
      <h2 id="asm-bind-cart-dialog-title" class="title modal-title">
        {{ 'asm.bindCart.dialog.title' | cxTranslate }}
      </h2>
    </div>

    <!-- Modal Body -->
    <div class="cx-dialog-body modal-body">
      <div class="cx-dialog-row">
        <div class="cx-dialog-item">
          {{ 'asm.bindCart.dialog.body' | cxTranslate }}
        </div>
      </div>
    </div>

    <!-- Modal Footer -->
    <div class="cx-dialog-footer modal-footer">
      <button
        (click)="closeModal(BIND_CART_ACTION.REPLACE)"
        [attr.aria-label]="'asm.bindCart.dialog.actions.replace' | cxTranslate"
        class="btn btn-primary"
        type="button"
      >
        {{ 'asm.bindCart.dialog.actions.replace' | cxTranslate }}
      </button>

      <button
        (click)="closeModal(BIND_CART_ACTION.CANCEL)"
        [attr.aria-label]="'common.cancel' | cxTranslate"
        class="btn btn-secondary"
        type="button"
      >
        {{ 'common.cancel' | cxTranslate }}
      </button>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }], null);
})();
var SAVE_CART_DIALOG_ACTION;
(function(SAVE_CART_DIALOG_ACTION2) {
  SAVE_CART_DIALOG_ACTION2["CANCEL"] = "CANCEL";
  SAVE_CART_DIALOG_ACTION2["SAVE"] = "SAVE";
})(SAVE_CART_DIALOG_ACTION || (SAVE_CART_DIALOG_ACTION = {}));
var AsmSaveCartDialogComponent = class _AsmSaveCartDialogComponent {
  constructor(launchDialogService, savedCartFacade) {
    this.launchDialogService = launchDialogService;
    this.savedCartFacade = savedCartFacade;
    this.BIND_CART_ACTION = SAVE_CART_DIALOG_ACTION;
    this.showDialogAlert$ = new BehaviorSubject(true);
    this.globalMessageType = GlobalMessageType;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
    useFeatureStyles("a11yQTY2Quantity");
  }
  ngOnInit() {
    this.launchDialogService.data$.pipe(take(1)).subscribe((data) => {
      this.cart = data;
      this.setCartTotalQty();
    });
  }
  setCartTotalQty() {
    let count = 0;
    if (this.cart.entries) {
      for (const entry of this.cart.entries) {
        count += entry.quantity ? entry.quantity : 0;
      }
    }
    this.cartQty = count;
  }
  closeDialogAlert() {
    this.showDialogAlert$.next(false);
  }
  closeModal(reason) {
    if (reason === SAVE_CART_DIALOG_ACTION.SAVE) {
      this.saveCart();
    }
    this.launchDialogService.closeDialog(reason);
  }
  saveCart() {
    this.savedCartFacade.saveCart({
      cartId: this.cart.code,
      saveCartName: this.cart.code,
      saveCartDescription: "-"
    });
  }
  static {
    this.ɵfac = function AsmSaveCartDialogComponent_Factory(t) {
      return new (t || _AsmSaveCartDialogComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(SavedCartFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmSaveCartDialogComponent,
      selectors: [["cx-asm-save-cart-dialog"]],
      decls: 37,
      vars: 30,
      consts: [["showSaveCartWarning", ""], ["role", "dialog", "aria-labelledby", "asm-save-cart-dialog-title", 1, "cx-asm-save-cart-dialog", "cx-modal-container", "cx-asm-dialog", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], ["id", "asm-save-cart-dialog-title", 1, "title", "modal-title"], [1, "cx-dialog-body", "modal-body"], [4, "ngIf", "ngIfElse"], [1, "cx-dialog-content"], [1, "cx-dialog-row", "row"], [1, "cx-dialog-item", "col-sm-6", "col-md-6", "text-right", "item-left-text"], [1, "cx-dialog-item", "col-sm-6", "col-md-6", "text-left", "item-right-text"], ["class", "cx-dialog-item col-sm-6 col-md-6 text-right item-left-text", 4, "cxFeature"], [1, "cx-dialog-footer", "modal-footer"], ["id", "asm-save-cart-dialog-btn", "type", "button", 1, "btn", "btn-primary", 3, "click", "disabled"], ["type", "button", 1, "btn", "btn-secondary", 3, "click"], [1, "message-container"], [3, "text", "type", "closeMessage", 4, "ngIf"], [3, "closeMessage", "text", "type"]],
      template: function AsmSaveCartDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 1);
          ɵɵlistener("esc", function AsmSaveCartDialogComponent_Template_div_esc_0_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal(ctx.BIND_CART_ACTION.CANCEL));
          });
          ɵɵelementStart(1, "div", 2)(2, "div", 3)(3, "h2", 4);
          ɵɵtext(4);
          ɵɵpipe(5, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(6, "div", 5);
          ɵɵtemplate(7, AsmSaveCartDialogComponent_ng_container_7_Template, 4, 3, "ng-container", 6)(8, AsmSaveCartDialogComponent_ng_template_8_Template, 3, 3, "ng-template", null, 0, ɵɵtemplateRefExtractor);
          ɵɵelementStart(10, "div", 7)(11, "div", 8)(12, "div", 9);
          ɵɵtext(13);
          ɵɵpipe(14, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(15, "div", 10);
          ɵɵtext(16);
          ɵɵelementEnd()();
          ɵɵelementStart(17, "div", 8);
          ɵɵtemplate(18, AsmSaveCartDialogComponent_div_18_Template, 3, 3, "div", 11)(19, AsmSaveCartDialogComponent_div_19_Template, 3, 3, "div", 11);
          ɵɵelementStart(20, "div", 10);
          ɵɵtext(21);
          ɵɵelementEnd()();
          ɵɵelementStart(22, "div", 8)(23, "div", 9);
          ɵɵtext(24);
          ɵɵpipe(25, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(26, "div", 10);
          ɵɵtext(27);
          ɵɵelementEnd()()()();
          ɵɵelementStart(28, "div", 12)(29, "button", 13);
          ɵɵpipe(30, "cxTranslate");
          ɵɵlistener("click", function AsmSaveCartDialogComponent_Template_button_click_29_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal(ctx.BIND_CART_ACTION.SAVE));
          });
          ɵɵtext(31);
          ɵɵpipe(32, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(33, "button", 14);
          ɵɵpipe(34, "cxTranslate");
          ɵɵlistener("click", function AsmSaveCartDialogComponent_Template_button_click_33_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal(ctx.BIND_CART_ACTION.CANCEL));
          });
          ɵɵtext(35);
          ɵɵpipe(36, "cxTranslate");
          ɵɵelementEnd()()()();
        }
        if (rf & 2) {
          const showSaveCartWarning_r5 = ɵɵreference(9);
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 16, "asm.saveCart.dialog.title"), " ");
          ɵɵadvance(3);
          ɵɵproperty("ngIf", ctx.cartQty > 0)("ngIfElse", showSaveCartWarning_r5);
          ɵɵadvance(6);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 18, "asm.saveCart.dialog.row.id"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ctx.cart.code, " ");
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yQTY2Quantity");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yQTY2Quantity");
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ctx.cartQty, " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(25, 20, "asm.saveCart.dialog.row.total"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ctx.cart.totalPriceWithTax == null ? null : ctx.cart.totalPriceWithTax.formattedValue, " ");
          ɵɵadvance(2);
          ɵɵproperty("disabled", ctx.cartQty === 0);
          ɵɵattribute("aria-label", ɵɵpipeBind1(30, 22, "asm.saveCart.dialog.actions.save"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(32, 24, "asm.saveCart.dialog.actions.save"), " ");
          ɵɵadvance(2);
          ɵɵattribute("aria-label", ɵɵpipeBind1(34, 26, "common.cancel"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(36, 28, "common.cancel"), " ");
        }
      },
      dependencies: [NgIf, FocusDirective, MessageComponent, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmSaveCartDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-save-cart-dialog",
      template: `<div
  class="cx-asm-save-cart-dialog cx-modal-container cx-asm-dialog"
  role="dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal(BIND_CART_ACTION.CANCEL)"
  aria-labelledby="asm-save-cart-dialog-title"
>
  <div class="cx-modal-content">
    <!-- Modal Header -->
    <div class="cx-dialog-header modal-header">
      <h2 id="asm-save-cart-dialog-title" class="title modal-title">
        {{ 'asm.saveCart.dialog.title' | cxTranslate }}
      </h2>
    </div>

    <!-- Modal Body -->
    <div class="cx-dialog-body modal-body">
      <ng-container *ngIf="cartQty > 0; else showSaveCartWarning">
        <div class="message-container">
          <cx-message
            *ngIf="showDialogAlert$ | async"
            [text]="'asm.saveCart.dialog.saveInfo' | cxTranslate"
            [type]="globalMessageType.MSG_TYPE_INFO"
            (closeMessage)="closeDialogAlert()"
          >
          </cx-message>
        </div>
      </ng-container>
      <ng-template #showSaveCartWarning>
        <div class="message-container">
          <cx-message
            *ngIf="showDialogAlert$ | async"
            [text]="'asm.saveCart.dialog.disableInfo' | cxTranslate"
            [type]="globalMessageType.MSG_TYPE_WARNING"
            (closeMessage)="closeDialogAlert()"
          >
          </cx-message>
        </div>
      </ng-template>

      <div class="cx-dialog-content">
        <div class="cx-dialog-row row">
          <div
            class="cx-dialog-item col-sm-6 col-md-6 text-right item-left-text"
          >
            {{ 'asm.saveCart.dialog.row.id' | cxTranslate }}
          </div>
          <div
            class="cx-dialog-item col-sm-6 col-md-6 text-left item-right-text"
          >
            {{ cart.code }}
          </div>
        </div>
        <div class="cx-dialog-row row">
          <div
            *cxFeature="'a11yQTY2Quantity'"
            class="cx-dialog-item col-sm-6 col-md-6 text-right item-left-text"
          >
            {{ 'asm.saveCart.dialog.row.qtyFull' | cxTranslate }}
          </div>
          <div
            *cxFeature="'!a11yQTY2Quantity'"
            class="cx-dialog-item col-sm-6 col-md-6 text-right item-left-text"
          >
            {{ 'asm.saveCart.dialog.row.qty' | cxTranslate }}
          </div>
          <div
            class="cx-dialog-item col-sm-6 col-md-6 text-left item-right-text"
          >
            {{ cartQty }}
          </div>
        </div>
        <div class="cx-dialog-row row">
          <div
            class="cx-dialog-item col-sm-6 col-md-6 text-right item-left-text"
          >
            {{ 'asm.saveCart.dialog.row.total' | cxTranslate }}
          </div>
          <div
            class="cx-dialog-item col-sm-6 col-md-6 text-left item-right-text"
          >
            {{ cart.totalPriceWithTax?.formattedValue }}
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Footer -->
    <div class="cx-dialog-footer modal-footer">
      <button
        id="asm-save-cart-dialog-btn"
        (click)="closeModal(BIND_CART_ACTION.SAVE)"
        [attr.aria-label]="'asm.saveCart.dialog.actions.save' | cxTranslate"
        class="btn btn-primary"
        type="button"
        [disabled]="this.cartQty === 0"
      >
        {{ 'asm.saveCart.dialog.actions.save' | cxTranslate }}
      </button>

      <button
        (click)="closeModal(BIND_CART_ACTION.CANCEL)"
        [attr.aria-label]="'common.cancel' | cxTranslate"
        class="btn btn-secondary"
        type="button"
      >
        {{ 'common.cancel' | cxTranslate }}
      </button>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: SavedCartFacade
  }], null);
})();
var AsmComponentService = class _AsmComponentService {
  constructor(authService, csAgentAuthService, winRef, asmEnablerService, asmDeepLinkService) {
    this.authService = authService;
    this.csAgentAuthService = csAgentAuthService;
    this.winRef = winRef;
    this.asmEnablerService = asmEnablerService;
    this.asmDeepLinkService = asmDeepLinkService;
    this.isEmulatedByDeepLink$ = new BehaviorSubject(false);
    this.showDeeplinkCartInfoAlert$ = new BehaviorSubject(false);
    this.routingService = inject(RoutingService);
  }
  /**
   * Returns a deep link parameter value if it is in the url.
   */
  getSearchParameter(key) {
    return this.asmDeepLinkService?.getSearchParameter(key);
  }
  isEmulatedByDeepLink() {
    return this.isEmulatedByDeepLink$;
  }
  setEmulatedByDeepLink(emulated) {
    this.isEmulatedByDeepLink$.next(emulated);
  }
  setShowDeeplinkCartInfoAlert(display) {
    this.showDeeplinkCartInfoAlert$.next(display);
  }
  shouldShowDeeplinkCartInfoAlert() {
    return this.showDeeplinkCartInfoAlert$;
  }
  logoutCustomerSupportAgentAndCustomer() {
    this.csAgentAuthService.logoutCustomerSupportAgent();
  }
  logoutCustomer() {
    this.authService.logout();
  }
  isCustomerEmulationSessionInProgress() {
    return this.csAgentAuthService.isCustomerEmulated();
  }
  /**
   * We're currently only removing the persisted storage in the browser
   * to ensure the ASM experience isn't loaded on the next visit. There are a few
   * optimizations we could think of:
   * - drop the `asm` parameter from the URL, in case it's still there
   * - remove the generated UI from the DOM (outlets currently do not support this)
   */
  unload() {
    if (this.winRef.localStorage) {
      this.winRef.localStorage.removeItem(ASM_ENABLED_LOCAL_STORAGE_KEY);
    }
  }
  /**
   * check whether try to emulate customer from deeplink
   */
  isEmulateInURL() {
    return this.asmDeepLinkService?.isEmulateInURL() || false;
  }
  /**
   * Returns valid deep link parameters in the url.
   */
  getDeepLinkUrlParams() {
    return this.asmDeepLinkService?.getParamsInUrl();
  }
  /**
   * Handles the navigation based on deep link parameters in the URL
   * or passed parameter.
   */
  handleDeepLinkNavigation(parameters = this.getDeepLinkUrlParams()) {
    this.asmDeepLinkService?.handleNavigation(parameters);
  }
  handleAsmDialogAction(event) {
    if (typeof event === "object" && event.actionType === AsmDialogActionType.NAVIGATE) {
      this.routingService.go(event.route);
    }
  }
  static {
    this.ɵfac = function AsmComponentService_Factory(t) {
      return new (t || _AsmComponentService)(ɵɵinject(AuthService), ɵɵinject(CsAgentAuthService), ɵɵinject(WindowRef), ɵɵinject(AsmEnablerService), ɵɵinject(AsmDeepLinkService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _AsmComponentService,
      factory: _AsmComponentService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmComponentService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: AuthService
  }, {
    type: CsAgentAuthService
  }, {
    type: WindowRef
  }, {
    type: AsmEnablerService
  }, {
    type: AsmDeepLinkService
  }], null);
})();
var DotSpinnerComponent = class _DotSpinnerComponent {
  static {
    this.ɵfac = function DotSpinnerComponent_Factory(t) {
      return new (t || _DotSpinnerComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _DotSpinnerComponent,
      selectors: [["cx-dot-spinner"]],
      decls: 3,
      vars: 0,
      template: function DotSpinnerComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div")(1, "div")(2, "div");
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DotSpinnerComponent, [{
    type: Component,
    args: [{
      selector: "cx-dot-spinner",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: "<div></div>\n<div></div>\n<div></div>\n"
    }]
  }], null, null);
})();
var AsmBindCartComponent = class _AsmBindCartComponent {
  constructor(globalMessageService, activeCartFacade, multiCartFacade, asmBindCartFacade, launchDialogService, savedCartFacade, asmComponentService, routing) {
    this.globalMessageService = globalMessageService;
    this.activeCartFacade = activeCartFacade;
    this.multiCartFacade = multiCartFacade;
    this.asmBindCartFacade = asmBindCartFacade;
    this.launchDialogService = launchDialogService;
    this.savedCartFacade = savedCartFacade;
    this.asmComponentService = asmComponentService;
    this.routing = routing;
    this.activeCartValidator = (control) => {
      if (control.value === this.activeCartId) {
        return {
          activeCartError: true
        };
      }
      if (!!this.deepLinkCartId && control.value !== this.deepLinkCartId) {
        this.resetDeeplinkCart();
      }
      return null;
    };
    this.cartId = new FormControl("", [Validators.required, Validators.minLength(1), this.activeCartValidator]);
    this.loading$ = new BehaviorSubject(false);
    this.valid$ = this.cartId.statusChanges.pipe(map((status) => status === "VALID"), shareReplay(1));
    this.activeCartId = "";
    this.deepLinkCartId = "";
    this.displayBindCartBtn$ = new BehaviorSubject(true);
    this.displaySaveCartBtn$ = new BehaviorSubject(false);
    this.subscription = new Subscription();
    this.featureConfig = inject(FeatureConfigService);
    this.isShowStyleChangesInASM = this.featureConfig.isEnabled("showStyleChangesInASM");
  }
  ngOnInit() {
    this.subscribeForDeeplinkCart();
    this.subscription.add(this.activeCartFacade.getActiveCartId().subscribe((response) => {
      this.activeCartId = response ?? "";
    }));
  }
  /**
   * Bind the input cart number to the customer
   */
  bindCartToCustomer() {
    const anonymousCartId = this.cartId.value;
    const subscription = combineLatest([this.loading$.asObservable(), this.valid$]).pipe(take(1), filter(([loading, valid]) => !loading && valid), tap(() => this.loading$.next(true)), concatMap(() => this.activeCartFacade.getActive().pipe(map((cart) => cart.deliveryItemsQuantity ?? 0), take(1))), concatMap((cartItemCount) => iif(() => Boolean(this.activeCartId && cartItemCount), this.openDialog(this.activeCartId, anonymousCartId), this.simpleBindCart(anonymousCartId))), finalize(() => this.loading$.next(false))).subscribe({
      next: () => {
        this.globalMessageService.add({
          key: "asm.bindCart.success"
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
      },
      error: (error) => {
        this.globalMessageService.add(error.details?.[0].message ?? "", GlobalMessageType.MSG_TYPE_ERROR);
      }
    });
    this.subscription.add(subscription);
  }
  onSaveInactiveCart() {
    this.asmComponentService?.setShowDeeplinkCartInfoAlert(false);
    const customerId = this.asmComponentService?.getSearchParameter("customerId");
    this.multiCartFacade.loadCart({
      cartId: this.deepLinkCartId,
      userId: customerId
    });
    this.multiCartFacade.getCartEntity(this.deepLinkCartId).pipe(filter((state) => state.loading === false && state.success === true), take(1), map((state) => state.value), filter((cart) => !!cart)).subscribe((cart) => {
      this.openASMSaveCartDialog(cart);
    });
    this.afterCloseASMSaveCartDialog();
  }
  clearText() {
    this.cartId.setValue("");
    this.resetDeeplinkCart();
  }
  resetDeeplinkCart() {
    this.deepLinkCartId = "";
    this.displayBindCartBtn$.next(true);
    this.displaySaveCartBtn$.next(false);
    this.asmComponentService?.setShowDeeplinkCartInfoAlert(false);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  /**
   * Binds cart on subscription and reloads cart
   */
  simpleBindCart(anonymousCartId) {
    return defer(() => this.asmBindCartFacade.bindCart(anonymousCartId)).pipe(tap(() => this.multiCartFacade.reloadCart(OCC_CART_ID_CURRENT)));
  }
  /**
   * Opens dialog and passes non-cancel result to select action
   */
  openDialog(activeCartId, anonymousCartId) {
    return defer(() => {
      this.launchDialogService.openDialogAndSubscribe("ASM_BIND_CART", this.bindToCartElemRef);
      return this.launchDialogService.dialogClose.pipe(filter((result) => Boolean(result)), take(1));
    }).pipe(filter((dialogResult) => Boolean(dialogResult)), concatMap((dialogResult) => {
      return this.selectBindAction(activeCartId, anonymousCartId, dialogResult);
    }));
  }
  selectBindAction(activeCartId, anonymousCartId, action) {
    switch (action) {
      case BIND_CART_DIALOG_ACTION.REPLACE:
        return this.replaceCart(activeCartId, anonymousCartId);
      case BIND_CART_DIALOG_ACTION.CANCEL:
      default:
        return EMPTY;
    }
  }
  replaceCart(previousActiveCartId, anonymousCartId) {
    return this.simpleBindCart(anonymousCartId).pipe(tap(() => {
      this.savedCartFacade.saveCart({
        cartId: previousActiveCartId,
        saveCartName: previousActiveCartId,
        // TODO(#12660): Remove default value once backend is updated
        saveCartDescription: "-"
      });
    }));
  }
  subscribeForDeeplinkCart() {
    this.subscription.add(this.asmComponentService?.isEmulatedByDeepLink().pipe(filter((emulated) => emulated && !!this.asmComponentService?.getSearchParameter("cartId"))).subscribe(() => {
      const cartType = this.asmComponentService?.getSearchParameter("cartType");
      if (cartType === "inactive" || cartType === "active") {
        this.displayBindCartBtn$.next(false);
        this.displaySaveCartBtn$.next(cartType === "inactive");
        this.deepLinkCartId = this.asmComponentService?.getSearchParameter("cartId");
        if (cartType === "inactive") {
          this.cartId.setValue(this.deepLinkCartId);
        }
        this.asmComponentService?.setShowDeeplinkCartInfoAlert(true);
        this.asmComponentService?.handleDeepLinkNavigation();
      }
    }));
  }
  openASMSaveCartDialog(inactiveCart) {
    this.launchDialogService.openDialogAndSubscribe("ASM_SAVE_CART", this.saveInactiveCartElemRef, inactiveCart);
  }
  afterCloseASMSaveCartDialog() {
    this.launchDialogService.dialogClose.pipe(filter((result) => result === SAVE_CART_DIALOG_ACTION.SAVE), take(1), tap(() => this.loading$.next(true))).subscribe();
    this.savedCartFacade.getSaveCartProcessSuccess().pipe(filter((success) => success), take(1), tap(() => this.loading$.next(false))).subscribe(() => {
      this.goToSavedCartDetails(this.deepLinkCartId);
      this.displaySaveCartBtn$.next(false);
    });
    this.savedCartFacade.getSaveCartProcessError().pipe(filter((error) => error), take(1), tap(() => this.loading$.next(false))).subscribe();
  }
  goToSavedCartDetails(cartId) {
    this.routing?.go({
      cxRoute: "savedCartsDetails",
      params: {
        savedCartId: cartId
      }
    });
  }
  static {
    this.ɵfac = function AsmBindCartComponent_Factory(t) {
      return new (t || _AsmBindCartComponent)(ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(ActiveCartFacade), ɵɵdirectiveInject(MultiCartFacade), ɵɵdirectiveInject(AsmBindCartFacade), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(SavedCartFacade), ɵɵdirectiveInject(AsmComponentService), ɵɵdirectiveInject(RoutingService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmBindCartComponent,
      selectors: [["cx-asm-bind-cart"]],
      viewQuery: function AsmBindCartComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c0, 5);
          ɵɵviewQuery(_c1, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.bindToCartElemRef = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.saveInactiveCartElemRef = _t.first);
        }
      },
      decls: 15,
      vars: 25,
      consts: [["cartIdElement", ""], ["bindToCart", ""], ["saveInactiveCart", ""], ["for", "cartNumber"], ["role", "search", 3, "click", "ngClass"], ["autocomplete", "off", "formcontrolname", "cartNumber", 3, "keydown.enter", "formControl"], ["class", "cx-asm-reset", 3, "visible", "click", 4, "ngIf"], ["class", "cx-asm-bindCartToCustomer", "type", "submit", 3, "disabled", "cx-asm-active", "cx-bind-loading", "click", 4, "ngIf"], ["id", "asm-save-inactive-cart-btn", "class", "cx-asm-bindCartToCustomer cx-asm-active", "type", "submit", 3, "cx-bind-loading", "click", 4, "ngIf"], [1, "cx-asm-reset", 3, "click"], [1, "cx-icon", "fas", "fa-times-circle"], ["type", "submit", 1, "cx-asm-bindCartToCustomer", 3, "click", "disabled"], ["id", "asm-save-inactive-cart-btn", "type", "submit", 1, "cx-asm-bindCartToCustomer", "cx-asm-active", 3, "click"]],
      template: function AsmBindCartComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "form")(1, "label", 3);
          ɵɵtext(2);
          ɵɵpipe(3, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(4, "div", 4);
          ɵɵpipe(5, "async");
          ɵɵpipe(6, "cxTranslate");
          ɵɵlistener("click", function AsmBindCartComponent_Template_div_click_4_listener() {
            ɵɵrestoreView(_r1);
            const cartIdElement_r2 = ɵɵreference(8);
            return ɵɵresetView(cartIdElement_r2.focus());
          });
          ɵɵelementStart(7, "input", 5, 0);
          ɵɵpipe(9, "cxTranslate");
          ɵɵlistener("keydown.enter", function AsmBindCartComponent_Template_input_keydown_enter_7_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.bindCartToCustomer());
          });
          ɵɵelementEnd();
          ɵɵtemplate(10, AsmBindCartComponent_button_10_Template, 4, 8, "button", 6);
          ɵɵelementEnd();
          ɵɵtemplate(11, AsmBindCartComponent_button_11_Template, 12, 23, "button", 7);
          ɵɵpipe(12, "async");
          ɵɵtemplate(13, AsmBindCartComponent_button_13_Template, 10, 16, "button", 8);
          ɵɵpipe(14, "async");
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance(2);
          ɵɵtextInterpolate1("", ɵɵpipeBind1(3, 10, "asm.bindCart.cartNumber"), " ");
          ɵɵadvance(2);
          ɵɵclassProp("active", ɵɵpipeBind1(5, 12, ctx.valid$));
          ɵɵproperty("ngClass", ɵɵpureFunction2(22, _c2, !ctx.isShowStyleChangesInASM, ctx.isShowStyleChangesInASM));
          ɵɵattribute("aria-label", ɵɵpipeBind1(6, 14, "asm.bindCart.assignCartId"));
          ɵɵadvance(3);
          ɵɵproperty("formControl", ctx.cartId);
          ɵɵattribute("aria-label", ɵɵpipeBind1(9, 16, "asm.bindCart.enterCartId"));
          ɵɵadvance(3);
          ɵɵproperty("ngIf", !ctx.isShowStyleChangesInASM);
          ɵɵadvance();
          ɵɵproperty("ngIf", ɵɵpipeBind1(12, 18, ctx.displayBindCartBtn$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(14, 20, ctx.displaySaveCartBtn$));
        }
      },
      dependencies: [NgClass, NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, FormControlDirective, IconComponent, NgForm, DotSpinnerComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmBindCartComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-bind-cart",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<form>
  <label for="cartNumber">{{ 'asm.bindCart.cartNumber' | cxTranslate }} </label>
  <div
    role="search"
    [attr.aria-label]="'asm.bindCart.assignCartId' | cxTranslate"
    [ngClass]="{
      'cx-asm-assignCart': !isShowStyleChangesInASM,
      'cx-asm-assignCart-input-show-no-button': isShowStyleChangesInASM,
    }"
    [class.active]="valid$ | async"
    (click)="cartIdElement.focus()"
  >
    <input
      autocomplete="off"
      #cartIdElement
      formcontrolname="cartNumber"
      [formControl]="cartId"
      (keydown.enter)="bindCartToCustomer()"
      [attr.aria-label]="'asm.bindCart.enterCartId' | cxTranslate"
    />
    <button
      *ngIf="!isShowStyleChangesInASM"
      class="cx-asm-reset"
      [attr.title]="'asm.bindCart.resetCartId' | cxTranslate"
      [attr.aria-label]="'asm.bindCart.resetCartId' | cxTranslate"
      [class.visible]="cartId.value?.length > 0"
      (click)="clearText()"
    >
      <cx-icon class="cx-icon fas fa-times-circle"></cx-icon>
    </button>
  </div>
  <button
    #bindToCart
    *ngIf="displayBindCartBtn$ | async"
    class="cx-asm-bindCartToCustomer"
    [disabled]="!(valid$ | async)"
    type="submit"
    [class.cx-asm-active]="valid$ | async"
    [class.cx-bind-loading]="loading$ | async"
    (click)="bindCartToCustomer()"
  >
    <span [attr.aria-hidden]="loading$ | async">
      {{ 'asm.bindCart.bindCartToCustomer' | cxTranslate }}
    </span>
    <cx-dot-spinner
      [attr.aria-hidden]="!(loading$ | async)"
      [attr.aria-label]="'common.loading' | cxTranslate"
    ></cx-dot-spinner>
  </button>

  <button
    id="asm-save-inactive-cart-btn"
    #saveInactiveCart
    *ngIf="displaySaveCartBtn$ | async"
    class="cx-asm-bindCartToCustomer cx-asm-active"
    type="submit"
    [class.cx-bind-loading]="loading$ | async"
    (click)="onSaveInactiveCart()"
  >
    <span [attr.aria-hidden]="loading$ | async">
      {{ 'asm.saveCart.saveCartBtn' | cxTranslate }}
    </span>
    <cx-dot-spinner
      [attr.aria-hidden]="!(loading$ | async)"
      [attr.aria-label]="'common.loading' | cxTranslate"
    ></cx-dot-spinner>
  </button>
</form>
`
    }]
  }], () => [{
    type: GlobalMessageService
  }, {
    type: ActiveCartFacade
  }, {
    type: MultiCartFacade
  }, {
    type: AsmBindCartFacade
  }, {
    type: LaunchDialogService
  }, {
    type: SavedCartFacade
  }, {
    type: AsmComponentService
  }, {
    type: RoutingService
  }], {
    bindToCartElemRef: [{
      type: ViewChild,
      args: ["bindToCart"]
    }],
    saveInactiveCartElemRef: [{
      type: ViewChild,
      args: ["saveInactiveCart"]
    }]
  });
})();
var AsmCreateCustomerFormComponent = class _AsmCreateCustomerFormComponent {
  constructor(launchDialogService, fb, asmCreateCustomerFacade, translationService) {
    this.launchDialogService = launchDialogService;
    this.fb = fb;
    this.asmCreateCustomerFacade = asmCreateCustomerFacade;
    this.translationService = translationService;
    this.iconTypes = ICON_TYPE;
    this.isLoading$ = new BehaviorSubject(false);
    this.showDialogInfoAlert = true;
    this.globalMessageType = GlobalMessageType;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
    this.registerForm = this.fb.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", [Validators.required, CustomFormValidators.emailValidator]]
    });
  }
  submitForm() {
    if (this.registerForm.valid) {
      this.registerUser();
    } else {
      this.registerForm.markAllAsTouched();
    }
  }
  registerUser() {
    this.isLoading$.next(true);
    const {
      firstName,
      lastName,
      email
    } = this.registerForm.value;
    this.createdCustomer = {
      firstName: firstName ?? "",
      lastName: lastName ?? "",
      email: email ?? ""
    };
    const obs$ = this.asmCreateCustomerFacade.createCustomer(this.collectDataFromRegisterForm());
    obs$.subscribe({
      next: (result) => this.onRegisterUserSuccess(result),
      error: (error) => this.onRegisterUserFail(error)
    });
    obs$.subscribe({
      complete: () => this.isLoading$.next(false)
    });
  }
  collectDataFromRegisterForm() {
    return {
      firstName: this.createdCustomer.firstName,
      lastName: this.createdCustomer.lastName,
      emailAddress: this.createdCustomer.email
    };
  }
  closeModal(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  closeDialogInfoAlert() {
    this.showDialogInfoAlert = false;
  }
  closeDialogBackendErroAlert(index) {
    this.showDialogBackendErrorAlerts[index] = false;
  }
  onRegisterUserSuccess(user) {
    this.launchDialogService.closeDialog(user);
  }
  onRegisterUserFail(error) {
    this.isLoading$.next(false);
    this.backendErrorMessages = [];
    this.showDialogBackendErrorAlerts = [];
    const unknownError = "httpHandlers.unknownError";
    const errorDetails = error.details ?? [];
    if (errorDetails.length === 0) {
      this.addErrorMessage(unknownError);
    }
    errorDetails.forEach((errorDetail) => {
      switch (errorDetail.type || "") {
        case "ValidationError":
          this.addErrorMessage(`asm.createCustomerForm.validationErrors.${errorDetail.subject}`);
          break;
        case "AssistedServiceDuplicatedUidError":
          this.addErrorMessage("asm.createCustomerForm.badRequestDuplicatedEmail", {
            emailAddress: this.createdCustomer.email
          });
          break;
        default:
          this.addErrorMessage(unknownError);
      }
    });
  }
  addErrorMessage(key, options) {
    this.translationService.translate(key, options).pipe(first()).subscribe((text) => {
      this.backendErrorMessages.push(text);
      this.showDialogBackendErrorAlerts.push(true);
    });
  }
  static {
    this.ɵfac = function AsmCreateCustomerFormComponent_Factory(t) {
      return new (t || _AsmCreateCustomerFormComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(FormBuilder), ɵɵdirectiveInject(AsmCreateCustomerFacade), ɵɵdirectiveInject(TranslationService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmCreateCustomerFormComponent,
      selectors: [["cx-asm-create-customer-form"]],
      decls: 23,
      vars: 17,
      consts: [["loading", ""], ["role", "dialog", "aria-labelledby", "asm-create-customer-form-title", 1, "cx-modal-container", "cx-asm-dialog", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [3, "ngSubmit", "formGroup"], [1, "cx-dialog-header", "modal-header"], ["id", "asm-create-customer-form-title", 1, "title", "modal-title"], [1, "cx-dialog-body", "modal-body"], [1, "message-container"], [3, "text", "type", "closeMessage", 4, "ngIf"], [4, "ngFor", "ngForOf"], [4, "ngIf", "ngIfElse"], [1, "modal-footer"], ["type", "submit", 1, "btn", "cx-asm-create-customer-btn", "cx-asm-create-customer-btn-create"], ["type", "button", 1, "btn", "cx-asm-create-customer-btn", "cx-asm-create-customer-btn-cancel", 3, "click"], [3, "closeMessage", "text", "type"], [1, "form-group"], [1, "label-content"], ["required", "true", "formControlName", "firstName", "name", "text", 1, "form-control", 3, "placeholder"], [3, "control"], ["required", "true", "name", "text", "formControlName", "lastName", 1, "form-control", 3, "placeholder"], ["required", "true", "name", "email", "formControlName", "email", 1, "form-control", 3, "placeholder"], [1, "cx-spinner"]],
      template: function AsmCreateCustomerFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 1);
          ɵɵlistener("esc", function AsmCreateCustomerFormComponent_Template_div_esc_0_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal("Escape clicked"));
          });
          ɵɵelementStart(1, "div", 2);
          ɵɵelementContainerStart(2);
          ɵɵelementStart(3, "form", 3);
          ɵɵlistener("ngSubmit", function AsmCreateCustomerFormComponent_Template_form_ngSubmit_3_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.submitForm());
          });
          ɵɵelementStart(4, "div", 4)(5, "h2", 5);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(8, "div", 6)(9, "div", 7);
          ɵɵtemplate(10, AsmCreateCustomerFormComponent_cx_message_10_Template, 2, 4, "cx-message", 8)(11, AsmCreateCustomerFormComponent_ng_container_11_Template, 2, 1, "ng-container", 9);
          ɵɵelementEnd();
          ɵɵtemplate(12, AsmCreateCustomerFormComponent_div_12_Template, 25, 21, "div", 10);
          ɵɵpipe(13, "async");
          ɵɵelementEnd();
          ɵɵelementStart(14, "div", 11)(15, "button", 12);
          ɵɵtext(16);
          ɵɵpipe(17, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(18, "button", 13);
          ɵɵlistener("click", function AsmCreateCustomerFormComponent_Template_button_click_18_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal("Cancel click"));
          });
          ɵɵtext(19);
          ɵɵpipe(20, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵelementContainerEnd();
          ɵɵelementEnd()();
          ɵɵtemplate(21, AsmCreateCustomerFormComponent_ng_template_21_Template, 2, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const loading_r7 = ɵɵreference(22);
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(3);
          ɵɵproperty("formGroup", ctx.registerForm);
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 9, "asm.createCustomerForm.title"), " ");
          ɵɵadvance(4);
          ɵɵproperty("ngIf", ctx.showDialogInfoAlert);
          ɵɵadvance();
          ɵɵproperty("ngForOf", ctx.backendErrorMessages);
          ɵɵadvance();
          ɵɵproperty("ngIf", !ɵɵpipeBind1(13, 11, ctx.isLoading$))("ngIfElse", loading_r7);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(17, 13, "asm.createCustomerForm.createAccount"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(20, 15, "asm.createCustomerForm.cancel"), " ");
        }
      },
      dependencies: [NgForOf, NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, FormErrorsComponent, SpinnerComponent, FocusDirective, MessageComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmCreateCustomerFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-create-customer-form",
      template: `<div
  class="cx-modal-container cx-asm-dialog"
  role="dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal('Escape clicked')"
  aria-labelledby="asm-create-customer-form-title"
>
  <div class="cx-modal-content">
    <ng-container>
      <form (ngSubmit)="submitForm()" [formGroup]="registerForm">
        <!-- Modal Header -->
        <div class="cx-dialog-header modal-header">
          <h2 id="asm-create-customer-form-title" class="title modal-title">
            {{ 'asm.createCustomerForm.title' | cxTranslate }}
          </h2>
        </div>
        <!-- Modal Body -->
        <div class="cx-dialog-body modal-body">
          <div class="message-container">
            <cx-message
              *ngIf="showDialogInfoAlert"
              [text]="'asm.createCustomerForm.createAccountAlert' | cxTranslate"
              [type]="globalMessageType.MSG_TYPE_INFO"
              (closeMessage)="closeDialogInfoAlert()"
            >
            </cx-message>
            <ng-container
              *ngFor="let errorMessage of backendErrorMessages; let i = index"
            >
              <cx-message
                *ngIf="showDialogBackendErrorAlerts[i]"
                [text]="errorMessage"
                [type]="globalMessageType.MSG_TYPE_ERROR"
                (closeMessage)="closeDialogBackendErroAlert(i)"
              >
              </cx-message>
            </ng-container>
          </div>

          <div *ngIf="!(isLoading$ | async); else loading">
            <div class="form-group">
              <label>
                <span class="label-content">{{
                  'asm.createCustomerForm.firstName.label' | cxTranslate
                }}</span>
                <input
                  required="true"
                  class="form-control"
                  placeholder="{{
                    'asm.createCustomerForm.firstName.placeholder' | cxTranslate
                  }}"
                  formControlName="firstName"
                  name="text"
                />
                <cx-form-errors
                  [control]="registerForm.get('firstName')"
                ></cx-form-errors>
              </label>
            </div>

            <div class="form-group">
              <label>
                <span class="label-content">{{
                  'asm.createCustomerForm.lastName.label' | cxTranslate
                }}</span>
                <input
                  required="true"
                  class="form-control"
                  placeholder="{{
                    'asm.createCustomerForm.lastName.placeholder' | cxTranslate
                  }}"
                  name="text"
                  formControlName="lastName"
                />
                <cx-form-errors
                  [control]="registerForm.get('lastName')"
                ></cx-form-errors>
              </label>
            </div>

            <div class="form-group">
              <label>
                <span class="label-content">{{
                  'asm.createCustomerForm.emailAddress.label' | cxTranslate
                }}</span>
                <input
                  required="true"
                  class="form-control"
                  placeholder="{{
                    'asm.createCustomerForm.emailAddress.placeholder'
                      | cxTranslate
                  }}"
                  name="email"
                  formControlName="email"
                />
                <cx-form-errors
                  [control]="registerForm.get('email')"
                ></cx-form-errors>
              </label>
            </div>
          </div>
        </div>
        <!-- Modal Footer -->
        <div class="modal-footer">
          <button
            type="submit"
            class="btn cx-asm-create-customer-btn cx-asm-create-customer-btn-create"
          >
            {{ 'asm.createCustomerForm.createAccount' | cxTranslate }}
          </button>
          <button
            type="button"
            class="btn cx-asm-create-customer-btn cx-asm-create-customer-btn-cancel"
            (click)="closeModal('Cancel click')"
          >
            {{ 'asm.createCustomerForm.cancel' | cxTranslate }}
          </button>
        </div>
      </form>
    </ng-container>
  </div>
</div>

<ng-template #loading>
  <div class="cx-spinner"><cx-spinner></cx-spinner></div>
</ng-template>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: FormBuilder
  }, {
    type: AsmCreateCustomerFacade
  }, {
    type: TranslationService
  }], null);
})();
var defaultAsmCreateCustomerFormLayoutConfig = {
  launch: {
    ASM_CREATE_CUSTOMER_FORM: {
      inlineRoot: true,
      component: AsmCreateCustomerFormComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var CSAgentLoginFormComponent = class _CSAgentLoginFormComponent {
  constructor(fb) {
    this.fb = fb;
    this.csAgentTokenLoading = false;
    this.submitEvent = new EventEmitter();
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
    useFeatureStyles("a11yTextSpacingAdjustments");
  }
  ngOnInit() {
    this.csAgentLoginForm = this.fb.group({
      userId: ["", [Validators.required]],
      password: ["", [Validators.required]]
    });
  }
  onSubmit() {
    if (this.csAgentLoginForm.valid) {
      this.submitEvent.emit({
        userId: this.csAgentLoginForm.get("userId")?.value,
        password: this.csAgentLoginForm.get("password")?.value
      });
    } else {
      this.csAgentLoginForm.markAllAsTouched();
    }
  }
  static {
    this.ɵfac = function CSAgentLoginFormComponent_Factory(t) {
      return new (t || _CSAgentLoginFormComponent)(ɵɵdirectiveInject(UntypedFormBuilder));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CSAgentLoginFormComponent,
      selectors: [["cx-csagent-login-form"]],
      inputs: {
        csAgentTokenLoading: "csAgentTokenLoading"
      },
      outputs: {
        submitEvent: "submitEvent"
      },
      decls: 2,
      vars: 2,
      consts: [[3, "formGroup", "ngSubmit", 4, "ngIf"], ["aria-hidden", "false", 4, "ngIf"], [3, "ngSubmit", "formGroup"], [1, "label-content"], ["required", "true", "type", "text", "formControlName", "userId"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "password", "formControlName", "password", "cxPasswordVisibilitySwitch", ""], ["type", "submit"], [3, "translationParams", "control"], [3, "control"], ["aria-hidden", "false"]],
      template: function CSAgentLoginFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CSAgentLoginFormComponent_form_0_Template, 20, 20, "form", 0)(1, CSAgentLoginFormComponent_cx_dot_spinner_1_Template, 2, 3, "cx-dot-spinner", 1);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", !ctx.csAgentTokenLoading);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.csAgentTokenLoading);
        }
      },
      dependencies: [NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, FormErrorsComponent, PasswordVisibilityToggleDirective, FeatureDirective, DotSpinnerComponent, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CSAgentLoginFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-csagent-login-form",
      template: `<form
  (ngSubmit)="onSubmit()"
  [formGroup]="csAgentLoginForm"
  *ngIf="!csAgentTokenLoading"
>
  <span class="label-content">
    {{ 'asm.loginForm.userId.label' | cxTranslate }}
  </span>
  <label>
    <input
      required="true"
      type="text"
      formControlName="userId"
      [attr.aria-label]="'asm.loginForm.userId.label' | cxTranslate"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'asm.loginForm.userId.label' | cxTranslate,
      }"
      [control]="csAgentLoginForm.get('userId')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="csAgentLoginForm.get('userId')"
    ></cx-form-errors>
  </label>

  <span class="label-content">
    {{ 'asm.loginForm.password.label' | cxTranslate }}
  </span>
  <label>
    <input
      required="true"
      type="password"
      formControlName="password"
      [attr.aria-label]="'asm.loginForm.password.label' | cxTranslate"
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'asm.loginForm.password.label' | cxTranslate,
      }"
      [control]="csAgentLoginForm.get('password')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="csAgentLoginForm.get('password')"
    ></cx-form-errors>
  </label>
  <button type="submit">
    {{ 'asm.loginForm.submit' | cxTranslate }}
  </button>
</form>

<cx-dot-spinner
  *ngIf="csAgentTokenLoading"
  aria-hidden="false"
  [attr.aria-label]="'common.loading' | cxTranslate"
></cx-dot-spinner>
`
    }]
  }], () => [{
    type: UntypedFormBuilder
  }], {
    csAgentTokenLoading: [{
      type: Input
    }],
    submitEvent: [{
      type: Output
    }]
  });
})();
var CustomerSelectionComponent = class _CustomerSelectionComponent {
  constructor(fb, asmService, config, directionService, launchDialogService) {
    this.fb = fb;
    this.asmService = asmService;
    this.config = config;
    this.directionService = directionService;
    this.launchDialogService = launchDialogService;
    this.subscription = new Subscription();
    this.searchByCustomer = false;
    this.searchByOrder = false;
    this.isLoading = false;
    this.activeFocusedButtonIndex = -1;
    this.featureConfig = inject(FeatureConfigService);
    this.isShowSearchingCustomerByOrderInASM = this.featureConfig.isEnabled("showSearchingCustomerByOrderInASM");
    this.submitEvent = new EventEmitter();
    useFeatureStyles("showSearchingCustomerByOrderInASM");
  }
  ngOnInit() {
    if (this.isShowSearchingCustomerByOrderInASM) {
      this.customerSelectionForm = this.fb.group({
        searchTerm: "",
        searchOrder: ""
      });
      this.subscription.add(this.customerSelectionForm.controls.searchOrder.valueChanges.pipe(debounceTime(300)).subscribe((searchTermValue) => {
        this.searchByCustomer = false;
        this.searchByOrder = true;
        this.handleSearchByOrder(searchTermValue);
      }));
    } else {
      this.customerSelectionForm = this.fb.group({
        searchTerm: ["", Validators.required]
      });
    }
    this.asmService.customerSearchReset();
    this.searchResultsLoading$ = this.asmService.getCustomerSearchResultsLoading();
    this.searchResults = this.asmService.getCustomerSearchResults();
    this.subscription.add(this.customerSelectionForm.controls.searchTerm.valueChanges.pipe(debounceTime(300)).subscribe((searchTermValue) => {
      if (this.isShowSearchingCustomerByOrderInASM) {
        this.searchByCustomer = true;
        this.searchByOrder = false;
        this.handleSearchByCustomer(searchTermValue);
      } else {
        this.handleSearchTerm(searchTermValue);
      }
    }));
    this.subscription.add(this.searchResultsLoading$.subscribe((loading) => {
      this.isLoading = loading;
    }));
  }
  handleSearchTerm(searchTermValue) {
    if (!!this.selectedCustomer && searchTermValue !== this.selectedCustomer.name) {
      this.selectedCustomer = void 0;
    }
    if (Boolean(this.selectedCustomer)) {
      return;
    }
    this.asmService.customerSearchReset();
    this.activeFocusedButtonIndex = -1;
    if (searchTermValue.trim().length >= 3) {
      this.asmService.customerSearch({
        query: searchTermValue,
        pageSize: this.config.asm?.customerSearch?.maxResults
      });
    }
  }
  handleSearchByCustomer(searchTermValue) {
    if (!!this.selectedCustomer) {
      this.selectedCustomer = void 0;
    }
    if (!!this.customerSelectionForm.controls.searchOrder.value) {
      this.customerSelectionForm.controls.searchOrder.setValue(void 0, {
        emitEvent: false
      });
    }
    this.asmService.customerSearchReset();
    this.activeFocusedButtonIndex = -1;
    if (searchTermValue.trim().length >= 3) {
      this.asmService.customerSearch({
        query: searchTermValue,
        pageSize: this.config.asm?.customerSearch?.maxResults
      });
    }
  }
  handleSearchByOrder(searchOrderValue) {
    if (!!this.selectedCustomer) {
      this.selectedCustomer = void 0;
    }
    if (!!this.customerSelectionForm.controls.searchTerm.value) {
      this.customerSelectionForm.controls.searchTerm.setValue(void 0, {
        emitEvent: false
      });
    }
    this.asmService.customerSearchReset();
    this.activeFocusedButtonIndex = -1;
    if (searchOrderValue.trim().length >= 3) {
      this.asmService.customerSearch({
        orderId: searchOrderValue,
        pageSize: this.config.asm?.customerSearch?.maxResults
      });
    }
  }
  isNoResultMessageInfoVisible(results, searchFlag, searchElement) {
    const searchTermValid = searchElement.value.length >= 3;
    const hasEntries = !!results.entries && results.entries.length > 0;
    return !this.isLoading && searchTermValid && searchFlag && !hasEntries;
  }
  isSearchResultsVisible(results, searchFlag) {
    return !!results.entries && searchFlag && results.entries.length > 0;
  }
  selectCustomerFromList(event, customer) {
    this.selectedCustomer = customer;
    if (this.isShowSearchingCustomerByOrderInASM) {
      this.customerSelectionForm.controls.searchTerm.setValue(this.selectedCustomer.name, {
        emitEvent: false
      });
    } else {
      this.customerSelectionForm.controls.searchTerm.setValue(this.selectedCustomer.name);
    }
    this.asmService.customerSearchReset();
    if (!this.isShowSearchingCustomerByOrderInASM) {
      this.searchTerm.nativeElement.focus();
    }
    event.preventDefault();
    event.stopPropagation();
  }
  onSubmit() {
    if (this.isShowSearchingCustomerByOrderInASM) {
      if (!!this.selectedCustomer) {
        this.submitEvent.emit({
          customerId: this.selectedCustomer.customerId,
          parameters: {
            orderId: this.customerSelectionForm.controls.searchOrder.value
          }
        });
      } else {
        this.customerSelectionForm.markAllAsTouched();
      }
    } else {
      if (this.customerSelectionForm.valid && !!this.selectedCustomer) {
        this.submitEvent.emit({
          customerId: this.selectedCustomer.customerId
        });
      } else {
        this.customerSelectionForm.markAllAsTouched();
      }
    }
  }
  onDocumentClick(event) {
    if (Boolean(this.resultList)) {
      if (this.resultList.nativeElement.contains(event.target) || this.searchTerm.nativeElement.contains(event.target)) {
        return;
      } else {
        this.asmService.customerSearchReset();
      }
    }
  }
  closeResults(event) {
    this.asmService.customerSearchReset();
    this.searchTerm.nativeElement.focus();
    event.preventDefault();
    event.stopPropagation();
  }
  closeOrderSearchResults(event) {
    this.asmService.customerSearchReset();
    this.searchOrder.nativeElement.focus();
    event.preventDefault();
    event.stopPropagation();
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.asmService.customerSearchReset();
  }
  /**
   * set focus to the first searched item
   * @param event keyboard event
   */
  focusFirstItem(event) {
    event.preventDefault();
    this.activeFocusedButtonIndex = 0;
    this.updateItemIndex(this.activeFocusedButtonIndex);
  }
  /**
   * set mouse cursor to the end of search text
   * @param event keyboard event
   */
  setSelectionEnd(event) {
    event.preventDefault();
    if (this.searchTerm.nativeElement.value?.length) {
      const selectionStart = this.searchTerm.nativeElement.value.length;
      this.searchTerm.nativeElement.selectionStart = selectionStart;
      this.searchTerm.nativeElement.selectionEnd = selectionStart;
    }
  }
  /**
   * set mouse cursor to the end of search order text
   * @param event keyboard event
   */
  setOrderSearchSelectionEnd(event) {
    event.preventDefault();
    if (this.searchOrder.nativeElement.value?.length) {
      const selectionStart = this.searchOrder.nativeElement.value.length;
      this.searchOrder.nativeElement.selectionStart = selectionStart;
      this.searchOrder.nativeElement.selectionEnd = selectionStart;
    }
  }
  /**
   * set focus on previous searh result item.  If no previous item then go to end of item.
   * @param event keyboard event
   */
  focusPreviousChild(event) {
    event.preventDefault();
    this.activeFocusedButtonIndex--;
    if (this.activeFocusedButtonIndex < 0) {
      this.activeFocusedButtonIndex = this.searchResultItems.length - 1;
    }
    this.updateItemIndex(this.activeFocusedButtonIndex);
  }
  /**
   * set focus on next searh result item.  if no next item then go to the first item
   * @param event keyboard event
   */
  focusNextChild(event) {
    event.preventDefault();
    this.activeFocusedButtonIndex++;
    if (this.activeFocusedButtonIndex > this.searchResultItems.length - 1) {
      this.activeFocusedButtonIndex = 0;
    }
    this.updateItemIndex(this.activeFocusedButtonIndex);
  }
  /**
   * set focus to input search text
   * @param event keyboard event
   */
  focusInputText(event) {
    event.preventDefault();
    this.activeFocusedButtonIndex = -1;
    this.searchTerm.nativeElement.focus();
    if (this.searchTerm.nativeElement.value?.length) {
      let selectionPos = this.searchTerm.nativeElement.selectionEnd;
      const searchTermLength = this.searchTerm.nativeElement.value.length;
      if (this.isBackNavigation(event)) {
        selectionPos = selectionPos <= 0 ? 0 : selectionPos - 1;
      } else if (this.isForwardsNavigation(event)) {
        selectionPos = selectionPos >= searchTermLength ? searchTermLength : selectionPos + 1;
      } else if (event.code === "Home") {
        selectionPos = 0;
      } else if (event.code === "End") {
        selectionPos = searchTermLength;
      }
      this.searchTerm.nativeElement.selectionStart = selectionPos;
      this.searchTerm.nativeElement.selectionEnd = selectionPos;
    }
  }
  /**
   * set focus to order search input search text
   * @param event keyboard event
   */
  focusOrderSearchInputText(event) {
    event.preventDefault();
    this.activeFocusedButtonIndex = -1;
    this.searchOrder.nativeElement.focus();
    if (this.searchOrder.nativeElement.value?.length) {
      let selectionPos = this.searchOrder.nativeElement.selectionEnd;
      const searchTermLength = this.searchOrder.nativeElement.value.length;
      if (this.isBackNavigation(event)) {
        selectionPos = selectionPos <= 0 ? 0 : selectionPos - 1;
      } else if (this.isForwardsNavigation(event)) {
        selectionPos = selectionPos >= searchTermLength ? searchTermLength : selectionPos + 1;
      } else if (event.code === "Home") {
        selectionPos = 0;
      } else if (event.code === "End") {
        selectionPos = searchTermLength;
      }
      this.searchOrder.nativeElement.selectionStart = selectionPos;
      this.searchOrder.nativeElement.selectionEnd = selectionPos;
    }
  }
  /**
   * set focus to selected item
   * @param {number} selectedIndex - current selected item index
   */
  updateItemIndex(selectedIndex) {
    this.searchResultItems.toArray()?.[selectedIndex]?.nativeElement.focus();
  }
  createCustomer() {
    this.asmService.customerSearchReset();
    this.launchDialogService.openDialogAndSubscribe("ASM_CREATE_CUSTOMER_FORM", this.createCustomerLink);
    if (this.isShowSearchingCustomerByOrderInASM) {
      setTimeout(() => {
        this.searchTerm.nativeElement.blur();
      });
    }
  }
  /**
   * Verifies whether the user navigates into a subgroup of the main group menu.
   *
   * @param {KeyboardEvent} event - Keyboard event
   * @returns {boolean} -'true' if the user navigates into the subgroup, otherwise 'false'.
   * @protected
   */
  isForwardsNavigation(event) {
    return event.code === "ArrowRight" && this.isLTRDirection() || event.code === "ArrowLeft" && this.isRTLDirection();
  }
  /**
   * Verifies whether the user navigates from a subgroup back to the main group menu.
   *
   * @param {KeyboardEvent} event - Keyboard event
   * @returns {boolean} -'true' if the user navigates back into the main group menu, otherwise 'false'.
   * @protected
   */
  isBackNavigation(event) {
    return event.code === "ArrowLeft" && this.isLTRDirection() || event.code === "ArrowRight" && this.isRTLDirection();
  }
  isLTRDirection() {
    return this.directionService.getDirection() === DirectionMode.LTR;
  }
  isRTLDirection() {
    return this.directionService.getDirection() === DirectionMode.RTL;
  }
  static {
    this.ɵfac = function CustomerSelectionComponent_Factory(t) {
      return new (t || _CustomerSelectionComponent)(ɵɵdirectiveInject(UntypedFormBuilder), ɵɵdirectiveInject(AsmService), ɵɵdirectiveInject(AsmConfig), ɵɵdirectiveInject(DirectionService), ɵɵdirectiveInject(LaunchDialogService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CustomerSelectionComponent,
      selectors: [["cx-customer-selection"]],
      viewQuery: function CustomerSelectionComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c4, 5);
          ɵɵviewQuery(_c5, 5);
          ɵɵviewQuery(_c6, 5);
          ɵɵviewQuery(_c7, 5);
          ɵɵviewQuery(_c8, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.resultList = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.searchTerm = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.searchOrder = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.createCustomerLink = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.searchResultItems = _t);
        }
      },
      hostBindings: function CustomerSelectionComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          ɵɵlistener("click", function CustomerSelectionComponent_click_HostBindingHandler($event) {
            return ctx.onDocumentClick($event);
          }, false, ɵɵresolveDocument);
        }
      },
      outputs: {
        submitEvent: "submitEvent"
      },
      decls: 2,
      vars: 2,
      consts: [["searchTerm", ""], ["searchOrder", ""], ["resultList", ""], ["createCustomerLink", ""], ["searchResultItem", ""], [3, "formGroup", "ngSubmit", 4, "cxFeature"], [4, "cxFeature"], [3, "ngSubmit", "formGroup"], [1, "searchLabel"], ["required", "true", "type", "text", "formControlName", "searchTerm", 3, "keydown.arrowdown", "keydown.end", "placeholder"], [4, "ngIf"], ["class", "asm-results", 4, "ngIf"], ["required", "true", "type", "text", "formControlName", "searchOrder", 3, "keydown.arrowdown", "keydown.end", "placeholder"], ["type", "submit", 3, "disabled"], ["class", "cx-message cx-message-info selection-message-info", 4, "ngIf"], [1, "cx-message", "cx-message-info", "selection-message-info"], [1, "cx-message-content"], [1, "cx-message-header"], [1, "cx-message-icon"], ["ng-reflect-type", "INFO", 1, "cx-icon", "fas", "fa-info-circle"], [1, "cx-message-text"], [1, "linkStyleLabel", 3, "click"], [1, "asm-results"], [3, "tabindex", "active", "keydown.arrowup", "keydown.arrowdown", "keydown.arrowright", "keydown.arrowleft", "keydown.enter", "keydown.escape", "keydown.home", "keydown.end", "click", 4, "ngFor", "ngForOf"], [3, "keydown.arrowup", "keydown.arrowdown", "keydown.arrowright", "keydown.arrowleft", "keydown.enter", "keydown.escape", "keydown.home", "keydown.end", "click", "tabindex"], [1, "result-name"], [1, "result-id"], ["aria-hidden", "false"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["type", "submit"], [3, "translationParams", "control"], [3, "control"], [3, "active", "click", "keydown.escape", "keydown.arrowright", "keydown.arrowleft", "keydown.home", "keydown.end", 4, "ngIf"], [3, "click", "keydown.escape", "keydown.arrowright", "keydown.arrowleft", "keydown.home", "keydown.end"], [1, "linkStyleLabel"]],
      template: function CustomerSelectionComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CustomerSelectionComponent_form_0_Template, 26, 33, "form", 5)(1, CustomerSelectionComponent_div_1_Template, 16, 20, "div", 6);
        }
        if (rf & 2) {
          ɵɵproperty("cxFeature", "showSearchingCustomerByOrderInASM");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!showSearchingCustomerByOrderInASM");
        }
      },
      dependencies: [NgForOf, NgIf, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, FormErrorsComponent, IconComponent, FeatureDirective, DotSpinnerComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CustomerSelectionComponent, [{
    type: Component,
    args: [{
      selector: "cx-customer-selection",
      host: {
        "(document:click)": "onDocumentClick($event)"
      },
      template: `<form
  *cxFeature="'showSearchingCustomerByOrderInASM'"
  (ngSubmit)="onSubmit()"
  [formGroup]="customerSelectionForm"
>
  <span class="searchLabel">{{
    'asm.customerSearch.customer' | cxTranslate
  }}</span>
  <label>
    <input
      required="true"
      #searchTerm
      type="text"
      formControlName="searchTerm"
      [attr.aria-label]="
        'asm.customerSearch.searchCustomer.label' | cxTranslate
      "
      placeholder="{{
        'asm.customerSearch.searchCustomer.label' | cxTranslate
      }}"
      (keydown.arrowdown)="focusFirstItem($event)"
      (keydown.end)="setSelectionEnd($event)"
    />

    <div *ngIf="searchResults | async as results" #resultList>
      <div
        *ngIf="
          isNoResultMessageInfoVisible(results, searchByCustomer, searchTerm)
        "
        class="cx-message cx-message-info selection-message-info"
      >
        <div class="cx-message-content">
          <div class="cx-message-header">
            <span class="cx-message-icon">
              <cx-icon
                class="cx-icon fas fa-info-circle"
                ng-reflect-type="INFO"
              ></cx-icon>
            </span>
            <span class="cx-message-text"
              >{{ 'asm.customerSearch.noCustomerMatchResult' | cxTranslate }}
            </span>
            <span
              #createCustomerLink
              class="linkStyleLabel"
              (click)="createCustomer()"
            >
              {{ 'asm.customerSearch.createCustomer' | cxTranslate }}
            </span>
          </div>
        </div>
      </div>
      <div
        *ngIf="isSearchResultsVisible(results, searchByCustomer)"
        class="asm-results"
      >
        <button
          #searchResultItem
          *ngFor="let result of results.entries; let i = index"
          [tabindex]="activeFocusedButtonIndex === i ? 0 : -1"
          [attr.aria-selected]="activeFocusedButtonIndex === i"
          [class.active]="activeFocusedButtonIndex === i"
          (keydown.arrowup)="focusPreviousChild($event)"
          (keydown.arrowdown)="focusNextChild($event)"
          (keydown.arrowright)="focusInputText($event)"
          (keydown.arrowleft)="focusInputText($event)"
          (keydown.enter)="selectCustomerFromList($event, result)"
          (keydown.escape)="closeResults($event)"
          (keydown.home)="focusInputText($event)"
          (keydown.end)="focusInputText($event)"
          (click)="selectCustomerFromList($event, result)"
        >
          <div class="result-name">{{ result.name }}</div>
          <div class="result-id">
            <span>{{ result.uid }}</span>
          </div>
        </button>
      </div>
    </div>

    <div class="asm-results" *ngIf="isLoading && searchByCustomer">
      <cx-dot-spinner
        aria-hidden="false"
        [attr.aria-label]="'common.loading' | cxTranslate"
      ></cx-dot-spinner>
    </div>
  </label>
  <span class="searchLabel">{{
    'asm.customerSearch.orderID' | cxTranslate
  }}</span>

  <label>
    <input
      required="true"
      #searchOrder
      type="text"
      formControlName="searchOrder"
      [attr.aria-label]="'asm.customerSearch.searchOrder.label' | cxTranslate"
      placeholder="{{ 'asm.customerSearch.searchOrder.label' | cxTranslate }}"
      (keydown.arrowdown)="focusFirstItem($event)"
      (keydown.end)="setOrderSearchSelectionEnd($event)"
    />
    <div *ngIf="searchResults | async as results" #resultList>
      <div
        *ngIf="
          isNoResultMessageInfoVisible(results, searchByOrder, searchOrder)
        "
        class="cx-message cx-message-info selection-message-info"
      >
        <div class="cx-message-content">
          <div class="cx-message-header">
            <span class="cx-message-icon">
              <cx-icon
                class="cx-icon fas fa-info-circle"
                ng-reflect-type="INFO"
              ></cx-icon>
            </span>
            <span class="cx-message-text">
              {{ 'asm.customerSearch.noOrderMatchResult' | cxTranslate }}
            </span>
          </div>
        </div>
      </div>
      <div
        *ngIf="isSearchResultsVisible(results, searchByOrder)"
        class="asm-results"
      >
        <button
          #searchResultItem
          *ngFor="let result of results.entries; let i = index"
          [tabindex]="activeFocusedButtonIndex === i ? 0 : -1"
          [attr.aria-selected]="activeFocusedButtonIndex === i"
          [class.active]="activeFocusedButtonIndex === i"
          (keydown.arrowup)="focusPreviousChild($event)"
          (keydown.arrowdown)="focusNextChild($event)"
          (keydown.arrowright)="focusOrderSearchInputText($event)"
          (keydown.arrowleft)="focusOrderSearchInputText($event)"
          (keydown.enter)="selectCustomerFromList($event, result)"
          (keydown.escape)="closeOrderSearchResults($event)"
          (keydown.home)="focusOrderSearchInputText($event)"
          (keydown.end)="focusOrderSearchInputText($event)"
          (click)="selectCustomerFromList($event, result)"
        >
          <div class="result-name">{{ searchOrder.value }}</div>
          <div class="result-id">
            <span>{{ result.name }}</span>
          </div>
        </button>
      </div>
    </div>

    <div class="asm-results" *ngIf="isLoading && searchByOrder">
      <cx-dot-spinner
        aria-hidden="false"
        [attr.aria-label]="'common.loading' | cxTranslate"
      ></cx-dot-spinner>
    </div>
  </label>

  <button
    type="submit"
    [class.active]="selectedCustomer"
    [disabled]="!selectedCustomer"
  >
    {{ 'asm.customerSearch.submit' | cxTranslate }}
  </button>
</form>

<div *cxFeature="'!showSearchingCustomerByOrderInASM'">
  <form (ngSubmit)="onSubmit()" [formGroup]="customerSelectionForm">
    <label>
      <input
        required="true"
        #searchTerm
        type="text"
        formControlName="searchTerm"
        [attr.aria-label]="'asm.customerSearch.searchTerm.label' | cxTranslate"
        placeholder="{{ 'asm.customerSearch.searchTerm.label' | cxTranslate }}"
        (keydown.arrowdown)="focusFirstItem($event)"
        (keydown.end)="setSelectionEnd($event)"
      />

      <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
      <cx-form-errors
        *cxFeature="'formErrorsDescriptiveMessages'"
        [translationParams]="{
          label: 'asm.customerSearch.searchTerm.label' | cxTranslate,
        }"
        [control]="customerSelectionForm.get('searchTerm')"
      ></cx-form-errors>

      <cx-form-errors
        *cxFeature="'!formErrorsDescriptiveMessages'"
        [control]="customerSelectionForm.get('searchTerm')"
      ></cx-form-errors>
    </label>
    <button type="submit" [class.active]="selectedCustomer">
      {{ 'asm.customerSearch.submit' | cxTranslate }}
    </button>
  </form>

  <div *ngIf="searchResults | async as results" class="asm-results" #resultList>
    <button
      #searchResultItem
      *ngFor="let result of results.entries; let i = index"
      [tabindex]="activeFocusedButtonIndex === i ? 0 : -1"
      [attr.aria-selected]="activeFocusedButtonIndex === i"
      [class.active]="activeFocusedButtonIndex === i"
      (keydown.arrowup)="focusPreviousChild($event)"
      (keydown.arrowdown)="focusNextChild($event)"
      (keydown.arrowright)="focusInputText($event)"
      (keydown.arrowleft)="focusInputText($event)"
      (keydown.enter)="selectCustomerFromList($event, result)"
      (keydown.escape)="closeResults($event)"
      (keydown.home)="focusInputText($event)"
      (keydown.end)="focusInputText($event)"
      (click)="selectCustomerFromList($event, result)"
    >
      <span class="result-name">{{ result.name }}</span>
      <span class="result-id">{{ result.uid }}</span>
    </button>

    <button
      #searchResultItem
      (click)="createCustomer()"
      (keydown.escape)="closeResults($event)"
      (keydown.arrowright)="focusInputText($event)"
      (keydown.arrowleft)="focusInputText($event)"
      (keydown.home)="focusInputText($event)"
      (keydown.end)="focusInputText($event)"
      [class.active]="activeFocusedButtonIndex === 0"
      [attr.aria-selected]="activeFocusedButtonIndex === 0"
      *ngIf="
        !(searchResultsLoading$ | async) &&
        searchTerm.value.length >= 3 &&
        !!results.entries &&
        results.entries.length <= 0
      "
    >
      <span>{{ 'asm.customerSearch.noMatchResult' | cxTranslate }}</span>
      <span #createCustomerLink class="linkStyleLabel">{{
        'asm.customerSearch.createCustomer' | cxTranslate
      }}</span>
    </button>
  </div>

  <div class="asm-results" *ngIf="searchResultsLoading$ | async">
    <cx-dot-spinner
      aria-hidden="false"
      [attr.aria-label]="'common.loading' | cxTranslate"
    ></cx-dot-spinner>
  </div>
</div>
`
    }]
  }], () => [{
    type: UntypedFormBuilder
  }, {
    type: AsmService
  }, {
    type: AsmConfig
  }, {
    type: DirectionService
  }, {
    type: LaunchDialogService
  }], {
    submitEvent: [{
      type: Output
    }],
    resultList: [{
      type: ViewChild,
      args: ["resultList"]
    }],
    searchTerm: [{
      type: ViewChild,
      args: ["searchTerm"]
    }],
    searchOrder: [{
      type: ViewChild,
      args: ["searchOrder"]
    }],
    createCustomerLink: [{
      type: ViewChild,
      args: ["createCustomerLink"]
    }],
    searchResultItems: [{
      type: ViewChildren,
      args: ["searchResultItem"]
    }]
  });
})();
var FormatTimerPipe = class _FormatTimerPipe {
  transform(totalSeconds) {
    if (totalSeconds < 0) {
      totalSeconds = 0;
    }
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    let zeroPaddedMinutes;
    if (minutes < 10) {
      zeroPaddedMinutes = ("00" + minutes).slice(-2);
    } else {
      zeroPaddedMinutes = minutes + "";
    }
    const zeroPaddedSeconds = ("00" + seconds).slice(-2);
    return `${zeroPaddedMinutes}:${zeroPaddedSeconds}`;
  }
  static {
    this.ɵfac = function FormatTimerPipe_Factory(t) {
      return new (t || _FormatTimerPipe)();
    };
  }
  static {
    this.ɵpipe = ɵɵdefinePipe({
      name: "formatTimer",
      type: _FormatTimerPipe,
      pure: true
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormatTimerPipe, [{
    type: Pipe,
    args: [{
      name: "formatTimer"
    }]
  }], null, null);
})();
var AsmSessionTimerComponent = class _AsmSessionTimerComponent {
  constructor(config, asmComponentService, routingService, changeDetectorRef, userIdService) {
    this.config = config;
    this.asmComponentService = asmComponentService;
    this.routingService = routingService;
    this.changeDetectorRef = changeDetectorRef;
    this.userIdService = userIdService;
    this.subscriptions = new Subscription();
    this.maxStartDelayInSeconds = 6e4;
  }
  ngOnInit() {
    this.initTimer();
    this.interval = setInterval(() => {
      const currentSeconds = (/* @__PURE__ */ new Date()).getTime() / 1e3;
      this.timeLeft = Math.floor(this.expiredTime - currentSeconds);
      if (this.timeLeft <= 0) {
        clearInterval(this.interval);
        this.asmComponentService.logoutCustomerSupportAgentAndCustomer();
      }
      this.changeDetectorRef.markForCheck();
    }, 1e3);
    this.resetOnNavigate();
    this.resetOnCustomerSessionChange();
  }
  resetOnNavigate() {
    this.subscriptions.add(this.routingService.isNavigating().subscribe((isNavigating) => {
      if (isNavigating) {
        this.resetTimer();
      }
    }));
  }
  resetOnCustomerSessionChange() {
    this.subscriptions.add(this.userIdService.getUserId().pipe(distinctUntilChanged()).subscribe(() => this.resetTimer()));
  }
  initTimer() {
    const timeoutPropertyInSeconds = this.getTimerStartDelayInSeconds();
    const currentSeconds = (/* @__PURE__ */ new Date()).getTime() / 1e3;
    this.timeLeft = timeoutPropertyInSeconds;
    this.expiredTime = currentSeconds + this.timeLeft;
  }
  resetTimer() {
    if (this.timeLeft > 0) {
      this.initTimer();
    }
  }
  getTimerStartDelayInSeconds() {
    if (this.config.asm?.agentSessionTimer?.startingDelayInSeconds === void 0) {
      return 600;
    }
    if (this.config.asm.agentSessionTimer.startingDelayInSeconds > this.maxStartDelayInSeconds) {
      return this.maxStartDelayInSeconds;
    } else {
      return this.config.asm.agentSessionTimer.startingDelayInSeconds;
    }
  }
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    if (this.interval) {
      clearInterval(this.interval);
    }
  }
  static {
    this.ɵfac = function AsmSessionTimerComponent_Factory(t) {
      return new (t || _AsmSessionTimerComponent)(ɵɵdirectiveInject(AsmConfig), ɵɵdirectiveInject(AsmComponentService), ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(UserIdService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmSessionTimerComponent,
      selectors: [["cx-asm-session-timer"]],
      decls: 9,
      vars: 12,
      consts: [[1, "label"], [1, "time"], [1, "reset", 3, "click", "title"]],
      template: function AsmSessionTimerComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "span", 0);
          ɵɵtext(1);
          ɵɵpipe(2, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(3, "span", 1);
          ɵɵtext(4);
          ɵɵpipe(5, "formatTimer");
          ɵɵpipe(6, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(7, "button", 2);
          ɵɵpipe(8, "cxTranslate");
          ɵɵlistener("click", function AsmSessionTimerComponent_Template_button_click_7_listener() {
            return ctx.resetTimer();
          });
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵtextInterpolate1("", ɵɵpipeBind1(2, 4, "asm.agentSessionTimer.label"), ":");
          ɵɵadvance(3);
          ɵɵtextInterpolate2("", ɵɵpipeBind1(5, 6, ctx.timeLeft), " ", ɵɵpipeBind1(6, 8, "asm.agentSessionTimer.minutes"), "");
          ɵɵadvance(3);
          ɵɵpropertyInterpolate("title", ɵɵpipeBind1(8, 10, "asm.agentSessionTimer.reset"));
        }
      },
      dependencies: [TranslatePipe, FormatTimerPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmSessionTimerComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-session-timer",
      template: `<span class="label">{{ 'asm.agentSessionTimer.label' | cxTranslate }}:</span>
<span class="time"
  >{{ timeLeft | formatTimer }}
  {{ 'asm.agentSessionTimer.minutes' | cxTranslate }}</span
>
<button
  class="reset"
  title="{{ 'asm.agentSessionTimer.reset' | cxTranslate }}"
  (click)="resetTimer()"
></button>
`
    }]
  }], () => [{
    type: AsmConfig
  }, {
    type: AsmComponentService
  }, {
    type: RoutingService
  }, {
    type: ChangeDetectorRef
  }, {
    type: UserIdService
  }], null);
})();
var CustomerEmulationComponent = class _CustomerEmulationComponent {
  constructor(asmComponentService, userAccountFacade, launchDialogService, featureModules) {
    this.asmComponentService = asmComponentService;
    this.userAccountFacade = userAccountFacade;
    this.launchDialogService = launchDialogService;
    this.featureModules = featureModules;
    this.isAsmCustomer360Configured = false;
    this.isAsmCustomer360Loaded$ = new BehaviorSubject(false);
    this.subscription = new Subscription();
    this.featureConfig = inject(FeatureConfigService);
    this.isShowStyleChangesInASM = this.featureConfig.isEnabled("showStyleChangesInASM");
  }
  ngOnInit() {
    this.isAsmCustomer360Configured = this.featureModules?.isConfigured("asmCustomer360");
    if (this.isAsmCustomer360Configured) {
      this.featureModules?.resolveFeature("asmCustomer360").subscribe(() => {
        this.isAsmCustomer360Loaded$.next(true);
      });
    }
    this.subscription.add(this.userAccountFacade.get().subscribe((user) => {
      if (user) {
        this.customer = user;
      }
    }));
    this.isCustomerEmulationSessionInProgress$ = this.asmComponentService.isCustomerEmulationSessionInProgress();
  }
  logoutCustomer() {
    this.asmComponentService.logoutCustomer();
  }
  openAsmCustomer360() {
    this.subscription.add(this.isAsmCustomer360Loaded$.pipe(filter((isReady) => Boolean(isReady))).subscribe(() => {
      const data = {
        customer: this.customer
      };
      this.launchDialogService?.openDialogAndSubscribe("ASM_CUSTOMER_360", this.asmCustomer360LauncherElement, data);
      this.subscription.add(this.launchDialogService?.dialogClose.pipe(filter((result) => Boolean(result))).subscribe((event) => {
        this.asmComponentService.handleAsmDialogAction(event);
      }));
    }));
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static {
    this.ɵfac = function CustomerEmulationComponent_Factory(t) {
      return new (t || _CustomerEmulationComponent)(ɵɵdirectiveInject(AsmComponentService), ɵɵdirectiveInject(UserAccountFacade), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(FeatureModulesService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CustomerEmulationComponent,
      selectors: [["cx-customer-emulation"]],
      viewQuery: function CustomerEmulationComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c9, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.asmCustomer360LauncherElement = _t.first);
        }
      },
      decls: 2,
      vars: 3,
      consts: [["asmCustomer360Launcher", ""], [4, "ngIf"], [1, "cx-asm-customerInfo"], [1, "cx-asm-name"], [1, "cx-asm-uid"], ["class", "cx-360-button", 3, "click", 4, "ngIf"], ["formcontrolname", "logoutCustomer", 3, "click"], [1, "cx-360-button", 3, "click"]],
      template: function CustomerEmulationComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CustomerEmulationComponent_ng_container_0_Template, 12, 7, "ng-container", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.isCustomerEmulationSessionInProgress$));
        }
      },
      dependencies: [NgIf, AsmBindCartComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CustomerEmulationComponent, [{
    type: Component,
    args: [{
      selector: "cx-customer-emulation",
      template: `<ng-container *ngIf="isCustomerEmulationSessionInProgress$ | async">
  <div class="cx-asm-customerInfo">
    <label class="cx-asm-name">{{ customer?.name }}</label>
    <label class="cx-asm-uid">{{ customer?.uid }}</label>
  </div>
  <cx-asm-bind-cart></cx-asm-bind-cart>
  <button
    *ngIf="isAsmCustomer360Configured && customer && isShowStyleChangesInASM"
    #asmCustomer360Launcher
    class="cx-360-button"
    (click)="openAsmCustomer360()"
  >
    {{ 'asm.asmCustomer360ViewButton' | cxTranslate }}
  </button>
  <button
    *ngIf="isAsmCustomer360Configured && customer && !isShowStyleChangesInASM"
    #asmCustomer360Launcher
    class="cx-360-button"
    (click)="openAsmCustomer360()"
  >
    {{ 'asm.asmCustomer360Button' | cxTranslate }}
  </button>
  <button formcontrolname="logoutCustomer" (click)="logoutCustomer()">
    {{ 'asm.endSession' | cxTranslate }}
  </button>
</ng-container>
`
    }]
  }], () => [{
    type: AsmComponentService
  }, {
    type: UserAccountFacade
  }, {
    type: LaunchDialogService
  }, {
    type: FeatureModulesService
  }], {
    asmCustomer360LauncherElement: [{
      type: ViewChild,
      args: ["asmCustomer360Launcher"]
    }]
  });
})();
var AsmToggleUiComponent = class _AsmToggleUiComponent {
  constructor(asmService) {
    this.asmService = asmService;
    this.subscription = new Subscription();
  }
  ngOnInit() {
    this.subscription.add(this.asmService.getAsmUiState().subscribe((uiState) => {
      this.isCollapsed = uiState.collapsed === void 0 ? false : uiState.collapsed;
    }));
  }
  toggleUi() {
    this.asmService.updateAsmUiState({
      collapsed: !this.isCollapsed
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static {
    this.ɵfac = function AsmToggleUiComponent_Factory(t) {
      return new (t || _AsmToggleUiComponent)(ɵɵdirectiveInject(AsmService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmToggleUiComponent,
      selectors: [["cx-asm-toggle-ui"]],
      decls: 4,
      vars: 3,
      consts: [["tabindex", "0", "role", "button", 1, "toggleUi", 3, "click"], [3, "ngClass"], ["class", "label", 4, "ngIf"], [1, "label"]],
      template: function AsmToggleUiComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "a", 0);
          ɵɵlistener("click", function AsmToggleUiComponent_Template_a_click_0_listener() {
            return ctx.toggleUi();
          });
          ɵɵelement(1, "span", 1);
          ɵɵtemplate(2, AsmToggleUiComponent_span_2_Template, 3, 3, "span", 2)(3, AsmToggleUiComponent_span_3_Template, 3, 3, "span", 2);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵproperty("ngClass", !ctx.isCollapsed ? "collapseIcon" : "expandIcon");
          ɵɵadvance();
          ɵɵproperty("ngIf", !ctx.isCollapsed);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.isCollapsed);
        }
      },
      dependencies: [NgClass, NgIf, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmToggleUiComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-toggle-ui",
      template: `<a class="toggleUi" (click)="toggleUi()" tabindex="0" role="button">
  <span [ngClass]="!isCollapsed ? 'collapseIcon' : 'expandIcon'"></span>
  <span *ngIf="!isCollapsed" class="label">
    {{ 'asm.toggleUi.collapse' | cxTranslate }}
  </span>
  <span *ngIf="isCollapsed" class="label">
    {{ 'asm.toggleUi.expand' | cxTranslate }}
  </span>
</a>
`
    }]
  }], () => [{
    type: AsmService
  }], null);
})();
var CART_TYPE_KEY = {
  active: "asm.activeCartAlertInfo",
  inactive: "asm.saveInactiveCartAlertInfo"
};
var AsmMainUiComponent = class _AsmMainUiComponent {
  constructor(authService, csAgentAuthService, asmComponentService, globalMessageService, routingService, asmService, userAccountFacade, launchDialogService) {
    this.authService = authService;
    this.csAgentAuthService = csAgentAuthService;
    this.asmComponentService = asmComponentService;
    this.globalMessageService = globalMessageService;
    this.routingService = routingService;
    this.asmService = asmService;
    this.userAccountFacade = userAccountFacade;
    this.launchDialogService = launchDialogService;
    this.iconTypes = ICON_TYPE;
    this.showDeeplinkCartInfoAlert$ = this.asmComponentService.shouldShowDeeplinkCartInfoAlert();
    this.deeplinkCartAlertKey = "";
    this.showCreateCustomerSuccessfullyAlert = false;
    this.globalMessageType = GlobalMessageType;
    this.disabled = false;
    this.startingCustomerSession = false;
    this.showCustomerEmulationInfoAlert = true;
    this.subscription = new Subscription();
  }
  ngOnInit() {
    this.customerSupportAgentLoggedIn$ = this.csAgentAuthService.isCustomerSupportAgentLoggedIn().pipe(distinctUntilChanged(), tap((loggedIn) => {
      if (!loggedIn) {
        this.closeModal();
      }
    }));
    this.csAgentTokenLoading$ = this.csAgentAuthService.getCustomerSupportAgentTokenLoading();
    this.customer$ = this.authService.isUserLoggedIn().pipe(switchMap((isLoggedIn) => {
      if (isLoggedIn) {
        this.handleCustomerSessionStartRedirection();
        return this.userAccountFacade.get();
      } else {
        return of(void 0);
      }
    }));
    this.isCollapsed$ = this.asmService.getAsmUiState().pipe(map((uiState) => uiState.collapsed === void 0 ? false : uiState.collapsed));
    this.subscription.add(this.launchDialogService.dialogClose.pipe(filter((result) => Boolean(result))).subscribe((result) => {
      if (typeof result !== "string") {
        if ("selectedUser" in result) {
          this.startCustomerEmulationSession(result.selectedUser);
          if (result.actionType === CustomerListColumnActionType.ORDER_HISTORY) {
            this.routingService.go({
              cxRoute: "orders"
            });
          }
        } else if ("customerId" in result) {
          this.startCustomerEmulationSession({
            customerId: result.customerId
          });
          this.showCreateCustomerSuccessfullyAlert = true;
          this.routingService.go("/");
        }
        if ("actionType" in result && result.actionType === CustomerListColumnActionType.ACTIVE_CART) {
          this.routingService.go({
            cxRoute: "cart"
          });
        } else if ("actionType" in result && result.actionType === CustomerListColumnActionType.CUSTOMER_360) {
          this.customer$.pipe(filter((curCustomer) => !!curCustomer), take(1)).subscribe((customer) => {
            setTimeout(() => {
              this.showC360Dialog(customer);
            }, 500);
          });
        }
      }
    }));
    this.subscribeForDeeplink();
  }
  showC360Dialog(customer) {
    const data = {
      customer
    };
    this.launchDialogService.openDialogAndSubscribe("ASM_CUSTOMER_360", this.element, data);
    this.subscription.add(this.launchDialogService.dialogClose.pipe(filter((closeContent) => Boolean(closeContent))).subscribe((event) => {
      this.asmComponentService.handleAsmDialogAction(event);
    }));
  }
  /**
   * When agent is logged in and deep link has customerID,
   * call logout if has customer emulated(userLoggedin) but not emulated by deep link.
   * call startSessionWithParameters
   */
  subscribeForDeeplink() {
    if (this.asmComponentService.isEmulateInURL()) {
      this.routingService.go("/");
    }
    const parameters = this.asmComponentService.getDeepLinkUrlParams() ?? {
      customerId: this.asmComponentService.getSearchParameter("customerId"),
      orderId: this.asmComponentService.getSearchParameter("orderId"),
      ticketId: this.asmComponentService.getSearchParameter("ticketId"),
      cartId: this.asmComponentService.getSearchParameter("cartId"),
      cartType: this.asmComponentService.getSearchParameter("cartType"),
      emulated: false
    };
    this.deeplinkCartAlertKey = CART_TYPE_KEY[parameters.cartType || ""];
    this.subscription.add(combineLatest([this.customerSupportAgentLoggedIn$, this.authService.isUserLoggedIn(), this.asmComponentService.isEmulatedByDeepLink()]).subscribe(([agentLoggedIn, userLoggedin, isEmulatedByDeepLink]) => {
      if (agentLoggedIn && parameters.customerId) {
        if (!isEmulatedByDeepLink && userLoggedin) {
          this.confirmSwitchCustomer(parameters.customerId);
        } else {
          setTimeout(() => this.startSessionWithParameters(__spreadProps(__spreadValues({}, parameters), {
            emulated: isEmulatedByDeepLink
          })));
        }
      }
    }));
  }
  confirmSwitchCustomer(switchCustomerId) {
    this.customer$.pipe(filter((curCustomer) => !!curCustomer), take(1)).subscribe((curCustomer) => {
      if (curCustomer?.customerId !== switchCustomerId) {
        this.userAccountFacade.getById(switchCustomerId).subscribe({
          next: (switchCustomer) => {
            this.launchDialogService.openDialogAndSubscribe("ASM_SWITCH_CUSTOMER", this.element, {
              curCustomer,
              switchCustomer
            });
          },
          error: (error) => {
            this.globalMessageService.add(error.details?.[0].message ?? "", GlobalMessageType.MSG_TYPE_ERROR);
          }
        });
      } else {
        this.asmComponentService.setEmulatedByDeepLink(true);
      }
    });
  }
  /**
   * If url contains customerId and we haven't emulatedFromURL, we'll change the isEmulatedByDeepLink flag and
   * start emulate customer in URL.
   */
  startSessionWithParameters(parameters) {
    if (!parameters.emulated) {
      this.asmComponentService.setEmulatedByDeepLink(true);
      this.startCustomerEmulationSession({
        customerId: parameters.customerId
      }, parameters);
    }
  }
  handleCustomerSessionStartRedirection() {
    this.asmComponentService.isCustomerEmulationSessionInProgress().pipe(take(1)).subscribe((isCustomerEmulated) => {
      if (this.startingCustomerSession && isCustomerEmulated) {
        this.startingCustomerSession = false;
        this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_ERROR);
        this.routingService.go("/");
      }
    });
  }
  loginCustomerSupportAgent({
    userId,
    password
  }) {
    this.csAgentAuthService.authorizeCustomerSupportAgent(userId, password);
  }
  logout() {
    this.asmComponentService.logoutCustomerSupportAgentAndCustomer();
  }
  startCustomerEmulationSession({
    customerId
  }, parameters) {
    if (customerId) {
      this.csAgentAuthService.startCustomerEmulationSession(customerId);
      this.startingCustomerSession = true;
      this.showCustomerEmulationInfoAlert = true;
      this.showCreateCustomerSuccessfullyAlert = false;
      if (parameters) {
        this.asmComponentService.handleDeepLinkNavigation(__spreadValues({
          customerId
        }, parameters));
      }
    } else {
      this.globalMessageService.add({
        key: "asm.error.noCustomerId"
      }, GlobalMessageType.MSG_TYPE_ERROR);
    }
  }
  hideUi() {
    this.disabled = true;
    this.asmComponentService.unload();
  }
  showCustomList() {
    this.launchDialogService.openDialogAndSubscribe("ASM_CUSTOMER_LIST", this.element);
  }
  closeModal() {
    this.launchDialogService.closeDialog("logout");
  }
  createCustomer() {
    this.launchDialogService?.openDialogAndSubscribe("ASM_CREATE_CUSTOMER_FORM", this.addNewCustomerLink);
  }
  closeDialogConfirmationAlert() {
    this.showCreateCustomerSuccessfullyAlert = false;
  }
  closeDeeplinkCartInfoAlert() {
    this.asmComponentService.setShowDeeplinkCartInfoAlert(false);
  }
  closeCustomerEmulationInfoAlert() {
    this.showCustomerEmulationInfoAlert = false;
  }
  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
  static {
    this.ɵfac = function AsmMainUiComponent_Factory(t) {
      return new (t || _AsmMainUiComponent)(ɵɵdirectiveInject(AuthService), ɵɵdirectiveInject(CsAgentAuthService), ɵɵdirectiveInject(AsmComponentService), ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(AsmService), ɵɵdirectiveInject(UserAccountFacade), ɵɵdirectiveInject(LaunchDialogService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmMainUiComponent,
      selectors: [["cx-asm-main-ui"]],
      viewQuery: function AsmMainUiComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c10, 5);
          ɵɵviewQuery(_c11, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.addNewCustomerLink = _t.first);
        }
      },
      hostVars: 2,
      hostBindings: function AsmMainUiComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassProp("hidden", ctx.disabled);
        }
      },
      decls: 27,
      vars: 30,
      consts: [["customerListLink", ""], ["showLoginForm", ""], ["showCustomerSelection", ""], [1, "asm-bar"], [1, "asm-bar-branding"], ["src", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAwCAYAAADuFn/PAAAAAXNSR0IArs4c6QAAD7RJREFUeAHtW3twVGcVP7t795V30rwJBBJeASq01NJgnZa2otTW2nHAqrRak+rUKfgYZ/xDW5lRR2e0/mGtAadqq6WjUAdNa4udqVZaEdtCKQ2FQEh5JSQh5Lnvp7/ft9lkd9l7swkhwMiZ3N27937fd8533ufcG9P1L/VE5SpMOwdMmk0iocDzWjAUnnbk/9cITSYx2xwS9Xs3Wzs7NmqhcOT/mh/Tunkw32SzScjr2Vy2v3XDa5tWhbRI5KoHmi4hmGx2ifi8mz8UmvHI9k2VyvVokasWMC38N8HtRHyezUejex5pXbdu1O9r5qsCuLgCUD4fmu/1bq5sbd9wdNMY84lYM10VwMUTAJlvtUnU491c0XZc+fxUZFo0Mn4QjiJMMFREcKJG4xxrC/7ETCQ854+JAtbBny5Mak3d1ab3BsKtCrhhuJ2K9lNpmU+KYAHpWRAFa4K4x7t5NouU5WhS4rRIvt0idotJ3MGIDPgj0usNSZ8vLMOBiIQhJQukoZkpHGOJcGXLiPD0WBNStOmvQ8ETAjp7iN0d++RelBLhBFsAnVQe/fXHZk7wDEuarXaJBrxNFe2nNzLb0VsBMWA0HoyO8WNDDnDxIzOy5ONzcuX6MqdU5VhxLZlYWoUvFJEud0iODQZkb5dXHa19PnEFw2LDBi0QRqqac14BBPnz2yul0GEZxZt68vzhQXm6pS+Gl9xLANL4uUWFsm5hPmiIjiPu2EQqSY8nJCeHAnK4zy+tOLrdQXXTClqVLFLwJKDM7BSLmMD8iN/btCRn3obtm+adz+CElTTlW0YuEDe1qR6M//oNJXJDRVbC0PNPqYFZVrPUFNjU8bHqHGUF3NxLx4ZkZ/uQdLnOF34Acad+To6srDRe/7ML8+T5Q/3KEpNFD5lijVKnWa4tdpxPWIZXeiGM/3S65Y/vD8hbnR6lLBdkEdR8DZrv9zUtyT+wYfu6+YbMJ5mjQZjMZ1H20HXF8s0VZWKjjU4C6IIWgyk8PlqVLY0vnhDGkMTVNJjA3bV5464+t9AhS4vtsqfDBWuiKY0Bk4dIhq5nbFbyWXGWJnfPzZc1NRT0gDy+p1uG/WHlmpJHZvALG6TmR/2epoOFBzccTEg1jWabTXBBpkhYgoGQNCy9Rr6zsnzSzE9ERKZvazknAX9IzFhf4QGuMFofNXmarKjMThye9pwWtqYmV6Jwc2R4fI3Rb/qyKQDGgvsWF8ovVlcJSEOPJsaTUTzkkdGBRMZstorA7SwqXLRBMmQ+STczC/IHwnA3TvlGfdkUbCe2xBsnhmVna79YTQi3YB7x8AhA0LfPzpNsW7JG6yG+BWOLHWYJgwHxNUa/KeUphPqZOfKt+nKlJIk0j+Ib2UPyb8QfMD/q8zYV9/Ru3L7ONK7bSSTZHIUZm6FJDdeXIrsZnynMdBh4jfbuR1B8YnenhBCIVZZFV4GDuLLh2j4xLz+RBsPzylyrspYAlIRrJB1TZAGJBHxmUZFcV5YFRUmDLxU/fpP5aC80Fff1GWY7iTgSzzWa26wCu6yA9I3g7VPDsu1Ar3zQ75MAGEwNLnBoUgtfv2JmriybkSM5SFcJO1p65Z3Tw2JnPgqtiUMIgluGsXUlzviljL7vnF8gLx86h7UShnNdIy3A0NeODcrrHwwqn56LrKv2GtA6K0+K4Pv1wAoF+STw7T05lBy4kibQ8lhkMdvxNZUMD06K+VxSC0NLawtto8xLwjPyYx+Y2bCtVVwjAYrpGvdOBXzlcFSeguVUF9rlzroiuXlOgfzmv2fEwgFwG4kQhitag80xUE8EbgLTZsISOgb9Y3MhzPEE8NapIdmyu0McyNRIDjOcmVC2x1ZXy621BbokLK/KEZQ8CPLJ9I9OwDpm9POR7fzqYPXyjTJBtzO6Dk4QH8MosPQ1goND4DSDNFCKDT4dHk99O8xRRSjKaTnR65Ff7jolX37ufTnT78UYBE1oafygT2Uhd9vcwkT8GZ3noVa4tSY/5tIS1jQBrxFYIWdkqurIAkMdoL2jzyvf/1u7dA8HdKdW5FmlCHEnFozH9qASAfDCYtLYz2+qe7P9gphPAhADEBipTQZwIzTwJ3fVSmm2VTy+kARgNeyiqkDFbzDFooQioh7w4PfovZFxDL7U5Mp8W1pMrLppYXqwBtbFuJ2MF2ptAFEwK4kO0MWkoGPAK/s7hnVnMhZmw30m4eI+aEZgPtzOr+pqTmzYvj25saa7oMENiDIq3UN+gyGxW5+6tkRurM6XHe/2yIstZ6XtrEcJTgOxTOPoluIVbypb+JvK+slF1+jiae/1yuvH+qVx5Yy0Y66tzJX5xVnScsYlrFpZA5AfRkCGcVwEljoKoDOMaz5UxXqgIQ7Aa6lxo1Mxj3l+OOD73eEFKze2rKvX1xa9hdNcx1aicqjLJb0ufZOMzyvPs8nDH62SPzculWceWAJmVUkNAlsAgdwFywhCS0LQstTDz0BfZJebEB/0YM8HA7Jjf7eqpNONYWF4x4JC8QVDav0g8LCvYwS8z3GJ9NDaEY9lfql+Fc4kg/sJJ8wNm20S9nu3+sKBr12Iz0+l10wtOQ2fTa3OFBjUbpqdL9/9xBz5y1eXyVNfWCy0EA0bc6Pw4oZJfPzwwWXdPr9IcrhzHdjV1icHod20LD1YXVes1qCgufZ4AmDKTOFTQUgDafPg+PwNFbIAqaYeuOEKe90B5XIUHgseIwa9W/3RYOPxTat8evMmc121o+m/m/51QlaBSdVFE0sRnVaLmse5LZ0ueeK14/IShKk6nbQvCDiLqd3iYl36uuAC950cFK8/KK9DEAvK0lfJc0uyZHlVrvzzyLmY+xnHAvIg8CpYrQM0ZiGAVF+TJXdDUe6+ttSwC9ra7ZJ+eASVraG3A5+/1VLqbmjfeOf4vlp3l+lvQAAoxHDvNLKDh7e+J1vWf0hmogczGVhSmSNbPr9EnvnPafnB344iINP8o3Lj7AJZDB+uB3va+6V70KcC+T9bz0nDyplpny8wzty1pFRePXQ2IwE8WD9DPgdtN2EiBWBFvMoEXnm/V/xwddnOLHY1n9OGfQ1tP5x65pMW1PgIRjiYYew/MSj3bdkrfz/YkwmdumO+WF8lP753IVLQqEod74LWscDRg1cP9ap+jxWMOgBL6BjQt/JVC4qkIgfv1JBurG8E1PyCLKvkI83OlPknoYgvvtslDjzDDQe8W8H8L7c9cXGYT9qRa2ETPJAZ2OEyTvS65StPvysP//6AvH18wGh/hvfWLq+QtcvLhW5g9aIS3bH96Mf/tw09IygAApL0DvlkdxuqXh0oy7PLzaglmNbGzEBn4CQuM2b86IUjctYFrxD0bTU5LI0Xk/kk0RxhMEs4GCbplnbs7ZC1T74lX9jytvzpzQ45Y6CVentdf1OVrIHLmGkQV/a098mpc24xgfmKDmj2Ky3GFnjX0jIIi3pjbAF6dKW7zjrksR2Hpfm9PtEi/q3RLG3KA246vBrdRCrQWTjgL1kJ/gPM4FGe75Dl8OV3LC6VW5CNVBSMHycWVuTKN1fXpi6f9Jsuh81Atq0JVIAPetwyhEedeToV+sraIvSgnOhank+7WmSCH0eRhv8Ymr8TzwSQ7zxr7rc9dPzxqc129Egy1Xz9paRd8Eeqt+Y1lVNjwzwvRz/l08tnyCNgbhH88YUAU8O2brd0IhX24zlzCVzMbGQ7FLDR06nvbTsodvitR++tmxT6QU9QDqEafuGdTmned0b6fSaxg/mRwa6Hjj/9oH4QmhQ2/UnnWQALFWYbDFpxQfCb+QMrRAqgH02xJ3celdOIF5sbl+NhRHykPiK9O9l2TZbOyleH3ph019fADe05qh8rOOeNw72y+0gv6I7thSnxOaSXp895YGUelfmxTnA4nGKPBrfCrTW2P/3glKea6eiPX9Ms8P9xYMq4/iOzlAvY09qrLttIfDr+QiLtnUMqflM40w3LqgtQNxh3A954v0cebz4szpE2OWnkXpiWMsdnC8XuQLaDgBs1WxoudsBNxyNYQEwAZP6c0hx5dO0SVUTthGlu//cJOXC8X4bx8JouSAkCJsAZOXgW8NAdtcoq0i18sa9lA//NC/WLO+Jnzygbb3Kkvs2haIMgzKhwI0g1oxbrJWE+6dAs9CmAIPzvA7fORsESaxfcc2OVfOrDVXKsa1gOnhyQDrSbB1Ce0y+XoVBbsaBEFs3M/MlWDMvUfjoSNDvdyrRM7i++x8QxJjI/6Hs2rFkveqqZiDf1XFkAU7B55Tny6fpZSfep8XORyfC4IoEtWFp4BBsZAb4wpv45Iuh/1uvvY8CdVp8fpyP+rbH4iSIQrV81B2kfnuxPA/AlgJ9tf0/KUR8sqi6U8kInyn6rCvpMAs6hGDuJVHQ/CrL7bquRuZXjv8KSjmy0/tWTOfV0bmSAcjsh/7OewMC0Zjvp6OM1ja+J1MGVrL1ljt6YKb/ehuD93KvHVJfSjnaB06aJNvLWHRXWj86lF+mpF4IqRTo6WQHwAQULPB4EExtrYL7X6Wg8/utLq/lxpppZUfrQ+37tnTNq4/Ebk/lmoH793TOKeUbzd2EM35jIBvMZcfxgthvxhYfXizYwqmEnnkjxIf+/W7rQqoox0GjNdPdoASw0eZjRzxf4fG+H45L6/FQ6zVS8M2dd8u0nd8v9P/yH/H7nETnd40odZ/ib7NmHfPurP90lbx7uESdyeyPYtb8TjwbBHAiMLpDtcAoifvAa7/Hd0kNoVUyUnjhu9b4n10fANQX8f3BndTa2vXzxGmtxvBP5Nl33pW1KvUCnejWR2laEarQOvnnZvGKpm10olXgUWJhrFxs0lsCxLk9AulG9toBBb0Cj6a/d3qCsva1W5lTQZ6tl1fjEj0Fo+XOvHAUuMHksNiYOSTpnS/tOJAcLZvFhfvo1kyYk/Njd0i1vHxlAbAltc3VlP3C5MZ+kmq574E/n7YquhO+JsuPLgsWJjiaDZLylywk+uI1hMJzpKythK1wGGcrfRi6DYyjIDHgfYyUGBrDmZP6XzWZHO0NCzR6LfX3rb+/Rfwofw3RJPrV4gErErlwBKmDlE3AjDAYMBn1J3V8ykk+9NPaRCTQL/KmXeg16/6Nj1UkGH1iT/48AZBkMHhvCt5Qj4UCzW3NctswntRr5lgmo/DmVBzGeZzJ9WseQ+eFgoNkz5Frf2vzZy1Lz4wxBDM5QAvEZl/m32cJUE8y3kfkNlzXzyUr1XtBlztOMyVNuJ+Rvdg571u+7Apg/IoCM93dZD+S7mnA7f/W4PPdfKcwfEcCV74KU26HPd3vvvxLcTqImX4pWfiL+Cz7nf6ZEI8G/ut3eK8Lnp254pAOTevnK+G0yI4RFQvtzQ9r6vc0NEyvfL5Mt/g8XIbTVhsig+gAAAABJRU5ErkJggg==", "width", "48", "height", "24", 1, "logo", 3, "alt", "title"], [1, "asm-title"], [1, "asm-bar-actions"], [1, "cx-asm-help-portal"], ["href", "https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/d1ca9a1517f847a5b57b4e08400807c1/2367ff04ccb649ac82a3795ecf72a804.html?locale=en-US", "target", "_blank", "rel", "noopener noreferrer", "role", "button"], [3, "type"], ["class", "cx-asm-customer-list", 4, "ngIf"], [4, "ngIf"], ["class", "close", 3, "title", "click", 4, "ngIf"], ["class", "logout", 3, "title", "click", 4, "ngIf"], [1, "cx-asm-customer-list"], ["tabindex", "0", "role", "button", 1, "cx-asm-customer-list-link", 3, "click"], [1, "close", 3, "click", "title"], [1, "logout", 3, "click", "title"], [4, "ngIf", "ngIfElse"], [3, "text", "type", "closeMessage", 4, "ngIf"], [3, "closeMessage", "text", "type"], [3, "submitEvent", 4, "ngIf"], [3, "submitEvent"], [3, "csAgentTokenLoading", "submitEvent", 4, "ngIf"], [3, "submitEvent", "csAgentTokenLoading"]],
      template: function AsmMainUiComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 3)(1, "div", 4);
          ɵɵelement(2, "img", 5);
          ɵɵpipe(3, "cxTranslate");
          ɵɵpipe(4, "cxTranslate");
          ɵɵelementStart(5, "div", 6);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(8, "div", 7)(9, "div", 8)(10, "a", 9);
          ɵɵelement(11, "cx-icon", 10);
          ɵɵelementStart(12, "span");
          ɵɵtext(13);
          ɵɵpipe(14, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵtemplate(15, AsmMainUiComponent_div_15_Template, 7, 4, "div", 11);
          ɵɵpipe(16, "async");
          ɵɵelement(17, "cx-asm-toggle-ui");
          ɵɵtemplate(18, AsmMainUiComponent_cx_asm_session_timer_18_Template, 1, 0, "cx-asm-session-timer", 12);
          ɵɵpipe(19, "async");
          ɵɵtemplate(20, AsmMainUiComponent_button_20_Template, 2, 3, "button", 13);
          ɵɵpipe(21, "async");
          ɵɵpipe(22, "async");
          ɵɵtemplate(23, AsmMainUiComponent_button_23_Template, 2, 3, "button", 14);
          ɵɵpipe(24, "async");
          ɵɵelementEnd()();
          ɵɵtemplate(25, AsmMainUiComponent_ng_container_25_Template, 5, 4, "ng-container", 12);
          ɵɵpipe(26, "async");
        }
        if (rf & 2) {
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("alt", ɵɵpipeBind1(3, 10, "asm.mainLogoLabel"));
          ɵɵpropertyInterpolate("title", ɵɵpipeBind1(4, 12, "asm.mainLogoLabel"));
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 14, "asm.mainTitle"), " ");
          ɵɵadvance(5);
          ɵɵproperty("type", ctx.iconTypes.HELP);
          ɵɵadvance(2);
          ɵɵtextInterpolate(ɵɵpipeBind1(14, 16, "asm.helpPortalUrl"));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(16, 18, ctx.customerSupportAgentLoggedIn$));
          ɵɵadvance(3);
          ɵɵproperty("ngIf", ɵɵpipeBind1(19, 20, ctx.customerSupportAgentLoggedIn$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", !ɵɵpipeBind1(21, 22, ctx.customerSupportAgentLoggedIn$) && !ɵɵpipeBind1(22, 24, ctx.csAgentTokenLoading$));
          ɵɵadvance(3);
          ɵɵproperty("ngIf", ɵɵpipeBind1(24, 26, ctx.customerSupportAgentLoggedIn$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", !ɵɵpipeBind1(26, 28, ctx.isCollapsed$));
        }
      },
      dependencies: [NgIf, IconComponent, MessageComponent, CSAgentLoginFormComponent, CustomerSelectionComponent, AsmSessionTimerComponent, CustomerEmulationComponent, AsmToggleUiComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmMainUiComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-main-ui",
      template: `<div class="asm-bar">
  <div class="asm-bar-branding">
    <img
      class="logo"
      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAwCAYAAADuFn/PAAAAAXNSR0IArs4c6QAAD7RJREFUeAHtW3twVGcVP7t795V30rwJBBJeASq01NJgnZa2otTW2nHAqrRak+rUKfgYZ/xDW5lRR2e0/mGtAadqq6WjUAdNa4udqVZaEdtCKQ2FQEh5JSQh5Lnvp7/ft9lkd9l7swkhwMiZ3N27937fd8533ufcG9P1L/VE5SpMOwdMmk0iocDzWjAUnnbk/9cITSYx2xwS9Xs3Wzs7NmqhcOT/mh/Tunkw32SzScjr2Vy2v3XDa5tWhbRI5KoHmi4hmGx2ifi8mz8UmvHI9k2VyvVokasWMC38N8HtRHyezUejex5pXbdu1O9r5qsCuLgCUD4fmu/1bq5sbd9wdNMY84lYM10VwMUTAJlvtUnU491c0XZc+fxUZFo0Mn4QjiJMMFREcKJG4xxrC/7ETCQ854+JAtbBny5Mak3d1ab3BsKtCrhhuJ2K9lNpmU+KYAHpWRAFa4K4x7t5NouU5WhS4rRIvt0idotJ3MGIDPgj0usNSZ8vLMOBiIQhJQukoZkpHGOJcGXLiPD0WBNStOmvQ8ETAjp7iN0d++RelBLhBFsAnVQe/fXHZk7wDEuarXaJBrxNFe2nNzLb0VsBMWA0HoyO8WNDDnDxIzOy5ONzcuX6MqdU5VhxLZlYWoUvFJEud0iODQZkb5dXHa19PnEFw2LDBi0QRqqac14BBPnz2yul0GEZxZt68vzhQXm6pS+Gl9xLANL4uUWFsm5hPmiIjiPu2EQqSY8nJCeHAnK4zy+tOLrdQXXTClqVLFLwJKDM7BSLmMD8iN/btCRn3obtm+adz+CElTTlW0YuEDe1qR6M//oNJXJDRVbC0PNPqYFZVrPUFNjU8bHqHGUF3NxLx4ZkZ/uQdLnOF34Acad+To6srDRe/7ML8+T5Q/3KEpNFD5lijVKnWa4tdpxPWIZXeiGM/3S65Y/vD8hbnR6lLBdkEdR8DZrv9zUtyT+wYfu6+YbMJ5mjQZjMZ1H20HXF8s0VZWKjjU4C6IIWgyk8PlqVLY0vnhDGkMTVNJjA3bV5464+t9AhS4vtsqfDBWuiKY0Bk4dIhq5nbFbyWXGWJnfPzZc1NRT0gDy+p1uG/WHlmpJHZvALG6TmR/2epoOFBzccTEg1jWabTXBBpkhYgoGQNCy9Rr6zsnzSzE9ERKZvazknAX9IzFhf4QGuMFofNXmarKjMThye9pwWtqYmV6Jwc2R4fI3Rb/qyKQDGgvsWF8ovVlcJSEOPJsaTUTzkkdGBRMZstorA7SwqXLRBMmQ+STczC/IHwnA3TvlGfdkUbCe2xBsnhmVna79YTQi3YB7x8AhA0LfPzpNsW7JG6yG+BWOLHWYJgwHxNUa/KeUphPqZOfKt+nKlJIk0j+Ib2UPyb8QfMD/q8zYV9/Ru3L7ONK7bSSTZHIUZm6FJDdeXIrsZnynMdBh4jfbuR1B8YnenhBCIVZZFV4GDuLLh2j4xLz+RBsPzylyrspYAlIRrJB1TZAGJBHxmUZFcV5YFRUmDLxU/fpP5aC80Fff1GWY7iTgSzzWa26wCu6yA9I3g7VPDsu1Ar3zQ75MAGEwNLnBoUgtfv2JmriybkSM5SFcJO1p65Z3Tw2JnPgqtiUMIgluGsXUlzviljL7vnF8gLx86h7UShnNdIy3A0NeODcrrHwwqn56LrKv2GtA6K0+K4Pv1wAoF+STw7T05lBy4kibQ8lhkMdvxNZUMD06K+VxSC0NLawtto8xLwjPyYx+Y2bCtVVwjAYrpGvdOBXzlcFSeguVUF9rlzroiuXlOgfzmv2fEwgFwG4kQhitag80xUE8EbgLTZsISOgb9Y3MhzPEE8NapIdmyu0McyNRIDjOcmVC2x1ZXy621BbokLK/KEZQ8CPLJ9I9OwDpm9POR7fzqYPXyjTJBtzO6Dk4QH8MosPQ1goND4DSDNFCKDT4dHk99O8xRRSjKaTnR65Ff7jolX37ufTnT78UYBE1oafygT2Uhd9vcwkT8GZ3noVa4tSY/5tIS1jQBrxFYIWdkqurIAkMdoL2jzyvf/1u7dA8HdKdW5FmlCHEnFozH9qASAfDCYtLYz2+qe7P9gphPAhADEBipTQZwIzTwJ3fVSmm2VTy+kARgNeyiqkDFbzDFooQioh7w4PfovZFxDL7U5Mp8W1pMrLppYXqwBtbFuJ2MF2ptAFEwK4kO0MWkoGPAK/s7hnVnMhZmw30m4eI+aEZgPtzOr+pqTmzYvj25saa7oMENiDIq3UN+gyGxW5+6tkRurM6XHe/2yIstZ6XtrEcJTgOxTOPoluIVbypb+JvK+slF1+jiae/1yuvH+qVx5Yy0Y66tzJX5xVnScsYlrFpZA5AfRkCGcVwEljoKoDOMaz5UxXqgIQ7Aa6lxo1Mxj3l+OOD73eEFKze2rKvX1xa9hdNcx1aicqjLJb0ufZOMzyvPs8nDH62SPzculWceWAJmVUkNAlsAgdwFywhCS0LQstTDz0BfZJebEB/0YM8HA7Jjf7eqpNONYWF4x4JC8QVDav0g8LCvYwS8z3GJ9NDaEY9lfql+Fc4kg/sJJ8wNm20S9nu3+sKBr12Iz0+l10wtOQ2fTa3OFBjUbpqdL9/9xBz5y1eXyVNfWCy0EA0bc6Pw4oZJfPzwwWXdPr9IcrhzHdjV1icHod20LD1YXVes1qCgufZ4AmDKTOFTQUgDafPg+PwNFbIAqaYeuOEKe90B5XIUHgseIwa9W/3RYOPxTat8evMmc121o+m/m/51QlaBSdVFE0sRnVaLmse5LZ0ueeK14/IShKk6nbQvCDiLqd3iYl36uuAC950cFK8/KK9DEAvK0lfJc0uyZHlVrvzzyLmY+xnHAvIg8CpYrQM0ZiGAVF+TJXdDUe6+ttSwC9ra7ZJ+eASVraG3A5+/1VLqbmjfeOf4vlp3l+lvQAAoxHDvNLKDh7e+J1vWf0hmogczGVhSmSNbPr9EnvnPafnB344iINP8o3Lj7AJZDB+uB3va+6V70KcC+T9bz0nDyplpny8wzty1pFRePXQ2IwE8WD9DPgdtN2EiBWBFvMoEXnm/V/xwddnOLHY1n9OGfQ1tP5x65pMW1PgIRjiYYew/MSj3bdkrfz/YkwmdumO+WF8lP753IVLQqEod74LWscDRg1cP9ap+jxWMOgBL6BjQt/JVC4qkIgfv1JBurG8E1PyCLKvkI83OlPknoYgvvtslDjzDDQe8W8H8L7c9cXGYT9qRa2ETPJAZ2OEyTvS65StPvysP//6AvH18wGh/hvfWLq+QtcvLhW5g9aIS3bH96Mf/tw09IygAApL0DvlkdxuqXh0oy7PLzaglmNbGzEBn4CQuM2b86IUjctYFrxD0bTU5LI0Xk/kk0RxhMEs4GCbplnbs7ZC1T74lX9jytvzpzQ45Y6CVentdf1OVrIHLmGkQV/a098mpc24xgfmKDmj2Ky3GFnjX0jIIi3pjbAF6dKW7zjrksR2Hpfm9PtEi/q3RLG3KA246vBrdRCrQWTjgL1kJ/gPM4FGe75Dl8OV3LC6VW5CNVBSMHycWVuTKN1fXpi6f9Jsuh81Atq0JVIAPetwyhEedeToV+sraIvSgnOhank+7WmSCH0eRhv8Ymr8TzwSQ7zxr7rc9dPzxqc129Egy1Xz9paRd8Eeqt+Y1lVNjwzwvRz/l08tnyCNgbhH88YUAU8O2brd0IhX24zlzCVzMbGQ7FLDR06nvbTsodvitR++tmxT6QU9QDqEafuGdTmned0b6fSaxg/mRwa6Hjj/9oH4QmhQ2/UnnWQALFWYbDFpxQfCb+QMrRAqgH02xJ3celdOIF5sbl+NhRHykPiK9O9l2TZbOyleH3ph019fADe05qh8rOOeNw72y+0gv6I7thSnxOaSXp895YGUelfmxTnA4nGKPBrfCrTW2P/3glKea6eiPX9Ms8P9xYMq4/iOzlAvY09qrLttIfDr+QiLtnUMqflM40w3LqgtQNxh3A954v0cebz4szpE2OWnkXpiWMsdnC8XuQLaDgBs1WxoudsBNxyNYQEwAZP6c0hx5dO0SVUTthGlu//cJOXC8X4bx8JouSAkCJsAZOXgW8NAdtcoq0i18sa9lA//NC/WLO+Jnzygbb3Kkvs2haIMgzKhwI0g1oxbrJWE+6dAs9CmAIPzvA7fORsESaxfcc2OVfOrDVXKsa1gOnhyQDrSbB1Ce0y+XoVBbsaBEFs3M/MlWDMvUfjoSNDvdyrRM7i++x8QxJjI/6Hs2rFkveqqZiDf1XFkAU7B55Tny6fpZSfep8XORyfC4IoEtWFp4BBsZAb4wpv45Iuh/1uvvY8CdVp8fpyP+rbH4iSIQrV81B2kfnuxPA/AlgJ9tf0/KUR8sqi6U8kInyn6rCvpMAs6hGDuJVHQ/CrL7bquRuZXjv8KSjmy0/tWTOfV0bmSAcjsh/7OewMC0Zjvp6OM1ja+J1MGVrL1ljt6YKb/ehuD93KvHVJfSjnaB06aJNvLWHRXWj86lF+mpF4IqRTo6WQHwAQULPB4EExtrYL7X6Wg8/utLq/lxpppZUfrQ+37tnTNq4/Ebk/lmoH793TOKeUbzd2EM35jIBvMZcfxgthvxhYfXizYwqmEnnkjxIf+/W7rQqoox0GjNdPdoASw0eZjRzxf4fG+H45L6/FQ6zVS8M2dd8u0nd8v9P/yH/H7nETnd40odZ/ib7NmHfPurP90lbx7uESdyeyPYtb8TjwbBHAiMLpDtcAoifvAa7/Hd0kNoVUyUnjhu9b4n10fANQX8f3BndTa2vXzxGmtxvBP5Nl33pW1KvUCnejWR2laEarQOvnnZvGKpm10olXgUWJhrFxs0lsCxLk9AulG9toBBb0Cj6a/d3qCsva1W5lTQZ6tl1fjEj0Fo+XOvHAUuMHksNiYOSTpnS/tOJAcLZvFhfvo1kyYk/Njd0i1vHxlAbAltc3VlP3C5MZ+kmq574E/n7YquhO+JsuPLgsWJjiaDZLylywk+uI1hMJzpKythK1wGGcrfRi6DYyjIDHgfYyUGBrDmZP6XzWZHO0NCzR6LfX3rb+/Rfwofw3RJPrV4gErErlwBKmDlE3AjDAYMBn1J3V8ykk+9NPaRCTQL/KmXeg16/6Nj1UkGH1iT/48AZBkMHhvCt5Qj4UCzW3NctswntRr5lgmo/DmVBzGeZzJ9WseQ+eFgoNkz5Frf2vzZy1Lz4wxBDM5QAvEZl/m32cJUE8y3kfkNlzXzyUr1XtBlztOMyVNuJ+Rvdg571u+7Apg/IoCM93dZD+S7mnA7f/W4PPdfKcwfEcCV74KU26HPd3vvvxLcTqImX4pWfiL+Cz7nf6ZEI8G/ut3eK8Lnp254pAOTevnK+G0yI4RFQvtzQ9r6vc0NEyvfL5Mt/g8XIbTVhsig+gAAAABJRU5ErkJggg=="
      width="48"
      height="24"
      alt="{{ 'asm.mainLogoLabel' | cxTranslate }}"
      title="{{ 'asm.mainLogoLabel' | cxTranslate }}"
    />

    <div class="asm-title">
      {{ 'asm.mainTitle' | cxTranslate }}
    </div>
  </div>
  <div class="asm-bar-actions">
    <div class="cx-asm-help-portal">
      <a
        href="https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/d1ca9a1517f847a5b57b4e08400807c1/2367ff04ccb649ac82a3795ecf72a804.html?locale=en-US"
        target="_blank"
        rel="noopener noreferrer"
        role="button"
      >
        <cx-icon [type]="iconTypes.HELP"></cx-icon>
        <span>{{ 'asm.helpPortalUrl' | cxTranslate }}</span></a
      >
    </div>

    <div
      class="cx-asm-customer-list"
      *ngIf="customerSupportAgentLoggedIn$ | async"
    >
      <a
        #customerListLink
        tabindex="0"
        role="button"
        class="cx-asm-customer-list-link"
        (click)="showCustomList()"
      >
        <cx-icon [type]="iconTypes.USER_FRIENDS"></cx-icon>
        <span>{{ 'asm.customers' | cxTranslate }}</span></a
      >
    </div>

    <cx-asm-toggle-ui></cx-asm-toggle-ui>

    <cx-asm-session-timer
      *ngIf="customerSupportAgentLoggedIn$ | async"
    ></cx-asm-session-timer>

    <button
      class="close"
      title="{{ 'asm.hideUi' | cxTranslate }}"
      *ngIf="
        !(customerSupportAgentLoggedIn$ | async) &&
        !(csAgentTokenLoading$ | async)
      "
      (click)="hideUi()"
    ></button>

    <button
      class="logout"
      title="{{ 'asm.logout' | cxTranslate }}"
      *ngIf="customerSupportAgentLoggedIn$ | async"
      (click)="logout()"
    ></button>
  </div>
</div>

<ng-container *ngIf="!(isCollapsed$ | async) as notCollapsed">
  <ng-container
    *ngIf="customerSupportAgentLoggedIn$ | async; else showLoginForm"
  >
    <ng-container *ngIf="customer$ | async; else showCustomerSelection">
      <cx-customer-emulation *ngIf="notCollapsed"></cx-customer-emulation>
      <cx-message
        *ngIf="notCollapsed && showCreateCustomerSuccessfullyAlert"
        [text]="'asm.createCustomerSuccessfullyAlert' | cxTranslate"
        [type]="globalMessageType.MSG_TYPE_CONFIRMATION"
        (closeMessage)="closeDialogConfirmationAlert()"
      >
      </cx-message>
      <cx-message
        *ngIf="showDeeplinkCartInfoAlert$ | async"
        [text]="deeplinkCartAlertKey | cxTranslate"
        [type]="globalMessageType.MSG_TYPE_INFO"
        (closeMessage)="closeDeeplinkCartInfoAlert()"
      >
      </cx-message>
      <cx-message
        *ngIf="notCollapsed && showCustomerEmulationInfoAlert"
        [text]="'asm.startCustomerEmulationAlertInfo' | cxTranslate"
        [type]="globalMessageType.MSG_TYPE_INFO"
        (closeMessage)="closeCustomerEmulationInfoAlert()"
      >
      </cx-message>
    </ng-container>
    <ng-template #showCustomerSelection>
      <cx-customer-selection
        *ngIf="notCollapsed"
        (submitEvent)="startCustomerEmulationSession($event, $event.parameters)"
      ></cx-customer-selection>
    </ng-template>
  </ng-container>

  <ng-template #showLoginForm>
    <cx-csagent-login-form
      *ngIf="notCollapsed"
      (submitEvent)="loginCustomerSupportAgent($event)"
      [csAgentTokenLoading]="csAgentTokenLoading$ | async"
    ></cx-csagent-login-form>
  </ng-template>
</ng-container>
`
    }]
  }], () => [{
    type: AuthService
  }, {
    type: CsAgentAuthService
  }, {
    type: AsmComponentService
  }, {
    type: GlobalMessageService
  }, {
    type: RoutingService
  }, {
    type: AsmService
  }, {
    type: UserAccountFacade
  }, {
    type: LaunchDialogService
  }], {
    disabled: [{
      type: HostBinding,
      args: ["class.hidden"]
    }],
    element: [{
      type: ViewChild,
      args: ["customerListLink"]
    }],
    addNewCustomerLink: [{
      type: ViewChild,
      args: ["addNewCustomerLink"]
    }]
  });
})();
var SWITCH_CUSTOMER_DIALOG_ACTION;
(function(SWITCH_CUSTOMER_DIALOG_ACTION2) {
  SWITCH_CUSTOMER_DIALOG_ACTION2["CANCEL"] = "CANCEL";
  SWITCH_CUSTOMER_DIALOG_ACTION2["SWITCH"] = "SWITCH";
})(SWITCH_CUSTOMER_DIALOG_ACTION || (SWITCH_CUSTOMER_DIALOG_ACTION = {}));
var AsmSwitchCustomerDialogComponent = class _AsmSwitchCustomerDialogComponent {
  constructor(launchDialogService, asmComponentService) {
    this.launchDialogService = launchDialogService;
    this.asmComponentService = asmComponentService;
    this.SWITCH_CUSTOMER_DIALOG_ACTION = SWITCH_CUSTOMER_DIALOG_ACTION;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
  }
  ngOnInit() {
    this.launchDialogService.data$.pipe(take(1)).subscribe((data) => {
      this.curCustomerName = data.curCustomer.name || "";
      this.switchCustomerName = data.switchCustomer.name || "";
    });
  }
  closeModal(reason) {
    if (reason === SWITCH_CUSTOMER_DIALOG_ACTION.SWITCH) {
      this.asmComponentService.logoutCustomer();
    }
    this.launchDialogService.closeDialog(reason);
  }
  static {
    this.ɵfac = function AsmSwitchCustomerDialogComponent_Factory(t) {
      return new (t || _AsmSwitchCustomerDialogComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(AsmComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AsmSwitchCustomerDialogComponent,
      selectors: [["cx-asm-switch-customer-dialog"]],
      decls: 23,
      vars: 23,
      consts: [["role", "dialog", "aria-labelledby", "asm-switch-customer-dialog-title", 1, "cx-asm-switch-customer-dialog", "cx-modal-container", "cx-asm-dialog", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], ["type", "WARNING"], ["id", "asm-switch-customer-dialog-title", 1, "title", "modal-title"], [1, "cx-dialog-body", "modal-body"], [1, "cx-dialog-row", "switch-customer-content"], [1, "cx-dialog-item"], [1, "cx-dialog-footer", "modal-footer"], ["type", "button", 1, "btn", "btn-primary", 3, "click"], ["type", "button", 1, "btn", "btn-secondary", 3, "click"]],
      template: function AsmSwitchCustomerDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵlistener("esc", function AsmSwitchCustomerDialogComponent_Template_div_esc_0_listener() {
            return ctx.closeModal(ctx.SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL);
          });
          ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "div")(4, "span");
          ɵɵelement(5, "cx-icon", 3);
          ɵɵelementEnd();
          ɵɵelementStart(6, "span", 4);
          ɵɵtext(7);
          ɵɵpipe(8, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵelementStart(9, "div", 5)(10, "div", 6)(11, "div", 7);
          ɵɵtext(12);
          ɵɵpipe(13, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵelementStart(14, "div", 8)(15, "button", 9);
          ɵɵpipe(16, "cxTranslate");
          ɵɵlistener("click", function AsmSwitchCustomerDialogComponent_Template_button_click_15_listener() {
            return ctx.closeModal(ctx.SWITCH_CUSTOMER_DIALOG_ACTION.SWITCH);
          });
          ɵɵtext(17);
          ɵɵpipe(18, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(19, "button", 10);
          ɵɵpipe(20, "cxTranslate");
          ɵɵlistener("click", function AsmSwitchCustomerDialogComponent_Template_button_click_19_listener() {
            return ctx.closeModal(ctx.SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL);
          });
          ɵɵtext(21);
          ɵɵpipe(22, "cxTranslate");
          ɵɵelementEnd()()()();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(7);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(8, 7, "asm.switchCustomer.dialog.title"), " ");
          ɵɵadvance(5);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind2(13, 9, "asm.switchCustomer.dialog.body", ɵɵpureFunction2(20, _c12, ctx.curCustomerName, ctx.switchCustomerName)), " ");
          ɵɵadvance(3);
          ɵɵattribute("aria-label", ɵɵpipeBind1(16, 12, "asm.switchCustomer.dialog.actions.switch"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(18, 14, "asm.switchCustomer.dialog.actions.switch"), " ");
          ɵɵadvance(2);
          ɵɵattribute("aria-label", ɵɵpipeBind1(20, 16, "common.cancel"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(22, 18, "common.cancel"), " ");
        }
      },
      dependencies: [IconComponent, FocusDirective, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmSwitchCustomerDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-asm-switch-customer-dialog",
      template: `<div
  class="cx-asm-switch-customer-dialog cx-modal-container cx-asm-dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL)"
  role="dialog"
  aria-labelledby="asm-switch-customer-dialog-title"
>
  <div class="cx-modal-content">
    <!-- Modal Header -->
    <div class="cx-dialog-header modal-header">
      <div>
        <span>
          <cx-icon type="WARNING"></cx-icon>
        </span>
        <span id="asm-switch-customer-dialog-title" class="title modal-title">
          {{ 'asm.switchCustomer.dialog.title' | cxTranslate }}
        </span>
      </div>
    </div>

    <!-- Modal Body -->
    <div class="cx-dialog-body modal-body">
      <div class="cx-dialog-row switch-customer-content">
        <div class="cx-dialog-item">
          {{
            'asm.switchCustomer.dialog.body'
              | cxTranslate
                : {
                    customerA: curCustomerName,
                    customerB: switchCustomerName,
                  }
          }}
        </div>
      </div>
    </div>

    <!-- Modal Footer -->
    <div class="cx-dialog-footer modal-footer">
      <button
        (click)="closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.SWITCH)"
        [attr.aria-label]="
          'asm.switchCustomer.dialog.actions.switch' | cxTranslate
        "
        class="btn btn-primary"
        type="button"
      >
        {{ 'asm.switchCustomer.dialog.actions.switch' | cxTranslate }}
      </button>

      <button
        (click)="closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL)"
        [attr.aria-label]="'common.cancel' | cxTranslate"
        class="btn btn-secondary"
        type="button"
      >
        {{ 'common.cancel' | cxTranslate }}
      </button>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: AsmComponentService
  }], null);
})();
var CustomerListComponent = class _CustomerListComponent {
  constructor(launchDialogService, breakpointService, asmConfig, translation, asmCustomerListFacade, occConfig) {
    this.launchDialogService = launchDialogService;
    this.breakpointService = breakpointService;
    this.asmConfig = asmConfig;
    this.translation = translation;
    this.asmCustomerListFacade = asmCustomerListFacade;
    this.occConfig = occConfig;
    this.DEFAULT_PAGE_SIZE = 5;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: "customer-list-selector",
      focusOnEscape: true
    };
    this.iconTypes = ICON_TYPE;
    this.BREAKPOINT = BREAKPOINT;
    this.currentPage = 0;
    this.maxPage = 0;
    this.loaded = false;
    this.listsError = false;
    this.listsEmpty = false;
    this.enableAsmB2bCustomerList = false;
    this.customerListColumnActionType = CustomerListColumnActionType;
    this.searchBox = new UntypedFormControl();
    this.teardown = new Subscription();
    this.breakpoint$ = this.getBreakpoint();
  }
  ngOnInit() {
    this.pageSize = this.asmConfig.asm?.customerList?.pageSize ?? this.DEFAULT_PAGE_SIZE;
    this.customerListConfig = this.asmConfig?.asm?.customerList;
    this.customerListsPage$ = this.asmCustomerListFacade.getCustomerListsState().pipe(tap((state) => this.listsError = !!state.error), map((state) => {
      if (state?.data?.userGroups?.length === 0) {
        this.listsEmpty = true;
        return void 0;
      } else {
        return state.data;
      }
    }), distinctUntilChanged(), tap((result) => {
      if (!this.selectedUserGroupId) {
        this.selectedUserGroupId = result?.userGroups?.[0]?.uid;
        this.sorts = null;
        this.fetchCustomers();
      }
    })) ?? NEVER;
    this.customerSearchLoading$ = this.asmCustomerListFacade.getCustomerListCustomersSearchResultsLoading().pipe(tap((loading) => this.loaded = !loading));
    this.teardown.add(this.customerSearchLoading$.subscribe());
    this.teardown.add(() => this.asmCustomerListFacade.customerListCustomersSearchReset());
    this.customerSearchError$ = this.asmCustomerListFacade.getCustomerListCustomersSearchResultsError();
    this.customerSearchPage$ = this.asmCustomerListFacade.getCustomerListCustomersSearchResults().pipe(tap((result) => {
      if (result?.sorts) {
        this.sorts = result.sorts;
        this.sortCode = result.pagination?.sort;
      }
      if (result?.entries.length < this.pageSize) {
        this.maxPage = result.pagination?.currentPage ?? 0;
      } else {
        this.maxPage = this.currentPage + 1;
      }
    }));
  }
  ngOnDestroy() {
    this.teardown.unsubscribe();
  }
  changePage(page) {
    const options = {
      customerListId: this.selectedUserGroupId,
      pageSize: this.pageSize,
      currentPage: page,
      sort: this.sortCode
    };
    if (this.searchBox?.value) {
      options.query = this.searchBox.value;
    }
    this.asmCustomerListFacade.customerListCustomersSearch(options);
  }
  fetchCustomers() {
    this.enableAsmB2bCustomerList = this.selectedUserGroupId === "b2bCustomerList";
    if (this.selectedUserGroupId) {
      const options = {
        customerListId: this.selectedUserGroupId,
        pageSize: this.pageSize,
        currentPage: this.currentPage
      };
      if (this.sortCode) {
        options.sort = this.sortCode;
      }
      if (this.searchBox?.value) {
        options.query = this.searchBox.value;
      }
      this.asmCustomerListFacade.customerListCustomersSearchReset();
      this.asmCustomerListFacade.customerListCustomersSearch(options);
    }
    this.updateCustomerListColumns();
  }
  updateCustomerListColumns() {
    const columns = this.customerListConfig?.columns || [];
    for (const column of columns) {
      if (column.headerLocalizationKey === "asm.customerList.tableHeader.account" || column.headerLocalizationKey === "hideHeaders") {
        column.headerLocalizationKey = this.enableAsmB2bCustomerList ? "asm.customerList.tableHeader.account" : "hideHeaders";
      }
    }
  }
  onChangeCustomerGroup() {
    this.currentPage = 0;
    this.sorts = null;
    this.sortCode = "";
    this.fetchCustomers();
  }
  getGroupName(customerListsPage, id) {
    return customerListsPage?.userGroups?.find((userGroup) => userGroup.uid === id)?.name ?? "";
  }
  getBadgeText(customerEntry) {
    return (customerEntry.firstName?.charAt(0) ?? "") + (customerEntry.lastName?.charAt(0) ?? "");
  }
  startColumnAction(customerEntry, action) {
    this.selectedCustomer = customerEntry;
    const closeValue = {
      actionType: action,
      selectedUser: customerEntry
    };
    this.closeModal(closeValue);
  }
  onKey(event) {
    if (event.key === "Enter") {
      this.searchCustomers();
    }
  }
  searchCustomers() {
    this.currentPage = 0;
    this.fetchCustomers();
  }
  isRequired(customerEntry, type) {
    if (type === CustomerListColumnActionType.ACTIVE_CART && !customerEntry.lastCartId) {
      return true;
    }
    if (type === CustomerListColumnActionType.ORDER_HISTORY && customerEntry.hasOrder !== true) {
      return true;
    }
    return false;
  }
  changeSortCode(sortCode) {
    this.sortCode = sortCode;
    this.fetchCustomers();
  }
  goToNextPage() {
    if (this.currentPage >= this.maxPage) {
      this.currentPage = this.maxPage;
    } else {
      if (this.loaded) {
        this.currentPage++;
        this.fetchCustomers();
      }
    }
  }
  goToPreviousPage() {
    if (this.currentPage <= 0) {
      this.currentPage = 0;
    } else {
      if (this.loaded) {
        this.currentPage--;
        this.fetchCustomers();
      }
    }
  }
  closeModal(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  getSortLabels() {
    return combineLatest([this.translation.translate("asm.customerList.tableSort.byName"), this.translation.translate("asm.customerList.tableSort.byNameAsc"), this.translation.translate("asm.customerList.tableSort.byNameDesc"), this.translation.translate("asm.customerList.tableSort.byDateAsc"), this.translation.translate("asm.customerList.tableSort.byDateDesc"), this.translation.translate("asm.customerList.tableSort.byOrderDateAsc"), this.translation.translate("asm.customerList.tableSort.byOrderDateDesc"), this.translation.translate("asm.customerList.tableSort.byUnit"), this.translation.translate("asm.customerList.tableSort.byUnitDesc")]).pipe(map(([textByName, textByNameAsc, textByNameDesc, textByDateAsc, textByDateDesc, textByOrderDateAsc, textByOrderDateDesc, textByUnit, textByUnitDesc]) => {
      return {
        byName: textByName,
        byNameAsc: textByNameAsc,
        byNameDesc: textByNameDesc,
        byOrderDateAsc: textByOrderDateAsc,
        byOrderDateDesc: textByOrderDateDesc,
        byDateAsc: textByDateAsc,
        byDateDesc: textByDateDesc,
        byUnit: textByUnit,
        byUnitDesc: textByUnitDesc
      };
    }));
  }
  createCustomer() {
    this.launchDialogService.closeDialog("Create customer click");
    this.launchDialogService?.openDialogAndSubscribe("ASM_CREATE_CUSTOMER_FORM", this.addNewCustomerLink);
  }
  getBreakpoint() {
    return this.breakpointService.breakpoint$.pipe(map((breakpoint) => {
      if (breakpoint === BREAKPOINT.lg || breakpoint === BREAKPOINT.xl) {
        breakpoint = BREAKPOINT.md;
      }
      return breakpoint;
    }));
  }
  static {
    this.ɵfac = function CustomerListComponent_Factory(t) {
      return new (t || _CustomerListComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(BreakpointService), ɵɵdirectiveInject(AsmConfig), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(AsmCustomerListFacade), ɵɵdirectiveInject(OccConfig));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CustomerListComponent,
      selectors: [["cx-customer-list"]],
      viewQuery: function CustomerListComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c11, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.addNewCustomerLink = _t.first);
        }
      },
      decls: 48,
      vars: 28,
      consts: [["cell", ""], ["cellContent", ""], ["search", ""], ["total", ""], ["sort", ""], ["pagination", ""], ["groupSelector", ""], ["closeButton", ""], ["createCustomerButton", ""], ["role", "dialog", "aria-labelledby", "asm-customer-list-title", 1, "cx-asm-customer-list", "cx-modal-container", "cx-asm-dialog", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], ["id", "asm-customer-list-title", 1, "title", "modal-title"], ["id", "asm-customer-list-desc", 1, "cx-visually-hidden"], [4, "ngTemplateOutlet"], ["class", "cx-dialog-sub-header modal-header", 3, "tablet-mobile", 4, "ngIf"], [1, "cx-dialog-body", "modal-body"], [1, "cx-dialog-row"], [1, "cx-dialog-item"], ["class", "cx-error-state", 4, "ngIf"], [4, "ngIf"], ["class", "cx-dialog-sub-header modal-header cx-dialog-foot", 3, "asm-mobile-pagination", 4, "ngIf"], [1, "cx-dialog-footer", "modal-footer"], ["type", "button", 1, "btn", "cx-asm-customer-list-btn-cancel", 3, "click"], [1, "cx-dialog-sub-header", "modal-header"], [1, "cx-header-select"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "cx-header-actions"], [1, "cx-error-state"], ["id", "asm-cusomer-list-table", "role", "table", "class", "table", 4, "ngIf"], ["class", "cx-empty-state", 4, "ngIf"], ["id", "asm-cusomer-list-table", "role", "table", 1, "table"], [1, "cx-visually-hidden"], ["role", "row", 4, "ngFor", "ngForOf"], ["role", "row"], ["role", "columnheader", 4, "ngFor", "ngForOf"], ["role", "columnheader"], ["role", "cell", "class", "cx-multi-cell", 4, "ngIf"], ["role", "cell", 4, "ngFor", "ngForOf"], ["role", "cell"], ["role", "cell", 1, "cx-multi-cell"], [4, "ngFor", "ngForOf"], [1, "cx-empty-state"], [1, "cx-dialog-sub-header", "modal-header", "cx-dialog-foot"], [3, "viewPageEvent", "pagination"], ["class", "cx-cell-container", 4, "ngIf"], [1, "cx-cell-container"], ["class", "cx-header-text", 4, "ngIf"], ["class", "cx-avatar", 4, "ngIf"], ["class", "btn btn-link cx-action-link cx-btn-cell", 3, "class", "disabled", "click", 4, "ngIf"], [1, "cx-header-text"], [1, "cx-avatar"], [3, "alt", "title", 4, "ngIf"], ["class", "cx-avatar-text", 4, "ngIf"], [3, "alt", "title"], [1, "cx-avatar-text"], [1, "btn", "btn-link", "cx-action-link", "cx-btn-cell", 3, "click", "disabled"], [3, "cx-action-color", "type", 4, "ngIf"], [3, "type"], [1, "form-group", "search-wrapper"], ["type", "text", 1, "form-control", 3, "keyup", "formControl", "placeholder"], ["role", "button", 1, "search", 3, "click", "type", "title"], ["class", "cx-total", 4, "ngIf"], [1, "cx-total"], ["class", "label-content", 4, "cxFeature"], ["class", "cx-visually-hidden", 4, "cxFeature"], ["ariaControls", "asm-cusomer-list-table", 1, "sort-selector", 3, "sortListEvent", "sortOptions", "sortLabels", "selectedOption", "placeholder", "ariaLabel"], [1, "label-content"], [1, "cx-pagination-buttons"], ["class", "btn btn-link cx-action-link cx-btn-previous", 3, "disabled", "click", 4, "ngIf"], ["class", "btn btn-link cx-action-link cx-btn-next", 3, "disabled", "click", 4, "ngIf"], [1, "btn", "btn-link", "cx-action-link", "cx-btn-previous", 3, "click", "disabled"], [1, "previous", 3, "type"], [1, "btn", "btn-link", "cx-action-link", "cx-btn-next", 3, "click", "disabled"], [1, "next", 3, "type"], ["bindLabel", "name", "bindValue", "uid", 1, "customer-list-selector", 3, "change", "ngModelChange", "searchable", "clearable", "tabIndex", "ngModel", "items", "cxNgSelectA11y"], ["type", "button", 1, "close", 3, "click", "title"], ["aria-hidden", "true"], ["type", "button", 1, "btn", "cx-asm-create-customer-btn", 3, "click"]],
      template: function CustomerListComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 9);
          ɵɵlistener("esc", function CustomerListComponent_Template_div_esc_0_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal("Escape clicked"));
          });
          ɵɵelementStart(1, "div", 10);
          ɵɵelementContainerStart(2);
          ɵɵelementStart(3, "div", 11)(4, "h2", 12);
          ɵɵtext(5);
          ɵɵpipe(6, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(7, "div", 13);
          ɵɵtext(8);
          ɵɵpipe(9, "cxTranslate");
          ɵɵelementEnd();
          ɵɵtemplate(10, CustomerListComponent_10_Template, 1, 0, null, 14);
          ɵɵelementEnd();
          ɵɵtemplate(11, CustomerListComponent_div_11_Template, 11, 24, "div", 15);
          ɵɵpipe(12, "async");
          ɵɵelementStart(13, "div", 16)(14, "div", 17)(15, "div", 18);
          ɵɵtemplate(16, CustomerListComponent_div_16_Template, 3, 3, "div", 19)(17, CustomerListComponent_div_17_Template, 3, 3, "div", 19)(18, CustomerListComponent_div_18_Template, 3, 3, "div", 19);
          ɵɵpipe(19, "async");
          ɵɵtemplate(20, CustomerListComponent_cx_spinner_20_Template, 1, 0, "cx-spinner", 20);
          ɵɵpipe(21, "async");
          ɵɵtemplate(22, CustomerListComponent_div_22_Template, 3, 2, "div", 20);
          ɵɵpipe(23, "async");
          ɵɵelementEnd()()();
          ɵɵtemplate(24, CustomerListComponent_div_24_Template, 6, 11, "div", 21);
          ɵɵpipe(25, "async");
          ɵɵelementStart(26, "div", 22)(27, "button", 23);
          ɵɵlistener("click", function CustomerListComponent_Template_button_click_27_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.closeModal("Cancel click"));
          });
          ɵɵtext(28);
          ɵɵpipe(29, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementContainerEnd();
          ɵɵelementEnd()();
          ɵɵtemplate(30, CustomerListComponent_ng_template_30_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor)(32, CustomerListComponent_ng_template_32_Template, 3, 2, "ng-template", null, 1, ɵɵtemplateRefExtractor)(34, CustomerListComponent_ng_template_34_Template, 7, 14, "ng-template", null, 2, ɵɵtemplateRefExtractor)(36, CustomerListComponent_ng_template_36_Template, 1, 1, "ng-template", null, 3, ɵɵtemplateRefExtractor)(38, CustomerListComponent_ng_template_38_Template, 6, 11, "ng-template", null, 4, ɵɵtemplateRefExtractor)(40, CustomerListComponent_ng_template_40_Template, 6, 8, "ng-template", null, 5, ɵɵtemplateRefExtractor)(42, CustomerListComponent_ng_template_42_Template, 4, 10, "ng-template", null, 6, ɵɵtemplateRefExtractor)(44, CustomerListComponent_ng_template_44_Template, 5, 7, "ng-template", null, 7, ɵɵtemplateRefExtractor)(46, CustomerListComponent_ng_template_46_Template, 5, 4, "ng-template", null, 8, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const createCustomerButton_r38 = ɵɵreference(47);
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(5);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 12, "asm.customerList.title"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 14, "asm.customerList.description"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", createCustomerButton_r38);
          ɵɵadvance();
          ɵɵproperty("ngIf", ɵɵpipeBind1(12, 16, ctx.customerListsPage$));
          ɵɵadvance(5);
          ɵɵproperty("ngIf", ctx.listsEmpty);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.listsError);
          ɵɵadvance();
          ɵɵproperty("ngIf", ɵɵpipeBind1(19, 18, ctx.customerSearchError$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(21, 20, ctx.customerSearchLoading$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(23, 22, ctx.customerSearchPage$));
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(25, 24, ctx.customerListsPage$));
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(29, 26, "asm.createCustomerForm.cancel"), " ");
        }
      },
      dependencies: [NgForOf, NgIf, NgTemplateOutlet, DefaultValueAccessor, NgControlStatus, FormControlDirective, IconComponent, NgSelectComponent, NgModel, SpinnerComponent, FocusDirective, NgSelectA11yDirective, SortingComponent, PaginationComponent, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CustomerListComponent, [{
    type: Component,
    args: [{
      selector: "cx-customer-list",
      template: `<div
  class="cx-asm-customer-list cx-modal-container cx-asm-dialog"
  role="dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal('Escape clicked')"
  aria-labelledby="asm-customer-list-title"
>
  <div class="cx-modal-content">
    <!-- Modal Header -->
    <ng-container>
      <div class="cx-dialog-header modal-header">
        <h2 id="asm-customer-list-title" class="title modal-title">
          {{ 'asm.customerList.title' | cxTranslate }}
        </h2>
        <div id="asm-customer-list-desc" class="cx-visually-hidden">
          {{ 'asm.customerList.description' | cxTranslate }}
        </div>
        <ng-template *ngTemplateOutlet="createCustomerButton"></ng-template>
      </div>
      <div
        class="cx-dialog-sub-header modal-header"
        [class.tablet-mobile]="(breakpoint$ | async) !== BREAKPOINT.md"
        *ngIf="customerListsPage$ | async as customerListsPage"
      >
        <div
          class="cx-header-select"
          [class.mobile]="(breakpoint$ | async) === BREAKPOINT.xs"
        >
          <ng-template
            *ngTemplateOutlet="
              groupSelector;
              context: { customerListsPage: customerListsPage }
            "
          ></ng-template>
          <ng-template
            *ngTemplateOutlet="
              total;
              context: {
                customerSearchPage: customerSearchPage$ | async,
              }
            "
          >
          </ng-template>
        </div>

        <div
          class="cx-header-actions"
          [class.mobile]="(breakpoint$ | async) === BREAKPOINT.xs"
        >
          <ng-template *ngTemplateOutlet="sort"></ng-template>
          <ng-template *ngTemplateOutlet="search"></ng-template>
        </div>
      </div>
      <!-- Modal Body -->
      <div class="cx-dialog-body modal-body">
        <div class="cx-dialog-row">
          <div class="cx-dialog-item">
            <div *ngIf="listsEmpty" class="cx-error-state">
              {{ 'asm.customerList.noLists' | cxTranslate }}
            </div>
            <div *ngIf="listsError" class="cx-error-state">
              {{ 'asm.customerList.listsError' | cxTranslate }}
            </div>
            <div *ngIf="customerSearchError$ | async" class="cx-error-state">
              {{ 'generalErrors.pageFailure' | cxTranslate }}
            </div>
            <cx-spinner *ngIf="customerSearchLoading$ | async"></cx-spinner>
            <div *ngIf="customerSearchPage$ | async as customerSearchPage">
              <table
                id="asm-cusomer-list-table"
                role="table"
                class="table"
                *ngIf="loaded"
              >
                <caption class="cx-visually-hidden">
                  {{
                    'asm.customerList.title' | cxTranslate
                  }}
                </caption>
                <thead *ngIf="(breakpoint$ | async) === BREAKPOINT.md">
                  <tr role="row">
                    <th
                      role="columnheader"
                      *ngFor="let column of customerListConfig?.columns"
                    >
                      <span
                        *ngIf="
                          column.headerLocalizationKey &&
                          column.headerLocalizationKey !== 'hideHeaders'
                        "
                      >
                        <ng-container
                          *ngIf="
                            column.headerLocalizationKey ===
                            'asm.customerList.tableHeader.customer'
                          "
                        >
                          {{
                            'asm.customerList.tableHeader.customerName'
                              | cxTranslate
                          }}
                        </ng-container>
                        <ng-container
                          *ngIf="
                            column.headerLocalizationKey ===
                            'asm.customerList.tableHeader.email'
                          "
                        >
                          {{
                            'asm.customerList.tableHeader.emailId' | cxTranslate
                          }}
                        </ng-container>
                        <ng-container
                          *ngIf="
                            column.headerLocalizationKey !==
                              'asm.customerList.tableHeader.customer' &&
                            column.headerLocalizationKey !==
                              'asm.customerList.tableHeader.email'
                          "
                        >
                          {{ column.headerLocalizationKey | cxTranslate }}
                        </ng-container>
                      </span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    role="row"
                    *ngFor="let customerEntry of customerSearchPage?.entries"
                  >
                    <!-- multi columns if desktop -->
                    <ng-container
                      *ngIf="(breakpoint$ | async) === BREAKPOINT.md"
                    >
                      <td
                        role="cell"
                        *ngFor="let column of customerListConfig?.columns"
                      >
                        <ng-template
                          *ngTemplateOutlet="
                            cell;
                            context: {
                              customerEntry: customerEntry,
                              column: column,
                              showHeader: false,
                            }
                          "
                        ></ng-template>
                      </td>
                    </ng-container>
                    <!-- two column if tablet -->
                    <ng-container
                      *ngIf="(breakpoint$ | async) === BREAKPOINT.sm"
                    >
                      <td role="cell" class="cx-multi-cell">
                        <ng-container
                          *ngFor="
                            let column of customerListConfig?.columns;
                            let even = even
                          "
                        >
                          <ng-container *ngIf="even">
                            <ng-template
                              *ngTemplateOutlet="
                                cell;
                                context: {
                                  customerEntry: customerEntry,
                                  column: column,
                                  showHeader: true,
                                }
                              "
                            ></ng-template>
                          </ng-container>
                        </ng-container>
                      </td>
                      <td role="cell" class="cx-multi-cell">
                        <ng-container
                          *ngFor="
                            let column of customerListConfig?.columns;
                            let odd = odd
                          "
                        >
                          <ng-container *ngIf="odd">
                            <ng-template
                              *ngTemplateOutlet="
                                cell;
                                context: {
                                  customerEntry: customerEntry,
                                  column: column,
                                  showHeader: true,
                                }
                              "
                            ></ng-template>
                          </ng-container>
                        </ng-container>
                      </td>
                    </ng-container>
                    <!-- one column if mobile -->
                    <td
                      role="cell"
                      class="cx-multi-cell"
                      *ngIf="(breakpoint$ | async) === BREAKPOINT.xs"
                    >
                      <ng-container
                        *ngFor="let column of customerListConfig?.columns"
                      >
                        <ng-template
                          *ngTemplateOutlet="
                            cell;
                            context: {
                              customerEntry: customerEntry,
                              column: column,
                              showHeader: true,
                            }
                          "
                        ></ng-template>
                      </ng-container>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div
                class="cx-empty-state"
                *ngIf="!customerSearchPage?.entries.length"
              >
                {{ 'asm.customerList.noCustomers' | cxTranslate }}
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Modal Foot -->
      <div
        class="cx-dialog-sub-header modal-header cx-dialog-foot"
        [class.asm-mobile-pagination]="(breakpoint$ | async) !== BREAKPOINT.md"
        *ngIf="customerListsPage$ | async as customerListsPage"
      >
        <div
          class="cx-header-actions"
          [class.mobile]="(breakpoint$ | async) === BREAKPOINT.xs"
        >
          <div *ngIf="customerSearchPage$ | async as customerSearchPage">
            <cx-pagination
              [pagination]="customerSearchPage.pagination"
              (viewPageEvent)="changePage($event)"
            ></cx-pagination>
          </div>
        </div>
      </div>
      <div class="cx-dialog-footer modal-footer">
        <button
          type="button"
          class="btn cx-asm-customer-list-btn-cancel"
          (click)="closeModal('Cancel click')"
        >
          {{ 'asm.createCustomerForm.cancel' | cxTranslate }}
        </button>
      </div>
    </ng-container>
  </div>
</div>

<ng-template
  #cell
  let-customerEntry="customerEntry"
  let-column="column"
  let-showHeader="showHeader"
>
  <div
    class="cx-cell-container"
    *ngIf="column.headerLocalizationKey !== 'hideHeaders'"
  >
    <span class="cx-header-text" *ngIf="showHeader">
      {{ column.headerLocalizationKey | cxTranslate }}
    </span>

    <ng-container *ngIf="!column.actionType">
      <ng-container
        *ngTemplateOutlet="
          cellContent;
          context: { column: column, customerEntry: customerEntry }
        "
      ></ng-container>
    </ng-container>

    <div
      class="cx-avatar"
      *ngIf="
        customerListConfig?.showAvatar &&
        column?.actionType === customerListColumnActionType?.START_SESSION
      "
    >
      <img
        *ngIf="customerEntry?.userAvatar?.url"
        [attr.src]="
          occConfig?.backend?.occ?.baseUrl + customerEntry?.userAvatar?.url
        "
        alt="{{ 'asm.mainLogoLabel' | cxTranslate }}"
        title="{{ 'asm.mainLogoLabel' | cxTranslate }}"
      />
      <div class="cx-avatar-text" *ngIf="!customerEntry?.userAvatar?.url">
        {{ getBadgeText(customerEntry) }}
      </div>
    </div>

    <button
      *ngIf="column.actionType"
      (click)="startColumnAction(customerEntry, column.actionType)"
      class="btn btn-link cx-action-link cx-btn-cell"
      [class]="
        (column.actionType === 'ACTIVE_CART' ? 'cx-cart ' : '') +
        (column.actionType !== 'START_SESSION' ? 'cx-action-disable' : '')
      "
      [disabled]="isRequired(customerEntry, column.actionType)"
      [attr.title]="
        column.icon
          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey
            | cxTranslate)
          : undefined
      "
      [attr.aria-label]="
        column.icon
          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey
            | cxTranslate)
          : undefined
      "
    >
      <ng-container
        *ngTemplateOutlet="
          cellContent;
          context: { column: column, customerEntry: customerEntry }
        "
      ></ng-container>
    </button>
  </div>
</ng-template>
<ng-template #cellContent let-customerEntry="customerEntry" let-column="column">
  <div>
    <span *ngIf="!column.icon">{{
      column.renderer?.(customerEntry) || ''
    }}</span>
    <cx-icon
      *ngIf="column.icon"
      [attr.title]="
        !column.actionType
          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey
            | cxTranslate)
          : undefined
      "
      [class.cx-action-color]="
        column.actionType && !isRequired(customerEntry, column.actionType)
      "
      [type]="column.icon.symbol"
      [attr.aria-label]="
        !column.actionType
          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey
            | cxTranslate)
          : undefined
      "
    ></cx-icon>
  </div>
</ng-template>

<ng-template #search>
  <div class="form-group search-wrapper">
    <input
      [formControl]="searchBox"
      (keyup)="onKey($event)"
      type="text"
      class="form-control"
      placeholder="{{ 'asm.customerList.searchBox' | cxTranslate }}"
      attr.aria-label="{{ 'asm.customerList.enterSearchBox' | cxTranslate }}"
    />
    <cx-icon
      [type]="iconTypes.SEARCH"
      role="button"
      [attr.aria-label]="'storeFinder.searchNearestStores' | cxTranslate"
      [title]="'storeFinder.searchNearestStores' | cxTranslate"
      class="search"
      (click)="searchCustomers()"
    ></cx-icon>
  </div>
</ng-template>

<ng-template #total let-customerSearchPage="customerSearchPage">
  <span class="cx-total" *ngIf="customerSearchPage?.pagination?.totalResults">
    <ng-container *ngIf="customerSearchPage?.pagination?.totalResults > 1">
      {{
        'asm.customerList.noOfCustomers'
          | cxTranslate: { count: customerSearchPage?.pagination?.totalResults }
      }}
    </ng-container>
    <ng-container *ngIf="customerSearchPage?.pagination?.totalResults === 1">
      {{ 'asm.customerList.oneCustomer' | cxTranslate }}
    </ng-container>
  </span>
</ng-template>

<ng-template #sort>
  <label>
    <span *cxFeature="'a11yShowLabelOfSelect'" class="label-content">{{
      'asm.customerList.tableSort.sortBy' | cxTranslate
    }}</span>
    <span *cxFeature="'!a11yShowLabelOfSelect'" class="cx-visually-hidden">{{
      'asm.customerList.tableSort.sortBy' | cxTranslate
    }}</span>
    <cx-sorting
      class="sort-selector"
      [sortOptions]="sorts"
      [sortLabels]="getSortLabels() | async"
      (sortListEvent)="changeSortCode($event)"
      [selectedOption]="sortCode"
      placeholder="{{ 'asm.customerList.tableSort.sortBy' | cxTranslate }}"
      [ariaLabel]="sortCode"
      ariaControls="asm-cusomer-list-table"
    ></cx-sorting>
  </label>
</ng-template>

<ng-template #pagination>
  <div class="cx-pagination-buttons">
    <div>
      {{
        'asm.customerList.page.page' | cxTranslate: { count: currentPage + 1 }
      }}
    </div>
    <button
      *ngIf="maxPage > 0"
      (click)="goToPreviousPage()"
      class="btn btn-link cx-action-link cx-btn-previous"
      [disabled]="currentPage === 0 || !loaded"
    >
      <cx-icon class="previous" [type]="iconTypes.CARET_LEFT"></cx-icon
      ><span>{{ 'asm.customerList.page.previous' | cxTranslate }}</span>
    </button>
    <button
      *ngIf="maxPage > 0"
      (click)="goToNextPage()"
      class="btn btn-link cx-action-link cx-btn-next"
      [disabled]="currentPage === maxPage || !loaded"
    >
      <span>{{ 'asm.customerList.page.next' | cxTranslate }}</span
      ><cx-icon class="next" [type]="iconTypes.CARET_RIGHT"></cx-icon>
    </button>
  </div>
</ng-template>

<ng-template #groupSelector let-customerListsPage="customerListsPage">
  <label>
    <span *cxFeature="'a11yShowLabelOfSelect'" class="label-content">{{
      'asm.customerList.title' | cxTranslate
    }}</span>
    <span *cxFeature="'!a11yShowLabelOfSelect'" class="cx-visually-hidden">{{
      'asm.customerList.title' | cxTranslate
    }}</span>
    <ng-select
      class="customer-list-selector"
      [searchable]="false"
      [clearable]="false"
      (change)="onChangeCustomerGroup()"
      [tabIndex]="0"
      [(ngModel)]="selectedUserGroupId"
      [items]="customerListsPage?.userGroups"
      bindLabel="name"
      bindValue="uid"
      [cxNgSelectA11y]="{
        ariaLabel: getGroupName(customerListsPage, selectedUserGroupId),
        ariaControls: 'asm-cusomer-list-table',
      }"
    >
    </ng-select>
  </label>
</ng-template>

<ng-template #closeButton>
  <button
    type="button"
    class="close"
    attr.aria-label="{{ 'common.close' | cxTranslate }}"
    (click)="closeModal('Cross click')"
    title="{{ 'common.close' | cxTranslate }}"
  >
    <span aria-hidden="true">
      <cx-icon [type]="iconTypes.CLOSE"></cx-icon>
    </span>
  </button>
</ng-template>

<ng-template #createCustomerButton>
  <button
    type="button"
    class="btn cx-asm-create-customer-btn"
    (click)="createCustomer()"
  >
    <cx-icon [type]="iconTypes.USER_PLUS"></cx-icon>
    <span>{{ 'asm.customerList.createCustomer' | cxTranslate }}</span>
  </button>
</ng-template>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: BreakpointService
  }, {
    type: AsmConfig
  }, {
    type: TranslationService
  }, {
    type: AsmCustomerListFacade
  }, {
    type: OccConfig
  }], {
    addNewCustomerLink: [{
      type: ViewChild,
      args: ["addNewCustomerLink"]
    }]
  });
})();
var defaultCustomerListLayoutConfig = {
  launch: {
    ASM_CUSTOMER_LIST: {
      inlineRoot: true,
      component: CustomerListComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var defaultAsmLayoutConfig = {
  launch: {
    ASM: {
      outlet: "cx-storefront",
      component: AsmMainUiComponent
    }
  }
};
var defaultAsmPaginationConfig = {
  pagination: {
    rangeCount: 2,
    addPrevious: true,
    addNext: true,
    addStart: false,
    addEnd: false,
    addFirst: true,
    addLast: true,
    addDots: true,
    substituteDotsForSingularPage: true,
    dotsLabel: "···"
  }
};
var defaultBindCartLayoutConfig = {
  launch: {
    [
      "ASM_BIND_CART"
      /* LAUNCH_CALLER.ASM_BIND_CART */
    ]: {
      inlineRoot: true,
      component: AsmBindCartDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var defaultSaveCartLayoutConfig = {
  launch: {
    [
      "ASM_SAVE_CART"
      /* LAUNCH_CALLER.ASM_SAVE_CART */
    ]: {
      inlineRoot: true,
      component: AsmSaveCartDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var defaultSwitchCustomerLayoutConfig = {
  launch: {
    [
      "ASM_SWITCH_CUSTOMER"
      /* LAUNCH_CALLER.ASM_SWITCH_CUSTOMER */
    ]: {
      inlineRoot: true,
      component: AsmSwitchCustomerDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var AsmComponentsModule = class _AsmComponentsModule {
  static {
    this.ɵfac = function AsmComponentsModule_Factory(t) {
      return new (t || _AsmComponentsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AsmComponentsModule,
      declarations: [AsmBindCartDialogComponent, AsmSaveCartDialogComponent, AsmMainUiComponent, CSAgentLoginFormComponent, CustomerListComponent, CustomerSelectionComponent, AsmSessionTimerComponent, FormatTimerPipe, CustomerEmulationComponent, AsmToggleUiComponent, AsmBindCartComponent, AsmSwitchCustomerDialogComponent, DotSpinnerComponent, AsmCreateCustomerFormComponent],
      imports: [CommonModule, ReactiveFormsModule, I18nModule, FormErrorsModule, IconModule, NgSelectModule, FormsModule, SpinnerModule, PasswordVisibilityToggleModule, KeyboardFocusModule, NgSelectA11yModule, SortingModule, PaginationModule, MessageComponentModule, FeaturesConfigModule],
      exports: [AsmBindCartDialogComponent, AsmSaveCartDialogComponent, AsmMainUiComponent, CSAgentLoginFormComponent, CustomerListComponent, CustomerSelectionComponent, AsmSessionTimerComponent, FormatTimerPipe, CustomerEmulationComponent, AsmToggleUiComponent, AsmBindCartComponent, AsmSwitchCustomerDialogComponent, DotSpinnerComponent, AsmCreateCustomerFormComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultAsmLayoutConfig), provideDefaultConfig(defaultBindCartLayoutConfig), provideDefaultConfig(defaultSaveCartLayoutConfig), provideDefaultConfig(defaultSwitchCustomerLayoutConfig), provideDefaultConfig(defaultCustomerListLayoutConfig), provideDefaultConfig(defaultAsmPaginationConfig), provideDefaultConfig(defaultAsmCreateCustomerFormLayoutConfig)],
      imports: [CommonModule, ReactiveFormsModule, I18nModule, FormErrorsModule, IconModule, NgSelectModule, FormsModule, SpinnerModule, PasswordVisibilityToggleModule, KeyboardFocusModule, NgSelectA11yModule, SortingModule, PaginationModule, MessageComponentModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmComponentsModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, ReactiveFormsModule, I18nModule, FormErrorsModule, IconModule, NgSelectModule, FormsModule, SpinnerModule, PasswordVisibilityToggleModule, KeyboardFocusModule, NgSelectA11yModule, SortingModule, PaginationModule, MessageComponentModule, FeaturesConfigModule],
      declarations: [AsmBindCartDialogComponent, AsmSaveCartDialogComponent, AsmMainUiComponent, CSAgentLoginFormComponent, CustomerListComponent, CustomerSelectionComponent, AsmSessionTimerComponent, FormatTimerPipe, CustomerEmulationComponent, AsmToggleUiComponent, AsmBindCartComponent, AsmSwitchCustomerDialogComponent, DotSpinnerComponent, AsmCreateCustomerFormComponent],
      exports: [AsmBindCartDialogComponent, AsmSaveCartDialogComponent, AsmMainUiComponent, CSAgentLoginFormComponent, CustomerListComponent, CustomerSelectionComponent, AsmSessionTimerComponent, FormatTimerPipe, CustomerEmulationComponent, AsmToggleUiComponent, AsmBindCartComponent, AsmSwitchCustomerDialogComponent, DotSpinnerComponent, AsmCreateCustomerFormComponent],
      providers: [provideDefaultConfig(defaultAsmLayoutConfig), provideDefaultConfig(defaultBindCartLayoutConfig), provideDefaultConfig(defaultSaveCartLayoutConfig), provideDefaultConfig(defaultSwitchCustomerLayoutConfig), provideDefaultConfig(defaultCustomerListLayoutConfig), provideDefaultConfig(defaultAsmPaginationConfig), provideDefaultConfig(defaultAsmCreateCustomerFormLayoutConfig)]
    }]
  }], null, null);
})();

// node_modules/@spartacus/asm/fesm2022/spartacus-asm-occ.mjs
var OccAsmAdapter = class _OccAsmAdapter {
  constructor(http, occEndpointsService, converterService, config, baseSiteService) {
    this.http = http;
    this.occEndpointsService = occEndpointsService;
    this.converterService = converterService;
    this.config = config;
    this.baseSiteService = baseSiteService;
    this.logger = inject(LoggerService);
    this.baseSiteService.getActive().subscribe((value) => this.activeBaseSite = value);
  }
  getHeaders() {
    return InterceptorUtil.createHeader(USE_CUSTOMER_SUPPORT_AGENT_TOKEN, true, new HttpHeaders());
  }
  customerLists() {
    const headers = this.getHeaders();
    const params = new HttpParams().set("baseSite", this.activeBaseSite);
    const url = this.occEndpointsService.buildUrl("asmCustomerLists", {}, {
      baseSite: false,
      prefix: false
    });
    return this.http.get(url, {
      headers,
      params
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), this.converterService.pipeable(CUSTOMER_LISTS_NORMALIZER));
  }
  customerSearch(options) {
    const headers = this.getHeaders();
    let params = new HttpParams().set("baseSite", this.activeBaseSite);
    if (options.sort !== void 0) {
      params = params.set("sort", options.sort);
    } else {
      if (!options.customerListId) {
        params = params.set("sort", "byNameAsc");
      }
    }
    if (options.query !== void 0) {
      params = params.set("query", options.query);
    }
    if (options.orderId !== void 0) {
      params = params.set("orderId", options.orderId);
    }
    if (options.pageSize !== void 0) {
      params = params.set("pageSize", options.pageSize.toString());
    }
    if (options.currentPage !== void 0) {
      params = params.set("currentPage", options.currentPage.toString());
    }
    if (options.customerListId !== void 0) {
      params = params.set("customerListId", options.customerListId);
    }
    const url = this.occEndpointsService.buildUrl("asmCustomerSearch", {}, {
      baseSite: false,
      prefix: false
    });
    return this.http.get(url, {
      headers,
      params
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), this.converterService.pipeable(CUSTOMER_SEARCH_PAGE_NORMALIZER));
  }
  bindCart({
    cartId,
    customerId
  }) {
    const headers = InterceptorUtil.createHeader(USE_CUSTOMER_SUPPORT_AGENT_TOKEN, true, new HttpHeaders().set("Content-Type", "application/x-www-form-urlencoded"));
    const params = new HttpParams().set("baseSite", this.activeBaseSite);
    const body = new URLSearchParams();
    body.set("cartId", cartId);
    body.set("customerId", customerId);
    const url = this.occEndpointsService.buildUrl("asmBindCart", {}, {
      baseSite: false,
      prefix: false
    });
    return this.http.post(url, body, {
      headers,
      params
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }));
  }
  createCustomer(user) {
    const headers = this.getHeaders();
    const params = new HttpParams().set("baseSite", this.activeBaseSite);
    const url = this.occEndpointsService.buildUrl("asmCreateCustomer", {}, {
      baseSite: false,
      prefix: false
    });
    return this.http.post(url, user, {
      headers,
      params
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }));
  }
  static {
    this.ɵfac = function OccAsmAdapter_Factory(t) {
      return new (t || _OccAsmAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService), ɵɵinject(AsmConfig), ɵɵinject(BaseSiteService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccAsmAdapter,
      factory: _OccAsmAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccAsmAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }, {
    type: AsmConfig
  }, {
    type: BaseSiteService
  }], null);
})();
var defaultOccAsmConfig = {
  backend: {
    occ: {
      endpoints: {
        asmCustomerSearch: "/assistedservicewebservices/customers/search",
        asmCustomerLists: "/assistedservicewebservices/customerlists",
        asmBindCart: "/assistedservicewebservices/bind-cart",
        asmCreateCustomer: "/assistedservicewebservices/customers"
      }
    }
  }
};
var AsmOccModule = class _AsmOccModule {
  static {
    this.ɵfac = function AsmOccModule_Factory(t) {
      return new (t || _AsmOccModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AsmOccModule,
      imports: [CommonModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultOccAsmConfig), {
        provide: AsmAdapter,
        useClass: OccAsmAdapter
      }],
      imports: [CommonModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmOccModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule],
      providers: [provideDefaultConfig(defaultOccAsmConfig), {
        provide: AsmAdapter,
        useClass: OccAsmAdapter
      }]
    }]
  }], null, null);
})();

// node_modules/@spartacus/asm/fesm2022/spartacus-asm.mjs
var AsmModule = class _AsmModule {
  static {
    this.ɵfac = function AsmModule_Factory(t) {
      return new (t || _AsmModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AsmModule,
      imports: [AsmComponentsModule, AsmCoreModule, AsmOccModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [AsmComponentsModule, AsmCoreModule, AsmOccModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsmModule, [{
    type: NgModule,
    args: [{
      imports: [AsmComponentsModule, AsmCoreModule, AsmOccModule]
    }]
  }], null, null);
})();
export {
  AsmModule
};
//# sourceMappingURL=@spartacus_asm.js.map
