import {
  facadeFactory,
  provideDefaultConfig,
  provideDefaultConfigFactory
} from "./chunk-CJWHFW34.js";
import {
  Injectable,
  NgModule,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule
} from "./chunk-JMCPXHNJ.js";

// node_modules/@spartacus/storefinder/fesm2022/spartacus-storefinder-root.mjs
var GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG = "cx-development";
var defaultStoreFinderLayoutConfig = {
  layoutSlots: {
    StoreFinderPageTemplate: {
      slots: ["MiddleContent", "SideContent"]
    }
  }
};
var STORE_FINDER_FEATURE = "storeFinder";
var StoreFinderFacade = class _StoreFinderFacade {
  static {
    this.ɵfac = function StoreFinderFacade_Factory(t) {
      return new (t || _StoreFinderFacade)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _StoreFinderFacade,
      factory: () => (() => facadeFactory({
        facade: _StoreFinderFacade,
        feature: STORE_FINDER_FEATURE,
        methods: ["getStoresLoading", "getStoresLoaded", "getFindStoresEntities", "getViewAllStoresLoading", "getViewAllStoresEntities", "findStoresAction", "viewAllStores", "viewStoreById", "callFindStoresAction", "getStoreLatitude", "getStoreLongitude", "getDirections", "getFindStoreEntityById"],
        async: true
      }))(),
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderFacade, [{
    type: Injectable,
    args: [{
      providedIn: "root",
      useFactory: () => facadeFactory({
        facade: StoreFinderFacade,
        feature: STORE_FINDER_FEATURE,
        methods: ["getStoresLoading", "getStoresLoaded", "getFindStoresEntities", "getViewAllStoresLoading", "getViewAllStoresEntities", "findStoresAction", "viewAllStores", "viewStoreById", "callFindStoresAction", "getStoreLatitude", "getStoreLongitude", "getDirections", "getFindStoreEntityById"],
        async: true
      })
    }]
  }], null, null);
})();
var StoreFinderOutlets;
(function(StoreFinderOutlets2) {
  StoreFinderOutlets2["PREFERRED_STORE"] = "cx-pick-up-in-store-make-my-store";
})(StoreFinderOutlets || (StoreFinderOutlets = {}));
function defaultStoreFinderComponentsConfig() {
  const config = {
    featureModules: {
      [STORE_FINDER_FEATURE]: {
        cmsComponents: ["StoreFinderComponent"]
      }
    }
  };
  return config;
}
var StoreFinderRootModule = class _StoreFinderRootModule {
  static {
    this.ɵfac = function StoreFinderRootModule_Factory(t) {
      return new (t || _StoreFinderRootModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _StoreFinderRootModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultStoreFinderLayoutConfig), provideDefaultConfigFactory(defaultStoreFinderComponentsConfig)]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderRootModule, [{
    type: NgModule,
    args: [{
      declarations: [],
      providers: [provideDefaultConfig(defaultStoreFinderLayoutConfig), provideDefaultConfigFactory(defaultStoreFinderComponentsConfig)]
    }]
  }], null, null);
})();

export {
  GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG,
  defaultStoreFinderLayoutConfig,
  STORE_FINDER_FEATURE,
  StoreFinderFacade,
  StoreFinderOutlets,
  defaultStoreFinderComponentsConfig,
  StoreFinderRootModule
};
//# sourceMappingURL=chunk-2R5TI3FB.js.map
