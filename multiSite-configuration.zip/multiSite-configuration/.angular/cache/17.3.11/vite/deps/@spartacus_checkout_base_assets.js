import "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/checkout/fesm2022/spartacus-checkout-base-assets.mjs
var checkout = {
  backToCart: "Back to cart"
};
var checkoutProgress = {
  label: "Checkout Progress",
  deliveryAddress: "Shipping Address",
  deliveryMode: "Delivery Mode",
  paymentDetails: "Payment",
  reviewOrder: "Review",
  state: {
    completed: "{{step}}, Completed",
    selected: "{{step}}, Selected",
    disabled: "{{step}}, Disabled"
  }
};
var checkoutAddress = {
  shippingAddress: "Shipping Address",
  selectYourDeliveryAddress: "Select your Delivery Address",
  defaultDeliveryAddress: "Default Delivery Address",
  addNewAddress: "Add New Address",
  shipToThisAddress: "Ship to this address",
  deliveryAddressSelected: "Delivery address selected"
};
var checkoutMode = {
  deliveryMethod: "Delivery Method",
  deliveryOptions: "Delivery Options",
  standardDelivery: "Standard Delivery",
  premiumDelivery: "Premium Delivery",
  deliveryEntries: "Items to be Shipped"
};
var checkoutReview = {
  review: "Review",
  reviewOrder: "Review Order",
  orderItems: "Order Items",
  confirmThatRead: "I am confirming that I have read and agreed with the",
  placeOrder: "Place Order",
  termsAndConditions: "Terms & Conditions",
  editDeliveryAddressDetails: "Edit delivery address details, opens Delivery Address page",
  editBillingDetails: "Edit billing address, opens Payment Details page",
  editPaymentDetails: "Edit payment details, opens Payment Details page",
  editPaymentType: "Edit payment method, opens Method of Payment page",
  editDeliveryMode: "Edit delivery mode, opens Delivery Mode page",
  orderInProcess: "Order is in process. Please wait."
};
var checkoutOrderConfirmation = {
  confirmationOfOrder: "Confirmation of Order:",
  thankYou: "Thank you for your order!",
  invoiceHasBeenSentByEmail: "An invoice has been sent by email. You should receive it soon.",
  orderItems: "Order Items",
  orderPlacedSuccessfully: "Order placed successfully",
  createAccount: "Create an account?",
  createAccountForNext: "Create an account for <{{email}}> for a faster checkout on your next visit."
};
var checkout$1 = {
  checkout,
  checkoutProgress,
  checkoutAddress,
  checkoutMode,
  checkoutReview,
  checkoutOrderConfirmation
};
var en = {
  checkout: checkout$1
};
var checkoutTranslations = {
  en
};
var checkoutTranslationChunksConfig = {
  checkout: [
    "checkout",
    "checkoutProgress",
    "checkoutAddress",
    "checkoutMode",
    "checkoutReview",
    "checkoutOrderConfirmation"
  ]
};
export {
  checkoutTranslationChunksConfig,
  checkoutTranslations
};
//# sourceMappingURL=@spartacus_checkout_base_assets.js.map
