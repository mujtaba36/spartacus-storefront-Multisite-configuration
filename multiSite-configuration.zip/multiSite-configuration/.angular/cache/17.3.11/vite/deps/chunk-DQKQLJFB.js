import {
  GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG,
  StoreFinderOutlets
} from "./chunk-2R5TI3FB.js";
import {
  BtnLikeLinkDirective,
  BtnLikeLinkModule,
  DefaultValueAccessor,
  FormControlDirective,
  ICON_TYPE,
  IconComponent,
  IconModule,
  ListNavigationModule,
  NgControlStatus,
  OutletDirective,
  OutletModule,
  PaginationComponent,
  ReactiveFormsModule,
  SpinnerComponent,
  SpinnerModule,
  UntypedFormControl
} from "./chunk-FIMZ5LIU.js";
import {
  ActivatedRoute,
  Config,
  ConverterService,
  FeatureDirective,
  FeaturesConfigModule,
  GlobalMessageService,
  GlobalMessageType,
  I18nModule,
  LoggerService,
  OccEndpointsService,
  POINT_OF_SERVICE_NORMALIZER,
  RouterLink,
  RouterModule,
  RouterOutlet,
  RoutingService,
  ScriptLoader,
  TranslatePipe,
  UrlModule,
  WindowRef,
  provideDefaultConfig,
  siteContextGroup_actions,
  tryNormalizeHttpError,
  useFeatureStyles,
  utilsGroup
} from "./chunk-CJWHFW34.js";
import {
  Actions,
  EffectsFeatureModule,
  EffectsModule,
  createEffect,
  ofType
} from "./chunk-OIYGDMWQ.js";
import {
  Store,
  StoreFeatureModule,
  StoreModule,
  createFeatureSelector,
  createSelector,
  select
} from "./chunk-PJOH4OHD.js";
import {
  AsyncPipe,
  CommonModule,
  DOCUMENT,
  HttpClient,
  JsonPipe,
  KeyValuePipe,
  NgClass,
  NgForOf,
  NgIf,
  NgSwitch,
  NgSwitchCase,
  NgTemplateOutlet,
  isPlatformBrowser
} from "./chunk-XWT3SXR6.js";
import {
  ChangeDetectionStrategy,
  Component,
  Directive,
  EventEmitter,
  Inject,
  Injectable,
  InjectionToken,
  Input,
  NgModule,
  Optional,
  Output,
  PLATFORM_ID,
  Subscription,
  ViewChild,
  catchError,
  filter,
  inject,
  isDevMode,
  map,
  mergeMap,
  of,
  setClassMetadata,
  switchMap,
  withLatestFrom,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵdefineComponent,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinject,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵprojection,
  ɵɵprojectionDef,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵpureFunction3,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-JMCPXHNJ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/storefinder/fesm2022/spartacus-storefinder-core.mjs
var StoreFinderConfig = class _StoreFinderConfig {
  static {
    this.ɵfac = function StoreFinderConfig_Factory(t) {
      return new (t || _StoreFinderConfig)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _StoreFinderConfig,
      factory: function StoreFinderConfig_Factory(t) {
        let r = null;
        if (t) {
          r = new (t || _StoreFinderConfig)();
        } else {
          r = ɵɵinject(Config);
        }
        return r;
      },
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderConfig, [{
    type: Injectable,
    args: [{
      providedIn: "root",
      useExisting: Config
    }]
  }], null, null);
})();
var StoreFinderAdapter = class {
};
var StoreFinderConnector = class _StoreFinderConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  search(query, searchConfig, longitudeLatitude, radius) {
    return this.adapter.search(query, searchConfig, longitudeLatitude, radius);
  }
  getCounts() {
    return this.adapter.loadCounts();
  }
  get(storeId) {
    return this.adapter.load(storeId);
  }
  static {
    this.ɵfac = function StoreFinderConnector_Factory(t) {
      return new (t || _StoreFinderConnector)(ɵɵinject(StoreFinderAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _StoreFinderConnector,
      factory: _StoreFinderConnector.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderConnector, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: StoreFinderAdapter
  }], null);
})();
var STORE_FINDER_SEARCH_PAGE_NORMALIZER = new InjectionToken("StoreFinderSearchPageNormalizer");
var STORE_COUNT_NORMALIZER = new InjectionToken("StoreCountNormalizer");
var STORE_FINDER_FEATURE = "stores";
var STORE_FINDER_DATA = "[StoreFinder] Store Finder Data";
var FIND_STORES_ON_HOLD = "[StoreFinder] On Hold";
var FIND_STORES = "[StoreFinder] Find Stores";
var FIND_STORES_FAIL = "[StoreFinder] Find Stores Fail";
var FIND_STORES_SUCCESS = "[StoreFinder] Find Stores Success";
var FIND_STORE_BY_ID = "[StoreFinder] Find a Store by Id";
var FIND_STORE_BY_ID_FAIL = "[StoreFinder] Find a Store by Id Fail";
var FIND_STORE_BY_ID_SUCCESS = "[StoreFinder] Find a Store by Id Success";
var FindStoresOnHold = class extends utilsGroup.LoaderLoadAction {
  constructor() {
    super(STORE_FINDER_DATA);
    this.type = FIND_STORES_ON_HOLD;
  }
};
var FindStores = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(STORE_FINDER_DATA);
    this.payload = payload;
    this.type = FIND_STORES;
  }
};
var FindStoresFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(STORE_FINDER_DATA, payload);
    this.payload = payload;
    this.type = FIND_STORES_FAIL;
  }
};
var FindStoresSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(STORE_FINDER_DATA);
    this.payload = payload;
    this.type = FIND_STORES_SUCCESS;
  }
};
var FindStoreById = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(STORE_FINDER_DATA);
    this.payload = payload;
    this.type = FIND_STORE_BY_ID;
  }
};
var FindStoreByIdFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(STORE_FINDER_DATA, payload);
    this.payload = payload;
    this.type = FIND_STORE_BY_ID_FAIL;
  }
};
var FindStoreByIdSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(STORE_FINDER_DATA);
    this.payload = payload;
    this.type = FIND_STORE_BY_ID_SUCCESS;
  }
};
var VIEW_ALL_STORES = "[StoreFinder] View All Stores";
var VIEW_ALL_STORES_FAIL = "[StoreFinder] View All Stores Fail";
var VIEW_ALL_STORES_SUCCESS = "[StoreFinder] View All Stores Success";
var CLEAR_STORE_FINDER_DATA = "[StoreFinder] Clear Data";
var ViewAllStores = class extends utilsGroup.LoaderLoadAction {
  constructor() {
    super(STORE_FINDER_DATA);
    this.type = VIEW_ALL_STORES;
  }
};
var ViewAllStoresFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(STORE_FINDER_DATA, payload);
    this.payload = payload;
    this.type = VIEW_ALL_STORES_FAIL;
  }
};
var ViewAllStoresSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(STORE_FINDER_DATA);
    this.payload = payload;
    this.type = VIEW_ALL_STORES_SUCCESS;
  }
};
var ClearStoreFinderData = class {
  constructor() {
    this.type = CLEAR_STORE_FINDER_DATA;
  }
};
var storeFinderGroup_actions = Object.freeze({
  __proto__: null,
  CLEAR_STORE_FINDER_DATA,
  ClearStoreFinderData,
  FIND_STORES,
  FIND_STORES_FAIL,
  FIND_STORES_ON_HOLD,
  FIND_STORES_SUCCESS,
  FIND_STORE_BY_ID,
  FIND_STORE_BY_ID_FAIL,
  FIND_STORE_BY_ID_SUCCESS,
  FindStoreById,
  FindStoreByIdFail,
  FindStoreByIdSuccess,
  FindStores,
  FindStoresFail,
  FindStoresOnHold,
  FindStoresSuccess,
  VIEW_ALL_STORES,
  VIEW_ALL_STORES_FAIL,
  VIEW_ALL_STORES_SUCCESS,
  ViewAllStores,
  ViewAllStoresFail,
  ViewAllStoresSuccess
});
var getStoreFinderState = createFeatureSelector(STORE_FINDER_FEATURE);
var getFindStoresState = createSelector(getStoreFinderState, (storesState) => storesState.findStores);
var getFindStoresEntities = createSelector(getFindStoresState, (state) => utilsGroup.loaderValueSelector(state));
var getStoresLoading = createSelector(getFindStoresState, (state) => utilsGroup.loaderLoadingSelector(state));
var getStoresSuccess = createSelector(getFindStoresState, (state) => utilsGroup.loaderSuccessSelector(state));
var getViewAllStoresState = createSelector(getStoreFinderState, (storesState) => storesState.viewAllStores);
var getViewAllStoresEntities = createSelector(getViewAllStoresState, (state) => utilsGroup.loaderValueSelector(state));
var getViewAllStoresLoading = createSelector(getViewAllStoresState, (state) => utilsGroup.loaderLoadingSelector(state));
var storeFinderGroup_selectors = Object.freeze({
  __proto__: null,
  getFindStoresEntities,
  getFindStoresState,
  getStoresLoading,
  getStoresSuccess,
  getViewAllStoresEntities,
  getViewAllStoresLoading,
  getViewAllStoresState
});
var StoreFinderService = class _StoreFinderService {
  constructor(store, winRef, globalMessageService, routingService, platformId) {
    this.store = store;
    this.winRef = winRef;
    this.globalMessageService = globalMessageService;
    this.routingService = routingService;
    this.platformId = platformId;
    this.geolocationWatchId = null;
    this.subscription = new Subscription();
    this.reloadStoreEntitiesOnContextChange();
  }
  /**
   * Returns boolean observable for store's loading state
   */
  getStoresLoading() {
    return this.store.pipe(select(getStoresLoading));
  }
  /**
   * Returns boolean observable for store's success state
   */
  getStoresLoaded() {
    return this.store.pipe(select(getStoresSuccess));
  }
  /**
   * Returns observable for store's entities
   * CXSPA-4871: The return value of this method signature is wrong, should be StoreFinderSearchPage.
   */
  getFindStoresEntities() {
    return this.store.pipe(select(getFindStoresEntities), map((data) => data.findStoresEntities));
  }
  /**
   * Returns observable for a single store by Id
   */
  getFindStoreEntityById() {
    return this.store.pipe(select(getFindStoresEntities), map((data) => data.findStoreEntityById));
  }
  /**
   * Returns boolean observable for view all store's loading state
   */
  getViewAllStoresLoading() {
    return this.store.pipe(select(getViewAllStoresLoading));
  }
  /**
   * Returns observable for view all store's entities
   */
  getViewAllStoresEntities() {
    return this.store.pipe(select(getViewAllStoresEntities), map((data) => data.viewAllStoresEntities));
  }
  /**
   * Store finding action functionality
   * @param queryText text query
   * @param searchConfig search configuration
   * @param longitudeLatitude longitude and latitude coordinates
   * @param countryIsoCode country ISO code
   * @param useMyLocation current location coordinates
   * @param radius radius of the scope from the center point
   */
  findStoresAction(queryText, searchConfig, longitudeLatitude, countryIsoCode, useMyLocation, radius) {
    if (useMyLocation && this.winRef.nativeWindow) {
      this.clearWatchGeolocation(new FindStoresOnHold());
      this.geolocationWatchId = this.winRef.nativeWindow.navigator.geolocation.watchPosition((pos) => {
        const position = {
          longitude: pos.coords.longitude,
          latitude: pos.coords.latitude
        };
        this.clearWatchGeolocation(new FindStores({
          queryText,
          searchConfig,
          longitudeLatitude: position,
          countryIsoCode,
          radius
        }));
      }, () => {
        this.globalMessageService.add({
          key: "storeFinder.geolocationNotEnabled"
        }, GlobalMessageType.MSG_TYPE_ERROR);
        this.routingService.go(["/store-finder"]);
      });
    } else {
      this.clearWatchGeolocation(new FindStores({
        queryText,
        searchConfig,
        longitudeLatitude,
        countryIsoCode,
        radius
      }));
    }
  }
  /**
   * View all stores
   */
  viewAllStores() {
    this.clearWatchGeolocation(new ViewAllStores());
  }
  /**
   * View all stores by id
   * @param storeId store id
   */
  viewStoreById(storeId) {
    this.clearWatchGeolocation(new FindStoreById({
      storeId
    }));
  }
  clearWatchGeolocation(callbackAction) {
    if (this.geolocationWatchId !== null) {
      this.winRef.nativeWindow?.navigator.geolocation.clearWatch(this.geolocationWatchId);
      this.geolocationWatchId = null;
    }
    this.store.dispatch(callbackAction);
  }
  isEmpty(store) {
    return !store || typeof store === "object" && Object.keys(store).length === 0;
  }
  /**
   * Reload store data when store entities are empty because of the context change
   */
  reloadStoreEntitiesOnContextChange() {
    if (isPlatformBrowser(this.platformId) || !this.platformId) {
      this.subscription = this.getFindStoresEntities().pipe(filter((data) => this.isEmpty(data)), withLatestFrom(this.getStoresLoading(), this.getStoresLoaded(), this.routingService.getParams())).subscribe(([, loading, loaded, routeParams]) => {
        if (!loading && !loaded) {
          if (routeParams.country && !routeParams.store) {
            this.callFindStoresAction(routeParams);
          }
          if (routeParams.store) {
            this.viewStoreById(routeParams.store);
          }
        }
      });
    }
  }
  callFindStoresAction(routeParams) {
    this.findStoresAction("", {
      pageSize: -1
    }, void 0, routeParams.country);
  }
  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
  /**
   * Returns store latitude
   * @param location store location
   */
  getStoreLatitude(location) {
    return location?.geoPoint?.latitude;
  }
  /**
   * Returns store longitude
   * @param location store location
   */
  getStoreLongitude(location) {
    return location?.geoPoint?.longitude;
  }
  /**
   * Generates a link leading to the directions of the given store location
   * @param location store location
   * @returns URL for directions to the store
   */
  getDirections(location) {
    const url = "https://www.google.com/maps/dir/Current+Location/";
    const latitude = this.getStoreLatitude(location);
    const longitude = this.getStoreLongitude(location);
    return url + latitude + "," + longitude;
  }
  static {
    this.ɵfac = function StoreFinderService_Factory(t) {
      return new (t || _StoreFinderService)(ɵɵinject(Store), ɵɵinject(WindowRef), ɵɵinject(GlobalMessageService), ɵɵinject(RoutingService), ɵɵinject(PLATFORM_ID));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _StoreFinderService,
      factory: _StoreFinderService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: Store
  }, {
    type: WindowRef
  }, {
    type: GlobalMessageService
  }, {
    type: RoutingService
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [PLATFORM_ID]
    }]
  }], null);
})();
var GoogleMapRendererService = class _GoogleMapRendererService {
  constructor(config, storeFinderService, scriptLoader) {
    this.config = config;
    this.storeFinderService = storeFinderService;
    this.scriptLoader = scriptLoader;
    this.googleMap = null;
    this.logger = inject(LoggerService);
  }
  /**
   * Renders google map on the given element and draws markers on it.
   * If map already exists it will use an existing map otherwise it will create one
   * @param mapElement HTML element inside of which the map will be displayed
   * @param locations array containign geo data to be displayed on the map
   * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
   */
  renderMap(mapElement, locations, selectMarkerHandler) {
    if (this.config.googleMaps?.apiKey) {
      if (Object.entries(locations[Object.keys(locations)[0]]).length > 0) {
        if (this.googleMap === null) {
          const apiKey = this.config.googleMaps.apiKey === GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG ? "" : this.config.googleMaps.apiKey;
          this.scriptLoader.embedScript({
            src: this.config.googleMaps.apiUrl,
            params: {
              key: apiKey
            },
            attributes: {
              type: "text/javascript"
            },
            callback: () => {
              this.drawMap(mapElement, locations, selectMarkerHandler);
            }
          });
        } else {
          this.drawMap(mapElement, locations, selectMarkerHandler);
        }
      }
    } else {
      if (isDevMode()) {
        this.logger.warn("A Google Maps api key is required in the store finder configuration to display the Google map.");
      }
    }
  }
  /**
   * Centers the map to the given point
   * @param latitute latitude of the new center
   * @param longitude longitude of the new center
   */
  centerMap(latitute, longitude) {
    this.googleMap.panTo({
      lat: latitute,
      lng: longitude
    });
    this.googleMap.setZoom(this.config.googleMaps.selectedMarkerScale);
  }
  /**
   * Defines and returns {@link google.maps.LatLng} representing a point where the map will be centered
   * @param locations list of locations
   */
  defineMapCenter(locations) {
    return new google.maps.LatLng(this.storeFinderService.getStoreLatitude(locations[0]), this.storeFinderService.getStoreLongitude(locations[0]));
  }
  /**
   * Creates google map inside if the given HTML element centered to the given point
   * @param mapElement {@link HTMLElement} inside of which the map will be created
   * @param mapCenter {@link google.maps.LatLng} the point where the map will be centered
   */
  initMap(mapElement, mapCenter) {
    const gestureOption = "greedy";
    const mapProp = {
      center: mapCenter,
      zoom: this.config.googleMaps.scale,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      gestureHandling: gestureOption
    };
    this.googleMap = new google.maps.Map(mapElement, mapProp);
  }
  /**
   * Erases the current map's markers and create a new one based on the given locations
   * @param locations array of locations to be displayed on the map
   * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
   */
  createMarkers(locations, selectMarkerHandler) {
    this.markers = [];
    locations.forEach((element, index) => {
      const marker = new google.maps.Marker({
        position: new google.maps.LatLng(this.storeFinderService.getStoreLatitude(element), this.storeFinderService.getStoreLongitude(element)),
        label: index + 1 + ""
      });
      this.markers.push(marker);
      marker.setMap(this.googleMap);
      marker.addListener("mouseover", function() {
        marker.setAnimation(google.maps.Animation.BOUNCE);
      });
      marker.addListener("mouseout", function() {
        marker.setAnimation(null);
      });
      if (selectMarkerHandler) {
        marker.addListener("click", function() {
          selectMarkerHandler(index);
        });
      }
    });
  }
  /**
   * Initialize and draw the map
   * @param mapElement {@link HTMLElement} inside of which the map will be drawn
   * @param locations array of locations to be displayed on the map
   * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
   */
  drawMap(mapElement, locations, selectMarkerHandler) {
    this.initMap(mapElement, this.defineMapCenter(locations));
    this.createMarkers(locations, selectMarkerHandler);
  }
  static {
    this.ɵfac = function GoogleMapRendererService_Factory(t) {
      return new (t || _GoogleMapRendererService)(ɵɵinject(StoreFinderConfig), ɵɵinject(StoreFinderService), ɵɵinject(ScriptLoader));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _GoogleMapRendererService,
      factory: _GoogleMapRendererService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(GoogleMapRendererService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: StoreFinderConfig
  }, {
    type: StoreFinderService
  }, {
    type: ScriptLoader
  }], null);
})();
var defaultStoreFinderConfig = {
  googleMaps: {
    apiUrl: "https://maps.googleapis.com/maps/api/js",
    apiKey: "",
    scale: 5,
    selectedMarkerScale: 17,
    radius: 5e4
  }
};
var initialState$1 = {
  findStoresEntities: {},
  findStoreEntityById: {}
};
function findStoresReducer(state = initialState$1, action) {
  switch (action.type) {
    case FIND_STORES_SUCCESS: {
      const findStoresEntities = action.payload;
      return __spreadProps(__spreadValues({}, state), {
        findStoresEntities
      });
    }
    case FIND_STORE_BY_ID_SUCCESS: {
      const findStoreEntityById = action.payload;
      return __spreadProps(__spreadValues({}, state), {
        findStoreEntityById
      });
    }
  }
  return state;
}
var initialState = {
  viewAllStoresEntities: {}
};
function viewAllStoresReducer(state = initialState, action) {
  switch (action.type) {
    case VIEW_ALL_STORES_SUCCESS: {
      const viewAllStoresEntities = action.payload;
      return __spreadProps(__spreadValues({}, state), {
        viewAllStoresEntities
      });
    }
  }
  return state;
}
function getReducers() {
  return {
    findStores: utilsGroup.loaderReducer(STORE_FINDER_DATA, findStoresReducer),
    viewAllStores: utilsGroup.loaderReducer(STORE_FINDER_DATA, viewAllStoresReducer)
  };
}
var reducerToken = new InjectionToken("StoreFinderReducers");
var reducerProvider = {
  provide: reducerToken,
  useFactory: getReducers
};
function clearStoreFinderState(reducer) {
  return function(state, action) {
    if (action.type === siteContextGroup_actions.LANGUAGE_CHANGE) {
      state = void 0;
    }
    if (action.type === CLEAR_STORE_FINDER_DATA) {
      state = void 0;
    }
    return reducer(state, action);
  };
}
var metaReducers = [clearStoreFinderState];
var FindStoresEffect = class _FindStoresEffect {
  constructor(actions$, storeFinderConnector) {
    this.actions$ = actions$;
    this.storeFinderConnector = storeFinderConnector;
    this.logger = inject(LoggerService);
    this.findStores$ = createEffect(() => this.actions$.pipe(ofType(FIND_STORES), map((action) => action.payload), mergeMap((payload) => this.storeFinderConnector.search(payload.queryText, payload.searchConfig, payload.longitudeLatitude, payload.radius).pipe(map((data) => {
      if (payload.countryIsoCode) {
        data.stores = data.stores.filter((store) => store.address.country.isocode === payload.countryIsoCode);
        data.stores.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
      }
      return new FindStoresSuccess(data);
    }), catchError((error) => of(new FindStoresFail(tryNormalizeHttpError(error, this.logger))))))));
    this.findStoreById$ = createEffect(() => this.actions$.pipe(ofType(FIND_STORE_BY_ID), map((action) => action.payload), switchMap((payload) => this.storeFinderConnector.get(payload.storeId).pipe(map((data) => new FindStoreByIdSuccess(data)), catchError((error) => of(new FindStoreByIdFail(tryNormalizeHttpError(error, this.logger))))))));
  }
  static {
    this.ɵfac = function FindStoresEffect_Factory(t) {
      return new (t || _FindStoresEffect)(ɵɵinject(Actions), ɵɵinject(StoreFinderConnector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _FindStoresEffect,
      factory: _FindStoresEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FindStoresEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: StoreFinderConnector
  }], null);
})();
var ViewAllStoresEffect = class _ViewAllStoresEffect {
  constructor(actions$, storeFinderConnector) {
    this.actions$ = actions$;
    this.storeFinderConnector = storeFinderConnector;
    this.logger = inject(LoggerService);
    this.viewAllStores$ = createEffect(() => this.actions$.pipe(ofType(VIEW_ALL_STORES, CLEAR_STORE_FINDER_DATA), switchMap(() => {
      return this.storeFinderConnector.getCounts().pipe(map((data) => {
        data.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
        return new ViewAllStoresSuccess(data);
      }), catchError((error) => of(new ViewAllStoresFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.clearStoreFinderData$ = createEffect(() => this.actions$.pipe(ofType(siteContextGroup_actions.LANGUAGE_CHANGE, siteContextGroup_actions.CURRENCY_CHANGE), map(() => {
      return new ClearStoreFinderData();
    })));
  }
  static {
    this.ɵfac = function ViewAllStoresEffect_Factory(t) {
      return new (t || _ViewAllStoresEffect)(ɵɵinject(Actions), ɵɵinject(StoreFinderConnector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ViewAllStoresEffect,
      factory: _ViewAllStoresEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ViewAllStoresEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: StoreFinderConnector
  }], null);
})();
var effects = [FindStoresEffect, ViewAllStoresEffect];
var StoreFinderStoreModule = class _StoreFinderStoreModule {
  static {
    this.ɵfac = function StoreFinderStoreModule_Factory(t) {
      return new (t || _StoreFinderStoreModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _StoreFinderStoreModule,
      imports: [CommonModule, StoreFeatureModule, EffectsFeatureModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [reducerProvider],
      imports: [CommonModule, StoreModule.forFeature(STORE_FINDER_FEATURE, reducerToken, {
        metaReducers
      }), EffectsModule.forFeature(effects)]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderStoreModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, StoreModule.forFeature(STORE_FINDER_FEATURE, reducerToken, {
        metaReducers
      }), EffectsModule.forFeature(effects)],
      providers: [reducerProvider]
    }]
  }], null, null);
})();
var StoreFinderCoreModule = class _StoreFinderCoreModule {
  static {
    this.ɵfac = function StoreFinderCoreModule_Factory(t) {
      return new (t || _StoreFinderCoreModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _StoreFinderCoreModule,
      imports: [StoreFinderStoreModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultStoreFinderConfig), StoreFinderConnector],
      imports: [StoreFinderStoreModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderCoreModule, [{
    type: NgModule,
    args: [{
      imports: [StoreFinderStoreModule],
      providers: [provideDefaultConfig(defaultStoreFinderConfig), StoreFinderConnector]
    }]
  }], null, null);
})();

// node_modules/@spartacus/storefinder/fesm2022/spartacus-storefinder-occ.mjs
var OccStoreFinderAdapter = class _OccStoreFinderAdapter {
  constructor(http, occEndpointsService, converterService) {
    this.http = http;
    this.occEndpointsService = occEndpointsService;
    this.converterService = converterService;
  }
  search(query, searchConfig, longitudeLatitude, radius) {
    return this.callOccFindStores(query, searchConfig, longitudeLatitude, radius).pipe(this.converterService.pipeable(STORE_FINDER_SEARCH_PAGE_NORMALIZER));
  }
  loadCounts() {
    return this.http.get(this.occEndpointsService.buildUrl("storescounts")).pipe(map(({
      countriesAndRegionsStoreCount
    }) => countriesAndRegionsStoreCount), this.converterService.pipeableMany(STORE_COUNT_NORMALIZER));
  }
  load(storeId) {
    return this.http.get(this.occEndpointsService.buildUrl("store", {
      urlParams: {
        storeId
      }
    })).pipe(this.converterService.pipeable(POINT_OF_SERVICE_NORMALIZER));
  }
  callOccFindStores(query, searchConfig, longitudeLatitude, radius) {
    const params = {};
    if (longitudeLatitude) {
      params["longitude"] = String(longitudeLatitude.longitude);
      params["latitude"] = String(longitudeLatitude.latitude);
    } else {
      params["query"] = query;
    }
    if (radius) {
      params["radius"] = String(radius);
    }
    if (searchConfig?.pageSize) {
      params["pageSize"] = String(searchConfig.pageSize);
    }
    if (searchConfig?.currentPage) {
      params["currentPage"] = String(searchConfig.currentPage);
    }
    if (searchConfig?.sort) {
      params["sort"] = searchConfig.sort;
    }
    return this.http.get(this.occEndpointsService.buildUrl("stores", {
      queryParams: params
    }));
  }
  static {
    this.ɵfac = function OccStoreFinderAdapter_Factory(t) {
      return new (t || _OccStoreFinderAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccStoreFinderAdapter,
      factory: _OccStoreFinderAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccStoreFinderAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var defaultOccStoreFinderConfig = {
  backend: {
    occ: {
      endpoints: {
        store: "stores/${storeId}?fields=FULL",
        stores: "stores?fields=stores(name,displayName,formattedDistance,openingHours(weekDayOpeningList(FULL),specialDayOpeningList(FULL)),geoPoint(latitude,longitude),address(line1,line2,town,region(FULL),postalCode,phone,country,email), features),pagination(DEFAULT),sorts(DEFAULT)",
        storescounts: "stores/storescounts"
      }
    }
  }
};
var StoreFinderOccModule = class _StoreFinderOccModule {
  static {
    this.ɵfac = function StoreFinderOccModule_Factory(t) {
      return new (t || _StoreFinderOccModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _StoreFinderOccModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultOccStoreFinderConfig), {
        provide: StoreFinderAdapter,
        useClass: OccStoreFinderAdapter
      }]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderOccModule, [{
    type: NgModule,
    args: [{
      providers: [provideDefaultConfig(defaultOccStoreFinderConfig), {
        provide: StoreFinderAdapter,
        useClass: OccStoreFinderAdapter
      }]
    }]
  }], null, null);
})();

// node_modules/@spartacus/storefinder/fesm2022/spartacus-storefinder-components.mjs
var _c0 = ["*"];
function ScheduleComponent_div_1_div_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 7);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "storeFinder.closed"), " ");
  }
}
function ScheduleComponent_div_1_div_1_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 8);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const day_r1 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", day_r1.openingTime == null ? null : day_r1.openingTime.formattedHour, " - ", day_r1.closingTime == null ? null : day_r1.closingTime.formattedHour, " ");
  }
}
function ScheduleComponent_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 3)(1, "div", 4);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵtemplate(3, ScheduleComponent_div_1_div_1_div_3_Template, 3, 3, "div", 5)(4, ScheduleComponent_div_1_div_1_div_4_Template, 2, 2, "div", 6);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const day_r1 = ctx.$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate(day_r1.weekDay);
    ɵɵadvance();
    ɵɵproperty("ngIf", day_r1.closed);
    ɵɵadvance();
    ɵɵproperty("ngIf", !day_r1.closed);
  }
}
function ScheduleComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, ScheduleComponent_div_1_div_1_Template, 5, 3, "div", 2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r1.weekDays);
  }
}
var _c1 = (a0, a1) => ({
  displayName: a0,
  name: a1
});
var _c2 = (a0) => [a0];
var _c3 = (a0, a1, a2) => [a0, a1, a2];
function StoreFinderListItemComponent_a_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "a", 8);
    ɵɵlistener("click", function StoreFinderListItemComponent_a_4_Template_a_click_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.handleStoreItemClick());
    })("keyup", function StoreFinderListItemComponent_a_4_Template_a_keyup_0_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onKey($event));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r1.location.displayName || ctx_r1.location.name, " ");
  }
}
function StoreFinderListItemComponent_a_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 9);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("routerLink", ɵɵpureFunction1(2, _c2, ctx_r1.location.name));
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r1.location.displayName || ctx_r1.location.name, " ");
  }
}
function StoreFinderListItemComponent_div_6_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 13);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r1.location.formattedDistance, " ");
  }
}
function StoreFinderListItemComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 10)(1, "div", 11);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵtext(3);
    ɵɵtemplate(4, StoreFinderListItemComponent_div_6_div_4_Template, 2, 1, "div", 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵtextInterpolate2(" ", ctx_r1.location.address.line1, " ", ctx_r1.location.address.line2, " ");
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r1.getFormattedStoreAddress(ɵɵpureFunction3(4, _c3, ctx_r1.location.address.town, ctx_r1.location.address.postalCode, ctx_r1.location.address.country.isocode)), " ");
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.location.formattedDistance && ctx_r1.displayDistance);
  }
}
function StoreFinderListItemComponent_ng_template_7_Template(rf, ctx) {
}
function StoreFinderListItemComponent_a_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "a", 14);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("click", function StoreFinderListItemComponent_a_8_Template_a_click_0_listener($event) {
      ɵɵrestoreView(_r3);
      return ɵɵresetView($event.stopPropagation());
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵpropertyInterpolate("href", ctx_r1.getDirections(ctx_r1.location), ɵɵsanitizeUrl);
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 3, "storeFinder.ariaLabelGetDirections"));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 5, "storeFinder.getDirections"));
  }
}
function StoreFinderListItemComponent_a_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "a", 15);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("click", function StoreFinderListItemComponent_a_9_Template_a_click_0_listener($event) {
      ɵɵrestoreView(_r4);
      return ɵɵresetView($event.stopPropagation());
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵpropertyInterpolate("href", ctx_r1.getDirections(ctx_r1.location), ɵɵsanitizeUrl);
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 3, "storeFinder.ariaLabelGetDirections"));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 5, "storeFinder.getDirections"));
  }
}
var _c4 = (a0) => ({
  count: a0
});
function StoreFinderGridComponent_ng_container_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 8);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loaded"));
  }
}
function StoreFinderGridComponent_ng_container_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 9)(1, "h3", 10);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "span", 11);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const locations_r1 = ɵɵnextContext().ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "storeFinder.storesFoundTitle"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(6, 4, "storeFinder.storesFound", ɵɵpureFunction1(7, _c4, locations_r1 == null ? null : locations_r1.stores == null ? null : locations_r1.stores.length)), " ");
  }
}
function StoreFinderGridComponent_ng_container_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 12);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const locations_r1 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(2, 1, "storeFinder.storesFound", ɵɵpureFunction1(4, _c4, locations_r1 == null ? null : locations_r1.stores == null ? null : locations_r1.stores.length)), " ");
  }
}
function StoreFinderGridComponent_ng_container_0_div_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 13);
    ɵɵelement(1, "cx-store-finder-list-item", 14);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const location_r2 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("location", location_r2);
  }
}
function StoreFinderGridComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, StoreFinderGridComponent_ng_container_0_div_1_Template, 2, 3, "div", 2);
    ɵɵelementStart(2, "div", 3);
    ɵɵtemplate(3, StoreFinderGridComponent_ng_container_0_div_3_Template, 7, 9, "div", 4)(4, StoreFinderGridComponent_ng_container_0_div_4_Template, 3, 6, "div", 5);
    ɵɵelementStart(5, "div", 6);
    ɵɵtemplate(6, StoreFinderGridComponent_ng_container_0_div_6_Template, 2, 1, "div", 7);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const locations_r1 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yRemoveStatusLoadedRole");
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "a11yStoreFinderAlerts");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yStoreFinderAlerts");
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", locations_r1 == null ? null : locations_r1.stores);
  }
}
function StoreFinderGridComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
var _c5 = () => ["/store-finder/find"];
var _c6 = (a0) => ({
  query: a0
});
var _c7 = (a0) => ({
  "disabled-action": a0
});
var _c8 = () => ["/store-finder/view-all"];
function StoreFinderSearchComponent_div_1_ng_template_10_Template(rf, ctx) {
}
function StoreFinderSearchComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 5)(1, "div", 6)(2, "div", 7)(3, "input", 8, 1);
    ɵɵpipe(5, "cxTranslate");
    ɵɵpipe(6, "cxTranslate");
    ɵɵlistener("keyup", function StoreFinderSearchComponent_div_1_Template_input_keyup_3_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onKey($event));
    });
    ɵɵelementEnd();
    ɵɵelementStart(7, "cx-icon", 9);
    ɵɵpipe(8, "cxTranslate");
    ɵɵpipe(9, "cxTranslate");
    ɵɵlistener("keyup", function StoreFinderSearchComponent_div_1_Template_cx_icon_keyup_7_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onKey($event));
    });
    ɵɵelementEnd()()();
    ɵɵtemplate(10, StoreFinderSearchComponent_div_1_ng_template_10_Template, 0, 0, "ng-template", 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const queryInput_r3 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    const searchActionButtons_r4 = ɵɵreference(4);
    ɵɵadvance(3);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(5, 11, "storeFinder.searchBox"));
    ɵɵproperty("formControl", ctx_r1.searchBox);
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 13, "storeFinder.searchBoxLabel"));
    ɵɵadvance(4);
    ɵɵproperty("type", ctx_r1.iconTypes.SEARCH)("routerLink", ɵɵpureFunction0(19, _c5))("queryParams", ɵɵpureFunction1(20, _c6, queryInput_r3.value))("ngClass", ɵɵpureFunction1(22, _c7, !(queryInput_r3.value && queryInput_r3.value.length)));
    ɵɵattribute("tabindex", (queryInput_r3.value == null ? null : queryInput_r3.value.length) ? 0 : -1)("aria-label", ɵɵpipeBind1(8, 15, "storeFinder.searchNearestStores"))("title", ɵɵpipeBind1(9, 17, "storeFinder.searchNearestStores"));
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", searchActionButtons_r4);
  }
}
function StoreFinderSearchComponent_div_2_ng_template_14_Template(rf, ctx) {
}
function StoreFinderSearchComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 11)(1, "div", 6)(2, "div", 12)(3, "label", 13)(4, "span", 14);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(7, "div", 15)(8, "input", 16, 1);
    ɵɵpipe(10, "cxTranslate");
    ɵɵlistener("keyup", function StoreFinderSearchComponent_div_2_Template_input_keyup_8_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onKey($event));
    });
    ɵɵelementEnd();
    ɵɵelementStart(11, "cx-icon", 9);
    ɵɵpipe(12, "cxTranslate");
    ɵɵpipe(13, "cxTranslate");
    ɵɵlistener("keyup", function StoreFinderSearchComponent_div_2_Template_cx_icon_keyup_11_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onKey($event));
    });
    ɵɵelementEnd()()()()();
    ɵɵtemplate(14, StoreFinderSearchComponent_div_2_ng_template_14_Template, 0, 0, "ng-template", 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const queryInput_r6 = ɵɵreference(9);
    const ctx_r1 = ɵɵnextContext();
    const searchActionButtons_r4 = ɵɵreference(4);
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 11, "storeFinder.findStoreBy"), " ");
    ɵɵadvance(3);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(10, 13, "storeFinder.searchBox"));
    ɵɵproperty("formControl", ctx_r1.searchBox);
    ɵɵadvance(3);
    ɵɵproperty("type", ctx_r1.iconTypes.SEARCH)("routerLink", ɵɵpureFunction0(19, _c5))("queryParams", ɵɵpureFunction1(20, _c6, queryInput_r6.value))("ngClass", ɵɵpureFunction1(22, _c7, !(queryInput_r6.value && queryInput_r6.value.length)));
    ɵɵattribute("tabindex", (queryInput_r6.value == null ? null : queryInput_r6.value.length) ? 0 : -1)("aria-label", ɵɵpipeBind1(12, 15, "storeFinder.searchNearestStores"))("title", ɵɵpipeBind1(13, 17, "storeFinder.searchNearestStores"));
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", searchActionButtons_r4);
  }
}
function StoreFinderSearchComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 6)(1, "div", 17)(2, "div", 18)(3, "button", 19);
    ɵɵlistener("click", function StoreFinderSearchComponent_ng_template_3_Template_button_click_3_listener() {
      ɵɵrestoreView(_r7);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.viewStoresWithMyLoc());
    });
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(6, "div", 18)(7, "button", 20);
    ɵɵtext(8);
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 3, "storeFinder.useMyLocation"), " ");
    ɵɵadvance(3);
    ɵɵproperty("routerLink", ɵɵpureFunction0(7, _c8));
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 5, "storeFinder.viewAllStores"), " ");
  }
}
var _c9 = ["mapElement"];
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 13)(1, "div");
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementStart(3, "div");
    ɵɵtext(4);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵtextInterpolate2("", ctx_r0.location.address.line1, " ", ctx_r0.location.address.line2, "");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ctx_r0.getFormattedStoreAddress(ɵɵpureFunction3(3, _c3, ctx_r0.location.address.town, ctx_r0.location.address.postalCode, ctx_r0.location.address.country.isocode)), " ");
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_li_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "li", 7);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(2, 2, "storeFinder.call"), " ", ctx_r0.location.address == null ? null : ctx_r0.location.address.phone, " ");
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 14)(1, "cx-schedule", 15)(2, "h3");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("location", ctx_r0.location);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 2, "storeFinder.storeHours"));
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_15_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 19);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const feature_r2 = ctx.$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", feature_r2.value, " ");
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 16)(1, "h3", 17);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div");
    ɵɵtemplate(5, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_15_div_5_Template, 2, 1, "div", 18);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "storeFinder.storeFeatures"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngForOf", ctx_r0.location.features == null ? null : ctx_r0.location.features.entry);
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_17_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 20);
    ɵɵelement(1, "cx-store-finder-map", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("locations", ɵɵpureFunction1(1, _c2, ctx_r0.location));
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2)(2, "div", 3)(3, "h2");
    ɵɵtext(4);
    ɵɵelementEnd();
    ɵɵtemplate(5, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_5_Template, 5, 7, "div", 4);
    ɵɵelementStart(6, "section", 5)(7, "ul", 6)(8, "li", 7)(9, "a", 8);
    ɵɵpipe(10, "cxTranslate");
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵtemplate(13, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_li_13_Template, 3, 4, "li", 9);
    ɵɵelementEnd()();
    ɵɵtemplate(14, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_14_Template, 5, 4, "div", 10)(15, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_15_Template, 6, 4, "div", 11);
    ɵɵpipe(16, "json");
    ɵɵelementEnd();
    ɵɵtemplate(17, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_div_17_Template, 2, 3, "div", 12);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance(4);
    ɵɵtextInterpolate(ctx_r0.location.displayName || ctx_r0.location.name);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.location.address);
    ɵɵadvance(4);
    ɵɵproperty("href", ctx_r0.getDirections(ctx_r0.location), ɵɵsanitizeUrl);
    ɵɵattribute("aria-label", ɵɵpipeBind1(10, 9, "storeFinder.ariaLabelGetDirections"));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(12, 11, "storeFinder.getDirections"));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.location.address == null ? null : ctx_r0.location.address.phone);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.location.openingHours);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(16, 13, ctx_r0.location.features) !== "{}");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r0.disableMap);
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_p_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 13);
    ɵɵtext(1);
    ɵɵelement(2, "br");
    ɵɵtext(3);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", ctx_r0.location.address.line1, " ", ctx_r0.location.address.line2, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ctx_r0.getFormattedStoreAddress(ɵɵpureFunction3(3, _c3, ctx_r0.location.address.town, ctx_r0.location.address.postalCode, ctx_r0.location.address.country.isocode)), " ");
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_li_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "li", 7);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(2, 2, "storeFinder.call"), " ", ctx_r0.location.address == null ? null : ctx_r0.location.address.phone, " ");
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_div_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 14)(1, "cx-schedule", 15)(2, "h3");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵproperty("location", ctx_r0.location);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 2, "storeFinder.storeHours"));
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_div_16_div_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 29)(1, "div", 30);
    ɵɵtext(2);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const feature_r3 = ctx.$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate(feature_r3.value);
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_div_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 16)(1, "div", 23)(2, "div", 27)(3, "h3", 17);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelementStart(6, "article", 23);
    ɵɵtemplate(7, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_div_16_div_7_Template, 3, 1, "div", 28);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 2, "storeFinder.storeFeatures"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngForOf", ctx_r0.location.features == null ? null : ctx_r0.location.features.entry);
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_article_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "article", 31);
    ɵɵelement(1, "cx-store-finder-map", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵproperty("locations", ɵɵpureFunction1(1, _c2, ctx_r0.location));
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 22)(2, "div", 23)(3, "article", 24)(4, "h2", 25);
    ɵɵtext(5);
    ɵɵelementEnd();
    ɵɵtemplate(6, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_p_6_Template, 4, 7, "p", 4);
    ɵɵelementStart(7, "section", 5)(8, "ul", 6)(9, "li", 7)(10, "a", 8);
    ɵɵpipe(11, "cxTranslate");
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵtemplate(14, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_li_14_Template, 3, 4, "li", 9);
    ɵɵelementEnd()();
    ɵɵtemplate(15, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_div_15_Template, 5, 4, "div", 10)(16, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_div_16_Template, 8, 4, "div", 11);
    ɵɵpipe(17, "json");
    ɵɵelementEnd();
    ɵɵtemplate(18, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_article_18_Template, 2, 3, "article", 26);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ctx_r0.location.displayName || ctx_r0.location.name, " ");
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.location.address);
    ɵɵadvance(4);
    ɵɵproperty("href", ctx_r0.getDirections(ctx_r0.location), ɵɵsanitizeUrl);
    ɵɵattribute("aria-label", ɵɵpipeBind1(11, 9, "storeFinder.ariaLabelGetDirections"));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(13, 11, "storeFinder.getDirections"));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.location.address == null ? null : ctx_r0.location.address.phone);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.location.openingHours);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(17, 13, ctx_r0.location.features) !== "{}");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r0.disableMap);
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_ng_container_1_Template, 19, 15, "ng-container", 0);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.location);
  }
}
function StoreFinderStoreDescriptionComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_1_Template, 18, 15, "ng-container", 1)(2, StoreFinderStoreDescriptionComponent_ng_container_0_ng_container_2_Template, 2, 1, "ng-container", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yStoreFinderOverflow");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yStoreFinderOverflow");
  }
}
var _c10 = ["storeMap"];
var _c11 = (a0) => ({
  "cx-selected-item": a0
});
var _c12 = (a0) => ({
  "nav-link": true,
  active: a0
});
function StoreFinderListComponent_ng_container_0_div_2_button_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 12);
    ɵɵlistener("click", function StoreFinderListComponent_ng_container_0_div_2_button_6_Template_button_click_0_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.hideStoreDetails());
    });
    ɵɵelement(1, "cx-icon", 13);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("type", ctx_r1.iconTypes.CARET_LEFT);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "storeFinder.back"), " ");
  }
}
function StoreFinderListComponent_ng_container_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 6)(1, "div", 7);
    ɵɵelement(2, "cx-store-finder-pagination-details", 8);
    ɵɵelementEnd();
    ɵɵelementStart(3, "div", 9)(4, "div", 10);
    ɵɵtext(5);
    ɵɵelementEnd();
    ɵɵtemplate(6, StoreFinderListComponent_ng_container_0_div_2_button_6_Template, 4, 4, "button", 11);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance(2);
    ɵɵproperty("pagination", ctx_r1.locations.pagination);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ctx_r1.storeDetails == null ? null : ctx_r1.storeDetails.displayName, " ");
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.isDetailsModeVisible);
  }
}
function StoreFinderListComponent_ng_container_0_div_3_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 20);
    ɵɵelement(1, "cx-store-finder-store-description", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("location", ctx_r1.storeDetails)("disableMap", true);
  }
}
function StoreFinderListComponent_ng_container_0_div_3_ol_3_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "li", 24)(1, "cx-store-finder-list-item", 25);
    ɵɵlistener("storeItemClick", function StoreFinderListComponent_ng_container_0_div_3_ol_3_li_1_Template_cx_store_finder_list_item_storeItemClick_1_listener($event) {
      const location_r5 = ɵɵrestoreView(_r4).$implicit;
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.centerStoreOnMapByIndex($event, location_r5));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const location_r5 = ctx.$implicit;
    const i_r6 = ctx.index;
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵpropertyInterpolate("id", "item-" + i_r6);
    ɵɵproperty("ngClass", ɵɵpureFunction1(7, _c11, ctx_r1.selectedStoreIndex === i_r6));
    ɵɵadvance();
    ɵɵproperty("location", location_r5)("locationIndex", i_r6)("displayDistance", ctx_r1.useMylocation)("useClickEvent", true)("listOrderLabel", i_r6 + ctx_r1.locations.pagination.currentPage * ctx_r1.locations.pagination.pageSize + 1);
  }
}
function StoreFinderListComponent_ng_container_0_div_3_ol_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "ol", 22);
    ɵɵtemplate(1, StoreFinderListComponent_ng_container_0_div_3_ol_3_li_1_Template, 2, 9, "li", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r1.locations == null ? null : ctx_r1.locations.stores);
  }
}
function StoreFinderListComponent_ng_container_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 14)(1, "div", 15);
    ɵɵtemplate(2, StoreFinderListComponent_ng_container_0_div_3_div_2_Template, 2, 2, "div", 16)(3, StoreFinderListComponent_ng_container_0_div_3_ol_3_Template, 2, 1, "ol", 17);
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 18)(5, "cx-store-finder-map", 19, 0);
    ɵɵlistener("selectedStoreItem", function StoreFinderListComponent_ng_container_0_div_3_Template_cx_store_finder_map_selectedStoreItem_5_listener($event) {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.selectStoreItemList($event));
    });
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isDetailsModeVisible);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.isDetailsModeVisible);
    ɵɵadvance(2);
    ɵɵproperty("locations", ctx_r1.locations.stores);
  }
}
function StoreFinderListComponent_ng_container_0_div_4_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "li", 32)(1, "button", 33);
    ɵɵlistener("click", function StoreFinderListComponent_ng_container_0_div_4_li_2_Template_button_click_1_listener() {
      const mode_r8 = ɵɵrestoreView(_r7).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.setDisplayMode(mode_r8 == null ? null : mode_r8.value));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const mode_r8 = ctx.$implicit;
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("id", "tab-" + (mode_r8 == null ? null : mode_r8.value))("ngClass", ɵɵpureFunction1(7, _c12, ctx_r1.isDisplayModeActive(mode_r8 == null ? null : mode_r8.value)));
    ɵɵattribute("aria-controls", "tab-" + (mode_r8 == null ? null : mode_r8.value) + "-panel")("aria-selected", ctx_r1.isDisplayModeActive(mode_r8 == null ? null : mode_r8.value));
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 5, "storeFinder." + (mode_r8 == null ? null : mode_r8.value)), " ");
  }
}
function StoreFinderListComponent_ng_container_0_div_4_ng_template_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 20);
    ɵɵelement(1, "cx-store-finder-store-description", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵproperty("location", ctx_r1.storeDetails)("disableMap", true);
  }
}
function StoreFinderListComponent_ng_container_0_div_4_ng_template_6_ol_3_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "li", 24)(1, "cx-store-finder-list-item", 25);
    ɵɵlistener("storeItemClick", function StoreFinderListComponent_ng_container_0_div_4_ng_template_6_ol_3_li_1_Template_cx_store_finder_list_item_storeItemClick_1_listener($event) {
      const location_r10 = ɵɵrestoreView(_r9).$implicit;
      const ctx_r1 = ɵɵnextContext(5);
      return ɵɵresetView(ctx_r1.centerStoreOnMapByIndex($event, location_r10));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const location_r10 = ctx.$implicit;
    const i_r11 = ctx.index;
    const ctx_r1 = ɵɵnextContext(5);
    ɵɵpropertyInterpolate("id", "item-" + i_r11);
    ɵɵproperty("ngClass", ɵɵpureFunction1(7, _c11, ctx_r1.selectedStoreIndex === i_r11));
    ɵɵadvance();
    ɵɵproperty("location", location_r10)("locationIndex", i_r11)("displayDistance", ctx_r1.useMylocation)("useClickEvent", true)("listOrderLabel", i_r11 + ctx_r1.locations.pagination.currentPage * ctx_r1.locations.pagination.pageSize + 1);
  }
}
function StoreFinderListComponent_ng_container_0_div_4_ng_template_6_ol_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "ol", 22);
    ɵɵtemplate(1, StoreFinderListComponent_ng_container_0_div_4_ng_template_6_ol_3_li_1_Template, 2, 9, "li", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r1.locations == null ? null : ctx_r1.locations.stores);
  }
}
function StoreFinderListComponent_ng_container_0_div_4_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 34)(1, "div", 35);
    ɵɵtemplate(2, StoreFinderListComponent_ng_container_0_div_4_ng_template_6_div_2_Template, 2, 2, "div", 16)(3, StoreFinderListComponent_ng_container_0_div_4_ng_template_6_ol_3_Template, 2, 1, "ol", 17);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isDetailsModeVisible);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.isDetailsModeVisible);
  }
}
function StoreFinderListComponent_ng_container_0_div_4_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 36)(1, "div", 37)(2, "cx-store-finder-map", 19, 0);
    ɵɵlistener("selectedStoreItem", function StoreFinderListComponent_ng_container_0_div_4_ng_template_7_Template_cx_store_finder_map_selectedStoreItem_2_listener($event) {
      ɵɵrestoreView(_r12);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.selectStoreItemList($event));
    });
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("locations", ctx_r1.selectedStore ? ɵɵpureFunction1(1, _c2, ctx_r1.selectedStore) : ctx_r1.locations.stores);
  }
}
function StoreFinderListComponent_ng_container_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 26)(1, "ul", 27);
    ɵɵtemplate(2, StoreFinderListComponent_ng_container_0_div_4_li_2_Template, 4, 9, "li", 28);
    ɵɵpipe(3, "keyvalue");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 29)(5, "div", 30);
    ɵɵtemplate(6, StoreFinderListComponent_ng_container_0_div_4_ng_template_6_Template, 4, 2, "ng-template", 31)(7, StoreFinderListComponent_ng_container_0_div_4_ng_template_7_Template, 4, 3, "ng-template", 31);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ɵɵpipeBind1(3, 4, ctx_r1.displayModes));
    ɵɵadvance(3);
    ɵɵproperty("ngSwitch", ctx_r1.activeDisplayMode);
    ɵɵadvance();
    ɵɵproperty("ngSwitchCase", ctx_r1.displayModes.LIST_VIEW);
    ɵɵadvance();
    ɵɵproperty("ngSwitchCase", ctx_r1.displayModes.MAP_VIEW);
  }
}
function StoreFinderListComponent_ng_container_0_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 6)(1, "div", 38);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "storeFinder.noStoreFound"), " ");
  }
}
function StoreFinderListComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2);
    ɵɵtemplate(2, StoreFinderListComponent_ng_container_0_div_2_Template, 7, 3, "div", 3)(3, StoreFinderListComponent_ng_container_0_div_3_Template, 7, 3, "div", 4)(4, StoreFinderListComponent_ng_container_0_div_4_Template, 8, 6, "div", 5)(5, StoreFinderListComponent_ng_container_0_div_5_Template, 4, 3, "div", 3);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.locations == null ? null : ctx_r1.locations.pagination);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.locations == null ? null : ctx_r1.locations.stores);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.locations == null ? null : ctx_r1.locations.stores);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(ctx_r1.locations == null ? null : ctx_r1.locations.stores));
  }
}
function StoreFinderSearchResultComponent_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 6);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loaded"));
  }
}
function StoreFinderSearchResultComponent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div")(1, "div", 7)(2, "cx-pagination", 8);
    ɵɵlistener("viewPageEvent", function StoreFinderSearchResultComponent_div_0_div_2_Template_cx_pagination_viewPageEvent_2_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.viewPage($event));
    });
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const locations_r3 = ɵɵnextContext().ngIf;
    ɵɵadvance(2);
    ɵɵproperty("pagination", locations_r3.pagination);
  }
}
function StoreFinderSearchResultComponent_div_0_cx_store_finder_list_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-store-finder-list", 9);
  }
  if (rf & 2) {
    const locations_r3 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("locations", locations_r3)("useMylocation", ctx_r1.useMyLocation);
  }
}
function StoreFinderSearchResultComponent_div_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 10)(1, "div", 11)(2, "span", 12);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 1, "storeFinder.noStoresMessage"), " ");
  }
}
function StoreFinderSearchResultComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, StoreFinderSearchResultComponent_div_0_div_1_Template, 2, 3, "div", 2)(2, StoreFinderSearchResultComponent_div_0_div_2_Template, 3, 1, "div", 3)(3, StoreFinderSearchResultComponent_div_0_cx_store_finder_list_3_Template, 1, 2, "cx-store-finder-list", 4)(4, StoreFinderSearchResultComponent_div_0_div_4_Template, 5, 3, "div", 5);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const locations_r3 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yRemoveStatusLoadedRole");
    ɵɵadvance();
    ɵɵproperty("ngIf", locations_r3 == null ? null : locations_r3.stores.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", locations_r3 == null ? null : locations_r3.stores.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(locations_r3 == null ? null : locations_r3.stores.length));
  }
}
function StoreFinderSearchResultComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 13);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
var _c13 = (a0) => ["../country", a0];
function StoreFinderStoresCountComponent_ng_container_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 6);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loaded"));
  }
}
function StoreFinderStoresCountComponent_ng_container_0_ng_container_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 8)(1, "span", 9);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const locations_r1 = ɵɵnextContext(2).ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind2(3, 1, "storeFinder.ariaLabelCountriesCount", ɵɵpureFunction1(4, _c4, locations_r1 == null ? null : locations_r1.length)));
  }
}
function StoreFinderStoresCountComponent_ng_container_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, StoreFinderStoresCountComponent_ng_container_0_ng_container_2_div_1_Template, 4, 6, "div", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const locations_r1 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", locations_r1 == null ? null : locations_r1.length);
  }
}
function StoreFinderStoresCountComponent_ng_container_0_div_4_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 13);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const locations_r1 = ɵɵnextContext(2).ngIf;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(2, 1, "storeFinder.ariaLabelCountriesCount", ɵɵpureFunction1(4, _c4, locations_r1 == null ? null : locations_r1.length)), " ");
  }
}
function StoreFinderStoresCountComponent_ng_container_0_div_4_div_2_span_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 19);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const country_r3 = ɵɵnextContext().$implicit;
    ɵɵproperty("ngClass", (country_r3 == null ? null : country_r3.storeCountDataList) ? "country-header" : "country-header-link");
    ɵɵadvance();
    ɵɵtextInterpolate1("(", country_r3.count, ")");
  }
}
function StoreFinderStoresCountComponent_ng_container_0_div_4_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 14)(1, "a", 15);
    ɵɵlistener("keydown.space", function StoreFinderStoresCountComponent_ng_container_0_div_4_div_2_Template_a_keydown_space_1_listener($event) {
      const country_r3 = ɵɵrestoreView(_r2).$implicit;
      const ctx_r3 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r3.navigateToLocation(country_r3.isoCode, $event));
    });
    ɵɵelementStart(2, "h2", 16)(3, "span", 17);
    ɵɵtext(4);
    ɵɵelementEnd();
    ɵɵtemplate(5, StoreFinderStoresCountComponent_ng_container_0_div_4_div_2_span_5_Template, 2, 2, "span", 18);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const country_r3 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpureFunction1(5, _c13, country_r3.isoCode));
    ɵɵattribute("aria-label", country_r3.name + "(" + country_r3.count + ")");
    ɵɵadvance(2);
    ɵɵproperty("ngClass", (country_r3 == null ? null : country_r3.storeCountDataList) ? "country-header" : "country-header-link");
    ɵɵadvance();
    ɵɵtextInterpolate(country_r3.name);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(country_r3 == null ? null : country_r3.storeCountDataList));
  }
}
function StoreFinderStoresCountComponent_ng_container_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 10);
    ɵɵtemplate(1, StoreFinderStoresCountComponent_ng_container_0_div_4_div_1_Template, 3, 6, "div", 11)(2, StoreFinderStoresCountComponent_ng_container_0_div_4_div_2_Template, 6, 7, "div", 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const locations_r1 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yStoreFinderAlerts");
    ɵɵadvance();
    ɵɵproperty("ngForOf", locations_r1);
  }
}
function StoreFinderStoresCountComponent_ng_container_0_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 10)(1, "span", 20);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "storeFinder.noStoresMessage"), " ");
  }
}
function StoreFinderStoresCountComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, StoreFinderStoresCountComponent_ng_container_0_div_1_Template, 2, 3, "div", 2)(2, StoreFinderStoresCountComponent_ng_container_0_ng_container_2_Template, 2, 1, "ng-container", 3);
    ɵɵelementStart(3, "div", 4);
    ɵɵtemplate(4, StoreFinderStoresCountComponent_ng_container_0_div_4_Template, 3, 2, "div", 5)(5, StoreFinderStoresCountComponent_ng_container_0_div_5_Template, 4, 3, "div", 5);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const locations_r1 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yRemoveStatusLoadedRole");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yStoreFinderAlerts");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", locations_r1 == null ? null : locations_r1.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(locations_r1 == null ? null : locations_r1.length));
  }
}
function StoreFinderStoresCountComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 21);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
function StoreFinderComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 2);
    ɵɵelement(1, "cx-store-finder-header")(2, "router-outlet");
    ɵɵelementEnd();
  }
}
function StoreFinderComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 3)(1, "div", 2);
    ɵɵelement(2, "cx-store-finder-header")(3, "router-outlet");
    ɵɵelementEnd()();
  }
}
function StoreFinderStoreComponent_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 12);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 1, "common.loaded"));
  }
}
function StoreFinderStoreComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 3);
    ɵɵtemplate(1, StoreFinderStoreComponent_div_1_div_1_Template, 2, 3, "div", 4);
    ɵɵelementStart(2, "div", 5);
    ɵɵtext(3);
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 6)(5, "button", 7);
    ɵɵlistener("click", function StoreFinderStoreComponent_div_1_Template_button_click_5_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.goBack());
    });
    ɵɵelement(6, "cx-icon", 8);
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(9, "div", 9)(10, "div", 10);
    ɵɵelement(11, "cx-store-finder-store-description", 11);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const location_r3 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yRemoveStatusLoadedRole");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", location_r3 == null ? null : location_r3.displayName, " ");
    ɵɵadvance(3);
    ɵɵproperty("type", ctx_r1.iconTypes.CARET_LEFT);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(8, 6, "storeFinder.backToList"), " ");
    ɵɵadvance(4);
    ɵɵproperty("disableMap", ctx_r1.disableMap)("location", location_r3);
  }
}
function StoreFinderStoreComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 13);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
var AbstractStoreItemComponent = class _AbstractStoreItemComponent {
  constructor(storeFinderService) {
    this.storeFinderService = storeFinderService;
  }
  getDirections(location) {
    return this.storeFinderService.getDirections(location);
  }
  getFormattedStoreAddress(addressParts) {
    return addressParts.filter(Boolean).join(", ");
  }
  static {
    this.ɵfac = function AbstractStoreItemComponent_Factory(t) {
      return new (t || _AbstractStoreItemComponent)(ɵɵdirectiveInject(StoreFinderService));
    };
  }
  static {
    this.ɵdir = ɵɵdefineDirective({
      type: _AbstractStoreItemComponent,
      inputs: {
        location: "location"
      }
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AbstractStoreItemComponent, [{
    type: Directive
  }], () => [{
    type: StoreFinderService
  }], {
    location: [{
      type: Input
    }]
  });
})();
var ScheduleComponent = class _ScheduleComponent {
  constructor() {
  }
  ngOnInit() {
    if (this.location) {
      this.weekDays = this.location.openingHours?.weekDayOpeningList;
    }
  }
  static {
    this.ɵfac = function ScheduleComponent_Factory(t) {
      return new (t || _ScheduleComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ScheduleComponent,
      selectors: [["cx-schedule"]],
      inputs: {
        location: "location"
      },
      ngContentSelectors: _c0,
      decls: 2,
      vars: 1,
      consts: [["class", "container cx-store-hours", 4, "ngIf"], [1, "container", "cx-store-hours"], ["class", "row", 4, "ngFor", "ngForOf"], [1, "row"], [1, "cx-days", "col-4"], ["class", "cx-hours col-8 closed", 4, "ngIf"], ["class", "cx-hours col-8", 4, "ngIf"], [1, "cx-hours", "col-8", "closed"], [1, "cx-hours", "col-8"]],
      template: function ScheduleComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵprojectionDef();
          ɵɵprojection(0);
          ɵɵtemplate(1, ScheduleComponent_div_1_Template, 2, 1, "div", 0);
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.location.openingHours);
        }
      },
      dependencies: [NgForOf, NgIf, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ScheduleComponent, [{
    type: Component,
    args: [{
      selector: "cx-schedule",
      template: `<ng-content></ng-content>
<div class="container cx-store-hours" *ngIf="location.openingHours">
  <div *ngFor="let day of weekDays" class="row">
    <div class="cx-days col-4">{{ day.weekDay }}</div>

    <div *ngIf="day.closed" class="cx-hours col-8 closed">
      {{ 'storeFinder.closed' | cxTranslate }}
    </div>

    <div *ngIf="!day.closed" class="cx-hours col-8">
      {{ day.openingTime?.formattedHour }} -
      {{ day.closingTime?.formattedHour }}
    </div>
  </div>
</div>
`
    }]
  }], () => [], {
    location: [{
      type: Input
    }]
  });
})();
var StoreFinderListItemComponent = class _StoreFinderListItemComponent extends AbstractStoreItemComponent {
  constructor(storeFinderService) {
    super(storeFinderService);
    this.storeFinderService = storeFinderService;
    this.locationIndex = null;
    this.storeItemClick = new EventEmitter();
    this.StoreFinderOutlets = StoreFinderOutlets;
    useFeatureStyles("a11yTruncatedTextStoreFinder");
  }
  handleStoreItemClick() {
    if (this.locationIndex !== null) {
      this.storeItemClick.emit(this.locationIndex);
    }
  }
  onKey(event) {
    if (event.key === "Enter") {
      this.handleStoreItemClick();
    }
  }
  static {
    this.ɵfac = function StoreFinderListItemComponent_Factory(t) {
      return new (t || _StoreFinderListItemComponent)(ɵɵdirectiveInject(StoreFinderService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderListItemComponent,
      selectors: [["cx-store-finder-list-item"]],
      inputs: {
        locationIndex: "locationIndex",
        listOrderLabel: "listOrderLabel",
        displayDistance: "displayDistance",
        useClickEvent: "useClickEvent"
      },
      outputs: {
        storeItemClick: "storeItemClick"
      },
      features: [ɵɵInheritDefinitionFeature],
      decls: 10,
      vars: 11,
      consts: [["aria-relevant", "all"], [1, "cx-store-list-order"], ["class", "cx-store-name", "tabindex", "0", 3, "click", "keyup", 4, "ngIf"], ["class", "cx-store-name", "tabindex", "0", 3, "routerLink", 4, "ngIf"], ["class", "cx-store-address", 4, "ngIf"], [3, "cxOutlet", "cxOutletContext"], ["target", "_blank", "rel", "noopener noreferrer", "class", "btn btn-sm btn-secondary btn-block cx-button", "cxBtnLikeLink", "", 3, "href", "click", 4, "cxFeature"], ["target", "_blank", "rel", "noopener noreferrer", "class", "cx-button", 3, "href", "click", 4, "cxFeature"], ["tabindex", "0", 1, "cx-store-name", 3, "click", "keyup"], ["tabindex", "0", 1, "cx-store-name", 3, "routerLink"], [1, "cx-store-address"], [1, "cx-store-address-street"], ["class", "cx-store-distance", 4, "ngIf"], [1, "cx-store-distance"], ["target", "_blank", "rel", "noopener noreferrer", "cxBtnLikeLink", "", 1, "btn", "btn-sm", "btn-secondary", "btn-block", "cx-button", 3, "click", "href"], ["target", "_blank", "rel", "noopener noreferrer", 1, "cx-button", 3, "click", "href"]],
      template: function StoreFinderListItemComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementContainerStart(0);
          ɵɵelementStart(1, "div", 0)(2, "div", 1);
          ɵɵtext(3);
          ɵɵelementEnd();
          ɵɵtemplate(4, StoreFinderListItemComponent_a_4_Template, 2, 1, "a", 2)(5, StoreFinderListItemComponent_a_5_Template, 2, 4, "a", 3)(6, StoreFinderListItemComponent_div_6_Template, 5, 8, "div", 4)(7, StoreFinderListItemComponent_ng_template_7_Template, 0, 0, "ng-template", 5)(8, StoreFinderListItemComponent_a_8_Template, 4, 7, "a", 6)(9, StoreFinderListItemComponent_a_9_Template, 4, 7, "a", 7);
          ɵɵelementEnd();
          ɵɵelementContainerEnd();
        }
        if (rf & 2) {
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ctx.listOrderLabel, " ");
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.useClickEvent);
          ɵɵadvance();
          ɵɵproperty("ngIf", !ctx.useClickEvent);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.location.address);
          ɵɵadvance();
          ɵɵproperty("cxOutlet", ctx.StoreFinderOutlets.PREFERRED_STORE)("cxOutletContext", ɵɵpureFunction2(8, _c1, ctx.location.displayName, ctx.location.name));
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yStyleExternalLinksAsLinks");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yStyleExternalLinksAsLinks");
        }
      },
      dependencies: [NgIf, RouterLink, OutletDirective, FeatureDirective, BtnLikeLinkDirective, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderListItemComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-list-item",
      template: `<ng-container>
  <div aria-relevant="all">
    <div class="cx-store-list-order">
      {{ listOrderLabel }}
    </div>
    <a
      *ngIf="useClickEvent"
      (click)="handleStoreItemClick()"
      (keyup)="onKey($event)"
      class="cx-store-name"
      tabindex="0"
    >
      {{ location.displayName || location.name }}
    </a>
    <a
      *ngIf="!useClickEvent"
      [routerLink]="[location.name]"
      class="cx-store-name"
      tabindex="0"
    >
      {{ location.displayName || location.name }}
    </a>
    <div class="cx-store-address" *ngIf="location.address">
      <div class="cx-store-address-street">
        {{ location.address.line1 }} {{ location.address.line2 }}
      </div>
      {{
        getFormattedStoreAddress([
          location.address.town,
          location.address.postalCode,
          location.address.country.isocode,
        ])
      }}
      <div
        class="cx-store-distance"
        *ngIf="location.formattedDistance && displayDistance"
      >
        {{ location.formattedDistance }}
      </div>
    </div>
    <ng-template
      [cxOutlet]="StoreFinderOutlets.PREFERRED_STORE"
      [cxOutletContext]="{
        displayName: location.displayName,
        name: location.name,
      }"
    ></ng-template>

    <a
      href="{{ getDirections(location) }}"
      target="_blank"
      rel="noopener noreferrer"
      *cxFeature="'!a11yStyleExternalLinksAsLinks'"
      class="btn btn-sm btn-secondary btn-block cx-button"
      cxBtnLikeLink
      (click)="$event.stopPropagation()"
      [attr.aria-label]="'storeFinder.ariaLabelGetDirections' | cxTranslate"
      >{{ 'storeFinder.getDirections' | cxTranslate }}</a
    >
    <a
      href="{{ getDirections(location) }}"
      target="_blank"
      rel="noopener noreferrer"
      *cxFeature="'a11yStyleExternalLinksAsLinks'"
      class="cx-button"
      (click)="$event.stopPropagation()"
      [attr.aria-label]="'storeFinder.ariaLabelGetDirections' | cxTranslate"
      >{{ 'storeFinder.getDirections' | cxTranslate }}</a
    >
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: StoreFinderService
  }], {
    locationIndex: [{
      type: Input
    }],
    listOrderLabel: [{
      type: Input
    }],
    displayDistance: [{
      type: Input
    }],
    useClickEvent: [{
      type: Input
    }],
    storeItemClick: [{
      type: Output
    }]
  });
})();
var StoreFinderGridComponent = class _StoreFinderGridComponent {
  constructor(storeFinderService, route) {
    this.storeFinderService = storeFinderService;
    this.route = route;
    useFeatureStyles("a11yStoreFinderAlerts");
  }
  ngOnInit() {
    this.isLoading$ = this.storeFinderService.getStoresLoading();
    this.locations$ = this.storeFinderService.getFindStoresEntities();
    this.defaultLocation = {};
    this.findStores();
  }
  findStores() {
    if (this.route.snapshot.params.country) {
      this.storeFinderService.callFindStoresAction(this.route.snapshot.params);
    }
  }
  static {
    this.ɵfac = function StoreFinderGridComponent_Factory(t) {
      return new (t || _StoreFinderGridComponent)(ɵɵdirectiveInject(StoreFinderService), ɵɵdirectiveInject(ActivatedRoute));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderGridComponent,
      selectors: [["cx-store-finder-grid"]],
      decls: 5,
      vars: 6,
      consts: [["loading", ""], [4, "ngIf", "ngIfElse"], ["role", "status", 4, "cxFeature"], [1, "container"], ["class", "cx-counter", 4, "cxFeature"], ["class", "cx-visually-hidden", 4, "cxFeature"], [1, "row"], ["class", "col-sm-6 col-md-4 col-lg-3 item", 4, "ngFor", "ngForOf"], ["role", "status"], [1, "cx-counter"], [1, "cx-counter-title"], ["role", "alert"], [1, "cx-visually-hidden"], [1, "col-sm-6", "col-md-4", "col-lg-3", "item"], [3, "location"], [1, "cx-spinner"]],
      template: function StoreFinderGridComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, StoreFinderGridComponent_ng_container_0_Template, 7, 4, "ng-container", 1);
          ɵɵpipe(1, "async");
          ɵɵpipe(2, "async");
          ɵɵtemplate(3, StoreFinderGridComponent_ng_template_3_Template, 2, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const loading_r3 = ɵɵreference(4);
          ɵɵproperty("ngIf", !ɵɵpipeBind1(1, 2, ctx.isLoading$) && ɵɵpipeBind1(2, 4, ctx.locations$))("ngIfElse", loading_r3);
        }
      },
      dependencies: [NgForOf, NgIf, SpinnerComponent, FeatureDirective, StoreFinderListItemComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderGridComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-grid",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container
  *ngIf="
    !(isLoading$ | async) && (locations$ | async) as locations;
    else loading
  "
>
  <div
    *cxFeature="'!a11yRemoveStatusLoadedRole'"
    role="status"
    [attr.aria-label]="'common.loaded' | cxTranslate"
  ></div>
  <div class="container">
    <!-- TODO: (CXSPA-7581) - Remove feature flag next major release -->
    <div *cxFeature="'a11yStoreFinderAlerts'" class="cx-counter">
      <h3 class="cx-counter-title">
        {{ 'storeFinder.storesFoundTitle' | cxTranslate }}
      </h3>
      <span role="alert">
        {{
          'storeFinder.storesFound'
            | cxTranslate: { count: locations?.stores?.length }
        }}
      </span>
    </div>
    <div *cxFeature="'!a11yStoreFinderAlerts'" class="cx-visually-hidden">
      {{
        'storeFinder.storesFound'
          | cxTranslate: { count: locations?.stores?.length }
      }}
    </div>
    <div class="row">
      <div
        class="col-sm-6 col-md-4 col-lg-3 item"
        *ngFor="let location of locations?.stores"
      >
        <cx-store-finder-list-item
          [location]="location"
        ></cx-store-finder-list-item>
      </div>
    </div>
  </div>
</ng-container>

<ng-template #loading>
  <div class="cx-spinner"><cx-spinner></cx-spinner></div>
</ng-template>
`
    }]
  }], () => [{
    type: StoreFinderService
  }, {
    type: ActivatedRoute
  }], null);
})();
var StoreFinderSearchComponent = class _StoreFinderSearchComponent {
  constructor(routingService) {
    this.routingService = routingService;
    this.searchBox = new UntypedFormControl();
    this.iconTypes = ICON_TYPE;
  }
  findStores(address) {
    this.routingService.go(["store-finder/find"], {
      queryParams: {
        query: address
      }
    });
  }
  viewStoresWithMyLoc() {
    this.routingService.go(["store-finder/find"], {
      queryParams: {
        useMyLocation: true
      }
    });
  }
  onKey(event) {
    if (this.searchBox.value && this.searchBox.value.length && event.key === "Enter") {
      this.findStores(this.searchBox.value);
    }
  }
  static {
    this.ɵfac = function StoreFinderSearchComponent_Factory(t) {
      return new (t || _StoreFinderSearchComponent)(ɵɵdirectiveInject(RoutingService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderSearchComponent,
      selectors: [["cx-store-finder-search"]],
      decls: 5,
      vars: 2,
      consts: [["searchActionButtons", ""], ["queryInput", ""], [1, "container"], ["class", "row", 4, "cxFeature"], ["class", "row align-items-end", 4, "cxFeature"], [1, "row"], [1, "col-md-12", "col-lg-6"], [1, "form-group", "search-wrapper"], ["type", "text", 1, "form-control", 3, "keyup", "formControl", "placeholder"], ["role", "button", 1, "search", 3, "keyup", "type", "routerLink", "queryParams", "ngClass"], [3, "ngTemplateOutlet"], [1, "row", "align-items-end"], [1, "form-group"], ["for", "store-finder-search-input"], [1, "text-left", "label-content"], [1, "search-wrapper"], ["id", "store-finder-search-input", "type", "text", 1, "form-control", 3, "keyup", "formControl", "placeholder"], [1, "row", "cx-search-links", "mb-3"], [1, "col-6"], [1, "btn", "btn-primary", "btn-block", 3, "click"], [1, "btn", "btn-primary", "btn-block", 3, "routerLink"]],
      template: function StoreFinderSearchComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 2);
          ɵɵtemplate(1, StoreFinderSearchComponent_div_1_Template, 11, 24, "div", 3)(2, StoreFinderSearchComponent_div_2_Template, 15, 24, "div", 4);
          ɵɵelementEnd();
          ɵɵtemplate(3, StoreFinderSearchComponent_ng_template_3_Template, 10, 8, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yStoreFinderLabel");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yStoreFinderLabel");
        }
      },
      dependencies: [NgClass, NgTemplateOutlet, DefaultValueAccessor, NgControlStatus, FormControlDirective, RouterLink, IconComponent, FeatureDirective, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderSearchComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-search",
      template: `<div class="container">
  <div class="row" *cxFeature="'!a11yStoreFinderLabel'">
    <div class="col-md-12 col-lg-6">
      <div class="form-group search-wrapper">
        <input
          #queryInput
          [formControl]="searchBox"
          (keyup)="onKey($event)"
          type="text"
          class="form-control"
          [attr.aria-label]="'storeFinder.searchBoxLabel' | cxTranslate"
          placeholder="{{ 'storeFinder.searchBox' | cxTranslate }}"
        />
        <cx-icon
          [attr.tabindex]="queryInput.value?.length ? 0 : -1"
          [type]="iconTypes.SEARCH"
          role="button"
          [attr.aria-label]="'storeFinder.searchNearestStores' | cxTranslate"
          [attr.title]="'storeFinder.searchNearestStores' | cxTranslate"
          class="search"
          (keyup)="onKey($event)"
          [routerLink]="['/store-finder/find']"
          [queryParams]="{ query: queryInput.value }"
          [ngClass]="{
            'disabled-action': !(queryInput.value && queryInput.value.length),
          }"
        ></cx-icon>
      </div>
    </div>
    <ng-template [ngTemplateOutlet]="searchActionButtons"></ng-template>
  </div>

  <div class="row align-items-end" *cxFeature="'a11yStoreFinderLabel'">
    <div class="col-md-12 col-lg-6">
      <div class="form-group">
        <label for="store-finder-search-input">
          <span class="text-left label-content">
            {{ 'storeFinder.findStoreBy' | cxTranslate }}
          </span>
          <div class="search-wrapper">
            <input
              #queryInput
              id="store-finder-search-input"
              [formControl]="searchBox"
              (keyup)="onKey($event)"
              type="text"
              class="form-control"
              placeholder="{{ 'storeFinder.searchBox' | cxTranslate }}"
            />
            <cx-icon
              [attr.tabindex]="queryInput.value?.length ? 0 : -1"
              [type]="iconTypes.SEARCH"
              role="button"
              [attr.aria-label]="
                'storeFinder.searchNearestStores' | cxTranslate
              "
              [attr.title]="'storeFinder.searchNearestStores' | cxTranslate"
              class="search"
              (keyup)="onKey($event)"
              [routerLink]="['/store-finder/find']"
              [queryParams]="{ query: queryInput.value }"
              [ngClass]="{
                'disabled-action': !(
                  queryInput.value && queryInput.value.length
                ),
              }"
            ></cx-icon>
          </div>
        </label>
      </div>
    </div>
    <ng-template [ngTemplateOutlet]="searchActionButtons"></ng-template>
  </div>
</div>

<ng-template #searchActionButtons>
  <div class="col-md-12 col-lg-6">
    <div class="row cx-search-links mb-3">
      <div class="col-6">
        <button
          (click)="viewStoresWithMyLoc()"
          class="btn btn-primary btn-block"
        >
          {{ 'storeFinder.useMyLocation' | cxTranslate }}
        </button>
      </div>
      <div class="col-6">
        <button
          [routerLink]="['/store-finder/view-all']"
          class="btn btn-primary btn-block"
        >
          {{ 'storeFinder.viewAllStores' | cxTranslate }}
        </button>
      </div>
    </div>
  </div>
</ng-template>
`
    }]
  }], () => [{
    type: RoutingService
  }], null);
})();
var StoreFinderHeaderComponent = class _StoreFinderHeaderComponent {
  static {
    this.ɵfac = function StoreFinderHeaderComponent_Factory(t) {
      return new (t || _StoreFinderHeaderComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderHeaderComponent,
      selectors: [["cx-store-finder-header"]],
      decls: 3,
      vars: 3,
      consts: [["role", "search"]],
      template: function StoreFinderHeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementContainerStart(0);
          ɵɵelement(1, "cx-store-finder-search", 0);
          ɵɵpipe(2, "cxTranslate");
          ɵɵelementContainerEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵattribute("aria-label", ɵɵpipeBind1(2, 1, "storeFinder.storeFinder"));
        }
      },
      dependencies: [StoreFinderSearchComponent, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderHeaderComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-header",
      template: `<ng-container>
  <cx-store-finder-search
    role="search"
    [attr.aria-label]="'storeFinder.storeFinder' | cxTranslate"
  ></cx-store-finder-search>
</ng-container>
`
    }]
  }], null, null);
})();
var StoreFinderMapComponent = class _StoreFinderMapComponent {
  constructor(googleMapRendererService) {
    this.googleMapRendererService = googleMapRendererService;
    this.selectedStoreItem = new EventEmitter();
    useFeatureStyles("a11yStoreFinderOverflow");
  }
  ngOnChanges(changes) {
    if (changes.locations && this.locations) {
      this.renderMap();
    }
  }
  /**
   * Sets the center of the map to the given location
   * @param latitude latitude of the new center
   * @param longitude longitude of the new center
   */
  centerMap(latitude, longitude) {
    this.googleMapRendererService.centerMap(latitude, longitude);
  }
  renderMap() {
    this.googleMapRendererService.renderMap(this.mapElement.nativeElement, this.locations, (markerIndex) => {
      this.selectStoreItemClickHandle(markerIndex);
    });
  }
  selectStoreItemClickHandle(markerIndex) {
    this.selectedStoreItem.emit(markerIndex);
  }
  static {
    this.ɵfac = function StoreFinderMapComponent_Factory(t) {
      return new (t || _StoreFinderMapComponent)(ɵɵdirectiveInject(GoogleMapRendererService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderMapComponent,
      selectors: [["cx-store-finder-map"]],
      viewQuery: function StoreFinderMapComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c9, 7);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.mapElement = _t.first);
        }
      },
      inputs: {
        locations: "locations"
      },
      outputs: {
        selectedStoreItem: "selectedStoreItem"
      },
      features: [ɵɵNgOnChangesFeature],
      decls: 2,
      vars: 0,
      consts: [["mapElement", ""], ["aria-hidden", "true", 1, "cx-store-map"]],
      template: function StoreFinderMapComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 1, 0);
        }
      },
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderMapComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-map",
      template: '<div aria-hidden="true" #mapElement class="cx-store-map"></div>\n'
    }]
  }], () => [{
    type: GoogleMapRendererService
  }], {
    mapElement: [{
      type: ViewChild,
      args: ["mapElement", {
        static: true
      }]
    }],
    locations: [{
      type: Input
    }],
    selectedStoreItem: [{
      type: Output
    }]
  });
})();
var StoreFinderPaginationDetailsComponent = class _StoreFinderPaginationDetailsComponent {
  constructor() {
  }
  getResultsPerPage() {
    if (this.pagination.totalResults > this.pagination.pageSize) {
      const firstItem = this.pagination.currentPage * this.pagination.pageSize + 1;
      let resultsPerPage = (this.pagination.currentPage + 1) * this.pagination.pageSize;
      if (resultsPerPage > this.pagination.totalResults) {
        resultsPerPage = this.pagination.totalResults;
      }
      return `${firstItem} - ${resultsPerPage}`;
    } else {
      return `1 - ${this.pagination.totalResults}`;
    }
  }
  static {
    this.ɵfac = function StoreFinderPaginationDetailsComponent_Factory(t) {
      return new (t || _StoreFinderPaginationDetailsComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderPaginationDetailsComponent,
      selectors: [["cx-store-finder-pagination-details"]],
      inputs: {
        pagination: "pagination"
      },
      decls: 3,
      vars: 7,
      consts: [["role", "alert", 1, "cx-pagination-details"]],
      template: function StoreFinderPaginationDetailsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "span", 0);
          ɵɵtext(1);
          ɵɵpipe(2, "cxTranslate");
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵtextInterpolate2(" ", ctx.getResultsPerPage(), " ", ɵɵpipeBind2(2, 2, "storeFinder.fromStoresFound", ɵɵpureFunction1(5, _c4, ctx.pagination.totalResults)), "\n");
        }
      },
      dependencies: [TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderPaginationDetailsComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-pagination-details",
      template: `<span role="alert" class="cx-pagination-details">
  {{ getResultsPerPage() }}
  {{
    'storeFinder.fromStoresFound'
      | cxTranslate: { count: pagination.totalResults }
  }}
</span>
`
    }]
  }], () => [], {
    pagination: [{
      type: Input
    }]
  });
})();
var LocationDisplayMode;
(function(LocationDisplayMode2) {
  LocationDisplayMode2["LIST_VIEW"] = "listView";
  LocationDisplayMode2["MAP_VIEW"] = "mapView";
})(LocationDisplayMode || (LocationDisplayMode = {}));
var StoreFinderStoreDescriptionComponent = class _StoreFinderStoreDescriptionComponent extends AbstractStoreItemComponent {
  constructor(storeFinderService) {
    super(storeFinderService);
    this.storeFinderService = storeFinderService;
    useFeatureStyles("a11yStoreFinderOverflow");
  }
  static {
    this.ɵfac = function StoreFinderStoreDescriptionComponent_Factory(t) {
      return new (t || _StoreFinderStoreDescriptionComponent)(ɵɵdirectiveInject(StoreFinderService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderStoreDescriptionComponent,
      selectors: [["cx-store-finder-store-description"]],
      inputs: {
        location: "location",
        disableMap: "disableMap"
      },
      features: [ɵɵInheritDefinitionFeature],
      decls: 1,
      vars: 1,
      consts: [[4, "ngIf"], [4, "cxFeature"], [1, "cx-container"], [1, "cx-store"], ["class", "cx-store-description-address", 4, "ngIf"], [1, "cx-contact"], [1, "cx-list"], [1, "cx-item"], ["target", "_blank", "rel", "noopener noreferrer", 1, "cx-link", 3, "href"], ["class", "cx-item", 4, "ngIf"], ["class", "cx-schedule", 4, "ngIf"], ["class", "cx-features", 4, "ngIf"], ["class", "cx-storeMap", 4, "ngIf"], [1, "cx-store-description-address"], [1, "cx-schedule"], [3, "location"], [1, "cx-features"], [1, "cx-features-header"], ["class", "cx-feature-item", 4, "ngFor", "ngForOf"], [1, "cx-feature-item"], [1, "cx-storeMap"], [3, "locations"], [1, "container"], [1, "row"], [1, "cx-store", "col-md-4"], ["aria-hidden", "true"], ["class", "cx-storeMap col-lg-8", 4, "ngIf"], [1, "col-lg-12"], ["class", "col-lg-12 cx-feature-item", 4, "ngFor", "ngForOf"], [1, "col-lg-12", "cx-feature-item"], [1, "cx-feature-value"], [1, "cx-storeMap", "col-lg-8"]],
      template: function StoreFinderStoreDescriptionComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, StoreFinderStoreDescriptionComponent_ng_container_0_Template, 3, 2, "ng-container", 0);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ctx.location);
        }
      },
      dependencies: [NgForOf, NgIf, FeatureDirective, StoreFinderMapComponent, ScheduleComponent, JsonPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderStoreDescriptionComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-store-description",
      template: `<ng-container *ngIf="location">
  <!-- TODO: (CXSPA-5916) Remove feature flags next major -->
  <ng-container *cxFeature="'a11yStoreFinderOverflow'">
    <div class="cx-container">
      <div class="cx-store">
        <h2>{{ location.displayName || location.name }}</h2>
        <div *ngIf="location.address" class="cx-store-description-address">
          <div>{{ location.address.line1 }} {{ location.address.line2 }}</div>
          <div>
            {{
              getFormattedStoreAddress([
                location.address.town,
                location.address.postalCode,
                location.address.country.isocode,
              ])
            }}
          </div>
        </div>

        <section class="cx-contact">
          <ul class="cx-list">
            <li class="cx-item">
              <a
                class="cx-link"
                [href]="getDirections(location)"
                target="_blank"
                rel="noopener noreferrer"
                [attr.aria-label]="
                  'storeFinder.ariaLabelGetDirections' | cxTranslate
                "
                >{{ 'storeFinder.getDirections' | cxTranslate }}</a
              >
            </li>
            <li class="cx-item" *ngIf="location.address?.phone">
              {{ 'storeFinder.call' | cxTranslate }}
              {{ location.address?.phone }}
            </li>
          </ul>
        </section>
        <div class="cx-schedule" *ngIf="location.openingHours">
          <cx-schedule [location]="location">
            <h3>{{ 'storeFinder.storeHours' | cxTranslate }}</h3>
          </cx-schedule>
        </div>

        <div *ngIf="(location.features | json) !== '{}'" class="cx-features">
          <h3 class="cx-features-header">
            {{ 'storeFinder.storeFeatures' | cxTranslate }}
          </h3>

          <div>
            <div
              *ngFor="let feature of location.features?.entry"
              class="cx-feature-item"
            >
              {{ feature.value }}
            </div>
          </div>
        </div>
      </div>
      <div class="cx-storeMap" *ngIf="!disableMap">
        <cx-store-finder-map [locations]="[location]"></cx-store-finder-map>
      </div>
    </div>
  </ng-container>

  <ng-container *cxFeature="'!a11yStoreFinderOverflow'">
    <ng-container *ngIf="location">
      <div class="container">
        <div class="row">
          <article class="cx-store col-md-4">
            <h2 aria-hidden="true">
              {{ location.displayName || location.name }}
            </h2>

            <p *ngIf="location.address" class="cx-store-description-address">
              {{ location.address.line1 }} {{ location.address.line2 }} <br />
              {{
                getFormattedStoreAddress([
                  location.address.town,
                  location.address.postalCode,
                  location.address.country.isocode,
                ])
              }}
            </p>

            <section class="cx-contact">
              <ul class="cx-list">
                <li class="cx-item">
                  <a
                    class="cx-link"
                    [href]="getDirections(location)"
                    target="_blank"
                    rel="noopener noreferrer"
                    [attr.aria-label]="
                      'storeFinder.ariaLabelGetDirections' | cxTranslate
                    "
                    >{{ 'storeFinder.getDirections' | cxTranslate }}</a
                  >
                </li>
                <li class="cx-item" *ngIf="location.address?.phone">
                  {{ 'storeFinder.call' | cxTranslate }}
                  {{ location.address?.phone }}
                </li>
              </ul>
            </section>
            <div class="cx-schedule" *ngIf="location.openingHours">
              <cx-schedule [location]="location">
                <h3>{{ 'storeFinder.storeHours' | cxTranslate }}</h3>
              </cx-schedule>
            </div>

            <div
              *ngIf="(location.features | json) !== '{}'"
              class="cx-features"
            >
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="cx-features-header">
                    {{ 'storeFinder.storeFeatures' | cxTranslate }}
                  </h3>
                </div>
              </div>

              <article class="row">
                <div
                  class="col-lg-12 cx-feature-item"
                  *ngFor="let feature of location.features?.entry"
                >
                  <div class="cx-feature-value">{{ feature.value }}</div>
                </div>
              </article>
            </div>
          </article>
          <article class="cx-storeMap col-lg-8" *ngIf="!disableMap">
            <cx-store-finder-map [locations]="[location]"></cx-store-finder-map>
          </article>
        </div>
      </div>
    </ng-container>
  </ng-container>
</ng-container>
`
    }]
  }], () => [{
    type: StoreFinderService
  }], {
    location: [{
      type: Input
    }],
    disableMap: [{
      type: Input
    }]
  });
})();
var StoreFinderListComponent = class _StoreFinderListComponent {
  constructor(storeFinderService, document) {
    this.storeFinderService = storeFinderService;
    this.document = document;
    this.iconTypes = ICON_TYPE;
    this.displayModes = LocationDisplayMode;
    this.activeDisplayMode = LocationDisplayMode.LIST_VIEW;
    this.isDetailsModeVisible = false;
  }
  centerStoreOnMapByIndex(index, location) {
    this.showStoreDetails(location);
    this.selectedStoreIndex = index;
    this.selectedStore = location;
    this.storeMap.centerMap(this.storeFinderService.getStoreLatitude(this.locations.stores[index]), this.storeFinderService.getStoreLongitude(this.locations.stores[index]));
  }
  selectStoreItemList(index) {
    this.selectedStoreIndex = index;
    const storeListItem = this.document.getElementById("item-" + index);
    storeListItem.scrollIntoView({
      behavior: "smooth",
      block: "center"
    });
  }
  showStoreDetails(location) {
    this.isDetailsModeVisible = true;
    this.storeDetails = location;
  }
  hideStoreDetails() {
    this.isDetailsModeVisible = false;
    this.selectedStoreIndex = void 0;
    this.selectedStore = void 0;
    this.storeMap.renderMap();
  }
  setDisplayMode(mode) {
    this.activeDisplayMode = mode;
  }
  isDisplayModeActive(mode) {
    return this.activeDisplayMode === mode;
  }
  static {
    this.ɵfac = function StoreFinderListComponent_Factory(t) {
      return new (t || _StoreFinderListComponent)(ɵɵdirectiveInject(StoreFinderService), ɵɵdirectiveInject(DOCUMENT));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderListComponent,
      selectors: [["cx-store-finder-list"]],
      viewQuery: function StoreFinderListComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c10, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.storeMap = _t.first);
        }
      },
      inputs: {
        locations: "locations",
        useMylocation: "useMylocation"
      },
      decls: 1,
      vars: 1,
      consts: [["storeMap", ""], [4, "ngIf"], [1, "container", "mb-2"], ["class", "row", 4, "ngIf"], ["class", "row cx-columns", 4, "ngIf"], ["class", "cx-columns-mobile", 4, "ngIf"], [1, "row"], [1, "col-md-12"], [3, "pagination"], [1, "text-left", "cx-back-wrapper"], [1, "cx-visually-hidden"], ["class", "btn btn-block btn-secondary cx-back", 3, "click", 4, "ngIf"], [1, "btn", "btn-block", "btn-secondary", "cx-back", 3, "click"], [3, "type"], [1, "row", "cx-columns"], [1, "col-md-4", "cx-address-col"], ["class", "cx-store-details", 4, "ngIf"], ["class", "cx-list", 4, "ngIf"], [1, "col-md-8", "cx-map-col"], [3, "selectedStoreItem", "locations"], [1, "cx-store-details"], [3, "location", "disableMap"], [1, "cx-list"], ["class", "cx-list-items", 3, "id", "ngClass", 4, "ngFor", "ngForOf"], [1, "cx-list-items", 3, "id", "ngClass"], [3, "storeItemClick", "location", "locationIndex", "displayDistance", "useClickEvent", "listOrderLabel"], [1, "cx-columns-mobile"], ["role", "tablist", 1, "nav", "cx-nav"], ["class", "nav-item cx-nav-item", 4, "ngFor", "ngForOf"], [1, "tab-content"], [3, "ngSwitch"], [3, "ngSwitchCase"], [1, "nav-item", "cx-nav-item"], ["role", "tab", "aria-disabled", "false", 3, "click", "id", "ngClass"], ["id", "tab-listView-panel", "role", "tabpanel", "aria-labelledby", "tab-listView"], [1, "cx-address-col"], ["id", "tab-mapView-panel", "role", "tabpanel", "aria-labelledby", "tab-mapView"], [1, "cx-map-col"], [1, "col-md-12", "cx-not-found"]],
      template: function StoreFinderListComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, StoreFinderListComponent_ng_container_0_Template, 6, 4, "ng-container", 1);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ctx.locations);
        }
      },
      dependencies: [NgClass, NgForOf, NgIf, NgSwitch, NgSwitchCase, IconComponent, StoreFinderMapComponent, StoreFinderListItemComponent, StoreFinderStoreDescriptionComponent, StoreFinderPaginationDetailsComponent, KeyValuePipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderListComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-list",
      template: `<ng-container *ngIf="locations">
  <div class="container mb-2">
    <div class="row" *ngIf="locations?.pagination">
      <div class="col-md-12">
        <cx-store-finder-pagination-details
          [pagination]="locations.pagination"
        ></cx-store-finder-pagination-details>
      </div>
      <div class="text-left cx-back-wrapper">
        <div class="cx-visually-hidden">
          {{ storeDetails?.displayName }}
        </div>
        <button
          class="btn btn-block btn-secondary cx-back"
          *ngIf="isDetailsModeVisible"
          (click)="hideStoreDetails()"
        >
          <cx-icon [type]="iconTypes.CARET_LEFT"></cx-icon>
          {{ 'storeFinder.back' | cxTranslate }}
        </button>
      </div>
    </div>
    <div *ngIf="locations?.stores" class="row cx-columns">
      <div class="col-md-4 cx-address-col">
        <div class="cx-store-details" *ngIf="isDetailsModeVisible">
          <cx-store-finder-store-description
            [location]="storeDetails"
            [disableMap]="true"
          ></cx-store-finder-store-description>
        </div>
        <ol class="cx-list" *ngIf="!isDetailsModeVisible">
          <li
            *ngFor="let location of locations?.stores; let i = index"
            id="{{ 'item-' + i }}"
            [ngClass]="{
              'cx-selected-item': selectedStoreIndex === i,
            }"
            class="cx-list-items"
          >
            <cx-store-finder-list-item
              [location]="location"
              [locationIndex]="i"
              [displayDistance]="useMylocation"
              [useClickEvent]="true"
              (storeItemClick)="centerStoreOnMapByIndex($event, location)"
              [listOrderLabel]="
                i +
                locations.pagination.currentPage *
                  locations.pagination.pageSize +
                1
              "
            ></cx-store-finder-list-item>
          </li>
        </ol>
      </div>
      <div class="col-md-8 cx-map-col">
        <cx-store-finder-map
          #storeMap
          [locations]="locations.stores"
          (selectedStoreItem)="selectStoreItemList($event)"
        ></cx-store-finder-map>
      </div>
    </div>

    <!-- mobile tabs for column set only -->
    <div *ngIf="locations?.stores" class="cx-columns-mobile">
      <ul class="nav cx-nav" role="tablist">
        <li
          class="nav-item cx-nav-item"
          *ngFor="let mode of displayModes | keyvalue"
        >
          <button
            [id]="'tab-' + mode?.value"
            role="tab"
            [ngClass]="{
              'nav-link': true,
              active: isDisplayModeActive(mode?.value),
            }"
            [attr.aria-controls]="'tab-' + mode?.value + '-panel'"
            [attr.aria-selected]="isDisplayModeActive(mode?.value)"
            aria-disabled="false"
            (click)="setDisplayMode(mode?.value)"
          >
            {{ 'storeFinder.' + mode?.value | cxTranslate }}
          </button>
        </li>
      </ul>
      <div class="tab-content">
        <div [ngSwitch]="activeDisplayMode">
          <ng-template [ngSwitchCase]="displayModes.LIST_VIEW">
            <div
              id="tab-listView-panel"
              role="tabpanel"
              aria-labelledby="tab-listView"
            >
              <div class="cx-address-col">
                <div class="cx-store-details" *ngIf="isDetailsModeVisible">
                  <cx-store-finder-store-description
                    [location]="storeDetails"
                    [disableMap]="true"
                  ></cx-store-finder-store-description>
                </div>
                <ol class="cx-list" *ngIf="!isDetailsModeVisible">
                  <li
                    *ngFor="let location of locations?.stores; let i = index"
                    id="{{ 'item-' + i }}"
                    [ngClass]="{
                      'cx-selected-item': selectedStoreIndex === i,
                    }"
                    class="cx-list-items"
                  >
                    <cx-store-finder-list-item
                      [location]="location"
                      [locationIndex]="i"
                      [displayDistance]="useMylocation"
                      [useClickEvent]="true"
                      (storeItemClick)="
                        centerStoreOnMapByIndex($event, location)
                      "
                      [listOrderLabel]="
                        i +
                        locations.pagination.currentPage *
                          locations.pagination.pageSize +
                        1
                      "
                    ></cx-store-finder-list-item>
                  </li>
                </ol>
              </div>
            </div>
          </ng-template>
          <ng-template [ngSwitchCase]="displayModes.MAP_VIEW">
            <div
              id="tab-mapView-panel"
              role="tabpanel"
              aria-labelledby="tab-mapView"
            >
              <div class="cx-map-col">
                <cx-store-finder-map
                  #storeMap
                  [locations]="
                    selectedStore ? [selectedStore] : locations.stores
                  "
                  (selectedStoreItem)="selectStoreItemList($event)"
                ></cx-store-finder-map>
              </div>
            </div>
          </ng-template>
        </div>
      </div>
    </div>
    <!-- mobile tabs end -->

    <div *ngIf="!locations?.stores" class="row">
      <div class="col-md-12 cx-not-found">
        {{ 'storeFinder.noStoreFound' | cxTranslate }}
      </div>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: StoreFinderService
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [DOCUMENT]
    }]
  }], {
    locations: [{
      type: Input
    }],
    useMylocation: [{
      type: Input
    }],
    storeMap: [{
      type: ViewChild,
      args: ["storeMap"]
    }]
  });
})();
var StoreFinderSearchResultComponent = class _StoreFinderSearchResultComponent {
  constructor(storeFinderService, route, config) {
    this.storeFinderService = storeFinderService;
    this.route = route;
    this.config = config;
    this.countryCode = null;
    this.searchConfig = {
      currentPage: 0
    };
  }
  ngOnInit() {
    this.subscription = this.route.queryParams.subscribe((params) => this.initialize(params));
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  viewPage(pageNumber) {
    this.searchConfig = __spreadProps(__spreadValues({}, this.searchConfig), {
      currentPage: pageNumber
    });
    this.storeFinderService.findStoresAction(this.searchQuery.queryText, this.searchConfig, this.geolocation, this.countryCode, this.useMyLocation, this.radius);
  }
  initialize(params) {
    this.searchQuery = this.parseParameters(params);
    this.useMyLocation = params && params.useMyLocation ? true : false;
    this.searchConfig = __spreadProps(__spreadValues({}, this.searchConfig), {
      currentPage: 0
    });
    this.radius = this.config.googleMaps.radius;
    this.storeFinderService.findStoresAction(this.searchQuery.queryText, this.searchConfig, this.geolocation, this.countryCode, this.useMyLocation, this.radius);
    this.isLoading$ = this.storeFinderService.getStoresLoading();
    this.locations$ = this.storeFinderService.getFindStoresEntities();
  }
  parseParameters(queryParams) {
    let searchQuery;
    if (queryParams.query) {
      searchQuery = {
        queryText: queryParams.query
      };
    } else {
      searchQuery = {
        queryText: ""
      };
    }
    searchQuery.useMyLocation = queryParams.useMyLocation != null && queryParams.useMyLocation.toUpperCase() === "TRUE";
    return searchQuery;
  }
  static {
    this.ɵfac = function StoreFinderSearchResultComponent_Factory(t) {
      return new (t || _StoreFinderSearchResultComponent)(ɵɵdirectiveInject(StoreFinderService), ɵɵdirectiveInject(ActivatedRoute), ɵɵdirectiveInject(StoreFinderConfig));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderSearchResultComponent,
      selectors: [["cx-store-finder-search-result"]],
      decls: 5,
      vars: 6,
      consts: [["loading", ""], [4, "ngIf", "ngIfElse"], ["role", "status", 4, "cxFeature"], [4, "ngIf"], [3, "locations", "useMylocation", 4, "ngIf"], ["class", "container", 4, "ngIf"], ["role", "status"], [1, "cx-pagination"], ["aria-hidden", "true", 3, "viewPageEvent", "pagination"], [3, "locations", "useMylocation"], [1, "container"], [1, "row"], ["role", "alert", 1, "cx-no-stores"], [1, "cx-spinner"]],
      template: function StoreFinderSearchResultComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, StoreFinderSearchResultComponent_div_0_Template, 5, 4, "div", 1);
          ɵɵpipe(1, "async");
          ɵɵpipe(2, "async");
          ɵɵtemplate(3, StoreFinderSearchResultComponent_ng_template_3_Template, 2, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const loading_r4 = ɵɵreference(4);
          ɵɵproperty("ngIf", !ɵɵpipeBind1(1, 2, ctx.isLoading$) && ɵɵpipeBind1(2, 4, ctx.locations$))("ngIfElse", loading_r4);
        }
      },
      dependencies: [NgIf, PaginationComponent, SpinnerComponent, FeatureDirective, StoreFinderListComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderSearchResultComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-search-result",
      template: `<div
  *ngIf="
    !(isLoading$ | async) && (locations$ | async) as locations;
    else loading
  "
>
  <div
    *cxFeature="'!a11yRemoveStatusLoadedRole'"
    role="status"
    [attr.aria-label]="'common.loaded' | cxTranslate"
  ></div>
  <div *ngIf="locations?.stores.length">
    <div class="cx-pagination">
      <cx-pagination
        aria-hidden="true"
        [pagination]="locations.pagination"
        (viewPageEvent)="viewPage($event)"
      ></cx-pagination>
    </div>
  </div>
  <cx-store-finder-list
    *ngIf="locations?.stores.length"
    [locations]="locations"
    [useMylocation]="useMyLocation"
  ></cx-store-finder-list>
  <div class="container" *ngIf="!locations?.stores.length">
    <div class="row">
      <span class="cx-no-stores" role="alert">
        {{ 'storeFinder.noStoresMessage' | cxTranslate }}
      </span>
    </div>
  </div>
</div>
<ng-template #loading>
  <div class="cx-spinner">
    <cx-spinner></cx-spinner>
  </div>
</ng-template>
`
    }]
  }], () => [{
    type: StoreFinderService
  }, {
    type: ActivatedRoute
  }, {
    type: StoreFinderConfig
  }], null);
})();
var StoreFinderStoresCountComponent = class _StoreFinderStoresCountComponent {
  constructor(storeFinderService) {
    this.storeFinderService = storeFinderService;
    this.routingService = inject(RoutingService, {
      optional: true
    });
    useFeatureStyles("a11yStoreFinderAlerts");
  }
  ngOnInit() {
    this.storeFinderService.viewAllStores();
    this.locations$ = this.storeFinderService.getViewAllStoresEntities();
    this.isLoading$ = this.storeFinderService.getViewAllStoresLoading();
  }
  navigateToLocation(isoCode, event) {
    if (this.routingService) {
      event?.preventDefault();
      this.routingService.go(["/store-finder/country", isoCode]);
    }
  }
  static {
    this.ɵfac = function StoreFinderStoresCountComponent_Factory(t) {
      return new (t || _StoreFinderStoresCountComponent)(ɵɵdirectiveInject(StoreFinderService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderStoresCountComponent,
      selectors: [["cx-store-finder-stores-count"]],
      decls: 5,
      vars: 6,
      consts: [["loading", ""], [4, "ngIf", "ngIfElse"], ["role", "status", 4, "cxFeature"], [4, "cxFeature"], [1, "cx-count", "container"], ["class", "row", 4, "ngIf"], ["role", "status"], ["class", "col-12 m-3", 4, "ngIf"], [1, "col-12", "m-3"], ["role", "alert"], [1, "row"], ["class", "cx-visually-hidden", 4, "cxFeature"], ["class", "cx-set col-sm-6 col-md-4 col-lg-4 col-xl-3", 4, "ngFor", "ngForOf"], [1, "cx-visually-hidden"], [1, "cx-set", "col-sm-6", "col-md-4", "col-lg-4", "col-xl-3"], ["role", "button", 1, "btn-link", 3, "keydown.space", "routerLink"], ["aria-hidden", "true", 1, "cx-title"], [1, "cx-name", 3, "ngClass"], ["class", "cx-country-count", 3, "ngClass", 4, "ngIf"], [1, "cx-country-count", 3, "ngClass"], ["role", "alert", 1, "cx-no-stores"], [1, "cx-count-spinner"]],
      template: function StoreFinderStoresCountComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, StoreFinderStoresCountComponent_ng_container_0_Template, 6, 4, "ng-container", 1);
          ɵɵpipe(1, "async");
          ɵɵpipe(2, "async");
          ɵɵtemplate(3, StoreFinderStoresCountComponent_ng_template_3_Template, 2, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const loading_r5 = ɵɵreference(4);
          ɵɵproperty("ngIf", !ɵɵpipeBind1(1, 2, ctx.isLoading$) && ɵɵpipeBind1(2, 4, ctx.locations$))("ngIfElse", loading_r5);
        }
      },
      dependencies: [NgClass, NgForOf, NgIf, RouterLink, SpinnerComponent, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderStoresCountComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-stores-count",
      template: `<ng-container
  *ngIf="
    !(isLoading$ | async) && (locations$ | async) as locations;
    else loading
  "
>
  <div
    *cxFeature="'!a11yRemoveStatusLoadedRole'"
    role="status"
    [attr.aria-label]="'common.loaded' | cxTranslate"
  ></div>
  <!-- TODO: (CXSPA-7581) - Remove feature flag next major release -->
  <ng-container *cxFeature="'a11yStoreFinderAlerts'">
    <div *ngIf="locations?.length" class="col-12 m-3">
      <span role="alert">{{
        'storeFinder.ariaLabelCountriesCount'
          | cxTranslate: { count: locations?.length }
      }}</span>
    </div>
  </ng-container>
  <div class="cx-count container">
    <div class="row" *ngIf="locations?.length">
      <div *cxFeature="'!a11yStoreFinderAlerts'" class="cx-visually-hidden">
        {{
          'storeFinder.ariaLabelCountriesCount'
            | cxTranslate: { count: locations?.length }
        }}
      </div>

      <div
        *ngFor="let country of locations"
        class="cx-set col-sm-6 col-md-4 col-lg-4 col-xl-3"
      >
        <a
          [routerLink]="['../country', country.isoCode]"
          class="btn-link"
          role="button"
          [attr.aria-label]="country.name + '(' + country.count + ')'"
          (keydown.space)="navigateToLocation(country.isoCode, $event)"
        >
          <h2 class="cx-title" aria-hidden="true">
            <span
              [ngClass]="
                country?.storeCountDataList
                  ? 'country-header'
                  : 'country-header-link'
              "
              class="cx-name"
              >{{ country.name }}</span
            >
            <span
              [ngClass]="
                country?.storeCountDataList
                  ? 'country-header'
                  : 'country-header-link'
              "
              *ngIf="!country?.storeCountDataList"
              class="cx-country-count"
              >({{ country.count }})</span
            >
          </h2>
        </a>
      </div>
    </div>
    <div class="row" *ngIf="!locations?.length">
      <span class="cx-no-stores" role="alert">
        {{ 'storeFinder.noStoresMessage' | cxTranslate }}
      </span>
    </div>
  </div>
</ng-container>
<ng-template #loading>
  <div class="cx-count-spinner"><cx-spinner></cx-spinner></div>
</ng-template>
`
    }]
  }], () => [{
    type: StoreFinderService
  }], {
    routingService: [{
      type: Optional
    }]
  });
})();
var StoreFinderComponent = class _StoreFinderComponent {
  static {
    this.ɵfac = function StoreFinderComponent_Factory(t) {
      return new (t || _StoreFinderComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderComponent,
      selectors: [["cx-store-finder"]],
      decls: 3,
      vars: 2,
      consts: [["class", "cx-store-finder-wrapper", 4, "cxFeature"], ["aria-live", "assertive", "aria-relevant", "additions text", 4, "cxFeature"], [1, "cx-store-finder-wrapper"], ["aria-live", "assertive", "aria-relevant", "additions text"]],
      template: function StoreFinderComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementContainerStart(0);
          ɵɵtemplate(1, StoreFinderComponent_div_1_Template, 3, 0, "div", 0)(2, StoreFinderComponent_div_2_Template, 4, 0, "div", 1);
          ɵɵelementContainerEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yStoreFinderAlerts");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yStoreFinderAlerts");
        }
      },
      dependencies: [RouterOutlet, FeatureDirective, StoreFinderHeaderComponent],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder",
      template: `<ng-container>
  <div *cxFeature="'a11yStoreFinderAlerts'" class="cx-store-finder-wrapper">
    <cx-store-finder-header></cx-store-finder-header>
    <router-outlet></router-outlet>
  </div>
  <div
    *cxFeature="'!a11yStoreFinderAlerts'"
    aria-live="assertive"
    aria-relevant="additions text"
  >
    <div class="cx-store-finder-wrapper">
      <cx-store-finder-header></cx-store-finder-header>
      <router-outlet></router-outlet>
    </div>
  </div>
</ng-container>
`
    }]
  }], null, null);
})();
var StoreFinderStoreComponent = class _StoreFinderStoreComponent {
  constructor(storeFinderService, route, routingService) {
    this.storeFinderService = storeFinderService;
    this.route = route;
    this.routingService = routingService;
    this.iconTypes = ICON_TYPE;
  }
  ngOnInit() {
    if (!this.location) {
      this.requestStoresData();
      this.location$ = this.storeFinderService.getFindStoreEntityById();
      this.isLoading$ = this.storeFinderService.getStoresLoading();
    }
  }
  requestStoresData() {
    this.storeFinderService.viewStoreById(this.route.snapshot.params.store);
  }
  goBack() {
    this.routingService.go([`store-finder/country/${this.route.snapshot.params.country}`]);
  }
  static {
    this.ɵfac = function StoreFinderStoreComponent_Factory(t) {
      return new (t || _StoreFinderStoreComponent)(ɵɵdirectiveInject(StoreFinderService), ɵɵdirectiveInject(ActivatedRoute), ɵɵdirectiveInject(RoutingService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _StoreFinderStoreComponent,
      selectors: [["cx-store-finder-store"]],
      inputs: {
        location: "location",
        disableMap: "disableMap"
      },
      decls: 6,
      vars: 6,
      consts: [["loading", ""], ["aria-live", "assertive", "aria-atomic", "true", "aria-relevant", "additions"], ["class", "container", 4, "ngIf", "ngIfElse"], [1, "container"], ["role", "status", 4, "cxFeature"], [1, "cx-visually-hidden"], [1, "cx-store-actions"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], [3, "type"], [1, "row"], [1, "col-12", "p-0"], [3, "disableMap", "location"], ["role", "status"], [1, "cx-spinner"]],
      template: function StoreFinderStoreComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 1);
          ɵɵtemplate(1, StoreFinderStoreComponent_div_1_Template, 12, 8, "div", 2);
          ɵɵpipe(2, "async");
          ɵɵpipe(3, "async");
          ɵɵelementEnd();
          ɵɵtemplate(4, StoreFinderStoreComponent_ng_template_4_Template, 2, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const loading_r4 = ɵɵreference(5);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.location || !ɵɵpipeBind1(2, 2, ctx.isLoading$) && ɵɵpipeBind1(3, 4, ctx.location$))("ngIfElse", loading_r4);
        }
      },
      dependencies: [NgIf, SpinnerComponent, IconComponent, FeatureDirective, StoreFinderStoreDescriptionComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderStoreComponent, [{
    type: Component,
    args: [{
      selector: "cx-store-finder-store",
      template: `<div aria-live="assertive" aria-atomic="true" aria-relevant="additions">
  <div
    class="container"
    *ngIf="
      location || (!(isLoading$ | async) && (location$ | async)) as location;
      else loading
    "
  >
    <div
      *cxFeature="'!a11yRemoveStatusLoadedRole'"
      role="status"
      [attr.aria-label]="'common.loaded' | cxTranslate"
    ></div>
    <div class="cx-visually-hidden">
      {{ location?.displayName }}
    </div>
    <div class="cx-store-actions">
      <button class="btn btn-block btn-secondary" (click)="goBack()">
        <cx-icon [type]="iconTypes.CARET_LEFT"></cx-icon>
        {{ 'storeFinder.backToList' | cxTranslate }}
      </button>
    </div>
    <div class="row">
      <div class="col-12 p-0">
        <cx-store-finder-store-description
          [disableMap]="disableMap"
          [location]="location"
        ></cx-store-finder-store-description>
      </div>
    </div>
  </div>
</div>

<ng-template #loading>
  <div class="cx-spinner"><cx-spinner></cx-spinner></div>
</ng-template>
`
    }]
  }], () => [{
    type: StoreFinderService
  }, {
    type: ActivatedRoute
  }, {
    type: RoutingService
  }], {
    location: [{
      type: Input
    }],
    disableMap: [{
      type: Input
    }]
  });
})();
var StoreFinderComponentsModule = class _StoreFinderComponentsModule {
  static {
    this.ɵfac = function StoreFinderComponentsModule_Factory(t) {
      return new (t || _StoreFinderComponentsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _StoreFinderComponentsModule,
      declarations: [StoreFinderSearchComponent, StoreFinderListComponent, StoreFinderMapComponent, StoreFinderListItemComponent, StoreFinderStoresCountComponent, StoreFinderGridComponent, StoreFinderStoreDescriptionComponent, ScheduleComponent, StoreFinderHeaderComponent, StoreFinderSearchResultComponent, StoreFinderComponent, StoreFinderPaginationDetailsComponent, StoreFinderStoreComponent],
      imports: [CommonModule, ReactiveFormsModule, RouterModule, ListNavigationModule, SpinnerModule, UrlModule, StoreFinderCoreModule, I18nModule, IconModule, OutletModule, FeaturesConfigModule, BtnLikeLinkModule],
      exports: [ScheduleComponent, StoreFinderComponent, StoreFinderGridComponent, StoreFinderHeaderComponent, StoreFinderListItemComponent, StoreFinderMapComponent, StoreFinderPaginationDetailsComponent, StoreFinderSearchComponent, StoreFinderSearchResultComponent, StoreFinderListComponent, StoreFinderStoreDescriptionComponent, StoreFinderStoresCountComponent, StoreFinderStoreComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          StoreFinderComponent: {
            component: StoreFinderComponent,
            childRoutes: [{
              path: "find",
              component: StoreFinderSearchResultComponent
            }, {
              path: "view-all",
              component: StoreFinderStoresCountComponent
            }, {
              path: "country/:country",
              component: StoreFinderGridComponent
            }, {
              path: "country/:country/region/:region",
              component: StoreFinderGridComponent
            }, {
              path: "country/:country/region/:region/:store",
              component: StoreFinderStoreComponent
            }, {
              path: "country/:country/:store",
              component: StoreFinderStoreComponent
            }]
          }
        }
      })],
      imports: [CommonModule, ReactiveFormsModule, RouterModule, ListNavigationModule, SpinnerModule, UrlModule, StoreFinderCoreModule, I18nModule, IconModule, OutletModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderComponentsModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, ReactiveFormsModule, RouterModule, ListNavigationModule, SpinnerModule, UrlModule, StoreFinderCoreModule, I18nModule, IconModule, OutletModule, FeaturesConfigModule, BtnLikeLinkModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          StoreFinderComponent: {
            component: StoreFinderComponent,
            childRoutes: [{
              path: "find",
              component: StoreFinderSearchResultComponent
            }, {
              path: "view-all",
              component: StoreFinderStoresCountComponent
            }, {
              path: "country/:country",
              component: StoreFinderGridComponent
            }, {
              path: "country/:country/region/:region",
              component: StoreFinderGridComponent
            }, {
              path: "country/:country/region/:region/:store",
              component: StoreFinderStoreComponent
            }, {
              path: "country/:country/:store",
              component: StoreFinderStoreComponent
            }]
          }
        }
      })],
      declarations: [StoreFinderSearchComponent, StoreFinderListComponent, StoreFinderMapComponent, StoreFinderListItemComponent, StoreFinderStoresCountComponent, StoreFinderGridComponent, StoreFinderStoreDescriptionComponent, ScheduleComponent, StoreFinderHeaderComponent, StoreFinderSearchResultComponent, StoreFinderComponent, StoreFinderPaginationDetailsComponent, StoreFinderStoreComponent],
      exports: [ScheduleComponent, StoreFinderComponent, StoreFinderGridComponent, StoreFinderHeaderComponent, StoreFinderListItemComponent, StoreFinderMapComponent, StoreFinderPaginationDetailsComponent, StoreFinderSearchComponent, StoreFinderSearchResultComponent, StoreFinderListComponent, StoreFinderStoreDescriptionComponent, StoreFinderStoresCountComponent, StoreFinderStoreComponent]
    }]
  }], null, null);
})();

// node_modules/@spartacus/storefinder/fesm2022/spartacus-storefinder.mjs
var StoreFinderModule = class _StoreFinderModule {
  static {
    this.ɵfac = function StoreFinderModule_Factory(t) {
      return new (t || _StoreFinderModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _StoreFinderModule,
      imports: [StoreFinderCoreModule, StoreFinderOccModule, StoreFinderComponentsModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [StoreFinderCoreModule, StoreFinderOccModule, StoreFinderComponentsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StoreFinderModule, [{
    type: NgModule,
    args: [{
      imports: [StoreFinderCoreModule, StoreFinderOccModule, StoreFinderComponentsModule]
    }]
  }], null, null);
})();

export {
  StoreFinderConfig,
  StoreFinderService,
  StoreFinderModule
};
//# sourceMappingURL=chunk-DQKQLJFB.js.map
