import {
  CONSIGNMENT_TRACKING_NORMALIZER,
  DownloadOrderInvoicesEvent,
  ORDER_HISTORY_NORMALIZER,
  ORDER_NORMALIZER,
  ORDER_RETURNS_NORMALIZER,
  ORDER_RETURN_REQUEST_INPUT_SERIALIZER,
  ORDER_RETURN_REQUEST_NORMALIZER,
  OrderConfirmationOrderEntriesContextToken,
  OrderDetailsOrderEntriesContextToken,
  OrderFacade,
  OrderHistoryFacade,
  OrderOutlets,
  OrderPlacedEvent,
  OrderReturnRequestFacade,
  REORDER_ORDER_NORMALIZER,
  REPLENISHMENT_ORDER_FORM_SERIALIZER,
  REPLENISHMENT_ORDER_HISTORY_NORMALIZER,
  REPLENISHMENT_ORDER_NORMALIZER,
  ReorderOrderFacade,
  ReplenishmentOrderHistoryFacade,
  ReplenishmentOrderScheduledEvent,
  ScheduledReplenishmentOrderFacade,
  USE_MY_ACCOUNT_V2_ORDER,
  billingAddressCard,
  deliveryAddressCard,
  deliveryModeCard,
  paymentMethodCard
} from "./chunk-BQCHH7UO.js";
import {
  AbstractOrderContextDirective,
  AbstractOrderContextModule
} from "./chunk-CYL7HNIE.js";
import "./chunk-LN4HYVID.js";
import {
  UserRegisterFacade
} from "./chunk-GPGDLQX4.js";
import {
  AddToCartComponent,
  AddToCartModule
} from "./chunk-BULPDSON.js";
import {
  AbstractOrderType,
  ActiveCartFacade,
  CartOutlets,
  CartValidationStatusCode,
  MultiCartFacade,
  ORDER_ENTRY_PROMOTIONS_NORMALIZER,
  OrderEntriesSource,
  PromotionLocation
} from "./chunk-DJP5CYBU.js";
import {
  AddToHomeScreenBannerComponent,
  BtnLikeLinkDirective,
  BtnLikeLinkModule,
  CardComponent,
  CardModule,
  CmsComponentData,
  CustomFormValidators,
  DIALOG_TYPE,
  DatePickerModule,
  DefaultValueAccessor,
  FileDownloadService,
  FocusDirective,
  FormControlName,
  FormErrorsComponent,
  FormErrorsModule,
  FormGroupDirective,
  FormsModule,
  ICON_TYPE,
  IconComponent,
  IconModule,
  ItemCounterComponent,
  ItemCounterModule,
  KeyboardFocusModule,
  LaunchDialogService,
  ListNavigationModule,
  MediaComponent,
  MediaModule,
  MessageComponent,
  MessageComponentModule,
  NgControlStatus,
  NgControlStatusGroup,
  NgSelectModule,
  OutletContextData,
  OutletDirective,
  OutletModule,
  OutletPosition,
  OutletService,
  PaginationComponent,
  PaginationModule,
  PasswordVisibilityToggleDirective,
  PasswordVisibilityToggleModule,
  PromotionsComponent,
  PromotionsModule,
  PwaModule,
  ReactiveFormsModule,
  RequiredValidator,
  SelectFocusUtility,
  SortingComponent,
  SortingModule,
  SpinnerComponent,
  SpinnerModule,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
  provideOutlet,
  ɵNgNoValidate
} from "./chunk-FIMZ5LIU.js";
import {
  AuthGuard,
  AuthService,
  CommandService,
  CommandStrategy,
  ConverterService,
  CxDatePipe,
  DEFAULT_SERVER_ERROR_RETRIES_COUNT,
  EventService,
  FeatureConfigService,
  FeatureDirective,
  FeaturesConfigModule,
  GlobalMessageService,
  GlobalMessageType,
  I18nModule,
  InterceptorUtil,
  LanguageService,
  LoggerService,
  MODULE_INITIALIZER,
  OCC_CART_ID_CURRENT,
  OCC_USER_ID_ANONYMOUS,
  OCC_USER_ID_CURRENT,
  OccEndpointsService,
  PROCESS_FEATURE,
  PRODUCT_NORMALIZER,
  Router,
  RouterLink,
  RouterLinkActive,
  RouterModule,
  RoutingService,
  SemanticPathService,
  TimeUtils,
  TranslatePipe,
  TranslationService,
  USE_CLIENT_TOKEN,
  UrlModule,
  UrlPipe,
  UserIdService,
  backOff,
  facadeFactory,
  isJaloError,
  isNotUndefined,
  isServerError,
  normalizeHttpError,
  process_selectors,
  provideDefaultConfig,
  provideDefaultConfigFactory,
  siteContextGroup_actions,
  tryNormalizeHttpError,
  useFeatureStyles,
  utilsGroup
} from "./chunk-CJWHFW34.js";
import {
  Actions,
  EffectsFeatureModule,
  EffectsModule,
  createEffect,
  ofType
} from "./chunk-OIYGDMWQ.js";
import {
  Store,
  StoreFeatureModule,
  StoreModule,
  createFeatureSelector,
  createSelector,
  select
} from "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import {
  AsyncPipe,
  CommonModule,
  HttpClient,
  HttpHeaders,
  NgClass,
  NgForOf,
  NgIf,
  NgTemplateOutlet,
  SlicePipe,
  formatCurrency,
  getCurrencySymbol
} from "./chunk-XWT3SXR6.js";
import {
  BehaviorSubject,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ComponentFactoryResolver$1,
  EMPTY,
  ElementRef,
  HostBinding,
  HostListener,
  Injectable,
  InjectionToken,
  Input,
  NgModule,
  Optional,
  Subscription,
  ViewChild,
  ViewContainerRef,
  auditTime,
  catchError,
  combineLatest,
  concatMap,
  distinctUntilChanged,
  filter,
  first,
  inject,
  map,
  of,
  setClassMetadata,
  shareReplay,
  skip,
  startWith,
  switchMap,
  take,
  tap,
  using,
  withLatestFrom,
  ɵɵInheritDefinitionFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵhostProperty,
  ɵɵinject,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵpipeBind3,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵpureFunction3,
  ɵɵpureFunction4,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-JMCPXHNJ.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/order/fesm2022/spartacus-order-core.mjs
var OrderHistoryAdapter = class {
};
var OrderHistoryConnector = class _OrderHistoryConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  get(userId, orderCode) {
    return this.adapter.load(userId, orderCode);
  }
  getHistory(userId, pageSize, currentPage, sort) {
    return this.adapter.loadHistory(userId, pageSize, currentPage, sort);
  }
  getConsignmentTracking(orderCode, consignmentCode, userId) {
    return this.adapter.getConsignmentTracking(orderCode, consignmentCode, userId);
  }
  cancel(userId, orderCode, cancelRequestInput) {
    return this.adapter.cancel(userId, orderCode, cancelRequestInput);
  }
  return(userId, returnRequestInput) {
    return this.adapter.createReturnRequest(userId, returnRequestInput);
  }
  getReturnRequestDetail(userId, returnRequestCode) {
    return this.adapter.loadReturnRequestDetail(userId, returnRequestCode);
  }
  getReturnRequestList(userId, pageSize, currentPage, sort) {
    return this.adapter.loadReturnRequestList(userId, pageSize, currentPage, sort);
  }
  cancelReturnRequest(userId, returnRequestCode, returnRequestModification) {
    return this.adapter.cancelReturnRequest(userId, returnRequestCode, returnRequestModification);
  }
  static {
    this.ɵfac = function OrderHistoryConnector_Factory(t) {
      return new (t || _OrderHistoryConnector)(ɵɵinject(OrderHistoryAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderHistoryConnector,
      factory: _OrderHistoryConnector.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderHistoryConnector, [{
    type: Injectable
  }], () => [{
    type: OrderHistoryAdapter
  }], null);
})();
var OrderAdapter = class {
};
var OrderConnector = class _OrderConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  placeOrder(userId, cartId, termsChecked) {
    return this.adapter.placeOrder(userId, cartId, termsChecked);
  }
  placePaymentAuthorizedOrder(userId, cartId, termsChecked) {
    return this.adapter.placePaymentAuthorizedOrder(userId, cartId, termsChecked);
  }
  static {
    this.ɵfac = function OrderConnector_Factory(t) {
      return new (t || _OrderConnector)(ɵɵinject(OrderAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderConnector,
      factory: _OrderConnector.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConnector, [{
    type: Injectable
  }], () => [{
    type: OrderAdapter
  }], null);
})();
var ReorderOrderAdapter = class {
};
var ReorderOrderConnector = class _ReorderOrderConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  reorder(orderId, userId) {
    return this.adapter.reorder(orderId, userId);
  }
  static {
    this.ɵfac = function ReorderOrderConnector_Factory(t) {
      return new (t || _ReorderOrderConnector)(ɵɵinject(ReorderOrderAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReorderOrderConnector,
      factory: _ReorderOrderConnector.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReorderOrderConnector, [{
    type: Injectable
  }], () => [{
    type: ReorderOrderAdapter
  }], null);
})();
var ReplenishmentOrderHistoryAdapter = class {
};
var ReplenishmentOrderHistoryConnector = class _ReplenishmentOrderHistoryConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  load(userId, replenishmentOrderCode) {
    return this.adapter.load(userId, replenishmentOrderCode);
  }
  loadReplenishmentDetailsHistory(userId, replenishmentOrderCode, pageSize, currentPage, sort) {
    return this.adapter.loadReplenishmentDetailsHistory(userId, replenishmentOrderCode, pageSize, currentPage, sort);
  }
  cancelReplenishmentOrder(userId, replenishmentOrderCode) {
    return this.adapter.cancelReplenishmentOrder(userId, replenishmentOrderCode);
  }
  loadHistory(userId, pageSize, currentPage, sort) {
    return this.adapter.loadHistory(userId, pageSize, currentPage, sort);
  }
  static {
    this.ɵfac = function ReplenishmentOrderHistoryConnector_Factory(t) {
      return new (t || _ReplenishmentOrderHistoryConnector)(ɵɵinject(ReplenishmentOrderHistoryAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReplenishmentOrderHistoryConnector,
      factory: _ReplenishmentOrderHistoryConnector.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderHistoryConnector, [{
    type: Injectable
  }], () => [{
    type: ReplenishmentOrderHistoryAdapter
  }], null);
})();
var ScheduledReplenishmentOrderAdapter = class {
};
var ScheduledReplenishmentOrderConnector = class _ScheduledReplenishmentOrderConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  scheduleReplenishmentOrder(cartId, scheduleReplenishmentForm, termsChecked, userId) {
    return this.adapter.scheduleReplenishmentOrder(cartId, scheduleReplenishmentForm, termsChecked, userId);
  }
  static {
    this.ɵfac = function ScheduledReplenishmentOrderConnector_Factory(t) {
      return new (t || _ScheduledReplenishmentOrderConnector)(ɵɵinject(ScheduledReplenishmentOrderAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ScheduledReplenishmentOrderConnector,
      factory: _ScheduledReplenishmentOrderConnector.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ScheduledReplenishmentOrderConnector, [{
    type: Injectable
  }], () => [{
    type: ScheduledReplenishmentOrderAdapter
  }], null);
})();
var LOAD_CONSIGNMENT_TRACKING = "[Order] Load Consignment Tracking";
var LOAD_CONSIGNMENT_TRACKING_FAIL = "[Order] Load Consignment Tracking Fail";
var LOAD_CONSIGNMENT_TRACKING_SUCCESS = "[Order] Load Consignment Tracking Success";
var CLEAR_CONSIGNMENT_TRACKING = "[Order] Clear Consignment Tracking";
var LoadConsignmentTracking = class {
  constructor(payload) {
    this.payload = payload;
    this.type = LOAD_CONSIGNMENT_TRACKING;
  }
};
var LoadConsignmentTrackingFail = class {
  constructor(payload) {
    this.payload = payload;
    this.type = LOAD_CONSIGNMENT_TRACKING_FAIL;
    this.error = payload;
  }
};
var LoadConsignmentTrackingSuccess = class {
  constructor(payload) {
    this.payload = payload;
    this.type = LOAD_CONSIGNMENT_TRACKING_SUCCESS;
  }
};
var ClearConsignmentTracking = class {
  constructor() {
    this.type = CLEAR_CONSIGNMENT_TRACKING;
  }
};
var ORDER_FEATURE = "order";
var CANCEL_ORDER_PROCESS_ID = "cancelOrder";
var CANCEL_RETURN_PROCESS_ID = "cancelReturn";
var CANCEL_REPLENISHMENT_ORDER_PROCESS_ID = "cancelReplenishmentOrder";
var ORDERS = "[Order] User Orders";
var RETURN_REQUESTS = "[Order] Order Return Requests";
var RETURN_REQUEST_DETAILS = "[Order] Return Request Details";
var ORDER_DETAILS = "[Order] User Order Details";
var REPLENISHMENT_ORDERS = "[Order] User Replenishment Orders";
var REPLENISHMENT_ORDER_DETAILS = "[Order] User Replenishment Order Details";
var CONSIGNMENT_TRACKING_BY_ID_ENTITIES = "consignment-tracking-by-id-entities";
var ORDER_BY_ID_ENTITIES = "order-by-id-entities";
function getConsignmentTrackingByIdEntityKey(orderCode, consignmentCode) {
  return `${orderCode},${consignmentCode}`;
}
var LOAD_ORDER_DETAILS = "[Order] Load Order Details";
var LOAD_ORDER_DETAILS_FAIL = "[Order] Load Order Details Fail";
var LOAD_ORDER_DETAILS_SUCCESS = "[Order] Load Order Details Success";
var CLEAR_ORDER_DETAILS = "[Order] Clear Order Details";
var CANCEL_ORDER = "[Order] Cancel Order";
var CANCEL_ORDER_FAIL = "[Order] Cancel Order Fail";
var CANCEL_ORDER_SUCCESS = "[Order] Cancel Order Success";
var RESET_CANCEL_ORDER_PROCESS = "[Order] Reset Cancel Order Process";
var LoadOrderDetails = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(ORDER_DETAILS);
    this.payload = payload;
    this.type = LOAD_ORDER_DETAILS;
  }
};
var LoadOrderDetailsFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(ORDER_DETAILS, payload);
    this.payload = payload;
    this.type = LOAD_ORDER_DETAILS_FAIL;
  }
};
var LoadOrderDetailsSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(ORDER_DETAILS);
    this.payload = payload;
    this.type = LOAD_ORDER_DETAILS_SUCCESS;
  }
};
var ClearOrderDetails = class extends utilsGroup.LoaderResetAction {
  constructor() {
    super(ORDER_DETAILS);
    this.type = CLEAR_ORDER_DETAILS;
  }
};
var CancelOrder = class extends utilsGroup.EntityLoadAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_ORDER_PROCESS_ID);
    this.payload = payload;
    this.type = CANCEL_ORDER;
  }
};
var CancelOrderFail = class extends utilsGroup.EntityFailAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_ORDER_PROCESS_ID, payload);
    this.payload = payload;
    this.type = CANCEL_ORDER_FAIL;
  }
};
var CancelOrderSuccess = class extends utilsGroup.EntitySuccessAction {
  constructor() {
    super(PROCESS_FEATURE, CANCEL_ORDER_PROCESS_ID);
    this.type = CANCEL_ORDER_SUCCESS;
  }
};
var ResetCancelOrderProcess = class extends utilsGroup.EntityLoaderResetAction {
  constructor() {
    super(PROCESS_FEATURE, CANCEL_ORDER_PROCESS_ID);
    this.type = RESET_CANCEL_ORDER_PROCESS;
  }
};
var CREATE_ORDER_RETURN_REQUEST = "[Order] Create Order Return Request";
var CREATE_ORDER_RETURN_REQUEST_FAIL = "[Order] Create Order Return Request Fail";
var CREATE_ORDER_RETURN_REQUEST_SUCCESS = "[Order] Create Order Return Request Success";
var LOAD_ORDER_RETURN_REQUEST = "[Order] Load Order Return Request details";
var LOAD_ORDER_RETURN_REQUEST_FAIL = "[Order] Load Order Return Request details Fail";
var LOAD_ORDER_RETURN_REQUEST_SUCCESS = "[Order] Load Order Return Request details Success";
var CANCEL_ORDER_RETURN_REQUEST = "[Order] Cancel Order Return Request";
var CANCEL_ORDER_RETURN_REQUEST_FAIL = "[Order] Cancel Order Return Request Fail";
var CANCEL_ORDER_RETURN_REQUEST_SUCCESS = "[Order] Cancel Order Return Request Success";
var LOAD_ORDER_RETURN_REQUEST_LIST = "[Order] Load User Order Return Request List";
var LOAD_ORDER_RETURN_REQUEST_LIST_FAIL = "[Order] Load User Order Return Request List Fail";
var LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS = "[Order] Load User Order Return Request List Success";
var CLEAR_ORDER_RETURN_REQUEST = "[Order] Clear Order Return Request Details";
var CLEAR_ORDER_RETURN_REQUEST_LIST = "[Order] Clear Order Return Request List";
var RESET_CANCEL_RETURN_PROCESS = "[Order] Reset Cancel Return Request Process";
var CreateOrderReturnRequest = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(RETURN_REQUEST_DETAILS);
    this.payload = payload;
    this.type = CREATE_ORDER_RETURN_REQUEST;
  }
};
var CreateOrderReturnRequestFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(RETURN_REQUEST_DETAILS, payload);
    this.payload = payload;
    this.type = CREATE_ORDER_RETURN_REQUEST_FAIL;
  }
};
var CreateOrderReturnRequestSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(RETURN_REQUEST_DETAILS);
    this.payload = payload;
    this.type = CREATE_ORDER_RETURN_REQUEST_SUCCESS;
  }
};
var LoadOrderReturnRequest = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(RETURN_REQUEST_DETAILS);
    this.payload = payload;
    this.type = LOAD_ORDER_RETURN_REQUEST;
  }
};
var LoadOrderReturnRequestFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(RETURN_REQUEST_DETAILS, payload);
    this.payload = payload;
    this.type = LOAD_ORDER_RETURN_REQUEST_FAIL;
  }
};
var LoadOrderReturnRequestSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(RETURN_REQUEST_DETAILS);
    this.payload = payload;
    this.type = LOAD_ORDER_RETURN_REQUEST_SUCCESS;
  }
};
var CancelOrderReturnRequest = class extends utilsGroup.EntityLoadAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_RETURN_PROCESS_ID);
    this.payload = payload;
    this.type = CANCEL_ORDER_RETURN_REQUEST;
  }
};
var CancelOrderReturnRequestFail = class extends utilsGroup.EntityFailAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_RETURN_PROCESS_ID, payload);
    this.payload = payload;
    this.type = CANCEL_ORDER_RETURN_REQUEST_FAIL;
  }
};
var CancelOrderReturnRequestSuccess = class extends utilsGroup.EntitySuccessAction {
  constructor() {
    super(PROCESS_FEATURE, CANCEL_RETURN_PROCESS_ID);
    this.type = CANCEL_ORDER_RETURN_REQUEST_SUCCESS;
  }
};
var LoadOrderReturnRequestList = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(RETURN_REQUESTS);
    this.payload = payload;
    this.type = LOAD_ORDER_RETURN_REQUEST_LIST;
  }
};
var LoadOrderReturnRequestListFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(RETURN_REQUESTS, payload);
    this.payload = payload;
    this.type = LOAD_ORDER_RETURN_REQUEST_LIST_FAIL;
  }
};
var LoadOrderReturnRequestListSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(RETURN_REQUESTS);
    this.payload = payload;
    this.type = LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS;
  }
};
var ClearOrderReturnRequest = class extends utilsGroup.LoaderResetAction {
  constructor() {
    super(RETURN_REQUEST_DETAILS);
    this.type = CLEAR_ORDER_RETURN_REQUEST;
  }
};
var ClearOrderReturnRequestList = class extends utilsGroup.LoaderResetAction {
  constructor() {
    super(RETURN_REQUESTS);
    this.type = CLEAR_ORDER_RETURN_REQUEST_LIST;
  }
};
var ResetCancelReturnProcess = class extends utilsGroup.EntityLoaderResetAction {
  constructor() {
    super(PROCESS_FEATURE, CANCEL_RETURN_PROCESS_ID);
    this.type = RESET_CANCEL_RETURN_PROCESS;
  }
};
var LOAD_USER_ORDERS = "[Order] Load User Orders";
var LOAD_USER_ORDERS_FAIL = "[Order] Load User Orders Fail";
var LOAD_USER_ORDERS_SUCCESS = "[Order] Load User Orders Success";
var CLEAR_USER_ORDERS = "[Order] Clear User Orders";
var LoadUserOrders = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(ORDERS);
    this.payload = payload;
    this.type = LOAD_USER_ORDERS;
  }
};
var LoadUserOrdersFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(ORDERS, payload);
    this.payload = payload;
    this.type = LOAD_USER_ORDERS_FAIL;
  }
};
var LoadUserOrdersSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(ORDERS);
    this.payload = payload;
    this.type = LOAD_USER_ORDERS_SUCCESS;
  }
};
var ClearUserOrders = class extends utilsGroup.LoaderResetAction {
  constructor() {
    super(ORDERS);
    this.type = CLEAR_USER_ORDERS;
  }
};
var LOAD_REPLENISHMENT_ORDER_DETAILS = "[Order] Load Replenishment Order Details";
var LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS = "[Order] Load Replenishment Order Details Success";
var LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL = "[Order] Load Replenishment Order Details Fail";
var ClEAR_REPLENISHMENT_ORDER_DETAILS = "[Order] Clear Replenishment Order Details";
var CANCEL_REPLENISHMENT_ORDER = "[Order] Cancel Replenishment Order";
var CANCEL_REPLENISHMENT_ORDER_SUCCESS = "[Order] Cancel Replenishment Order Success";
var CANCEL_REPLENISHMENT_ORDER_FAIL = "[Order] Cancel Replenishment Order Fail";
var CLEAR_CANCEL_REPLENISHMENT_ORDER = "[Order] Clear Cancel Replenishment Order";
var LoadReplenishmentOrderDetails = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(REPLENISHMENT_ORDER_DETAILS);
    this.payload = payload;
    this.type = LOAD_REPLENISHMENT_ORDER_DETAILS;
  }
};
var LoadReplenishmentOrderDetailsSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(REPLENISHMENT_ORDER_DETAILS);
    this.payload = payload;
    this.type = LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS;
  }
};
var LoadReplenishmentOrderDetailsFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(REPLENISHMENT_ORDER_DETAILS, payload);
    this.payload = payload;
    this.type = LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL;
  }
};
var ClearReplenishmentOrderDetails = class extends utilsGroup.LoaderResetAction {
  constructor() {
    super(REPLENISHMENT_ORDER_DETAILS);
    this.type = ClEAR_REPLENISHMENT_ORDER_DETAILS;
  }
};
var CancelReplenishmentOrder = class extends utilsGroup.EntityLoadAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_REPLENISHMENT_ORDER_PROCESS_ID);
    this.payload = payload;
    this.type = CANCEL_REPLENISHMENT_ORDER;
  }
};
var CancelReplenishmentOrderSuccess = class extends utilsGroup.EntitySuccessAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_REPLENISHMENT_ORDER_PROCESS_ID);
    this.payload = payload;
    this.type = CANCEL_REPLENISHMENT_ORDER_SUCCESS;
  }
};
var CancelReplenishmentOrderFail = class extends utilsGroup.EntityFailAction {
  constructor(payload) {
    super(PROCESS_FEATURE, CANCEL_REPLENISHMENT_ORDER_PROCESS_ID, payload);
    this.payload = payload;
    this.type = CANCEL_REPLENISHMENT_ORDER_FAIL;
  }
};
var ClearCancelReplenishmentOrder = class extends utilsGroup.EntityLoaderResetAction {
  constructor() {
    super(PROCESS_FEATURE, CANCEL_REPLENISHMENT_ORDER_PROCESS_ID);
    this.type = CLEAR_CANCEL_REPLENISHMENT_ORDER;
  }
};
var LOAD_USER_REPLENISHMENT_ORDERS = "[Order] Load User Replenishment Orders";
var LOAD_USER_REPLENISHMENT_ORDERS_FAIL = "[Order] Load User Replenishment Orders Fail";
var LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS = "[Order] Load User Replenishment Orders Success";
var CLEAR_USER_REPLENISHMENT_ORDERS = "[Order] Clear User Replenishment Orders";
var LoadUserReplenishmentOrders = class extends utilsGroup.LoaderLoadAction {
  constructor(payload) {
    super(REPLENISHMENT_ORDERS);
    this.payload = payload;
    this.type = LOAD_USER_REPLENISHMENT_ORDERS;
  }
};
var LoadUserReplenishmentOrdersFail = class extends utilsGroup.LoaderFailAction {
  constructor(payload) {
    super(REPLENISHMENT_ORDERS, payload);
    this.payload = payload;
    this.type = LOAD_USER_REPLENISHMENT_ORDERS_FAIL;
  }
};
var LoadUserReplenishmentOrdersSuccess = class extends utilsGroup.LoaderSuccessAction {
  constructor(payload) {
    super(REPLENISHMENT_ORDERS);
    this.payload = payload;
    this.type = LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS;
  }
};
var ClearUserReplenishmentOrders = class extends utilsGroup.LoaderResetAction {
  constructor() {
    super(REPLENISHMENT_ORDERS);
    this.type = CLEAR_USER_REPLENISHMENT_ORDERS;
  }
};
var LOAD_CONSIGNMENT_TRACKING_BY_ID = "[Order] Load Consignment Tracking By ID Data";
var LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL = "[Order] Load  Consignment Tracking By ID Data Fail";
var LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS = "[Order] Load Consignment Tracking By ID Data Success";
var LoadConsignmentTrackingById = class extends utilsGroup.EntityLoadAction {
  constructor(payload) {
    super(CONSIGNMENT_TRACKING_BY_ID_ENTITIES, getConsignmentTrackingByIdEntityKey(payload.orderCode, payload.consignmentCode));
    this.payload = payload;
    this.type = LOAD_CONSIGNMENT_TRACKING_BY_ID;
  }
};
var LoadConsignmentTrackingByIdFail = class extends utilsGroup.EntityFailAction {
  constructor(payload) {
    super(CONSIGNMENT_TRACKING_BY_ID_ENTITIES, getConsignmentTrackingByIdEntityKey(payload.orderCode, payload.consignmentCode), payload.error);
    this.payload = payload;
    this.type = LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL;
  }
};
var LoadConsignmentTrackingByIdSuccess = class extends utilsGroup.EntitySuccessAction {
  constructor(payload) {
    super(CONSIGNMENT_TRACKING_BY_ID_ENTITIES, getConsignmentTrackingByIdEntityKey(payload.orderCode, payload.consignmentCode));
    this.payload = payload;
    this.type = LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS;
  }
};
var LOAD_ORDER_BY_ID = "[Order] Load Order By ID Data";
var LOAD_ORDER_BY_ID_FAIL = "[Order] Load Order By ID Data Fail";
var LOAD_ORDER_BY_ID_SUCCESS = "[Order] Load Order By ID Data Success";
var LoadOrderById = class extends utilsGroup.EntityLoadAction {
  constructor(payload) {
    super(ORDER_BY_ID_ENTITIES, payload.code);
    this.payload = payload;
    this.type = LOAD_ORDER_BY_ID;
  }
};
var LoadOrderByIdFail = class extends utilsGroup.EntityFailAction {
  constructor(payload) {
    super(ORDER_BY_ID_ENTITIES, payload.code, payload.error);
    this.payload = payload;
    this.type = LOAD_ORDER_BY_ID_FAIL;
  }
};
var LoadOrderByIdSuccess = class extends utilsGroup.EntitySuccessAction {
  constructor(payload) {
    super(ORDER_BY_ID_ENTITIES, payload.code ?? "");
    this.payload = payload;
    this.type = LOAD_ORDER_BY_ID_SUCCESS;
  }
};
var orderGroup_actions = Object.freeze({
  __proto__: null,
  CANCEL_ORDER,
  CANCEL_ORDER_FAIL,
  CANCEL_ORDER_RETURN_REQUEST,
  CANCEL_ORDER_RETURN_REQUEST_FAIL,
  CANCEL_ORDER_RETURN_REQUEST_SUCCESS,
  CANCEL_ORDER_SUCCESS,
  CANCEL_REPLENISHMENT_ORDER,
  CANCEL_REPLENISHMENT_ORDER_FAIL,
  CANCEL_REPLENISHMENT_ORDER_SUCCESS,
  CLEAR_CANCEL_REPLENISHMENT_ORDER,
  CLEAR_CONSIGNMENT_TRACKING,
  CLEAR_ORDER_DETAILS,
  CLEAR_ORDER_RETURN_REQUEST,
  CLEAR_ORDER_RETURN_REQUEST_LIST,
  CLEAR_USER_ORDERS,
  CLEAR_USER_REPLENISHMENT_ORDERS,
  CREATE_ORDER_RETURN_REQUEST,
  CREATE_ORDER_RETURN_REQUEST_FAIL,
  CREATE_ORDER_RETURN_REQUEST_SUCCESS,
  CancelOrder,
  CancelOrderFail,
  CancelOrderReturnRequest,
  CancelOrderReturnRequestFail,
  CancelOrderReturnRequestSuccess,
  CancelOrderSuccess,
  CancelReplenishmentOrder,
  CancelReplenishmentOrderFail,
  CancelReplenishmentOrderSuccess,
  ClEAR_REPLENISHMENT_ORDER_DETAILS,
  ClearCancelReplenishmentOrder,
  ClearConsignmentTracking,
  ClearOrderDetails,
  ClearOrderReturnRequest,
  ClearOrderReturnRequestList,
  ClearReplenishmentOrderDetails,
  ClearUserOrders,
  ClearUserReplenishmentOrders,
  CreateOrderReturnRequest,
  CreateOrderReturnRequestFail,
  CreateOrderReturnRequestSuccess,
  LOAD_CONSIGNMENT_TRACKING,
  LOAD_CONSIGNMENT_TRACKING_BY_ID,
  LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL,
  LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS,
  LOAD_CONSIGNMENT_TRACKING_FAIL,
  LOAD_CONSIGNMENT_TRACKING_SUCCESS,
  LOAD_ORDER_BY_ID,
  LOAD_ORDER_BY_ID_FAIL,
  LOAD_ORDER_BY_ID_SUCCESS,
  LOAD_ORDER_DETAILS,
  LOAD_ORDER_DETAILS_FAIL,
  LOAD_ORDER_DETAILS_SUCCESS,
  LOAD_ORDER_RETURN_REQUEST,
  LOAD_ORDER_RETURN_REQUEST_FAIL,
  LOAD_ORDER_RETURN_REQUEST_LIST,
  LOAD_ORDER_RETURN_REQUEST_LIST_FAIL,
  LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS,
  LOAD_ORDER_RETURN_REQUEST_SUCCESS,
  LOAD_REPLENISHMENT_ORDER_DETAILS,
  LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL,
  LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS,
  LOAD_USER_ORDERS,
  LOAD_USER_ORDERS_FAIL,
  LOAD_USER_ORDERS_SUCCESS,
  LOAD_USER_REPLENISHMENT_ORDERS,
  LOAD_USER_REPLENISHMENT_ORDERS_FAIL,
  LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS,
  LoadConsignmentTracking,
  LoadConsignmentTrackingById,
  LoadConsignmentTrackingByIdFail,
  LoadConsignmentTrackingByIdSuccess,
  LoadConsignmentTrackingFail,
  LoadConsignmentTrackingSuccess,
  LoadOrderById,
  LoadOrderByIdFail,
  LoadOrderByIdSuccess,
  LoadOrderDetails,
  LoadOrderDetailsFail,
  LoadOrderDetailsSuccess,
  LoadOrderReturnRequest,
  LoadOrderReturnRequestFail,
  LoadOrderReturnRequestList,
  LoadOrderReturnRequestListFail,
  LoadOrderReturnRequestListSuccess,
  LoadOrderReturnRequestSuccess,
  LoadReplenishmentOrderDetails,
  LoadReplenishmentOrderDetailsFail,
  LoadReplenishmentOrderDetailsSuccess,
  LoadUserOrders,
  LoadUserOrdersFail,
  LoadUserOrdersSuccess,
  LoadUserReplenishmentOrders,
  LoadUserReplenishmentOrdersFail,
  LoadUserReplenishmentOrdersSuccess,
  RESET_CANCEL_ORDER_PROCESS,
  RESET_CANCEL_RETURN_PROCESS,
  ResetCancelOrderProcess,
  ResetCancelReturnProcess
});
var getOrderState = createFeatureSelector(ORDER_FEATURE);
var getConsignmentTrackingState = createSelector(getOrderState, (state) => state.consignmentTracking);
var getConsignmentTracking = createSelector(getConsignmentTrackingState, (state) => state.tracking);
var getOrderDetailState = createSelector(getOrderState, (state) => state.orderDetail);
var getOrderDetails = createSelector(getOrderDetailState, (state) => utilsGroup.loaderValueSelector(state));
var getOrderDetailsLoading = createSelector(getOrderDetailState, (state) => utilsGroup.loaderLoadingSelector(state));
var getOrderReturnRequestState = createSelector(getOrderState, (state) => state.orderReturn);
var getOrderReturnRequest = createSelector(getOrderReturnRequestState, (state) => utilsGroup.loaderValueSelector(state));
var getOrderReturnRequestLoading = createSelector(getOrderReturnRequestState, (state) => utilsGroup.loaderLoadingSelector(state));
var getOrderReturnRequestSuccess = createSelector(getOrderReturnRequestState, (state) => utilsGroup.loaderSuccessSelector(state) && !utilsGroup.loaderLoadingSelector(state));
var getOrderReturnRequestListState = createSelector(getOrderState, (state) => state.orderReturnList);
var getOrderReturnRequestList = createSelector(getOrderReturnRequestListState, (state) => utilsGroup.loaderValueSelector(state));
var getOrdersState = createSelector(getOrderState, (state) => state.orders);
var getOrdersLoaded = createSelector(getOrdersState, (state) => utilsGroup.loaderSuccessSelector(state));
var getOrders = createSelector(getOrdersState, (state) => utilsGroup.loaderValueSelector(state));
var getReplenishmentOrderState = createSelector(getOrderState, (state) => state.replenishmentOrder);
var getReplenishmentOrderDetailsValue = createSelector(getReplenishmentOrderState, (state) => utilsGroup.loaderValueSelector(state));
var getReplenishmentOrderDetailsLoading = createSelector(getReplenishmentOrderState, (state) => utilsGroup.loaderLoadingSelector(state));
var getReplenishmentOrderDetailsSuccess = createSelector(getReplenishmentOrderState, (state) => utilsGroup.loaderSuccessSelector(state));
var getReplenishmentOrderDetailsError = createSelector(getReplenishmentOrderState, (state) => utilsGroup.loaderErrorSelector(state));
var getReplenishmentOrdersState = createSelector(getOrderState, (state) => state.replenishmentOrders);
var getReplenishmentOrders = createSelector(getReplenishmentOrdersState, (state) => utilsGroup.loaderValueSelector(state));
var getReplenishmentOrdersLoading = createSelector(getReplenishmentOrdersState, (state) => utilsGroup.loaderLoadingSelector(state));
var getReplenishmentOrdersError = createSelector(getReplenishmentOrdersState, (state) => utilsGroup.loaderErrorSelector(state));
var getReplenishmentOrdersSuccess = createSelector(getReplenishmentOrdersState, (state) => utilsGroup.loaderSuccessSelector(state));
var getConsignmentTrackingByIdEntities = createSelector(getOrderState, (state) => state.consignmentTrackingById);
var getConsignmentTrackingByIdEntity = (orderCode, consignmentCode) => createSelector(getConsignmentTrackingByIdEntities, (state) => utilsGroup.entityLoaderStateSelector(state, getConsignmentTrackingByIdEntityKey(orderCode, consignmentCode)));
var getConsignmentTrackingById = (orderCode, consignmentCode) => {
  return createSelector(getConsignmentTrackingByIdEntity(orderCode, consignmentCode), (consignmentTrackingByIdState) => utilsGroup.loaderValueSelector(consignmentTrackingByIdState));
};
var getConsignmentTrackingByIdLoading = (orderCode, consignmentCode) => {
  return createSelector(getConsignmentTrackingByIdEntity(orderCode, consignmentCode), (loaderState) => utilsGroup.loaderLoadingSelector(loaderState));
};
var getConsignmentTrackingByIdSuccess = (orderCode, consignmentCode) => {
  return createSelector(getConsignmentTrackingByIdEntity(orderCode, consignmentCode), (loaderState) => utilsGroup.loaderSuccessSelector(loaderState));
};
var getOrderByIdEntities = createSelector(getOrderState, (state) => state.orderById);
var getOrderByIdEntity = (code) => createSelector(getOrderByIdEntities, (state) => utilsGroup.entityLoaderStateSelector(state, code));
var getOrderById = (code) => {
  return createSelector(getOrderByIdEntity(code), (orderByIDState) => utilsGroup.loaderValueSelector(orderByIDState));
};
var getOrderByIdLoading = (code) => {
  return createSelector(getOrderByIdEntity(code), (loaderState) => utilsGroup.loaderLoadingSelector(loaderState));
};
var getOrderByIdSuccess = (code) => {
  return createSelector(getOrderByIdEntity(code), (loaderState) => utilsGroup.loaderSuccessSelector(loaderState));
};
var orderGroup_selectors = Object.freeze({
  __proto__: null,
  getConsignmentTracking,
  getConsignmentTrackingById,
  getConsignmentTrackingByIdEntities,
  getConsignmentTrackingByIdEntity,
  getConsignmentTrackingByIdLoading,
  getConsignmentTrackingByIdSuccess,
  getConsignmentTrackingState,
  getOrderById,
  getOrderByIdEntities,
  getOrderByIdEntity,
  getOrderByIdLoading,
  getOrderByIdSuccess,
  getOrderDetailState,
  getOrderDetails,
  getOrderDetailsLoading,
  getOrderReturnRequest,
  getOrderReturnRequestList,
  getOrderReturnRequestListState,
  getOrderReturnRequestLoading,
  getOrderReturnRequestState,
  getOrderReturnRequestSuccess,
  getOrderState,
  getOrders,
  getOrdersLoaded,
  getOrdersState,
  getReplenishmentOrderDetailsError,
  getReplenishmentOrderDetailsLoading,
  getReplenishmentOrderDetailsSuccess,
  getReplenishmentOrderDetailsValue,
  getReplenishmentOrderState,
  getReplenishmentOrders,
  getReplenishmentOrdersError,
  getReplenishmentOrdersLoading,
  getReplenishmentOrdersState,
  getReplenishmentOrdersSuccess
});
var OrderHistoryService = class _OrderHistoryService {
  constructor(store, processStateStore, userIdService, routingService) {
    this.store = store;
    this.processStateStore = processStateStore;
    this.userIdService = userIdService;
    this.routingService = routingService;
  }
  /**
   * Returns an order's detail
   */
  getOrderDetails() {
    return this.store.pipe(select(getOrderDetails));
  }
  /**
   * Retrieves order's details
   *
   * @param orderCode an order code
   */
  loadOrderDetails(orderCode) {
    this.userIdService.takeUserId().subscribe((userId) => {
      this.store.dispatch(new LoadOrderDetails({
        userId,
        orderCode
      }));
    });
  }
  /**
   * Clears order's details
   */
  clearOrderDetails() {
    this.store.dispatch(new ClearOrderDetails());
  }
  /**
   * Returns order history list
   */
  getOrderHistoryList(pageSize) {
    return this.store.pipe(select(getOrdersState), tap((orderListState) => {
      const attemptedLoad = orderListState.loading || orderListState.success || orderListState.error;
      if (!attemptedLoad) {
        this.loadOrderList(pageSize);
      }
    }), map((orderListState) => orderListState.value));
  }
  /**
   * Returns a loaded flag for order history list
   */
  getOrderHistoryListLoaded() {
    return this.store.pipe(select(getOrdersLoaded));
  }
  /**
   * Retrieves an order list
   * @param pageSize page size
   * @param currentPage current page
   * @param sort sort
   */
  loadOrderList(pageSize, currentPage, sort) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => {
        let replenishmentOrderCode;
        this.routingService.getRouterState().pipe(take(1)).subscribe((data) => {
          replenishmentOrderCode = data?.state?.params?.replenishmentOrderCode;
        }).unsubscribe();
        this.store.dispatch(new LoadUserOrders({
          userId,
          pageSize,
          currentPage,
          sort,
          replenishmentOrderCode
        }));
      },
      error: () => {
      }
    });
  }
  /**
   * Cleaning order list
   */
  clearOrderList() {
    this.store.dispatch(new ClearUserOrders());
  }
  /**
   *  Returns a consignment tracking detail
   */
  getConsignmentTracking() {
    return this.store.pipe(select(getConsignmentTracking));
  }
  /**
   * Retrieves consignment tracking details
   * @param orderCode an order code
   * @param consignmentCode a consignment code
   */
  loadConsignmentTracking(orderCode, consignmentCode) {
    this.userIdService.takeUserId().subscribe((userId) => {
      this.store.dispatch(new LoadConsignmentTracking({
        userId,
        orderCode,
        consignmentCode
      }));
    });
  }
  /**
   * Cleaning consignment tracking
   */
  clearConsignmentTracking() {
    this.store.dispatch(new ClearConsignmentTracking());
  }
  /*
   * Cancel an order
   */
  cancelOrder(orderCode, cancelRequestInput) {
    this.userIdService.takeUserId().subscribe((userId) => {
      this.store.dispatch(new CancelOrder({
        userId,
        orderCode,
        cancelRequestInput
      }));
    });
  }
  /**
   * Returns the cancel order loading flag
   */
  getCancelOrderLoading() {
    return this.processStateStore.pipe(select(process_selectors.getProcessLoadingFactory(CANCEL_ORDER_PROCESS_ID)));
  }
  /**
   * Returns the cancel order success flag
   */
  getCancelOrderSuccess() {
    return this.processStateStore.pipe(select(process_selectors.getProcessSuccessFactory(CANCEL_ORDER_PROCESS_ID)));
  }
  /**
   * Resets the cancel order process flags
   */
  resetCancelOrderProcessState() {
    return this.store.dispatch(new ResetCancelOrderProcess());
  }
  /**
   * Returns the order details loading flag
   */
  getOrderDetailsLoading() {
    return this.store.pipe(select(getOrderDetailsLoading));
  }
  getQueryParams(_order) {
    return null;
  }
  static {
    this.ɵfac = function OrderHistoryService_Factory(t) {
      return new (t || _OrderHistoryService)(ɵɵinject(Store), ɵɵinject(Store), ɵɵinject(UserIdService), ɵɵinject(RoutingService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderHistoryService,
      factory: _OrderHistoryService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderHistoryService, [{
    type: Injectable
  }], () => [{
    type: Store
  }, {
    type: Store
  }, {
    type: UserIdService
  }, {
    type: RoutingService
  }], null);
})();
var OrderReturnRequestService = class _OrderReturnRequestService {
  constructor(store, processStateStore, userIdService) {
    this.store = store;
    this.processStateStore = processStateStore;
    this.userIdService = userIdService;
  }
  /**
   * Create order return request
   * @param orderCode an order code
   * @param returnRequestInput order return request entry input
   */
  createOrderReturnRequest(returnRequestInput) {
    this.userIdService.takeUserId().subscribe((userId) => {
      this.store.dispatch(new CreateOrderReturnRequest({
        userId,
        returnRequestInput
      }));
    });
  }
  /**
   * Return an order return request
   */
  getOrderReturnRequest() {
    return this.store.pipe(select(getOrderReturnRequest));
  }
  /**
   * Gets order return request list
   */
  getOrderReturnRequestList(pageSize) {
    return this.store.pipe(select(getOrderReturnRequestListState), tap((returnListState) => {
      const attemptedLoad = returnListState.loading || returnListState.success || returnListState.error;
      if (!attemptedLoad) {
        this.loadOrderReturnRequestList(pageSize);
      }
    }), map((returnListState) => returnListState.value));
  }
  /**
   * Loads order return request detail
   * @param returnRequestCode
   */
  loadOrderReturnRequestDetail(returnRequestCode) {
    this.userIdService.takeUserId().subscribe((userId) => {
      this.store.dispatch(new LoadOrderReturnRequest({
        userId,
        returnRequestCode
      }));
    });
  }
  /**
   * Loads order return request list
   * @param pageSize page size
   * @param currentPage current page
   * @param sort sort
   */
  loadOrderReturnRequestList(pageSize, currentPage, sort) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => {
        this.store.dispatch(new LoadOrderReturnRequestList({
          userId,
          pageSize,
          currentPage,
          sort
        }));
      },
      error: () => {
      }
    });
  }
  /**
   * Cleaning order return request list
   */
  clearOrderReturnRequestList() {
    this.store.dispatch(new ClearOrderReturnRequestList());
  }
  /**
   * Get the order return request loading flag
   */
  getReturnRequestLoading() {
    return this.store.pipe(select(getOrderReturnRequestLoading));
  }
  /**
   * Get the order return request success flag
   */
  getReturnRequestSuccess() {
    return this.store.pipe(select(getOrderReturnRequestSuccess));
  }
  /**
   * Cleaning order return request details
   */
  clearOrderReturnRequestDetail() {
    this.store.dispatch(new ClearOrderReturnRequest());
  }
  /*
   * Cancel order return request
   */
  cancelOrderReturnRequest(returnRequestCode, returnRequestModification) {
    this.userIdService.takeUserId().subscribe((userId) => {
      this.store.dispatch(new CancelOrderReturnRequest({
        userId,
        returnRequestCode,
        returnRequestModification
      }));
    });
  }
  /**
   * Returns the cancel return request loading flag
   */
  getCancelReturnRequestLoading() {
    return this.processStateStore.pipe(select(process_selectors.getProcessLoadingFactory(CANCEL_RETURN_PROCESS_ID)));
  }
  /**
   * Returns the cancel return request success flag
   */
  getCancelReturnRequestSuccess() {
    return this.processStateStore.pipe(select(process_selectors.getProcessSuccessFactory(CANCEL_RETURN_PROCESS_ID)));
  }
  /**
   * Resets the cancel return request process flags
   */
  resetCancelReturnRequestProcessState() {
    return this.store.dispatch(new ResetCancelReturnProcess());
  }
  static {
    this.ɵfac = function OrderReturnRequestService_Factory(t) {
      return new (t || _OrderReturnRequestService)(ɵɵinject(Store), ɵɵinject(Store), ɵɵinject(UserIdService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderReturnRequestService,
      factory: _OrderReturnRequestService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderReturnRequestService, [{
    type: Injectable
  }], () => [{
    type: Store
  }, {
    type: Store
  }, {
    type: UserIdService
  }], null);
})();
var OrderService = class _OrderService {
  constructor(activeCartFacade, userIdService, commandService, orderConnector, eventService) {
    this.activeCartFacade = activeCartFacade;
    this.userIdService = userIdService;
    this.commandService = commandService;
    this.orderConnector = orderConnector;
    this.eventService = eventService;
    this.placedOrder$ = new BehaviorSubject(void 0);
    this.placeOrderCommand = this.commandService.create((payload) => this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => this.orderConnector.placeOrder(userId, cartId, payload).pipe(tap((order) => {
      this.placedOrder$.next(order);
      this.eventService.dispatch({
        userId,
        cartId,
        /**
         * As we know the cart is not anonymous (precondition checked),
         * we can safely use the cartId, which is actually the cart.code.
         */
        cartCode: cartId,
        order
      }, OrderPlacedEvent);
    })))), {
      strategy: CommandStrategy.CancelPrevious
    });
    this.placePaymentAuthorizedOrderCommand = this.commandService.create((payload) => this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => this.orderConnector.placePaymentAuthorizedOrder(userId, cartId, payload).pipe(tap((order) => {
      this.setPlacedOrder(order);
      this.eventService.dispatch({
        order,
        userId,
        cartId,
        /**
         * As we know the cart is not anonymous (precondition checked),
         * we can safely use the cartId, which is actually the cart.code.
         */
        cartCode: cartId
      }, OrderPlacedEvent);
    })))), {
      strategy: CommandStrategy.CancelPrevious
    });
  }
  /**
   * Performs the necessary checkout preconditions.
   */
  checkoutPreconditions() {
    return combineLatest([this.userIdService.takeUserId(), this.activeCartFacade.takeActiveCartId(), this.activeCartFacade.isGuestCart()]).pipe(take(1), map(([userId, cartId, isGuestCart]) => {
      if (!userId || !cartId || userId === OCC_USER_ID_ANONYMOUS && !isGuestCart) {
        throw new Error("Checkout conditions not met");
      }
      return [userId, cartId];
    }));
  }
  placeOrder(termsChecked) {
    return this.placeOrderCommand.execute(termsChecked);
  }
  placePaymentAuthorizedOrder(termsChecked) {
    return this.placePaymentAuthorizedOrderCommand.execute(termsChecked);
  }
  getOrderDetails() {
    return this.placedOrder$.asObservable();
  }
  clearPlacedOrder() {
    this.placedOrder$.next(void 0);
  }
  setPlacedOrder(order) {
    this.placedOrder$.next(order);
  }
  getPickupEntries() {
    return this.getOrderDetails().pipe(map((order) => order?.entries?.filter((entry) => entry.deliveryPointOfService !== void 0) || []));
  }
  getDeliveryEntries() {
    return this.getOrderDetails().pipe(map((order) => order?.entries?.filter((entry) => entry.deliveryPointOfService === void 0) || []));
  }
  static {
    this.ɵfac = function OrderService_Factory(t) {
      return new (t || _OrderService)(ɵɵinject(ActiveCartFacade), ɵɵinject(UserIdService), ɵɵinject(CommandService), ɵɵinject(OrderConnector), ɵɵinject(EventService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderService,
      factory: _OrderService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderService, [{
    type: Injectable
  }], () => [{
    type: ActiveCartFacade
  }, {
    type: UserIdService
  }, {
    type: CommandService
  }, {
    type: OrderConnector
  }, {
    type: EventService
  }], null);
})();
var ReorderOrderService = class _ReorderOrderService {
  constructor(commandService, reorderOrderConnector, userIdService, activeCartFacade, multiCartFacade) {
    this.commandService = commandService;
    this.reorderOrderConnector = reorderOrderConnector;
    this.userIdService = userIdService;
    this.activeCartFacade = activeCartFacade;
    this.multiCartFacade = multiCartFacade;
    this.reorderCommand = this.commandService.create(({
      orderId
    }) => this.reorderPreconditions().pipe(switchMap((userId) => this.reorderOrderConnector.reorder(orderId, userId))), {
      strategy: CommandStrategy.CancelPrevious
    });
  }
  /**
   * Create cart from an existing order
   */
  reorder(orderId) {
    return this.reorderCommand.execute({
      orderId
    });
  }
  reorderPreconditions() {
    return combineLatest([this.userIdService.takeUserId(), this.activeCartFacade.getActiveCartId()]).pipe(take(1), map(([userId, cartId]) => {
      if (!userId) {
        throw new Error("Must be logged in to reorder");
      }
      if (cartId) {
        this.multiCartFacade.deleteCart(cartId, userId);
      }
      return userId;
    }));
  }
  static {
    this.ɵfac = function ReorderOrderService_Factory(t) {
      return new (t || _ReorderOrderService)(ɵɵinject(CommandService), ɵɵinject(ReorderOrderConnector), ɵɵinject(UserIdService), ɵɵinject(ActiveCartFacade), ɵɵinject(MultiCartFacade));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReorderOrderService,
      factory: _ReorderOrderService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReorderOrderService, [{
    type: Injectable
  }], () => [{
    type: CommandService
  }, {
    type: ReorderOrderConnector
  }, {
    type: UserIdService
  }, {
    type: ActiveCartFacade
  }, {
    type: MultiCartFacade
  }], null);
})();
var ReplenishmentOrderHistoryService = class _ReplenishmentOrderHistoryService {
  constructor(store, processStateStore, userIdService) {
    this.store = store;
    this.processStateStore = processStateStore;
    this.userIdService = userIdService;
  }
  /**
   * Returns replenishment order details for a given 'current' user
   *
   * @param replenishmentOrderCode a replenishment order code
   */
  loadReplenishmentOrderDetails(replenishmentOrderCode) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => {
        this.store.dispatch(new LoadReplenishmentOrderDetails({
          userId,
          replenishmentOrderCode
        }));
      },
      error: () => {
      }
    });
  }
  /**
   * Returns a replenishment order details
   */
  getReplenishmentOrderDetails() {
    return this.store.pipe(select(getReplenishmentOrderDetailsValue));
  }
  /**
   * Returns a replenishment order details loading flag
   */
  getReplenishmentOrderDetailsLoading() {
    return this.store.pipe(select(getReplenishmentOrderDetailsLoading));
  }
  /**
   * Returns a replenishment order details success flag
   */
  getReplenishmentOrderDetailsSuccess() {
    return this.store.pipe(select(getReplenishmentOrderDetailsSuccess));
  }
  /**
   * Returns a replenishment order details error flag
   */
  getReplenishmentOrderDetailsError() {
    return this.store.pipe(select(getReplenishmentOrderDetailsError));
  }
  /**
   * Clears the replenishment orders details state
   */
  clearReplenishmentOrderDetails() {
    this.store.dispatch(new ClearReplenishmentOrderDetails());
  }
  /**
   * Cancels a specific replenishment order for a given 'current' user
   *
   * @param replenishmentOrderCode a replenishment order code
   */
  cancelReplenishmentOrder(replenishmentOrderCode) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => {
        this.store.dispatch(new CancelReplenishmentOrder({
          userId,
          replenishmentOrderCode
        }));
      },
      error: () => {
      }
    });
  }
  /**
   * Returns the cancel replenishment order loading flag
   */
  getCancelReplenishmentOrderLoading() {
    return this.processStateStore.pipe(select(process_selectors.getProcessLoadingFactory(CANCEL_REPLENISHMENT_ORDER_PROCESS_ID)));
  }
  /**
   * Returns the cancel replenishment order success flag
   */
  getCancelReplenishmentOrderSuccess() {
    return this.processStateStore.pipe(select(process_selectors.getProcessSuccessFactory(CANCEL_REPLENISHMENT_ORDER_PROCESS_ID)));
  }
  /**
   * Returns the cancel replenishment order error flag
   */
  getCancelReplenishmentOrderError() {
    return this.processStateStore.pipe(select(process_selectors.getProcessErrorFactory(CANCEL_REPLENISHMENT_ORDER_PROCESS_ID)));
  }
  /**
   * Clears the cancel replenishment order processing state
   */
  clearCancelReplenishmentOrderProcessState() {
    this.store.dispatch(new ClearCancelReplenishmentOrder());
  }
  /**
   * Returns replenishment order history list
   */
  getReplenishmentOrderHistoryList(pageSize) {
    return this.store.pipe(select(getReplenishmentOrdersState), tap((replenishmentOrderListState) => {
      const attemptedLoad = replenishmentOrderListState.loading || replenishmentOrderListState.success || replenishmentOrderListState.error;
      if (!attemptedLoad) {
        this.loadReplenishmentOrderList(pageSize);
      }
    }), map((replenishmentOrderListState) => replenishmentOrderListState.value));
  }
  /**
   * Returns a loading flag for replenishment order history list
   */
  getReplenishmentOrderHistoryListLoading() {
    return this.store.pipe(select(getReplenishmentOrdersLoading));
  }
  /**
   * Returns a error flag for replenishment order history list
   */
  getReplenishmentOrderHistoryListError() {
    return this.store.pipe(select(getReplenishmentOrdersError));
  }
  /**
   * Returns a success flag for replenishment order history list
   */
  getReplenishmentOrderHistoryListSuccess() {
    return this.store.pipe(select(getReplenishmentOrdersSuccess));
  }
  /**
   * Retrieves a replenishment order list
   * @param pageSize page size
   * @param currentPage current page
   * @param sort sort
   */
  loadReplenishmentOrderList(pageSize, currentPage, sort) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => {
        this.store.dispatch(new LoadUserReplenishmentOrders({
          userId,
          pageSize,
          currentPage,
          sort
        }));
      },
      error: () => {
      }
    });
  }
  /**
   * Cleaning replenishment order list
   */
  clearReplenishmentOrderList() {
    this.store.dispatch(new ClearUserReplenishmentOrders());
  }
  static {
    this.ɵfac = function ReplenishmentOrderHistoryService_Factory(t) {
      return new (t || _ReplenishmentOrderHistoryService)(ɵɵinject(Store), ɵɵinject(Store), ɵɵinject(UserIdService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReplenishmentOrderHistoryService,
      factory: _ReplenishmentOrderHistoryService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderHistoryService, [{
    type: Injectable
  }], () => [{
    type: Store
  }, {
    type: Store
  }, {
    type: UserIdService
  }], null);
})();
var ScheduledReplenishmentOrderService = class _ScheduledReplenishmentOrderService {
  constructor(activeCartFacade, userIdService, commandService, scheduledReplenishmentOrderConnector, eventService, orderFacade) {
    this.activeCartFacade = activeCartFacade;
    this.userIdService = userIdService;
    this.commandService = commandService;
    this.scheduledReplenishmentOrderConnector = scheduledReplenishmentOrderConnector;
    this.eventService = eventService;
    this.orderFacade = orderFacade;
    this.scheduleReplenishmentOrderCommand = this.commandService.create(({
      form,
      termsChecked
    }) => this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => this.scheduledReplenishmentOrderConnector.scheduleReplenishmentOrder(cartId, form, termsChecked, userId).pipe(tap((replenishmentOrder) => {
      this.orderFacade.setPlacedOrder(replenishmentOrder);
      this.eventService.dispatch({
        userId,
        cartId,
        /**
         * As we know the cart is not anonymous (precondition checked),
         * we can safely use the cartId, which is actually the cart.code.
         */
        cartCode: cartId,
        replenishmentOrder
      }, ReplenishmentOrderScheduledEvent);
    })))), {
      strategy: CommandStrategy.CancelPrevious
    });
  }
  checkoutPreconditions() {
    return combineLatest([this.userIdService.takeUserId(), this.activeCartFacade.takeActiveCartId(), this.activeCartFacade.isGuestCart()]).pipe(take(1), map(([userId, cartId, isGuestCart]) => {
      if (!userId || !cartId || userId === OCC_USER_ID_ANONYMOUS && !isGuestCart) {
        throw new Error("Order conditions not met");
      }
      return [userId, cartId];
    }));
  }
  /**
   * Schedule a replenishment order
   */
  scheduleReplenishmentOrder(scheduleReplenishmentForm, termsChecked) {
    return this.scheduleReplenishmentOrderCommand.execute({
      termsChecked,
      form: scheduleReplenishmentForm
    });
  }
  static {
    this.ɵfac = function ScheduledReplenishmentOrderService_Factory(t) {
      return new (t || _ScheduledReplenishmentOrderService)(ɵɵinject(ActiveCartFacade), ɵɵinject(UserIdService), ɵɵinject(CommandService), ɵɵinject(ScheduledReplenishmentOrderConnector), ɵɵinject(EventService), ɵɵinject(OrderFacade));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ScheduledReplenishmentOrderService,
      factory: _ScheduledReplenishmentOrderService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ScheduledReplenishmentOrderService, [{
    type: Injectable
  }], () => [{
    type: ActiveCartFacade
  }, {
    type: UserIdService
  }, {
    type: CommandService
  }, {
    type: ScheduledReplenishmentOrderConnector
  }, {
    type: EventService
  }, {
    type: OrderFacade
  }], null);
})();
var ConsignmentTrackingByIdEffects = class _ConsignmentTrackingByIdEffects {
  constructor() {
    this.logger = inject(LoggerService);
    this.actions$ = inject(Actions);
    this.orderConnector = inject(OrderHistoryConnector);
    this.loadConsignmentTrackingById$ = createEffect(() => this.actions$.pipe(ofType(LOAD_CONSIGNMENT_TRACKING_BY_ID), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.getConsignmentTracking(payload.orderCode, payload.consignmentCode, payload.userId).pipe(map((tracking) => new LoadConsignmentTrackingByIdSuccess({
        orderCode: payload.orderCode,
        consignmentCode: payload.consignmentCode,
        consignmentTracking: tracking
      })), catchError((error) => of(new LoadConsignmentTrackingByIdFail({
        orderCode: payload.orderCode,
        consignmentCode: payload.consignmentCode,
        error: tryNormalizeHttpError(error, this.logger)
      }))));
    })));
  }
  static {
    this.ɵfac = function ConsignmentTrackingByIdEffects_Factory(t) {
      return new (t || _ConsignmentTrackingByIdEffects)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ConsignmentTrackingByIdEffects,
      factory: _ConsignmentTrackingByIdEffects.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ConsignmentTrackingByIdEffects, [{
    type: Injectable
  }], null, null);
})();
var ConsignmentTrackingEffects = class _ConsignmentTrackingEffects {
  constructor(actions$, orderConnector) {
    this.actions$ = actions$;
    this.orderConnector = orderConnector;
    this.logger = inject(LoggerService);
    this.loadConsignmentTracking$ = createEffect(() => this.actions$.pipe(ofType(LOAD_CONSIGNMENT_TRACKING), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.getConsignmentTracking(payload.orderCode, payload.consignmentCode, payload.userId).pipe(map((tracking) => new LoadConsignmentTrackingSuccess(tracking)), catchError((error) => of(new LoadConsignmentTrackingFail(tryNormalizeHttpError(error, this.logger)))));
    })));
  }
  static {
    this.ɵfac = function ConsignmentTrackingEffects_Factory(t) {
      return new (t || _ConsignmentTrackingEffects)(ɵɵinject(Actions), ɵɵinject(OrderHistoryConnector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ConsignmentTrackingEffects,
      factory: _ConsignmentTrackingEffects.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ConsignmentTrackingEffects, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: OrderHistoryConnector
  }], null);
})();
var OrderByIdEffect = class _OrderByIdEffect {
  constructor() {
    this.logger = inject(LoggerService);
    this.actions$ = inject(Actions);
    this.orderConnector = inject(OrderHistoryConnector);
    this.loadOrderById$ = createEffect(() => this.actions$.pipe(ofType(LOAD_ORDER_BY_ID), map((action) => action.payload), concatMap(({
      userId,
      code
    }) => {
      return this.orderConnector.get(userId, code).pipe(map((order) => {
        return new LoadOrderByIdSuccess(order);
      }), catchError((error) => {
        return of(new LoadOrderByIdFail({
          code,
          error: tryNormalizeHttpError(error, this.logger)
        }));
      }));
    })));
  }
  static {
    this.ɵfac = function OrderByIdEffect_Factory(t) {
      return new (t || _OrderByIdEffect)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderByIdEffect,
      factory: _OrderByIdEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderByIdEffect, [{
    type: Injectable
  }], null, null);
})();
var OrderDetailsEffect = class _OrderDetailsEffect {
  constructor(actions$, orderConnector, globalMessageService, userIdService, store) {
    this.actions$ = actions$;
    this.orderConnector = orderConnector;
    this.globalMessageService = globalMessageService;
    this.userIdService = userIdService;
    this.store = store;
    this.logger = inject(LoggerService);
    this.loadOrderDetails$ = createEffect(() => this.actions$.pipe(ofType(LOAD_ORDER_DETAILS), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.get(payload.userId, payload.orderCode).pipe(map((order) => {
        return new LoadOrderDetailsSuccess(order);
      }), catchError((error) => of(new LoadOrderDetailsFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.cancelOrder$ = createEffect(() => this.actions$.pipe(ofType(CANCEL_ORDER), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.cancel(payload.userId, payload.orderCode, payload.cancelRequestInput).pipe(map(() => new CancelOrderSuccess()), catchError((error) => {
        error.error?.errors.forEach((err) => this.globalMessageService.add(err.message, GlobalMessageType.MSG_TYPE_ERROR));
        return of(new CancelOrderFail(tryNormalizeHttpError(error, this.logger)));
      }));
    })));
    this.resetOrderDetails$ = createEffect(() => this.actions$.pipe(ofType(siteContextGroup_actions.LANGUAGE_CHANGE, siteContextGroup_actions.CURRENCY_CHANGE), withLatestFrom(this.userIdService.getUserId(), this.store.pipe(filter((store2) => !!store2.order?.orderDetail), map((state) => state.order.orderDetail.value?.code))), switchMap(([, userId, orderCode]) => {
      if (orderCode) {
        return this.orderConnector.get(userId, orderCode).pipe(map((order) => {
          return new LoadOrderDetailsSuccess(order);
        }), catchError((error) => of(new LoadOrderDetailsFail(tryNormalizeHttpError(error, this.logger)))));
      }
      return EMPTY;
    })));
  }
  static {
    this.ɵfac = function OrderDetailsEffect_Factory(t) {
      return new (t || _OrderDetailsEffect)(ɵɵinject(Actions), ɵɵinject(OrderHistoryConnector), ɵɵinject(GlobalMessageService), ɵɵinject(UserIdService), ɵɵinject(Store));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderDetailsEffect,
      factory: _OrderDetailsEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailsEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: OrderHistoryConnector
  }, {
    type: GlobalMessageService
  }, {
    type: UserIdService
  }, {
    type: Store
  }], null);
})();
var OrderReturnRequestEffect = class _OrderReturnRequestEffect {
  constructor(actions$, orderConnector) {
    this.actions$ = actions$;
    this.orderConnector = orderConnector;
    this.logger = inject(LoggerService);
    this.createReturnRequest$ = createEffect(() => this.actions$.pipe(ofType(CREATE_ORDER_RETURN_REQUEST), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.return(payload.userId, payload.returnRequestInput).pipe(map((returnRequest) => new CreateOrderReturnRequestSuccess(returnRequest)), catchError((error) => of(new CreateOrderReturnRequestFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.loadReturnRequest$ = createEffect(() => this.actions$.pipe(ofType(LOAD_ORDER_RETURN_REQUEST), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.getReturnRequestDetail(payload.userId, payload.returnRequestCode).pipe(map((returnRequest) => new LoadOrderReturnRequestSuccess(returnRequest)), catchError((error) => of(new LoadOrderReturnRequestFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.cancelReturnRequest$ = createEffect(() => this.actions$.pipe(ofType(CANCEL_ORDER_RETURN_REQUEST), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.cancelReturnRequest(payload.userId, payload.returnRequestCode, payload.returnRequestModification).pipe(map(() => new CancelOrderReturnRequestSuccess()), catchError((error) => of(new CancelOrderReturnRequestFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.loadReturnRequestList$ = createEffect(() => this.actions$.pipe(ofType(LOAD_ORDER_RETURN_REQUEST_LIST), map((action) => action.payload), switchMap((payload) => {
      return this.orderConnector.getReturnRequestList(payload.userId, payload.pageSize, payload.currentPage, payload.sort).pipe(map((returnRequestList) => new LoadOrderReturnRequestListSuccess(returnRequestList)), catchError((error) => of(new LoadOrderReturnRequestListFail(tryNormalizeHttpError(error, this.logger)))));
    })));
  }
  static {
    this.ɵfac = function OrderReturnRequestEffect_Factory(t) {
      return new (t || _OrderReturnRequestEffect)(ɵɵinject(Actions), ɵɵinject(OrderHistoryConnector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderReturnRequestEffect,
      factory: _OrderReturnRequestEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderReturnRequestEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: OrderHistoryConnector
  }], null);
})();
var OrdersEffect = class _OrdersEffect {
  constructor(actions$, orderConnector, replenishmentOrderConnector) {
    this.actions$ = actions$;
    this.orderConnector = orderConnector;
    this.replenishmentOrderConnector = replenishmentOrderConnector;
    this.logger = inject(LoggerService);
    this.loadUserOrders$ = createEffect(() => this.actions$.pipe(ofType(LOAD_USER_ORDERS), map((action) => action.payload), switchMap((payload) => {
      return (Boolean(payload.replenishmentOrderCode) ? this.replenishmentOrderConnector.loadReplenishmentDetailsHistory(payload.userId, payload.replenishmentOrderCode ?? "", payload.pageSize, payload.currentPage, payload.sort) : this.orderConnector.getHistory(payload.userId, payload.pageSize, payload.currentPage, payload.sort)).pipe(map((orders) => {
        return new LoadUserOrdersSuccess(orders);
      }), catchError((error) => of(new LoadUserOrdersFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.resetUserOrders$ = createEffect(() => this.actions$.pipe(ofType(siteContextGroup_actions.LANGUAGE_CHANGE), map(() => {
      return new ClearUserOrders();
    })));
  }
  static {
    this.ɵfac = function OrdersEffect_Factory(t) {
      return new (t || _OrdersEffect)(ɵɵinject(Actions), ɵɵinject(OrderHistoryConnector), ɵɵinject(ReplenishmentOrderHistoryConnector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrdersEffect,
      factory: _OrdersEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrdersEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: OrderHistoryConnector
  }, {
    type: ReplenishmentOrderHistoryConnector
  }], null);
})();
var ReplenishmentOrderDetailsEffect = class _ReplenishmentOrderDetailsEffect {
  constructor(actions$, replenishmentOrderConnector, globalMessageService) {
    this.actions$ = actions$;
    this.replenishmentOrderConnector = replenishmentOrderConnector;
    this.globalMessageService = globalMessageService;
    this.logger = inject(LoggerService);
    this.loadReplenishmentOrderDetails$ = createEffect(() => this.actions$.pipe(ofType(LOAD_REPLENISHMENT_ORDER_DETAILS), map((action) => action.payload), switchMap((payload) => {
      return this.replenishmentOrderConnector.load(payload.userId, payload.replenishmentOrderCode).pipe(map((replenishmentOrder) => {
        return new LoadReplenishmentOrderDetailsSuccess(replenishmentOrder);
      }), catchError((error) => of(new LoadReplenishmentOrderDetailsFail(tryNormalizeHttpError(error, this.logger)))));
    })));
    this.cancelReplenishmentOrder$ = createEffect(() => this.actions$.pipe(ofType(CANCEL_REPLENISHMENT_ORDER), map((action) => action.payload), switchMap((payload) => {
      return this.replenishmentOrderConnector.cancelReplenishmentOrder(payload.userId, payload.replenishmentOrderCode).pipe(map((replenishmentOrder) => new CancelReplenishmentOrderSuccess(replenishmentOrder)), catchError((error) => {
        error?.error?.errors.forEach((err) => this.globalMessageService.add(err.message, GlobalMessageType.MSG_TYPE_ERROR));
        return of(new CancelReplenishmentOrderFail(tryNormalizeHttpError(error, this.logger)));
      }));
    })));
  }
  static {
    this.ɵfac = function ReplenishmentOrderDetailsEffect_Factory(t) {
      return new (t || _ReplenishmentOrderDetailsEffect)(ɵɵinject(Actions), ɵɵinject(ReplenishmentOrderHistoryConnector), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReplenishmentOrderDetailsEffect,
      factory: _ReplenishmentOrderDetailsEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderDetailsEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: ReplenishmentOrderHistoryConnector
  }, {
    type: GlobalMessageService
  }], null);
})();
var ReplenishmentOrdersEffect = class _ReplenishmentOrdersEffect {
  constructor(actions$, replenishmentOrderConnector) {
    this.actions$ = actions$;
    this.replenishmentOrderConnector = replenishmentOrderConnector;
    this.logger = inject(LoggerService);
    this.loadUserReplenishmentOrders$ = createEffect(() => this.actions$.pipe(ofType(LOAD_USER_REPLENISHMENT_ORDERS), map((action) => action.payload), switchMap((payload) => {
      return this.replenishmentOrderConnector.loadHistory(payload.userId, payload.pageSize, payload.currentPage, payload.sort).pipe(map((orders) => {
        return new LoadUserReplenishmentOrdersSuccess(orders);
      }), catchError((error) => of(new LoadUserReplenishmentOrdersFail(tryNormalizeHttpError(error, this.logger)))));
    })));
  }
  static {
    this.ɵfac = function ReplenishmentOrdersEffect_Factory(t) {
      return new (t || _ReplenishmentOrdersEffect)(ɵɵinject(Actions), ɵɵinject(ReplenishmentOrderHistoryConnector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReplenishmentOrdersEffect,
      factory: _ReplenishmentOrdersEffect.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrdersEffect, [{
    type: Injectable
  }], () => [{
    type: Actions
  }, {
    type: ReplenishmentOrderHistoryConnector
  }], null);
})();
var effects = [OrdersEffect, OrderDetailsEffect, ConsignmentTrackingEffects, OrderReturnRequestEffect, ReplenishmentOrderDetailsEffect, ReplenishmentOrdersEffect, ConsignmentTrackingByIdEffects, OrderByIdEffect];
var initialStateOfConsignmentTrackingById = void 0;
function reducer$7(state = initialStateOfConsignmentTrackingById, action) {
  switch (action.type) {
    case LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS: {
      return action.payload.consignmentTracking ? action.payload.consignmentTracking : initialStateOfConsignmentTrackingById;
    }
    case LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL: {
      return initialStateOfConsignmentTrackingById;
    }
  }
  return state;
}
var initialStateOfOrderById = void 0;
function reducer$6(state = initialStateOfOrderById, action) {
  switch (action.type) {
    case LOAD_ORDER_BY_ID_SUCCESS: {
      return action.payload ? action.payload : initialStateOfOrderById;
    }
    case LOAD_ORDER_BY_ID_FAIL: {
      return initialStateOfOrderById;
    }
  }
  return state;
}
var initialState$5 = {
  tracking: {}
};
function reducer$5(state = initialState$5, action) {
  switch (action.type) {
    case LOAD_CONSIGNMENT_TRACKING_SUCCESS: {
      const tracking = action.payload;
      return {
        tracking
      };
    }
    case CLEAR_CONSIGNMENT_TRACKING: {
      return initialState$5;
    }
  }
  return state;
}
var initialState$4 = {};
function reducer$4(state = initialState$4, action) {
  switch (action.type) {
    case LOAD_ORDER_DETAILS_SUCCESS: {
      const order = action.payload;
      return order;
    }
  }
  return state;
}
var initialState$3 = {
  returnRequests: [],
  pagination: {},
  sorts: []
};
function reducer$3(state = initialState$3, action) {
  switch (action.type) {
    case LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS: {
      return action.payload ? action.payload : initialState$3;
    }
  }
  return state;
}
var initialState$2 = {
  orders: [],
  pagination: {},
  sorts: []
};
function reducer$2(state = initialState$2, action) {
  switch (action.type) {
    case LOAD_USER_ORDERS_SUCCESS: {
      return action.payload ? action.payload : initialState$2;
    }
    case LOAD_USER_ORDERS_FAIL: {
      return initialState$2;
    }
  }
  return state;
}
var initialState$1 = {};
function reducer$1(state = initialState$1, action) {
  switch (action.type) {
    case LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS:
    case CANCEL_REPLENISHMENT_ORDER_SUCCESS: {
      return action.payload ? action.payload : initialState$1;
    }
    default: {
      return state;
    }
  }
}
var initialState = {
  replenishmentOrders: [],
  pagination: {},
  sorts: []
};
function reducer(state = initialState, action) {
  switch (action.type) {
    case LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS: {
      return action.payload ? action.payload : initialState;
    }
    case CANCEL_REPLENISHMENT_ORDER_SUCCESS: {
      const cancelledReplenishmentOrder = action.payload;
      const userReplenishmentOrders = [...state.replenishmentOrders ?? []];
      const index = userReplenishmentOrders.findIndex((replenishmentOrder) => replenishmentOrder.replenishmentOrderCode === cancelledReplenishmentOrder.replenishmentOrderCode);
      if (index === -1) {
        return initialState;
      } else {
        userReplenishmentOrders[index] = __spreadValues({}, cancelledReplenishmentOrder);
      }
      return __spreadProps(__spreadValues({}, state), {
        replenishmentOrders: userReplenishmentOrders
      });
    }
  }
  return state;
}
function getReducers() {
  return {
    orders: utilsGroup.loaderReducer(ORDERS, reducer$2),
    orderDetail: utilsGroup.loaderReducer(ORDER_DETAILS, reducer$4),
    replenishmentOrders: utilsGroup.loaderReducer(REPLENISHMENT_ORDERS, reducer),
    orderReturn: utilsGroup.loaderReducer(RETURN_REQUEST_DETAILS),
    orderReturnList: utilsGroup.loaderReducer(RETURN_REQUESTS, reducer$3),
    consignmentTracking: reducer$5,
    replenishmentOrder: utilsGroup.loaderReducer(REPLENISHMENT_ORDER_DETAILS, reducer$1),
    orderById: utilsGroup.entityLoaderReducer(ORDER_BY_ID_ENTITIES, reducer$6),
    consignmentTrackingById: utilsGroup.entityLoaderReducer(CONSIGNMENT_TRACKING_BY_ID_ENTITIES, reducer$7)
  };
}
var reducerToken = new InjectionToken("OrderReducers");
var reducerProvider = {
  provide: reducerToken,
  useFactory: getReducers
};
var MyAccountV2OrderHistoryService = class _MyAccountV2OrderHistoryService {
  constructor() {
    this.orderReturnRequestService = inject(OrderReturnRequestService);
    this.store = inject(Store);
    this.userIdService = inject(UserIdService);
    this.orderHistoryService = inject(OrderHistoryService);
  }
  clearOrderList() {
    this.orderHistoryService.clearOrderList();
  }
  getOrderDetailsWithTracking(orderCode) {
    return this.getOrderDetailsV2(orderCode).pipe(switchMap((order) => {
      const orderView = __spreadValues({}, order);
      orderView.consignments = [];
      const requests = (order?.consignments ?? []).map((consignment) => {
        const consignmentView = __spreadValues({}, consignment);
        if (consignment.code && consignment.trackingID) {
          return this.getConsignmentTracking(order?.code ?? "", consignment.code).pipe(map((trackingInfo) => {
            consignmentView.consignmentTracking = trackingInfo;
            orderView.consignments?.push(consignmentView);
            return orderView;
          }));
        } else {
          orderView.consignments?.push(consignmentView);
          return of(orderView);
        }
      });
      if (requests === void 0 || requests.length < 1) {
        return of(orderView);
      }
      return combineLatest(requests).pipe(switchMap((orders) => {
        if (orders !== void 0) {
          return of(orders[0]);
        } else {
          return of(order);
        }
      }));
    }));
  }
  getOrderHistoryListWithDetails(pageSize) {
    const orderListView = {};
    return this.orderHistoryService.getOrderHistoryList(pageSize).pipe(switchMap((orderList) => {
      orderListView.pagination = orderList?.pagination;
      orderListView.sorts = orderList?.sorts;
      orderListView.orders = [];
      const requests = (orderList?.orders ?? []).map((order) => {
        const orderView = __spreadValues({}, order);
        return this.getOrderDetailsWithTracking(order?.code ?? "").pipe(map((orderDetail) => {
          orderView.returnable = orderDetail?.returnable;
          orderView.totalItems = orderDetail?.totalItems;
          orderView.entries = orderDetail?.entries;
          orderView.consignments = orderDetail?.consignments;
          orderView.unconsignedEntries = orderDetail?.unconsignedEntries;
          orderView.returnRequests = [];
          orderListView.orders?.push(orderView);
          return orderListView;
        }));
      });
      if (requests.length === 0) {
        requests.push(of(orderListView));
      }
      return combineLatest(requests);
    }), map((requests) => {
      if (requests !== void 0) {
        return requests[0];
      } else {
        return {};
      }
    }));
  }
  getOrderHistoryList(pageSize) {
    const orderHistoryListRequest = this.getOrderHistoryListWithDetails(pageSize);
    const returnRequestListRequest = this.orderReturnRequestService.getOrderReturnRequestList();
    return combineLatest([orderHistoryListRequest, returnRequestListRequest]).pipe(switchMap((responses) => {
      const returnRequests = responses?.[1]?.returnRequests;
      const orderHistory = responses?.[0];
      if (returnRequests && orderHistory?.orders) {
        if (orderHistory.pagination?.totalResults === 0) {
          return of(orderHistory);
        }
        return orderHistory.orders.map((order) => {
          const returnItems = returnRequests?.filter((returnItem) => returnItem.order?.code === order.code);
          if (returnItems) {
            order.returnRequests = returnItems;
          }
          return orderHistory;
        });
      } else {
        return of(orderHistory);
      }
    }));
  }
  getOrderDetailsValue(code) {
    return this.store.select(getOrderById(code));
  }
  getOrderDetailsState(code) {
    return this.store.select(getOrderByIdEntity(code));
  }
  loadOrderDetails(code) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => this.store.dispatch(new LoadOrderById({
        userId,
        code
      }))
    });
  }
  //TODO: CXINT-2896: Remove this method in next major release
  /**
   * @deprecated since 2211.20. Use getOrderDetailsV2 instead
   */
  getOrderDetails(code) {
    const loading$ = this.getOrderDetailsState(code).pipe(auditTime(0), tap((state) => {
      if (!(state.loading || state.success || state.error)) {
        this.loadOrderDetails(code);
      }
    }));
    return using(() => loading$.subscribe(), () => this.getOrderDetailsValue(code));
  }
  //TODO: CXINT-2896: Rename this method to `getOrderDetails` in next major release
  getOrderDetailsV2(code) {
    const loading$ = this.getOrderDetailsState(code).pipe(auditTime(0), tap((state) => {
      if (!(state.loading || state.success || state.error)) {
        this.loadOrderDetails(code);
      }
    }));
    return loading$.pipe(filter((state) => (state.success || state.error) ?? false), map((state) => {
      return state.value;
    }));
  }
  getConsignmentTrackingValue(orderCode, consignmentCode) {
    return this.store.select(getConsignmentTrackingById(orderCode, consignmentCode)).pipe(filter((tracking) => Boolean(tracking)));
  }
  getConsignmentTrackingState(orderCode, consignmentCode) {
    return this.store.select(getConsignmentTrackingByIdEntity(orderCode, consignmentCode));
  }
  loadConsignmentTracking(orderCode, consignmentCode) {
    this.userIdService.takeUserId(true).subscribe({
      next: (userId) => this.store.dispatch(new LoadConsignmentTrackingById({
        orderCode,
        consignmentCode,
        userId
      }))
    });
  }
  getConsignmentTracking(orderCode, consignmentCode) {
    const loading$ = this.getConsignmentTrackingState(orderCode, consignmentCode).pipe(auditTime(0), tap((state) => {
      if (!(state.loading || state.success || state.error)) {
        this.loadConsignmentTracking(orderCode, consignmentCode);
      }
    }));
    return using(() => loading$.subscribe(), () => this.getConsignmentTrackingValue(orderCode, consignmentCode));
  }
  static {
    this.ɵfac = function MyAccountV2OrderHistoryService_Factory(t) {
      return new (t || _MyAccountV2OrderHistoryService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _MyAccountV2OrderHistoryService,
      factory: _MyAccountV2OrderHistoryService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrderHistoryService, [{
    type: Injectable
  }], null, null);
})();
var facadeProviders = [OrderReturnRequestService, {
  provide: OrderReturnRequestFacade,
  useExisting: OrderReturnRequestService
}, MyAccountV2OrderHistoryService, OrderHistoryService, {
  provide: OrderHistoryFacade,
  useExisting: OrderHistoryService
}, ReplenishmentOrderHistoryService, {
  provide: ReplenishmentOrderHistoryFacade,
  useExisting: ReplenishmentOrderHistoryService
}, ScheduledReplenishmentOrderService, {
  provide: ScheduledReplenishmentOrderFacade,
  useExisting: ScheduledReplenishmentOrderService
}, OrderService, {
  provide: OrderFacade,
  useExisting: OrderService
}, ReorderOrderService, {
  provide: ReorderOrderFacade,
  useExisting: ReorderOrderService
}];
var OrderStoreModule = class _OrderStoreModule {
  static {
    this.ɵfac = function OrderStoreModule_Factory(t) {
      return new (t || _OrderStoreModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderStoreModule,
      imports: [EffectsFeatureModule, StoreFeatureModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [reducerProvider],
      imports: [EffectsModule.forFeature(effects), StoreModule.forFeature(ORDER_FEATURE, reducerToken)]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderStoreModule, [{
    type: NgModule,
    args: [{
      imports: [EffectsModule.forFeature(effects), StoreModule.forFeature(ORDER_FEATURE, reducerToken)],
      providers: [reducerProvider]
    }]
  }], null, null);
})();
var OrderCoreModule = class _OrderCoreModule {
  static {
    this.ɵfac = function OrderCoreModule_Factory(t) {
      return new (t || _OrderCoreModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderCoreModule,
      imports: [OrderStoreModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [...facadeProviders, OrderHistoryConnector, ReplenishmentOrderHistoryConnector, OrderConnector, ScheduledReplenishmentOrderConnector, ReorderOrderConnector],
      imports: [OrderStoreModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderCoreModule, [{
    type: NgModule,
    args: [{
      imports: [OrderStoreModule],
      providers: [...facadeProviders, OrderHistoryConnector, ReplenishmentOrderHistoryConnector, OrderConnector, ScheduledReplenishmentOrderConnector, ReorderOrderConnector]
    }]
  }], null, null);
})();

// node_modules/@spartacus/pdf-invoices/fesm2022/spartacus-pdf-invoices-root.mjs
var PDF_INVOICES_FEATURE = "pdfInvoices";
var PDF_INVOICES_CORE_FEATURE = "pdfInvoicesCore";
function pdfInvoicesFacadeFactory() {
  return facadeFactory({
    facade: PDFInvoicesFacade,
    feature: PDF_INVOICES_FEATURE,
    methods: ["getInvoicesForOrder", "getInvoicePDF"]
  });
}
var PDFInvoicesFacade = class _PDFInvoicesFacade {
  static {
    this.ɵfac = function PDFInvoicesFacade_Factory(t) {
      return new (t || _PDFInvoicesFacade)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _PDFInvoicesFacade,
      factory: () => pdfInvoicesFacadeFactory(),
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PDFInvoicesFacade, [{
    type: Injectable,
    args: [{
      providedIn: "root",
      useFactory: pdfInvoicesFacadeFactory
    }]
  }], null, null);
})();
var InvoicesFields;
(function(InvoicesFields2) {
  InvoicesFields2["BASIC"] = "BASIC";
  InvoicesFields2["DEFAULT"] = "DEFAULT";
  InvoicesFields2["FULL"] = "FULL";
})(InvoicesFields || (InvoicesFields = {}));
function defaultRequestedDeliveryDateComponentsConfig() {
  const config = {
    featureModules: {
      [PDF_INVOICES_FEATURE]: {
        cmsComponents: ["AccountOrderDetailsPDFInvoicesComponent"]
      },
      // by default core is bundled together with components
      [PDF_INVOICES_CORE_FEATURE]: PDF_INVOICES_FEATURE
    }
  };
  return config;
}
var PDFInvoicesRootModule = class _PDFInvoicesRootModule {
  static {
    this.ɵfac = function PDFInvoicesRootModule_Factory(t) {
      return new (t || _PDFInvoicesRootModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _PDFInvoicesRootModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfigFactory(defaultRequestedDeliveryDateComponentsConfig)]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PDFInvoicesRootModule, [{
    type: NgModule,
    args: [{
      providers: [provideDefaultConfigFactory(defaultRequestedDeliveryDateComponentsConfig)]
    }]
  }], null, null);
})();

// node_modules/@spartacus/pdf-invoices/fesm2022/spartacus-pdf-invoices-components.mjs
var _c0 = (a0) => ({
  id: a0
});
function InvoicesListComponent_ng_container_0_ng_container_1_div_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 11)(1, "cx-pagination", 12);
    ɵɵlistener("viewPageEvent", function InvoicesListComponent_ng_container_0_ng_container_1_div_15_Template_cx_pagination_viewPageEvent_1_listener($event) {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("pagination", ctx_r1.pagination);
  }
}
function InvoicesListComponent_ng_container_0_ng_container_1_thead_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead", 13)(1, "th", 14);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "th", 14);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(7, "th", 14);
    ɵɵtext(8);
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(10, "th", 14);
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(13, "th", 14);
    ɵɵelement(14, "cx-icon", 15);
    ɵɵpipe(15, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 6, "pdfInvoices.invoicesTable.invoiceId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 8, "pdfInvoices.invoicesTable.createdAt"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 10, "pdfInvoices.invoicesTable.netAmount"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(12, 12, "pdfInvoices.invoicesTable.totalAmount"), " ");
    ɵɵadvance(3);
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(15, 14, "pdfInvoices.invoicesTable.attachment"));
    ɵɵproperty("type", ctx_r1.ICON_TYPE.DOWNLOAD);
  }
}
function InvoicesListComponent_ng_container_0_ng_container_1_thead_19_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead", 13)(1, "tr")(2, "th", 14);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "th", 14);
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(8, "th", 14);
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(11, "th", 14);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(14, "th", 14);
    ɵɵelement(15, "cx-icon", 15);
    ɵɵpipe(16, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 6, "pdfInvoices.invoicesTable.invoiceId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 8, "pdfInvoices.invoicesTable.createdAt"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 10, "pdfInvoices.invoicesTable.netAmount"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 12, "pdfInvoices.invoicesTable.totalAmount"), " ");
    ɵɵadvance(3);
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(16, 14, "pdfInvoices.invoicesTable.attachment"));
    ɵɵproperty("type", ctx_r1.ICON_TYPE.DOWNLOAD);
  }
}
function InvoicesListComponent_ng_container_0_ng_container_1_tr_21_button_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 24);
    ɵɵpipe(1, "cxTranslate");
    ɵɵlistener("click", function InvoicesListComponent_ng_container_0_ng_container_1_tr_21_button_31_Template_button_click_0_listener() {
      ɵɵrestoreView(_r4);
      const invoice_r5 = ɵɵnextContext().$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.downloadPDFInvoice(invoice_r5.invoiceId, invoice_r5.externalSystemId));
    });
    ɵɵelement(2, "cx-icon", 15);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelement(4, "span", 25);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const invoice_r5 = ɵɵnextContext().$implicit;
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵattribute("aria-label", ɵɵpipeBind2(1, 4, "pdfInvoices.invoicesTable.attachmentDescription", ɵɵpureFunction1(11, _c0, invoice_r5.invoiceId)));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(3, 7, "pdfInvoices.invoicesTable.download"));
    ɵɵproperty("type", ctx_r1.ICON_TYPE.FILE);
    ɵɵadvance(2);
    ɵɵproperty("innerText", ɵɵpipeBind1(5, 9, "pdfInvoices.invoicesTable.download"));
  }
}
function InvoicesListComponent_ng_container_0_ng_container_1_tr_21_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tr", 16)(1, "td", 17)(2, "div", 18);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "div", 19);
    ɵɵtext(6);
    ɵɵelementEnd()();
    ɵɵelementStart(7, "td", 20)(8, "div", 18);
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(11, "div", 19);
    ɵɵtext(12);
    ɵɵpipe(13, "cxDate");
    ɵɵelementEnd()();
    ɵɵelementStart(14, "td", 21)(15, "div", 18);
    ɵɵtext(16);
    ɵɵpipe(17, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(18, "div", 19);
    ɵɵtext(19);
    ɵɵelementEnd()();
    ɵɵelementStart(20, "td", 21)(21, "div", 18);
    ɵɵtext(22);
    ɵɵpipe(23, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(24, "div", 19);
    ɵɵtext(25);
    ɵɵelementEnd()();
    ɵɵelementStart(26, "td", 22)(27, "div", 18);
    ɵɵtext(28);
    ɵɵpipe(29, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(30, "div", 19);
    ɵɵtemplate(31, InvoicesListComponent_ng_container_0_ng_container_1_tr_21_button_31_Template, 6, 13, "button", 23);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const invoice_r5 = ctx.$implicit;
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 10, "pdfInvoices.invoicesTable.invoiceId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", invoice_r5.invoiceId, " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 12, "pdfInvoices.invoicesTable.createdAt"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(13, 14, invoice_r5.createdAt, "longDate"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(17, 17, "pdfInvoices.invoicesTable.netAmount"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", (invoice_r5.netAmount == null ? null : invoice_r5.netAmount.formattedValue) ? invoice_r5.netAmount == null ? null : invoice_r5.netAmount.formattedValue : (invoice_r5.netAmount == null ? null : invoice_r5.netAmount.currencyIso) + " " + (invoice_r5.netAmount == null ? null : invoice_r5.netAmount.value), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(23, 19, "pdfInvoices.invoicesTable.totalAmount"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", (invoice_r5.totalAmount == null ? null : invoice_r5.totalAmount.formattedValue) ? invoice_r5.totalAmount == null ? null : invoice_r5.totalAmount.formattedValue : (invoice_r5.totalAmount == null ? null : invoice_r5.totalAmount.currencyIso) + " " + (invoice_r5.totalAmount == null ? null : invoice_r5.totalAmount.value), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(29, 21, "pdfInvoices.invoicesTable.attachment"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", invoice_r5.invoiceId);
  }
}
function InvoicesListComponent_ng_container_0_ng_container_1_div_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 11)(1, "cx-pagination", 12);
    ɵɵlistener("viewPageEvent", function InvoicesListComponent_ng_container_0_ng_container_1_div_23_Template_cx_pagination_viewPageEvent_1_listener($event) {
      ɵɵrestoreView(_r6);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("pagination", ctx_r1.pagination);
  }
}
function InvoicesListComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div")(2, "div", 1)(3, "h2");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(6, "div", 2)(7, "div", 3)(8, "label", 4)(9, "span");
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(12, "cx-sorting", 5);
    ɵɵpipe(13, "cxTranslate");
    ɵɵpipe(14, "cxTranslate");
    ɵɵlistener("sortListEvent", function InvoicesListComponent_ng_container_0_ng_container_1_Template_cx_sorting_sortListEvent_12_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.sortChange($event));
    });
    ɵɵelementEnd()();
    ɵɵtemplate(15, InvoicesListComponent_ng_container_0_ng_container_1_div_15_Template, 2, 1, "div", 6);
    ɵɵelementEnd();
    ɵɵelementStart(16, "table", 7);
    ɵɵpipe(17, "cxTranslate");
    ɵɵtemplate(18, InvoicesListComponent_ng_container_0_ng_container_1_thead_18_Template, 16, 16, "thead", 8)(19, InvoicesListComponent_ng_container_0_ng_container_1_thead_19_Template, 17, 16, "thead", 8);
    ɵɵelementStart(20, "tbody");
    ɵɵtemplate(21, InvoicesListComponent_ng_container_0_ng_container_1_tr_21_Template, 32, 23, "tr", 9);
    ɵɵelementEnd()();
    ɵɵelementStart(22, "div", 10);
    ɵɵtemplate(23, InvoicesListComponent_ng_container_0_ng_container_1_div_23_Template, 2, 1, "div", 6);
    ɵɵelementEnd()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const invoicesList_r7 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 12, "pdfInvoices.invoicesTable.header"), " ");
    ɵɵadvance(6);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 14, "pdfInvoices.sortBy"), " ");
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(13, 16, "pdfInvoices.sortBy"));
    ɵɵproperty("sortOptions", ctx_r1.sortOptions)("selectedOption", ctx_r1.sort)("ariaLabel", ɵɵpipeBind1(14, 18, "pdfInvoices.sortInvoices"));
    ɵɵadvance(3);
    ɵɵproperty("ngIf", invoicesList_r7.pagination && invoicesList_r7.pagination.totalPages && invoicesList_r7.pagination.totalPages > 1);
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(17, 20, "pdfInvoices.invoicesTable.label"));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "!a11yTableHeaderReadout");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yTableHeaderReadout");
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", invoicesList_r7.invoices);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", invoicesList_r7.pagination && invoicesList_r7.pagination.totalPages && invoicesList_r7.pagination.totalPages > 1);
  }
}
function InvoicesListComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, InvoicesListComponent_ng_container_0_ng_container_1_Template, 24, 22, "ng-container", 0);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const invoicesList_r7 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", invoicesList_r7.pagination && invoicesList_r7.pagination.totalCount && invoicesList_r7.pagination.totalCount > 0);
  }
}
var InvoicesListComponent = class _InvoicesListComponent {
  constructor(pdfInvoicesFacade, translationService, downloadService, languageService, globalMessageService) {
    this.pdfInvoicesFacade = pdfInvoicesFacade;
    this.translationService = translationService;
    this.downloadService = downloadService;
    this.languageService = languageService;
    this.globalMessageService = globalMessageService;
    this.ICON_TYPE = ICON_TYPE;
    this.featureConfig = inject(FeatureConfigService);
    this.PAGE_SIZE = 5;
    this.sort = "byInvoiceIdAsc";
    this.sortMapping = {
      byCreatedAtAsc: this.featureConfig.isEnabled("pdfInvoicesSortByInvoiceDate") ? "createdAt:asc" : "invoiceDate:asc",
      byCreatedAtDesc: this.featureConfig.isEnabled("pdfInvoicesSortByInvoiceDate") ? "createdAt:desc" : "invoiceDate:desc",
      byInvoiceIdAsc: "invoiceId:asc",
      byInvoiceIdDesc: "invoiceId:desc",
      byNetAmountAsc: "netAmount:asc",
      byNetAmountDesc: "netAmount:desc",
      byTotalAmountAsc: "totalAmount:asc",
      byTotalAmountDesc: "totalAmount:desc"
    };
    this._initQueryParams = {
      currentPage: 0,
      pageSize: this.PAGE_SIZE,
      fields: InvoicesFields.FULL,
      sort: this.sortMapping[this.sort]
      //backend supports sort codes like invoiceId:asc
    };
    this.queryParams$ = new BehaviorSubject(this._initQueryParams);
    this.invoicesList$ = this.queryParams$.pipe(switchMap((param) => this.pdfInvoicesFacade.getInvoicesForOrder(param)), tap((invoicesList) => this.pagination = {
      currentPage: invoicesList.pagination?.page,
      pageSize: invoicesList.pagination?.count,
      totalPages: invoicesList.pagination?.totalPages,
      totalResults: invoicesList.pagination?.totalCount,
      sort: this.sortMapping[this.sort]
    }), catchError((error) => {
      if (error && this.getNotEnabledError(error)?.length) {
        this.globalMessageService.add({
          key: "pdfInvoices.featureNotEnabled"
        }, GlobalMessageType.MSG_TYPE_ERROR);
      }
      return EMPTY;
    }));
    this.subscription = new Subscription();
  }
  ngOnInit() {
    this.subscription.add(this.languageService.getActive().pipe(skip(1)).subscribe(() => this.updateQueryParams({
      fields: InvoicesFields.FULL
    })));
    this.getSortOptions();
  }
  updateQueryParams(partialParams) {
    Object.keys(partialParams).forEach((key) => this._initQueryParams[key] = partialParams[key]);
    if (!partialParams.fields) {
      this._initQueryParams.fields = InvoicesFields.DEFAULT;
    }
    this.queryParams$.next(this._initQueryParams);
  }
  pageChange(currentPage) {
    this.updateQueryParams({
      currentPage
    });
  }
  sortChange(sortCode) {
    this.sort = sortCode;
    this.updateQueryParams({
      sort: this.sortMapping[sortCode],
      currentPage: 0
    });
  }
  downloadPDFInvoice(invoiceId, externalSystemId) {
    this.pdfInvoicesFacade.getInvoicePDF(invoiceId, externalSystemId).pipe(take(1)).subscribe({
      next: (data) => {
        const file = new Blob([data], {
          type: data.type
        });
        const url = URL.createObjectURL(file);
        this.downloadService.download(url, `${invoiceId}.pdf`);
      }
    });
  }
  getSortOptions() {
    this.sortOptions = [];
    Object.keys(this.sortMapping).forEach((sortKey) => this.sortOptions.push({
      code: sortKey,
      selected: false
    }));
    const translations = this.sortOptions.map((sort) => this.translationService.translate(`pdfInvoices.sorts.${sort.code}`));
    combineLatest(translations).pipe(take(1)).subscribe((translated) => this.sortOptions.forEach((sort, index) => sort.name = translated[index]));
  }
  getNotEnabledError(response) {
    return response?.details ? response.details.filter((error) => error?.type === "UnknownResourceError") : [];
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static {
    this.ɵfac = function InvoicesListComponent_Factory(t) {
      return new (t || _InvoicesListComponent)(ɵɵdirectiveInject(PDFInvoicesFacade), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(FileDownloadService), ɵɵdirectiveInject(LanguageService), ɵɵdirectiveInject(GlobalMessageService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _InvoicesListComponent,
      selectors: [["cx-invoices-list"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "cx-invoices-list-header"], [1, "cx-invoices-list-body"], [1, "cx-invoices-list-sort", "top"], [1, "cx-invoices-list-form-group", "form-group"], ["ariaControls", "cx-invoices-list-table", 3, "sortListEvent", "sortOptions", "selectedOption", "placeholder", "ariaLabel"], ["class", "cx-invoices-list-pagination", 4, "ngIf"], ["id", "cx-invoices-list-table", 1, "table", "cx-invoices-list-table"], ["class", "cx-invoices-list-thead-mobile", 4, "cxFeature"], ["class", "cx-invoices-list-row", 4, "ngFor", "ngForOf"], [1, "cx-invoices-list-sort", "bottom"], [1, "cx-invoices-list-pagination"], [3, "viewPageEvent", "pagination"], [1, "cx-invoices-list-thead-mobile"], ["scope", "col"], [1, "cx-invoices-list-attachment-icon", 3, "type", "title"], [1, "cx-invoices-list-row"], [1, "cx-invoices-list-code"], [1, "cx-invoices-list-label"], [1, "cx-invoices-list-value"], [1, "cx-invoices-list-date"], [1, "cx-invoices-list-monetary"], [1, "cx-invoices-list-attachment"], ["class", "cx-invoices-list-attachment-btn", 3, "click", 4, "ngIf"], [1, "cx-invoices-list-attachment-btn", 3, "click"], [1, "cx-invoices-list-attachment-text", 3, "innerText"]],
      template: function InvoicesListComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, InvoicesListComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.invoicesList$));
        }
      },
      dependencies: [NgForOf, NgIf, SortingComponent, PaginationComponent, IconComponent, FeatureDirective, AsyncPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InvoicesListComponent, [{
    type: Component,
    args: [{
      selector: "cx-invoices-list",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="invoicesList$ | async as invoicesList">
  <ng-container
    *ngIf="
      invoicesList.pagination &&
      invoicesList.pagination.totalCount &&
      invoicesList.pagination.totalCount > 0
    "
  >
    <div>
      <!-- HEADER -->
      <div class="cx-invoices-list-header">
        <h2>
          {{ 'pdfInvoices.invoicesTable.header' | cxTranslate }}
        </h2>
      </div>

      <!-- BODY -->
      <div class="cx-invoices-list-body">
        <div class="cx-invoices-list-sort top">
          <label class="cx-invoices-list-form-group form-group">
            <span>
              {{ 'pdfInvoices.sortBy' | cxTranslate }}
            </span>
            <cx-sorting
              [sortOptions]="sortOptions"
              (sortListEvent)="sortChange($event)"
              [selectedOption]="sort"
              placeholder="{{ 'pdfInvoices.sortBy' | cxTranslate }}"
              [ariaLabel]="'pdfInvoices.sortInvoices' | cxTranslate"
              ariaControls="cx-invoices-list-table"
            ></cx-sorting>
          </label>
          <div
            class="cx-invoices-list-pagination"
            *ngIf="
              invoicesList.pagination &&
              invoicesList.pagination.totalPages &&
              invoicesList.pagination.totalPages > 1
            "
          >
            <cx-pagination
              [pagination]="pagination"
              (viewPageEvent)="pageChange($event)"
            ></cx-pagination>
          </div>
        </div>

        <!-- TABLE -->
        <table
          id="cx-invoices-list-table"
          class="table cx-invoices-list-table"
          attr.aria-label="{{
            'pdfInvoices.invoicesTable.label' | cxTranslate
          }}"
        >
          <thead
            *cxFeature="'!a11yTableHeaderReadout'"
            class="cx-invoices-list-thead-mobile"
          >
            <th scope="col">
              {{ 'pdfInvoices.invoicesTable.invoiceId' | cxTranslate }}
            </th>
            <th scope="col">
              {{ 'pdfInvoices.invoicesTable.createdAt' | cxTranslate }}
            </th>
            <th scope="col">
              {{ 'pdfInvoices.invoicesTable.netAmount' | cxTranslate }}
            </th>
            <th scope="col">
              {{ 'pdfInvoices.invoicesTable.totalAmount' | cxTranslate }}
            </th>
            <th scope="col">
              <cx-icon
                [type]="ICON_TYPE.DOWNLOAD"
                class="cx-invoices-list-attachment-icon"
                title="{{
                  'pdfInvoices.invoicesTable.attachment' | cxTranslate
                }}"
              ></cx-icon>
            </th>
          </thead>
          <thead
            *cxFeature="'a11yTableHeaderReadout'"
            class="cx-invoices-list-thead-mobile"
          >
            <tr>
              <th scope="col">
                {{ 'pdfInvoices.invoicesTable.invoiceId' | cxTranslate }}
              </th>
              <th scope="col">
                {{ 'pdfInvoices.invoicesTable.createdAt' | cxTranslate }}
              </th>
              <th scope="col">
                {{ 'pdfInvoices.invoicesTable.netAmount' | cxTranslate }}
              </th>
              <th scope="col">
                {{ 'pdfInvoices.invoicesTable.totalAmount' | cxTranslate }}
              </th>
              <th scope="col">
                <cx-icon
                  [type]="ICON_TYPE.DOWNLOAD"
                  class="cx-invoices-list-attachment-icon"
                  title="{{
                    'pdfInvoices.invoicesTable.attachment' | cxTranslate
                  }}"
                ></cx-icon>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              *ngFor="let invoice of invoicesList.invoices"
              class="cx-invoices-list-row"
            >
              <td class="cx-invoices-list-code">
                <div class="cx-invoices-list-label">
                  {{ 'pdfInvoices.invoicesTable.invoiceId' | cxTranslate }}
                </div>
                <div class="cx-invoices-list-value">
                  {{ invoice.invoiceId }}
                </div>
              </td>
              <td class="cx-invoices-list-date">
                <div class="cx-invoices-list-label">
                  {{ 'pdfInvoices.invoicesTable.createdAt' | cxTranslate }}
                </div>
                <div class="cx-invoices-list-value">
                  {{ invoice.createdAt | cxDate: 'longDate' }}
                </div>
              </td>
              <td class="cx-invoices-list-monetary">
                <div class="cx-invoices-list-label">
                  {{ 'pdfInvoices.invoicesTable.netAmount' | cxTranslate }}
                </div>
                <div class="cx-invoices-list-value">
                  {{
                    invoice.netAmount?.formattedValue
                      ? invoice.netAmount?.formattedValue
                      : invoice.netAmount?.currencyIso +
                        '&nbsp;' +
                        invoice.netAmount?.value
                  }}
                </div>
              </td>
              <td class="cx-invoices-list-monetary">
                <div class="cx-invoices-list-label">
                  {{ 'pdfInvoices.invoicesTable.totalAmount' | cxTranslate }}
                </div>
                <div class="cx-invoices-list-value">
                  {{
                    invoice.totalAmount?.formattedValue
                      ? invoice.totalAmount?.formattedValue
                      : invoice.totalAmount?.currencyIso +
                        '&nbsp;' +
                        invoice.totalAmount?.value
                  }}
                </div>
              </td>
              <td class="cx-invoices-list-attachment">
                <div class="cx-invoices-list-label">
                  {{ 'pdfInvoices.invoicesTable.attachment' | cxTranslate }}
                </div>
                <div class="cx-invoices-list-value">
                  <button
                    *ngIf="invoice.invoiceId"
                    class="cx-invoices-list-attachment-btn"
                    (click)="
                      downloadPDFInvoice(
                        invoice.invoiceId,
                        invoice.externalSystemId
                      )
                    "
                    attr.aria-label="{{
                      'pdfInvoices.invoicesTable.attachmentDescription'
                        | cxTranslate
                          : {
                              id: invoice.invoiceId,
                            }
                    }}"
                  >
                    <cx-icon
                      [type]="ICON_TYPE.FILE"
                      class="cx-invoices-list-attachment-icon"
                      title="{{
                        'pdfInvoices.invoicesTable.download' | cxTranslate
                      }}"
                    >
                    </cx-icon>
                    <span
                      class="cx-invoices-list-attachment-text"
                      [innerText]="
                        'pdfInvoices.invoicesTable.download' | cxTranslate
                      "
                    >
                    </span>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Select Form and Pagination Bottom -->
        <div class="cx-invoices-list-sort bottom">
          <div
            class="cx-invoices-list-pagination"
            *ngIf="
              invoicesList.pagination &&
              invoicesList.pagination.totalPages &&
              invoicesList.pagination.totalPages > 1
            "
          >
            <cx-pagination
              [pagination]="pagination"
              (viewPageEvent)="pageChange($event)"
            ></cx-pagination>
          </div>
        </div>
      </div>
    </div>
  </ng-container>
</ng-container>
`
    }]
  }], () => [{
    type: PDFInvoicesFacade
  }, {
    type: TranslationService
  }, {
    type: FileDownloadService
  }, {
    type: LanguageService
  }, {
    type: GlobalMessageService
  }], null);
})();
var PDFInvoicesComponentsModule = class _PDFInvoicesComponentsModule {
  static {
    this.ɵfac = function PDFInvoicesComponentsModule_Factory(t) {
      return new (t || _PDFInvoicesComponentsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _PDFInvoicesComponentsModule,
      declarations: [InvoicesListComponent],
      imports: [CommonModule, DatePickerModule, I18nModule, ReactiveFormsModule, ListNavigationModule, UrlModule, IconModule, MediaModule, SpinnerModule, FeaturesConfigModule],
      exports: [InvoicesListComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          AccountOrderDetailsPDFInvoicesComponent: {
            component: InvoicesListComponent,
            guards: [AuthGuard]
          }
        }
      })],
      imports: [CommonModule, DatePickerModule, I18nModule, ReactiveFormsModule, ListNavigationModule, UrlModule, IconModule, MediaModule, SpinnerModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PDFInvoicesComponentsModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, DatePickerModule, I18nModule, ReactiveFormsModule, ListNavigationModule, UrlModule, IconModule, MediaModule, SpinnerModule, FeaturesConfigModule],
      declarations: [InvoicesListComponent],
      exports: [InvoicesListComponent],
      providers: [provideDefaultConfig({
        cmsComponents: {
          AccountOrderDetailsPDFInvoicesComponent: {
            component: InvoicesListComponent,
            guards: [AuthGuard]
          }
        }
      })]
    }]
  }], null, null);
})();

// node_modules/@spartacus/order/fesm2022/spartacus-order-components.mjs
var _c02 = (a0) => ({
  code: a0
});
var _c1 = (a0, a1) => ({
  cxRoute: a0,
  params: a1
});
function AmendOrderActionsComponent_button_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 4);
    ɵɵlistener("click", function AmendOrderActionsComponent_button_6_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.continue($event));
    });
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "common.continue"), " ");
  }
}
function AmendOrderActionsComponent_button_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "button", 5);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 2, "orderDetails.cancellationAndReturn.submitDescription"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "orderDetails.cancellationAndReturn.submit"), " ");
  }
}
function CancelOrReturnItemsComponent_div_0_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 11);
    ɵɵlistener("click", function CancelOrReturnItemsComponent_div_0_button_1_Template_button_click_0_listener() {
      ɵɵrestoreView(_r1);
      const form_r2 = ɵɵnextContext().ngIf;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.setAll(form_r2));
    });
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderDetails.cancellationAndReturn.setAll"), " ");
  }
}
function CancelOrReturnItemsComponent_div_0_th_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "th", 12);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderDetails.cancellationAndReturn.quantity"), " ");
  }
}
function CancelOrReturnItemsComponent_div_0_th_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "th", 13);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderDetails.cancellationAndReturn.totalPrice"), " ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_div_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 28);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const item_r4 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(2, 2, "cartItems.id"), " ", item_r4.product.code, " ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 33);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const variant_r5 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", variant_r5.name, ": ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_div_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 25);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const variant_r5 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", variant_r5.value, " ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 30);
    ɵɵtemplate(1, CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_div_1_div_1_Template, 2, 1, "div", 31)(2, CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_div_1_div_2_Template, 2, 1, "div", 32);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const variant_r5 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("ngIf", variant_r5.name);
    ɵɵadvance();
    ɵɵproperty("ngIf", variant_r5.value);
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_div_1_Template, 3, 2, "div", 29);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const item_r4 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵproperty("ngForOf", item_r4.product.baseOptions[0] == null ? null : item_r4.product.baseOptions[0].selected == null ? null : item_r4.product.baseOptions[0].selected.variantOptionQualifiers);
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_td_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 34)(1, "div", 24);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 25);
    ɵɵtext(5);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const item_r4 = ɵɵnextContext().$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "orderDetails.cancellationAndReturn.itemPrice"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", item_r4.basePrice == null ? null : item_r4.basePrice.formattedValue, " ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_td_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 35)(1, "div", 36);
    ɵɵpipe(2, "cxTranslate");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "div", 25);
    ɵɵtext(6);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const item_r4 = ɵɵnextContext().$implicit;
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(2, 3, "cartItems.quantityTitle"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 5, "orderDetails.cancellationAndReturn.quantity"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ctx_r2.getMaxAmendQuantity(item_r4), " ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_ng_container_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const item_r4 = ɵɵnextContext().$implicit;
    const form_r2 = ɵɵnextContext().ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r2.getControl(form_r2, item_r4).value, " ");
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_cx_item_counter_17_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-item-counter", 37);
  }
  if (rf & 2) {
    const item_r4 = ɵɵnextContext().$implicit;
    const form_r2 = ɵɵnextContext().ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("min", 0)("max", ctx_r2.getMaxAmendQuantity(item_r4))("control", ctx_r2.getControl(form_r2, item_r4));
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_td_18_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 38)(1, "div", 24);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 25);
    ɵɵtext(5);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    let tmp_7_0;
    const item_r4 = ɵɵnextContext().$implicit;
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "orderDetails.cancellationAndReturn.totalPrice"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate((tmp_7_0 = ctx_r2.getItemPrice(item_r4)) == null ? null : tmp_7_0.formattedValue);
  }
}
function CancelOrReturnItemsComponent_div_0_tr_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tr", 14)(1, "td", 15)(2, "div", 16);
    ɵɵelement(3, "cx-media", 17);
    ɵɵelementStart(4, "div", 18)(5, "div", 19);
    ɵɵtext(6);
    ɵɵelementEnd();
    ɵɵtemplate(7, CancelOrReturnItemsComponent_div_0_tr_20_div_7_Template, 3, 4, "div", 20);
    ɵɵelementEnd();
    ɵɵtemplate(8, CancelOrReturnItemsComponent_div_0_tr_20_ng_container_8_Template, 2, 1, "ng-container", 0);
    ɵɵelementEnd()();
    ɵɵtemplate(9, CancelOrReturnItemsComponent_div_0_tr_20_td_9_Template, 6, 4, "td", 21)(10, CancelOrReturnItemsComponent_div_0_tr_20_td_10_Template, 7, 7, "td", 22);
    ɵɵelementStart(11, "td", 23)(12, "div", 24);
    ɵɵtext(13);
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(15, "div", 25);
    ɵɵtemplate(16, CancelOrReturnItemsComponent_div_0_tr_20_ng_container_16_Template, 2, 1, "ng-container", 0)(17, CancelOrReturnItemsComponent_div_0_tr_20_cx_item_counter_17_Template, 1, 3, "cx-item-counter", 26);
    ɵɵelementEnd()();
    ɵɵtemplate(18, CancelOrReturnItemsComponent_div_0_tr_20_td_18_Template, 6, 4, "td", 27);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const item_r4 = ctx.$implicit;
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵadvance(3);
    ɵɵproperty("container", item_r4.product.images == null ? null : item_r4.product.images.PRIMARY);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", item_r4.product.name, " ");
    ɵɵadvance();
    ɵɵproperty("ngIf", item_r4.product.code);
    ɵɵadvance();
    ɵɵproperty("ngIf", item_r4.product.baseOptions == null ? null : item_r4.product.baseOptions.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", item_r4.basePrice);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r2.isConfirmation);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 10, ctx_r2.isCancellation() ? "orderDetails.cancellationAndReturn.cancelQty" : "orderDetails.cancellationAndReturn.returnQty"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r2.isConfirmation);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r2.isConfirmation);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.isConfirmation);
  }
}
function CancelOrReturnItemsComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, CancelOrReturnItemsComponent_div_0_button_1_Template, 3, 3, "button", 1);
    ɵɵelementStart(2, "table", 2)(3, "caption", 3);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(6, "thead")(7, "tr")(8, "th", 4);
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(11, "th", 5);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(14, CancelOrReturnItemsComponent_div_0_th_14_Template, 3, 3, "th", 6);
    ɵɵelementStart(15, "th", 7);
    ɵɵtext(16);
    ɵɵpipe(17, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(18, CancelOrReturnItemsComponent_div_0_th_18_Template, 3, 3, "th", 8);
    ɵɵelementEnd()();
    ɵɵelementStart(19, "tbody", 9);
    ɵɵtemplate(20, CancelOrReturnItemsComponent_div_0_tr_20_Template, 19, 12, "tr", 10);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r2.isConfirmation);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 8, "orderDetails.caption"), " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 10, "orderDetails.cancellationAndReturn.item"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 12, "orderDetails.cancellationAndReturn.itemPrice"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r2.isConfirmation);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(17, 14, ctx_r2.isCancellation() ? "orderDetails.cancellationAndReturn.cancelQty" : "orderDetails.cancellationAndReturn.returnQty"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r2.isConfirmation);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r2.entries);
  }
}
function CancelOrderConfirmationComponent_form_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CancelOrderConfirmationComponent_form_0_cx_amend_order_items_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-items", 5);
  }
  if (rf & 2) {
    const entries_r4 = ctx.ngIf;
    ɵɵproperty("entries", entries_r4)("isConfirmation", true);
  }
}
function CancelOrderConfirmationComponent_form_0_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CancelOrderConfirmationComponent_form_0_ng_template_5_cx_amend_order_actions_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-actions", 7);
  }
  if (rf & 2) {
    const form_r2 = ɵɵnextContext(2).ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("orderCode", ctx_r2.orderCode)("amendOrderForm", form_r2);
  }
}
function CancelOrderConfirmationComponent_form_0_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CancelOrderConfirmationComponent_form_0_ng_template_5_cx_amend_order_actions_0_Template, 1, 2, "cx-amend-order-actions", 6);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r2.orderCode);
  }
}
function CancelOrderConfirmationComponent_form_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "form", 2);
    ɵɵlistener("ngSubmit", function CancelOrderConfirmationComponent_form_0_Template_form_ngSubmit_0_listener() {
      const form_r2 = ɵɵrestoreView(_r1).ngIf;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.submit(form_r2));
    });
    ɵɵtemplate(1, CancelOrderConfirmationComponent_form_0_ng_container_1_Template, 1, 0, "ng-container", 3)(2, CancelOrderConfirmationComponent_form_0_cx_amend_order_items_2_Template, 1, 2, "cx-amend-order-items", 4);
    ɵɵpipe(3, "async");
    ɵɵtemplate(4, CancelOrderConfirmationComponent_form_0_ng_container_4_Template, 1, 0, "ng-container", 3)(5, CancelOrderConfirmationComponent_form_0_ng_template_5_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const form_r2 = ctx.ngIf;
    const actions_r5 = ɵɵreference(6);
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("formGroup", form_r2);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", actions_r5);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(3, 4, ctx_r2.entries$));
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", actions_r5);
  }
}
function CancelOrderComponent_ng_container_0_cx_message_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-message", 6);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵproperty("text", ɵɵpipeBind1(1, 3, "formErrors.cxNoSelectedItemToCancel"))("isVisibleCloseButton", false)("type", ctx_r0.globalMessageType.MSG_TYPE_ERROR);
  }
}
function CancelOrderComponent_ng_container_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CancelOrderComponent_ng_container_0_cx_amend_order_items_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-items", 7);
  }
  if (rf & 2) {
    const entries_r2 = ctx.ngIf;
    ɵɵproperty("entries", entries_r2);
  }
}
function CancelOrderComponent_ng_container_0_cx_form_errors_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 8);
  }
  if (rf & 2) {
    const form_r3 = ɵɵnextContext().ngIf;
    ɵɵproperty("control", form_r3.get("entries"));
  }
}
function CancelOrderComponent_ng_container_0_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CancelOrderComponent_ng_container_0_ng_template_7_cx_amend_order_actions_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-actions", 10);
  }
  if (rf & 2) {
    const form_r3 = ɵɵnextContext(2).ngIf;
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("orderCode", ctx_r0.orderCode)("amendOrderForm", form_r3);
  }
}
function CancelOrderComponent_ng_container_0_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CancelOrderComponent_ng_container_0_ng_template_7_cx_amend_order_actions_0_Template, 1, 2, "cx-amend-order-actions", 9);
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r0.orderCode);
  }
}
function CancelOrderComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CancelOrderComponent_ng_container_0_cx_message_1_Template, 2, 5, "cx-message", 2)(2, CancelOrderComponent_ng_container_0_ng_container_2_Template, 1, 0, "ng-container", 3)(3, CancelOrderComponent_ng_container_0_cx_amend_order_items_3_Template, 1, 1, "cx-amend-order-items", 4);
    ɵɵpipe(4, "async");
    ɵɵtemplate(5, CancelOrderComponent_ng_container_0_cx_form_errors_5_Template, 1, 1, "cx-form-errors", 5)(6, CancelOrderComponent_ng_container_0_ng_container_6_Template, 1, 0, "ng-container", 3)(7, CancelOrderComponent_ng_container_0_ng_template_7_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const form_r3 = ctx.ngIf;
    const actions_r4 = ɵɵreference(8);
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !form_r3.get("entries").valid && form_r3.get("entries").touched);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", actions_r4);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(4, 5, ctx_r0.entries$));
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "!a11yRepeatedCancelOrderError");
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", actions_r4);
  }
}
function ReturnOrderConfirmationComponent_form_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function ReturnOrderConfirmationComponent_form_0_cx_amend_order_items_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-items", 5);
  }
  if (rf & 2) {
    const entries_r4 = ctx.ngIf;
    ɵɵproperty("entries", entries_r4)("isConfirmation", true);
  }
}
function ReturnOrderConfirmationComponent_form_0_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function ReturnOrderConfirmationComponent_form_0_ng_template_5_cx_amend_order_actions_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-actions", 7);
  }
  if (rf & 2) {
    const form_r2 = ɵɵnextContext(2).ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("orderCode", ctx_r2.orderCode)("amendOrderForm", form_r2);
  }
}
function ReturnOrderConfirmationComponent_form_0_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ReturnOrderConfirmationComponent_form_0_ng_template_5_cx_amend_order_actions_0_Template, 1, 2, "cx-amend-order-actions", 6);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r2.orderCode);
  }
}
function ReturnOrderConfirmationComponent_form_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "form", 2);
    ɵɵlistener("ngSubmit", function ReturnOrderConfirmationComponent_form_0_Template_form_ngSubmit_0_listener() {
      const form_r2 = ɵɵrestoreView(_r1).ngIf;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.submit(form_r2));
    });
    ɵɵtemplate(1, ReturnOrderConfirmationComponent_form_0_ng_container_1_Template, 1, 0, "ng-container", 3)(2, ReturnOrderConfirmationComponent_form_0_cx_amend_order_items_2_Template, 1, 2, "cx-amend-order-items", 4);
    ɵɵpipe(3, "async");
    ɵɵtemplate(4, ReturnOrderConfirmationComponent_form_0_ng_container_4_Template, 1, 0, "ng-container", 3)(5, ReturnOrderConfirmationComponent_form_0_ng_template_5_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const form_r2 = ctx.ngIf;
    const actions_r5 = ɵɵreference(6);
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("formGroup", form_r2);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", actions_r5);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(3, 4, ctx_r2.entries$));
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", actions_r5);
  }
}
function ReturnOrderComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function ReturnOrderComponent_ng_container_0_cx_amend_order_items_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-items", 5);
  }
  if (rf & 2) {
    const entries_r1 = ctx.ngIf;
    ɵɵproperty("entries", entries_r1);
  }
}
function ReturnOrderComponent_ng_container_0_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function ReturnOrderComponent_ng_container_0_ng_template_6_cx_amend_order_actions_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-amend-order-actions", 7);
  }
  if (rf & 2) {
    const form_r2 = ɵɵnextContext(2).ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("orderCode", ctx_r2.orderCode)("amendOrderForm", form_r2);
  }
}
function ReturnOrderComponent_ng_container_0_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ReturnOrderComponent_ng_container_0_ng_template_6_cx_amend_order_actions_0_Template, 1, 2, "cx-amend-order-actions", 6);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r2.orderCode);
  }
}
function ReturnOrderComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, ReturnOrderComponent_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 2)(2, ReturnOrderComponent_ng_container_0_cx_amend_order_items_2_Template, 1, 1, "cx-amend-order-items", 3);
    ɵɵpipe(3, "async");
    ɵɵelement(4, "cx-form-errors", 4);
    ɵɵtemplate(5, ReturnOrderComponent_ng_container_0_ng_container_5_Template, 1, 0, "ng-container", 2)(6, ReturnOrderComponent_ng_container_0_ng_template_6_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const form_r2 = ctx.ngIf;
    const actions_r4 = ɵɵreference(7);
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", actions_r4);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(3, 4, ctx_r2.entries$));
    ɵɵadvance(2);
    ɵɵproperty("control", form_r2.get("entries"));
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", actions_r4);
  }
}
var _c2 = () => ({
  cxRoute: "orders"
});
var _c3 = (a0) => ({
  value: a0
});
var _c4 = (a0) => ({
  cxRoute: "orderDetails",
  params: a0
});
var _c5 = () => ({
  value: 1
});
var _c6 = (a0) => ({
  cxRoute: "orderReturn",
  params: a0
});
var _c7 = () => ({
  cxRoute: "home"
});
function MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext().$implicit;
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 2, "myAccountV2Orders.orderStatusLabel"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "orderDetails.statusDisplay_" + order_r1.statusDisplay), " ");
  }
}
function MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_span_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" + ", ɵɵpipeBind2(2, 1, "myAccountV2Orders.items", ɵɵpureFunction1(4, _c3, order_r1.totalItems - 1)), " ");
  }
}
function MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_span_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" + ", ɵɵpipeBind2(2, 1, "myAccountV2Orders.item", ɵɵpureFunction0(4, _c5)), " ");
  }
}
function MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_span_28_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵelementStart(2, "a", 27);
    ɵɵpipe(3, "cxUrl");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", " | ", "");
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(3, 3, ɵɵpureFunction1(7, _c6, order_r1)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 5, "myAccountV2Orders.returnOrder"), " ");
  }
}
function MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 16)(2, "div", 17);
    ɵɵelement(3, "cx-media", 18);
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 19)(5, "div", 20)(6, "div", 21);
    ɵɵtext(7);
    ɵɵtemplate(8, MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_span_8_Template, 3, 6, "span", 14)(9, MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_span_9_Template, 3, 5, "span", 14);
    ɵɵelementEnd();
    ɵɵelementStart(10, "div", 22);
    ɵɵtext(11);
    ɵɵpipe(12, "cxDate");
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(14, "div", 23);
    ɵɵtext(15);
    ɵɵpipe(16, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(17, "div", 24)(18, "div", 25);
    ɵɵtext(19);
    ɵɵpipe(20, "cxTranslate");
    ɵɵelementEnd()()()();
    ɵɵelementStart(21, "div", 26)(22, "span")(23, "a", 27);
    ɵɵpipe(24, "cxUrl");
    ɵɵpipe(25, "cxTranslate");
    ɵɵtext(26);
    ɵɵpipe(27, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵtemplate(28, MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_span_28_Template, 6, 9, "span", 14);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const product_r2 = ctx.ngIf;
    const order_r1 = ɵɵnextContext().$implicit;
    ɵɵadvance(3);
    ɵɵproperty("container", product_r2.images == null ? null : product_r2.images.PRIMARY);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", product_r2.name, " ");
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1.totalItems - 1 > 1);
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1.totalItems - 1 === 1);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(13, 14, "myAccountV2Orders.purchasedOn", ɵɵpureFunction1(30, _c3, ɵɵpipeBind2(12, 11, order_r1.placed, "d, MMMM, yyyy"))), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(16, 17, "myAccountV2Orders.orderedItems", ɵɵpureFunction1(32, _c3, order_r1.totalItems)), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(20, 20, "myAccountV2Orders.totalPrice", ɵɵpureFunction1(34, _c3, order_r1.total == null ? null : order_r1.total.formattedValue)), " ");
    ɵɵadvance(4);
    ɵɵproperty("routerLink", ɵɵpipeBind1(24, 23, ɵɵpureFunction1(36, _c4, order_r1)));
    ɵɵattribute("aria-label", ɵɵpipeBind2(25, 25, "myAccountV2Orders.orderDetailsLabel", ɵɵpureFunction1(38, _c3, order_r1.code)));
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(27, 28, "myAccountV2Orders.orderDetails"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", order_r1.returnable);
  }
}
function MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 9)(2, "div", 10);
    ɵɵtemplate(3, MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_div_3_Template, 4, 6, "div", 11);
    ɵɵelementStart(4, "div", 12);
    ɵɵpipe(5, "cxTranslate");
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(8, "div", 13);
    ɵɵtemplate(9, MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_ng_container_9_Template, 29, 40, "ng-container", 14);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ctx.$implicit;
    const ctx_r2 = ɵɵnextContext(3);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", order_r1.statusDisplay);
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(5, 4, "myAccountV2OrderHistory.orderCodeLabel"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(7, 6, "myAccountV2Orders.orderNumber", ɵɵpureFunction1(9, _c3, order_r1.code)), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r2.getProduct(order_r1));
  }
}
function MyAccountV2OrdersComponent_div_11_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 7);
    ɵɵtemplate(2, MyAccountV2OrdersComponent_div_11_ng_container_1_ng_container_2_Template, 10, 11, "ng-container", 8);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const orderHistory_r4 = ɵɵnextContext().ngIf;
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", orderHistory_r4.orders);
  }
}
function MyAccountV2OrdersComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, MyAccountV2OrdersComponent_div_11_ng_container_1_Template, 3, 1, "ng-container", 6);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const orderHistory_r4 = ctx.ngIf;
    ɵɵnextContext();
    const noOrder_r5 = ɵɵreference(14);
    ɵɵadvance();
    ɵɵproperty("ngIf", orderHistory_r4.pagination.totalResults > 0)("ngIfElse", noOrder_r5);
  }
}
function MyAccountV2OrdersComponent_ng_template_13_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 29)(1, "div");
    ɵɵpipe(2, "cxTranslate");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "a", 30);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 4, "orderHistory.notFound"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 6, "orderHistory.noOrders"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 8, ɵɵpureFunction0(12, _c7)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(8, 10, "orderHistory.startShopping"));
  }
}
function MyAccountV2OrdersComponent_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, MyAccountV2OrdersComponent_ng_template_13_div_0_Template, 9, 13, "div", 28);
    ɵɵpipe(1, "async");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    const loading_r6 = ɵɵreference(16);
    ɵɵproperty("ngIf", ɵɵpipeBind1(1, 2, ctx_r2.isLoaded$))("ngIfElse", loading_r6);
  }
}
function MyAccountV2OrdersComponent_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 31);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
function OrderDetailBillingComponent_div_0_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5);
    ɵɵelement(1, "cx-card", 6);
    ɵɵpipe(2, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const paymentDetails_r1 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 1, ctx_r1.getPaymentMethodCard(paymentDetails_r1)));
  }
}
function OrderDetailBillingComponent_div_0_div_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5);
    ɵɵelement(1, "cx-card", 6);
    ɵɵpipe(2, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const paymentDetails_r1 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 1, ctx_r1.getBillingAddressCard(paymentDetails_r1)));
  }
}
function OrderDetailBillingComponent_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 3);
    ɵɵtemplate(1, OrderDetailBillingComponent_div_0_div_1_div_1_Template, 3, 3, "div", 4)(2, OrderDetailBillingComponent_div_0_div_1_div_2_Template, 3, 3, "div", 4);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const paymentDetails_r1 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.isPaymentInfoCardFull(paymentDetails_r1));
    ɵɵadvance();
    ɵɵproperty("ngIf", paymentDetails_r1 == null ? null : paymentDetails_r1.billingAddress);
  }
}
function OrderDetailBillingComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, OrderDetailBillingComponent_div_0_div_1_Template, 3, 2, "div", 2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r3 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r3.paymentInfo);
  }
}
var _c8 = (a0) => ({
  item: a0,
  readonly: true
});
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_1_ng_template_15_Template(rf, ctx) {
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 7);
    ɵɵelement(2, "cx-card", 9);
    ɵɵpipe(3, "async");
    ɵɵelement(4, "cx-card", 9);
    ɵɵpipe(5, "async");
    ɵɵelementEnd();
    ɵɵelementStart(6, "div", 7);
    ɵɵelement(7, "cx-card", 9);
    ɵɵpipe(8, "cxDate");
    ɵɵpipe(9, "async");
    ɵɵelement(10, "cx-card", 9);
    ɵɵpipe(11, "async");
    ɵɵelement(12, "cx-card", 9);
    ɵɵpipe(13, "cxDate");
    ɵɵpipe(14, "async");
    ɵɵtemplate(15, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_1_ng_template_15_Template, 0, 0, "ng-template", 8);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(3, 7, ctx_r1.getReplenishmentCodeCardContent(order_r1 == null ? null : order_r1.replenishmentOrderCode)));
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(5, 9, ctx_r1.getReplenishmentActiveCardContent(order_r1 == null ? null : order_r1.active)));
    ɵɵadvance(3);
    ɵɵproperty("content", ɵɵpipeBind1(9, 13, ctx_r1.getReplenishmentStartOnCardContent(ɵɵpipeBind1(8, 11, order_r1 == null ? null : order_r1.firstDate))));
    ɵɵadvance(3);
    ɵɵproperty("content", ɵɵpipeBind1(11, 15, ctx_r1.getReplenishmentFrequencyCardContent(order_r1 == null ? null : order_r1.trigger == null ? null : order_r1.trigger.displayTimeTable)));
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(14, 19, ctx_r1.getReplenishmentNextDateCardContent(ɵɵpipeBind1(13, 17, order_r1 == null ? null : order_r1.trigger == null ? null : order_r1.trigger.activationTime))));
    ɵɵadvance(3);
    ɵɵproperty("cxOutlet", ctx_r1.cartOutlets.ORDER_OVERVIEW)("cxOutletContext", ɵɵpureFunction1(21, _c8, order_r1));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_template_2_ng_template_8_Template(rf, ctx) {
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 7);
    ɵɵelement(1, "cx-card", 9);
    ɵɵpipe(2, "async");
    ɵɵelement(3, "cx-card", 9);
    ɵɵpipe(4, "cxDate");
    ɵɵpipe(5, "async");
    ɵɵelement(6, "cx-card", 9);
    ɵɵpipe(7, "async");
    ɵɵtemplate(8, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_template_2_ng_template_8_Template, 0, 0, "ng-template", 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 5, ctx_r1.getOrderCodeCardContent(order_r1 == null ? null : order_r1.code)));
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(5, 9, ctx_r1.getOrderCurrentDateCardContent(ɵɵpipeBind1(4, 7, order_r1 == null ? null : order_r1.created))));
    ɵɵadvance(3);
    ɵɵproperty("content", ɵɵpipeBind1(7, 11, ctx_r1.getOrderStatusCardContent(order_r1.statusDisplay)));
    ɵɵadvance(2);
    ɵɵproperty("cxOutlet", ctx_r1.cartOutlets.ORDER_OVERVIEW)("cxOutletContext", ɵɵpureFunction1(13, _c8, order_r1));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_4_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelement(1, "cx-card", 9);
    ɵɵpipe(2, "async");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(4).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 1, ctx_r1.getCostCenterCardContent(order_r1 == null ? null : order_r1.costCenter)));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 7);
    ɵɵelement(2, "cx-card", 9);
    ɵɵpipe(3, "async");
    ɵɵelement(4, "cx-card", 9);
    ɵɵpipe(5, "async");
    ɵɵtemplate(6, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_4_ng_container_6_Template, 3, 3, "ng-container", 3);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(3, 3, ctx_r1.getPurchaseOrderNumber(order_r1 == null ? null : order_r1.purchaseOrderNumber)));
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(5, 5, ctx_r1.getMethodOfPaymentCardContent(order_r1.paymentInfo)));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", order_r1.costCenter);
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelement(1, "cx-card", 9);
    ɵɵpipe(2, "async");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 1, ctx_r1.getAddressCardContent(order_r1 == null ? null : order_r1.deliveryAddress)));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelement(1, "cx-card", 9);
    ɵɵpipe(2, "async");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 1, ctx_r1.getDeliveryModeCardContent(order_r1 == null ? null : order_r1.deliveryMode)));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_template_8_Template(rf, ctx) {
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_9_div_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelement(1, "cx-card", 9);
    ɵɵpipe(2, "async");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(5).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(2, 1, ctx_r1.getPaymentInfoCardContent(order_r1 == null ? null : order_r1.paymentInfo)));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_9_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 7);
    ɵɵtemplate(1, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_9_div_1_ng_container_1_Template, 3, 3, "ng-container", 3);
    ɵɵelement(2, "cx-card", 9);
    ɵɵpipe(3, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(4).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.isPaymentInfoCardFull(order_r1 == null ? null : order_r1.paymentInfo));
    ɵɵadvance();
    ɵɵproperty("content", ɵɵpipeBind1(3, 2, ctx_r1.getBillingAddressCardContent(order_r1 == null ? null : order_r1.paymentInfo == null ? null : order_r1.paymentInfo.billingAddress)));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_9_div_1_Template, 4, 4, "div", 10);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", (order_r1 == null ? null : order_r1.paymentInfo == null ? null : order_r1.paymentInfo.billingAddress) || ctx_r1.isPaymentInfoCardFull(order_r1 == null ? null : order_r1.paymentInfo));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5);
    ɵɵtemplate(1, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_1_Template, 16, 23, "ng-container", 6)(2, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_template_2_Template, 9, 15, "ng-template", null, 0, ɵɵtemplateRefExtractor)(4, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_4_Template, 7, 7, "ng-container", 3);
    ɵɵelementStart(5, "div", 7);
    ɵɵtemplate(6, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_6_Template, 3, 3, "ng-container", 3)(7, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_7_Template, 3, 3, "ng-container", 3)(8, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_template_8_Template, 0, 0, "ng-template", 8);
    ɵɵelementEnd();
    ɵɵtemplate(9, OrderOverviewComponent_div_0_ng_container_1_div_1_ng_container_9_Template, 2, 1, "ng-container", 3);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const otherOrder_r3 = ɵɵreference(3);
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1.replenishmentOrderCode)("ngIfElse", otherOrder_r3);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", order_r1.purchaseOrderNumber || order_r1.purchaseOrderNumber === "");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", order_r1.deliveryAddress);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.shouldShowDeliveryMode(order_r1.deliveryMode));
    ɵɵadvance();
    ɵɵproperty("cxOutlet", ctx_r1.orderOutlets.SERVICE_DETAILS)("cxOutletContext", ɵɵpureFunction1(8, _c8, order_r1));
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1.paymentInfo);
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_3_ng_template_9_Template(rf, ctx) {
}
function OrderOverviewComponent_div_0_ng_container_1_div_3_cx_order_detail_billing_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-order-detail-billing");
  }
}
function OrderOverviewComponent_div_0_ng_container_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5)(1, "div", 11);
    ɵɵelement(2, "cx-card", 9);
    ɵɵpipe(3, "async");
    ɵɵelement(4, "cx-card", 9);
    ɵɵpipe(5, "cxDate");
    ɵɵpipe(6, "async");
    ɵɵelement(7, "cx-card", 9);
    ɵɵpipe(8, "async");
    ɵɵtemplate(9, OrderOverviewComponent_div_0_ng_container_1_div_3_ng_template_9_Template, 0, 0, "ng-template", 8);
    ɵɵelementEnd();
    ɵɵtemplate(10, OrderOverviewComponent_div_0_ng_container_1_div_3_cx_order_detail_billing_10_Template, 1, 0, "cx-order-detail-billing", 3);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(3, 6, ctx_r1.getOrderCodeCardContent(order_r1 == null ? null : order_r1.code)));
    ɵɵadvance(2);
    ɵɵproperty("content", ɵɵpipeBind1(6, 10, ctx_r1.getOrderCurrentDateCardContent(ɵɵpipeBind1(5, 8, order_r1 == null ? null : order_r1.created))));
    ɵɵadvance(3);
    ɵɵproperty("content", ɵɵpipeBind1(8, 12, ctx_r1.getOrderStatusCardContent(order_r1.statusDisplay)));
    ɵɵadvance(2);
    ɵɵproperty("cxOutlet", ctx_r1.cartOutlets.ORDER_OVERVIEW)("cxOutletContext", ɵɵpureFunction1(14, _c8, order_r1));
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.isPaymentInfoCardFull(order_r1 == null ? null : order_r1.paymentInfo) || (order_r1 == null ? null : order_r1.paymentInfo == null ? null : order_r1.paymentInfo.billingAddress));
  }
}
function OrderOverviewComponent_div_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderOverviewComponent_div_0_ng_container_1_div_1_Template, 10, 10, "div", 4);
    ɵɵpipe(2, "async");
    ɵɵtemplate(3, OrderOverviewComponent_div_0_ng_container_1_div_3_Template, 11, 16, "div", 4);
    ɵɵpipe(4, "async");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ɵɵpipeBind1(2, 2, ctx_r1.simple$));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(4, 4, ctx_r1.simple$));
  }
}
function OrderOverviewComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 2);
    ɵɵtemplate(1, OrderOverviewComponent_div_0_ng_container_1_Template, 5, 6, "ng-container", 3);
    ɵɵpipe(2, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !ɵɵpipeBind1(2, 1, ctx_r1.isOrderLoading$));
  }
}
var _c9 = () => [];
var _c10 = (a0, a1) => ({
  id: a0,
  type: a1
});
var _c11 = (a0, a1) => ({
  items: a0,
  readonly: true,
  promotionLocation: a1
});
function OrderConfirmationItemsComponent_div_0_h3_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h3", 5);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "checkoutOrderConfirmation.orderItems"), " ");
  }
}
function OrderConfirmationItemsComponent_div_0_h4_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h4", 5);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "checkoutOrderConfirmation.orderItems"), " ");
  }
}
function OrderConfirmationItemsComponent_div_0_ng_template_4_Template(rf, ctx) {
}
function OrderConfirmationItemsComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, OrderConfirmationItemsComponent_div_0_h3_1_Template, 3, 3, "h3", 2)(2, OrderConfirmationItemsComponent_div_0_h4_2_Template, 3, 3, "h4", 2);
    ɵɵelement(3, "cx-promotions", 3);
    ɵɵtemplate(4, OrderConfirmationItemsComponent_div_0_ng_template_4_Template, 0, 0, "ng-template", 4);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yOrderConfirmationHeadingOrder");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "!a11yOrderConfirmationHeadingOrder");
    ɵɵadvance();
    ɵɵproperty("promotions", order_r1.appliedOrderPromotions || ɵɵpureFunction0(6, _c9));
    ɵɵadvance();
    ɵɵproperty("cxAbstractOrderContext", ɵɵpureFunction2(7, _c10, order_r1.code, ctx_r1.abstractOrderType.ORDER))("cxOutlet", ctx_r1.cartOutlets.CART_ITEM_LIST)("cxOutletContext", ɵɵpureFunction2(10, _c11, order_r1.entries, ctx_r1.promotionLocation));
  }
}
var _c12 = (a0) => ({
  items: a0,
  readonly: true
});
function OrderConfirmationShippingComponent_div_0_ng_container_1_div_13_ng_template_1_Template(rf, ctx) {
}
function OrderConfirmationShippingComponent_div_0_ng_container_1_div_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 9);
    ɵɵtemplate(1, OrderConfirmationShippingComponent_div_0_ng_container_1_div_13_ng_template_1_Template, 0, 0, "ng-template", 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("cxAbstractOrderContext", ɵɵpureFunction2(3, _c10, order_r1.code, ctx_r1.abstractOrderType.ORDER))("cxOutlet", ctx_r1.cartOutlets.CART_ITEM_LIST)("cxOutletContext", ɵɵpureFunction1(6, _c12, ctx_r1.entries));
  }
}
function OrderConfirmationShippingComponent_div_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "h2", 3);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 4)(5, "div", 5)(6, "div", 6);
    ɵɵelement(7, "cx-card", 7);
    ɵɵpipe(8, "async");
    ɵɵelementEnd()();
    ɵɵelementStart(9, "div", 5)(10, "div", 6);
    ɵɵelement(11, "cx-card", 7);
    ɵɵpipe(12, "async");
    ɵɵelementEnd()()();
    ɵɵtemplate(13, OrderConfirmationShippingComponent_div_0_ng_container_1_div_13_Template, 2, 8, "div", 8);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "checkoutMode.deliveryEntries"), " ");
    ɵɵadvance(5);
    ɵɵproperty("content", ɵɵpipeBind1(8, 6, ctx_r1.getDeliveryAddressCard(order_r1.deliveryAddress)));
    ɵɵadvance(4);
    ɵɵproperty("content", ɵɵpipeBind1(12, 8, ctx_r1.getDeliveryModeCard(order_r1.deliveryMode)));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.showItemList);
  }
}
function OrderConfirmationShippingComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, OrderConfirmationShippingComponent_div_0_ng_container_1_Template, 14, 10, "ng-container", 2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.showItemList || (ctx_r1.entries == null ? null : ctx_r1.entries.length) > 0);
  }
}
var _c13 = (a0) => ({
  email: a0
});
var _c14 = (a0) => ({
  label: a0
});
function OrderGuestRegisterFormComponent_p_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 13);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), " ");
  }
}
function OrderGuestRegisterFormComponent_ng_template_15_Template(rf, ctx) {
}
function OrderGuestRegisterFormComponent_cx_form_errors_19_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c14, ɵɵpipeBind1(1, 2, "register.password.label")))("control", ctx_r1.guestRegisterForm.get("password"));
  }
}
function OrderGuestRegisterFormComponent_cx_form_errors_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.guestRegisterForm.get("password"));
  }
}
function OrderGuestRegisterFormComponent_ng_template_26_Template(rf, ctx) {
}
function OrderGuestRegisterFormComponent_cx_form_errors_30_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c14, ɵɵpipeBind1(1, 2, "register.confirmPassword.label")))("control", ctx_r1.guestRegisterForm.get("passwordconf"));
  }
}
function OrderGuestRegisterFormComponent_cx_form_errors_31_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.guestRegisterForm.get("passwordconf"));
  }
}
function OrderGuestRegisterFormComponent_ng_template_35_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 17);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function OrderGuestRegisterFormComponent_ng_template_35_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, OrderGuestRegisterFormComponent_ng_template_35_abbr_0_Template, 3, 3, "abbr", 16);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function OrderConfirmationThankYouMessageComponent_ng_container_0_div_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵelement(1, "cx-guest-register-form", 4);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("guid", ctx_r1.orderGuid)("email", order_r1.paymentInfo.billingAddress.email);
  }
}
function OrderConfirmationThankYouMessageComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "span", 2);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(5, "div", 3)(6, "h2");
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(9, "p");
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵtemplate(12, OrderConfirmationThankYouMessageComponent_ng_container_0_div_12_Template, 2, 2, "div", 0);
    ɵɵelement(13, "cx-add-to-home-screen-banner");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    let tmp_2_0;
    const order_r1 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(4, 5, "checkoutOrderConfirmation.confirmationOfOrder"), " ", (tmp_2_0 = order_r1.replenishmentOrderCode) !== null && tmp_2_0 !== void 0 ? tmp_2_0 : order_r1.code, " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(8, 7, "checkoutOrderConfirmation.thankYou"));
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 9, "checkoutOrderConfirmation.invoiceHasBeenSentByEmail"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.isGuestCustomer && ctx_r1.orderGuid && (order_r1 == null ? null : order_r1.paymentInfo == null ? null : order_r1.paymentInfo.billingAddress == null ? null : order_r1.paymentInfo.billingAddress.email));
  }
}
function OrderConfirmationTotalsComponent_div_0_ng_template_3_Template(rf, ctx) {
}
function OrderConfirmationTotalsComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1)(1, "div", 2)(2, "div", 3);
    ɵɵtemplate(3, OrderConfirmationTotalsComponent_div_0_ng_template_3_Template, 0, 0, "ng-template", 4);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const order_r1 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵproperty("cxOutlet", ctx_r1.cartOutlets.ORDER_SUMMARY)("cxOutletContext", order_r1);
  }
}
var _c15 = (a0) => ({
  cxRoute: "orderCancel",
  params: a0
});
function OrderDetailActionsComponent_ng_container_0_a_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 5);
    ɵɵpipe(1, "cxUrl");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext().ngIf;
    ɵɵproperty("routerLink", ɵɵpipeBind1(1, 2, ɵɵpureFunction1(6, _c15, order_r1)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "orderDetails.cancellationAndReturn.cancelAction"), " ");
  }
}
function OrderDetailActionsComponent_ng_container_0_a_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 5);
    ɵɵpipe(1, "cxUrl");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext().ngIf;
    ɵɵproperty("routerLink", ɵɵpipeBind1(1, 2, ɵɵpureFunction1(6, _c6, order_r1)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "orderDetails.cancellationAndReturn.returnAction"), " ");
  }
}
function OrderDetailActionsComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "button", 3);
    ɵɵpipe(4, "cxUrl");
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(7, "div", 2);
    ɵɵtemplate(8, OrderDetailActionsComponent_ng_container_0_a_8_Template, 4, 8, "a", 4)(9, OrderDetailActionsComponent_ng_container_0_a_9_Template, 4, 8, "a", 4);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ctx.ngIf;
    ɵɵadvance(3);
    ɵɵproperty("routerLink", ɵɵpipeBind1(4, 4, ɵɵpureFunction0(8, _c2)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 6, "common.back"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", order_r1.cancellable);
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1.returnable);
  }
}
function MyAccountV2OrderDetailsActionsComponent_ng_container_0_span_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 8)(1, "button", 10);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction1(6, _c15, ctx_r1.order)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 4, "myAccountV2OrderDetails.cancelItems"), " ");
  }
}
function MyAccountV2OrderDetailsActionsComponent_ng_container_0_span_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 8)(1, "button", 11);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction1(6, _c6, ctx_r1.order)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 4, "myAccountV2OrderDetails.returnItems"), " ");
  }
}
function MyAccountV2OrderDetailsActionsComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "span", 3)(4, "span", 4)(5, "button", 5);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()()()();
    ɵɵelementStart(9, "div", 6)(10, "span", 3);
    ɵɵtemplate(11, MyAccountV2OrderDetailsActionsComponent_ng_container_0_span_11_Template, 5, 8, "span", 7)(12, MyAccountV2OrderDetailsActionsComponent_ng_container_0_span_12_Template, 5, 8, "span", 7);
    ɵɵelementStart(13, "span", 8)(14, "button", 9);
    ɵɵlistener("click", function MyAccountV2OrderDetailsActionsComponent_ng_container_0_Template_button_click_14_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.showDialog(ctx_r1.order));
    });
    ɵɵtext(15);
    ɵɵpipe(16, "cxTranslate");
    ɵɵelementEnd()()()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(5);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 5, ɵɵpureFunction0(11, _c2)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(8, 7, "myAccountV2OrderDetails.viewAllOrders"), " ");
    ɵɵadvance(4);
    ɵɵproperty("ngIf", ctx_r1.order.cancellable);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.order.returnable);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(16, 9, "myAccountV2OrderDetails.downloadInvoices"), " ");
  }
}
function MyAccountV2DownloadInvoicesComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 10);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "myAccountV2OrderDetails.noInvoices"), " ");
  }
}
function MyAccountV2DownloadInvoicesComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 11);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
var _c16 = ["element"];
function ConsignmentTrackingComponent_ng_container_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div")(1, "button", 1);
    ɵɵlistener("click", function ConsignmentTrackingComponent_ng_container_0_div_1_Template_button_click_1_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.openTrackingDialog(ctx_r1.consignment));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "orderDetails.consignmentTracking.action"), " ");
  }
}
function ConsignmentTrackingComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, ConsignmentTrackingComponent_ng_container_0_div_1_Template, 4, 3, "div", 0);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.consignmentStatus.includes(ctx_r1.consignment.status));
  }
}
var _c17 = (a0, a1) => ({
  item: a0,
  order: a1
});
var _c18 = (a0, a1, a2) => ({
  displayAddToCart: a0,
  addToCartString: a1,
  optionalBtn: a2
});
var _c19 = (a0, a1, a2) => ({
  items: a0,
  readonly: true,
  promotionLocation: a1,
  options: a2
});
function OrderConsignedEntriesComponent_div_0_ng_template_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const consignment_r1 = ɵɵnextContext(2).$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderDetails.deliveryStatus_" + (consignment_r1 == null ? null : consignment_r1.status)), " ");
  }
}
function OrderConsignedEntriesComponent_div_0_ng_template_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 11)(1, "div");
    ɵɵtext(2);
    ɵɵpipe(3, "cxDate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const consignment_r1 = ɵɵnextContext(2).$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 1, consignment_r1 == null ? null : consignment_r1.statusDate));
  }
}
function OrderConsignedEntriesComponent_div_0_ng_template_1_cx_consignment_tracking_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-consignment-tracking", 12);
  }
  if (rf & 2) {
    const consignment_r1 = ɵɵnextContext(2).$implicit;
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("orderCode", ctx_r1.order.code)("consignment", consignment_r1);
  }
}
function OrderConsignedEntriesComponent_div_0_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 6)(1, "div", 7);
    ɵɵtemplate(2, OrderConsignedEntriesComponent_div_0_ng_template_1_span_2_Template, 3, 3, "span", 8);
    ɵɵelementEnd();
    ɵɵtemplate(3, OrderConsignedEntriesComponent_div_0_ng_template_1_div_3_Template, 4, 3, "div", 9)(4, OrderConsignedEntriesComponent_div_0_ng_template_1_cx_consignment_tracking_4_Template, 1, 2, "cx-consignment-tracking", 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const consignment_r1 = ɵɵnextContext().$implicit;
    ɵɵadvance(2);
    ɵɵproperty("ngIf", consignment_r1);
    ɵɵadvance();
    ɵɵproperty("ngIf", consignment_r1 == null ? null : consignment_r1.statusDate);
    ɵɵadvance();
    ɵɵproperty("cxFeature", "consignmentTracking");
  }
}
function OrderConsignedEntriesComponent_div_0_ng_template_3_Template(rf, ctx) {
}
function OrderConsignedEntriesComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 2);
    ɵɵtemplate(1, OrderConsignedEntriesComponent_div_0_ng_template_1_Template, 5, 3, "ng-template", 3);
    ɵɵelementStart(2, "div", 4);
    ɵɵtemplate(3, OrderConsignedEntriesComponent_div_0_ng_template_3_Template, 0, 0, "ng-template", 5);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const consignment_r1 = ctx.$implicit;
    const ctx_r1 = ɵɵnextContext();
    const addToCartBtn_r3 = ɵɵreference(2);
    ɵɵadvance();
    ɵɵproperty("cxOutlet", ctx_r1.OrderOutlets.ORDER_CONSIGNMENT)("cxOutletContext", ɵɵpureFunction2(5, _c17, consignment_r1, ctx_r1.order));
    ɵɵadvance(2);
    ɵɵproperty("cxAbstractOrderContext", ɵɵpureFunction2(8, _c10, ctx_r1.order.code, ctx_r1.abstractOrderType.ORDER))("cxOutlet", ctx_r1.CartOutlets.CART_ITEM_LIST)("cxOutletContext", ɵɵpureFunction3(15, _c19, consignment_r1.entries, ctx_r1.promotionLocation, ɵɵpureFunction3(11, _c18, ctx_r1.enableAddToCart, ctx_r1.buyItAgainTranslation, addToCartBtn_r3)));
  }
}
function OrderConsignedEntriesComponent_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-add-to-cart", 13);
  }
  if (rf & 2) {
    const ctx_ir4 = ctx.$implicit;
    ɵɵproperty("productCode", ctx_ir4.item.product == null ? null : ctx_ir4.item.product.code)("product", ctx_ir4.item.product)("showQuantity", false)("options", ctx_ir4.options)("pickupStore", ctx_ir4.item.deliveryPointOfService == null ? null : ctx_ir4.item.deliveryPointOfService.name);
  }
}
var _c20 = (a0) => ({
  showItemList: false,
  order: a0
});
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelement(1, "cx-promotions", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    ɵɵadvance();
    ɵɵproperty("promotions", order_r1.appliedOrderPromotions || ɵɵpureFunction0(1, _c9));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "deliveryPointOfServiceDetails.itemsToBePickUp"), " ");
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_cx_order_consigned_entries_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-order-consigned-entries", 6);
    ɵɵpipe(1, "async");
    ɵɵpipe(2, "cxTranslate");
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("order", order_r1)("consignments", ctx_r1.pickupConsignments)("enableAddToCart", ɵɵpipeBind1(1, 4, ctx_r1.enableAddToCart$))("buyItAgainTranslation", ɵɵpipeBind1(2, 6, "addToCart.buyItAgain"));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_4_ng_template_0_Template(rf, ctx) {
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, OrderDetailItemsComponent_ng_container_0_ng_container_1_4_ng_template_0_Template, 0, 0, "ng-template", 7);
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("cxOutlet", ctx_r1.OrderOutlets.CONSIGNMENT_DELIVERY_INFO)("cxOutletContext", ɵɵpureFunction1(2, _c20, order_r1));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_cx_order_consigned_entries_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-order-consigned-entries", 6);
    ɵɵpipe(1, "async");
    ɵɵpipe(2, "cxTranslate");
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("order", order_r1)("consignments", ctx_r1.deliveryConsignments)("enableAddToCart", ɵɵpipeBind1(1, 4, ctx_r1.enableAddToCart$))("buyItAgainTranslation", ɵɵpipeBind1(2, 6, "addToCart.buyItAgain"));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 9)(1, "div", 10);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "orderDetails.statusDisplay_" + (order_r1 == null ? null : order_r1.statusDisplay)), " ");
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_2_h2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h2", 14);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "checkoutMode.deliveryEntries"), " ");
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_2_ng_template_4_Template(rf, ctx) {
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_2_h2_1_Template, 3, 3, "h2", 11);
    ɵɵpipe(2, "async");
    ɵɵelementStart(3, "div", 12);
    ɵɵtemplate(4, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_2_ng_template_4_Template, 0, 0, "ng-template", 13);
    ɵɵpipe(5, "async");
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const addToCartBtn_r3 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 4, ctx_r1.groupCartItems$));
    ɵɵadvance(3);
    ɵɵproperty("cxAbstractOrderContext", ɵɵpureFunction2(10, _c10, order_r1.code, ctx_r1.abstractOrderType.ORDER))("cxOutlet", ctx_r1.CartOutlets.CART_ITEM_LIST)("cxOutletContext", ɵɵpureFunction3(17, _c19, ctx_r1.deliveryUnConsignedEntries, ctx_r1.promotionLocation, ɵɵpureFunction3(13, _c18, ɵɵpipeBind1(5, 6, ctx_r1.enableAddToCart$), ɵɵpipeBind1(6, 8, "addToCart.buyItAgain"), addToCartBtn_r3)));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_3_ng_template_5_Template(rf, ctx) {
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "h2", 14);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 12);
    ɵɵtemplate(5, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_3_ng_template_5_Template, 0, 0, "ng-template", 13);
    ɵɵpipe(6, "async");
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    const addToCartBtn_r3 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "checkoutPickupInStore.heading"), " ");
    ɵɵadvance(3);
    ɵɵproperty("cxAbstractOrderContext", ɵɵpureFunction2(10, _c10, order_r1.code, ctx_r1.abstractOrderType.ORDER))("cxOutlet", ctx_r1.CartOutlets.CART_ITEM_LIST)("cxOutletContext", ɵɵpureFunction3(17, _c19, ctx_r1.pickupUnconsignedEntries, ctx_r1.promotionLocation, ɵɵpureFunction3(13, _c18, ɵɵpipeBind1(6, 6, ctx_r1.enableAddToCart$), ɵɵpipeBind1(7, 8, "addToCart.buyItAgain"), addToCartBtn_r3)));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_div_1_Template, 4, 3, "div", 8)(2, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_2_Template, 7, 21, "ng-container", 1)(3, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_ng_container_3_Template, 8, 21, "ng-container", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1 == null ? null : order_r1.statusDisplay);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.deliveryUnConsignedEntries == null ? null : ctx_r1.deliveryUnConsignedEntries.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.pickupUnconsignedEntries == null ? null : ctx_r1.pickupUnconsignedEntries.length);
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_8_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 9)(1, "div", 10);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(3).ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "orderDetails.statusDisplay_" + (order_r1 == null ? null : order_r1.statusDisplay)), " ");
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_8_ng_template_4_Template(rf, ctx) {
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 15);
    ɵɵtemplate(2, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_8_div_2_Template, 4, 3, "div", 8);
    ɵɵelementStart(3, "div", 12);
    ɵɵtemplate(4, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_8_ng_template_4_Template, 0, 0, "ng-template", 13);
    ɵɵpipe(5, "async");
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext(2).ngIf;
    const addToCartBtn_r3 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", order_r1 == null ? null : order_r1.statusDisplay);
    ɵɵadvance(2);
    ɵɵproperty("cxAbstractOrderContext", ɵɵpureFunction2(8, _c10, order_r1.code, ctx_r1.abstractOrderType.ORDER))("cxOutlet", ctx_r1.CartOutlets.CART_ITEM_LIST)("cxOutletContext", ɵɵpureFunction3(15, _c19, order_r1.entries, ctx_r1.promotionLocation, ɵɵpureFunction3(11, _c18, ɵɵpipeBind1(5, 4, ctx_r1.enableAddToCart$), ɵɵpipeBind1(6, 6, "addToCart.buyItAgain"), addToCartBtn_r3)));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_1_Template, 2, 2, "ng-container", 1)(2, OrderDetailItemsComponent_ng_container_0_ng_container_1_div_2_Template, 3, 3, "div", 2)(3, OrderDetailItemsComponent_ng_container_0_ng_container_1_cx_order_consigned_entries_3_Template, 3, 8, "cx-order-consigned-entries", 3)(4, OrderDetailItemsComponent_ng_container_0_ng_container_1_4_Template, 1, 4, null, 1);
    ɵɵpipe(5, "async");
    ɵɵtemplate(6, OrderDetailItemsComponent_ng_container_0_ng_container_1_cx_order_consigned_entries_6_Template, 3, 8, "cx-order-consigned-entries", 3)(7, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_7_Template, 4, 3, "ng-container", 1)(8, OrderDetailItemsComponent_ng_container_0_ng_container_1_ng_container_8_Template, 7, 19, "ng-container", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", (order_r1.consignments == null ? null : order_r1.consignments.length) || (order_r1.unconsignedEntries == null ? null : order_r1.unconsignedEntries.length) || order_r1.replenishmentOrderCode);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.pickupConsignments == null ? null : ctx_r1.pickupConsignments.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.pickupConsignments);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.deliveryConsignments && ctx_r1.deliveryConsignments.length > 0 && ɵɵpipeBind1(5, 7, ctx_r1.groupCartItems$));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.deliveryConsignments);
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r1 == null ? null : order_r1.unconsignedEntries == null ? null : order_r1.unconsignedEntries.length);
    ɵɵadvance();
    ɵɵproperty("ngIf", (order_r1 == null ? null : order_r1.entries) && (order_r1 == null ? null : order_r1.replenishmentOrderCode));
  }
}
function OrderDetailItemsComponent_ng_container_0_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-add-to-cart", 16);
  }
  if (rf & 2) {
    const ctx_ir4 = ctx.$implicit;
    ɵɵproperty("productCode", ctx_ir4.item.product == null ? null : ctx_ir4.item.product.code)("product", ctx_ir4.item.product)("showQuantity", false)("options", ctx_ir4.options)("pickupStore", ctx_ir4.item.deliveryPointOfService == null ? null : ctx_ir4.item.deliveryPointOfService.name);
  }
}
function OrderDetailItemsComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderDetailItemsComponent_ng_container_0_ng_container_1_Template, 9, 9, "ng-container", 1);
    ɵɵpipe(2, "async");
    ɵɵtemplate(3, OrderDetailItemsComponent_ng_container_0_ng_template_3_Template, 1, 5, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !ɵɵpipeBind1(2, 1, ctx_r1.isOrderLoading$));
  }
}
function TrackingEventsComponent_ng_container_2_ng_container_9_ng_container_29_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 17);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignmentTracking_r4 = ɵɵnextContext(2).ngIf;
    ɵɵadvance();
    ɵɵproperty("href", consignmentTracking_r4.trackingUrl, ɵɵsanitizeUrl);
    ɵɵadvance();
    ɵɵtextInterpolate(consignmentTracking_r4 == null ? null : consignmentTracking_r4.trackingID);
  }
}
function TrackingEventsComponent_ng_container_2_ng_container_9_ng_container_30_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "label");
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignmentTracking_r4 = ɵɵnextContext(2).ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", consignmentTracking_r4 == null ? null : consignmentTracking_r4.trackingID, " ");
  }
}
function TrackingEventsComponent_ng_container_2_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 11)(2, "div", 12)(3, "div", 13)(4, "div", 14);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(7, "div", 15);
    ɵɵtext(8);
    ɵɵpipe(9, "cxDate");
    ɵɵelementEnd()();
    ɵɵelementStart(10, "div", 13)(11, "div", 14);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(14, "div", 15);
    ɵɵtext(15);
    ɵɵpipe(16, "cxDate");
    ɵɵelementEnd()()();
    ɵɵelementStart(17, "div", 12)(18, "div", 13)(19, "div", 14);
    ɵɵtext(20);
    ɵɵpipe(21, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(22, "div", 15);
    ɵɵtext(23);
    ɵɵelementEnd()();
    ɵɵelementStart(24, "div", 13)(25, "div", 14);
    ɵɵtext(26);
    ɵɵpipe(27, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(28, "div", 15);
    ɵɵtemplate(29, TrackingEventsComponent_ng_container_2_ng_container_9_ng_container_29_Template, 3, 2, "ng-container", 16)(30, TrackingEventsComponent_ng_container_2_ng_container_9_ng_container_30_Template, 3, 1, "ng-container", 16);
    ɵɵelementEnd()()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignmentTracking_r4 = ɵɵnextContext().ngIf;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 9, "orderDetails.consignmentTracking.dialog.shipped"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(9, 11, ctx_r2.shipDate, "medium"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 14, "orderDetails.consignmentTracking.dialog.estimate"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(16, 16, consignmentTracking_r4 == null ? null : consignmentTracking_r4.targetArrivalDate, "medium"), " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(21, 19, "orderDetails.consignmentTracking.dialog.carrier"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", consignmentTracking_r4 == null ? null : consignmentTracking_r4.carrierDetails == null ? null : consignmentTracking_r4.carrierDetails.name, " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(27, 21, "orderDetails.consignmentTracking.dialog.trackingId"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", consignmentTracking_r4 == null ? null : consignmentTracking_r4.trackingUrl);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(consignmentTracking_r4 == null ? null : consignmentTracking_r4.trackingUrl));
  }
}
function TrackingEventsComponent_ng_container_2_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 18)(2, "div", 19);
    ɵɵtext(3);
    ɵɵpipe(4, "cxDate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "div", 20);
    ɵɵtext(6);
    ɵɵelementEnd();
    ɵɵelementStart(7, "div", 19);
    ɵɵtext(8);
    ɵɵelementEnd();
    ɵɵelementStart(9, "div", 21);
    ɵɵtext(10);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignmentEvent_r5 = ctx.$implicit;
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(4, 4, consignmentEvent_r5.eventDate, "medium"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", consignmentEvent_r5.referenceCode, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", consignmentEvent_r5.detail, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" location: ", consignmentEvent_r5.location, " ");
  }
}
function TrackingEventsComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 5)(2, "div", 6);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "button", 7);
    ɵɵpipe(6, "cxTranslate");
    ɵɵlistener("click", function TrackingEventsComponent_ng_container_2_Template_button_click_5_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.close("Cross click"));
    });
    ɵɵelementStart(7, "span", 8);
    ɵɵtext(8, "×");
    ɵɵelementEnd()()();
    ɵɵtemplate(9, TrackingEventsComponent_ng_container_2_ng_container_9_Template, 31, 23, "ng-container", 4);
    ɵɵelementStart(10, "div", 9);
    ɵɵtemplate(11, TrackingEventsComponent_ng_container_2_ng_container_11_Template, 11, 7, "ng-container", 10);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignmentTracking_r4 = ctx.ngIf;
    ɵɵnextContext();
    const noTracking_r6 = ɵɵreference(5);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 5, "orderDetails.consignmentTracking.dialog.header"), " ");
    ɵɵadvance(2);
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 7, "common.close"));
    ɵɵadvance(4);
    ɵɵproperty("ngIf", (consignmentTracking_r4 == null ? null : consignmentTracking_r4.carrierDetails) && (consignmentTracking_r4 == null ? null : consignmentTracking_r4.trackingID))("ngIfElse", noTracking_r6);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", consignmentTracking_r4.trackingEvents);
  }
}
function TrackingEventsComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22)(1, "div", 15);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "orderDetails.consignmentTracking.dialog.noTracking"), " ");
  }
}
function TrackingEventsComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 23)(1, "div", 24)(2, "div", 25);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "button", 26);
    ɵɵpipe(6, "cxTranslate");
    ɵɵlistener("click", function TrackingEventsComponent_ng_template_6_Template_button_click_5_listener() {
      ɵɵrestoreView(_r7);
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.close("Cross click"));
    });
    ɵɵelementStart(7, "span", 8);
    ɵɵtext(8, "×");
    ɵɵelementEnd()()();
    ɵɵelementStart(9, "div", 27)(10, "div", 12)(11, "div", 28);
    ɵɵelement(12, "cx-spinner");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 2, "orderDetails.consignmentTracking.dialog.loadingHeader"), " ");
    ɵɵadvance(2);
    ɵɵattribute("aria-label", ɵɵpipeBind1(6, 4, "common.close"));
  }
}
function MyAccountV2ConsignmentTrackingComponent_div_0_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderDetails.deliveryStatus_" + ctx_r0.consignment.status), " ");
  }
}
function MyAccountV2ConsignmentTrackingComponent_div_0_span_3_span_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementStart(3, "a", 8);
    ɵɵlistener("click", function MyAccountV2ConsignmentTrackingComponent_div_0_span_3_span_1_Template_a_click_3_listener() {
      ɵɵrestoreView(_r2);
      const ctx_r0 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r0.openTrackingDialog(ctx_r0.consignment));
    });
    ɵɵtext(4);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 2, "orderDetails.consignmentTracking.dialog.trackingId"), ": ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ctx_r0.consignment.trackingID, " ");
  }
}
function MyAccountV2ConsignmentTrackingComponent_div_0_span_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 6);
    ɵɵtemplate(1, MyAccountV2ConsignmentTrackingComponent_div_0_span_3_span_1_Template, 5, 4, "span", 7);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵnextContext();
    const showNoTrackingMessage_r3 = ɵɵreference(6);
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.consignment.trackingID)("ngIfElse", showNoTrackingMessage_r3);
  }
}
function MyAccountV2ConsignmentTrackingComponent_div_0_span_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 9);
    ɵɵtext(1);
    ɵɵpipe(2, "cxDate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, ctx_r0.consignment.statusDate), " ");
  }
}
function MyAccountV2ConsignmentTrackingComponent_div_0_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "a", 8);
    ɵɵlistener("click", function MyAccountV2ConsignmentTrackingComponent_div_0_ng_template_5_Template_a_click_0_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r0 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r0.openTrackingDialog(ctx_r0.consignment));
    });
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderDetails.consignmentTracking.action"), " ");
  }
}
function MyAccountV2ConsignmentTrackingComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 2)(1, "span");
    ɵɵtemplate(2, MyAccountV2ConsignmentTrackingComponent_div_0_span_2_Template, 3, 3, "span", 3)(3, MyAccountV2ConsignmentTrackingComponent_div_0_span_3_Template, 2, 2, "span", 4);
    ɵɵelementEnd();
    ɵɵtemplate(4, MyAccountV2ConsignmentTrackingComponent_div_0_span_4_Template, 3, 3, "span", 5)(5, MyAccountV2ConsignmentTrackingComponent_div_0_ng_template_5_Template, 3, 3, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_3_0;
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.consignment.status);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.consignmentStatus.includes((tmp_3_0 = ctx_r0.consignment.status) !== null && tmp_3_0 !== void 0 ? tmp_3_0 : ""));
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.consignment == null ? null : ctx_r0.consignment.statusDate);
  }
}
function OrderDetailReorderComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2)(2, "div", 3)(3, "button", 4, 0);
    ɵɵlistener("click", function OrderDetailReorderComponent_ng_container_0_ng_container_1_Template_button_click_3_listener() {
      ɵɵrestoreView(_r1);
      const order_r2 = ɵɵnextContext().ngIf;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onReorderClick(order_r2));
    });
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 1, "reorder.button"), " ");
  }
}
function OrderDetailReorderComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderDetailReorderComponent_ng_container_0_ng_container_1_Template, 7, 3, "ng-container", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r2 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", order_r2.code);
  }
}
var _c21 = (a0, a1, a2, a3) => ({
  quantity: a0,
  quantityAdded: a1,
  productCode: a2,
  productName: a3
});
function ReorderDialogComponent_ng_container_13_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 14)(2, "p");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "div", 15)(6, "div", 16)(7, "div", 17)(8, "button", 18);
    ɵɵlistener("click", function ReorderDialogComponent_ng_container_13_ng_container_1_Template_button_click_8_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.close("Cancel creating cart from order"));
    });
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(11, "button", 19);
    ɵɵlistener("click", function ReorderDialogComponent_ng_container_13_ng_container_1_Template_button_click_11_listener() {
      ɵɵrestoreView(_r1);
      const data_r3 = ɵɵnextContext().ngIf;
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.createCartFromOrder(data_r3.orderCode));
    });
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd()()()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 3, "reorder.dialog.areYouSureToReplaceCart"), " ");
    ɵɵadvance(6);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 5, "reorder.dialog.cancel"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 7, "reorder.dialog.continue"), " ");
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "span", 21)(2, "span", 22);
    ɵɵelement(3, "cx-icon", 23);
    ɵɵelementEnd();
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵadvance(3);
    ɵɵproperty("type", ctx_r1.iconTypes.SUCCESS);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 2, "reorder.dialog.messages.success"), " ");
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_span_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "span", 22);
    ɵɵelement(2, "cx-icon", 25);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(6);
    ɵɵadvance(2);
    ɵɵproperty("type", ctx_r1.iconTypes.INFO);
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_span_0_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 22);
    ɵɵelement(1, "cx-icon", 26);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(6);
    ɵɵadvance();
    ɵɵproperty("type", ctx_r1.iconTypes.ERROR);
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_span_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 21);
    ɵɵtemplate(1, ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_span_0_ng_container_1_Template, 3, 1, "ng-container", 13)(2, ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_span_0_ng_template_2_Template, 2, 1, "ng-template", null, 3, ɵɵtemplateRefExtractor);
    ɵɵelementStart(4, "span");
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const cartModification_r4 = ctx.$implicit;
    const errorIcon_r5 = ɵɵreference(3);
    const ctx_r1 = ɵɵnextContext(5);
    ɵɵadvance();
    ɵɵproperty("ngIf", cartModification_r4.statusCode === ctx_r1.cartValidationStatusCode.LOW_STOCK)("ngIfElse", errorIcon_r5);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(6, 3, "reorder.dialog.messages." + cartModification_r4.statusCode, ɵɵpureFunction4(6, _c21, cartModification_r4.quantity, cartModification_r4.quantityAdded, cartModification_r4.entry.product.code, cartModification_r4.entry.product.name)), " ");
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_span_0_Template, 7, 11, "span", 24);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵproperty("ngForOf", ctx_r1.cartModifications);
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "p", 20);
    ɵɵtemplate(2, ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_container_2_Template, 6, 4, "ng-container", 13)(3, ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_ng_template_3_Template, 1, 1, "ng-template", null, 2, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const cartResponse_r6 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !(ctx_r1.cartModifications == null ? null : ctx_r1.cartModifications.length))("ngIfElse", cartResponse_r6);
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 27);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
function ReorderDialogComponent_ng_container_13_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ReorderDialogComponent_ng_container_13_ng_template_3_ng_container_0_Template, 5, 2, "ng-container", 13);
    ɵɵpipe(1, "async");
    ɵɵtemplate(2, ReorderDialogComponent_ng_container_13_ng_template_3_ng_template_2_Template, 2, 0, "ng-template", null, 1, ɵɵtemplateRefExtractor);
  }
  if (rf & 2) {
    const loading_r7 = ɵɵreference(3);
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", !ɵɵpipeBind1(1, 2, ctx_r1.loading$))("ngIfElse", loading_r7);
  }
}
function ReorderDialogComponent_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, ReorderDialogComponent_ng_container_13_ng_container_1_Template, 14, 9, "ng-container", 13);
    ɵɵpipe(2, "async");
    ɵɵtemplate(3, ReorderDialogComponent_ng_container_13_ng_template_3_Template, 4, 4, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const result_r8 = ɵɵreference(4);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(2, 2, ctx_r1.showDecisionPrompt$))("ngIfElse", result_r8);
  }
}
function OrderDetailTotalsComponent_ng_container_0_ng_template_3_Template(rf, ctx) {
}
function OrderDetailTotalsComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "div", 2);
    ɵɵtemplate(3, OrderDetailTotalsComponent_ng_container_0_ng_template_3_Template, 0, 0, "ng-template", 3);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r1 = ctx.ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵproperty("cxOutlet", ctx_r1.CartOutlets.ORDER_SUMMARY)("cxOutletContext", order_r1);
  }
}
var _c22 = (a0, a1) => ({
  orderHistory: a0,
  replenishmentOrder: a1
});
var _c23 = (a0) => ({
  "cx-order-history-table-po": a0
});
function OrderHistoryComponent_ng_container_0_ng_container_1_h4_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h4");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderHistory.replenishmentHistory"), " ");
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_h2_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h2");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "orderHistory.orderHistory"), " ");
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 18)(1, "cx-pagination", 19);
    ɵɵlistener("viewPageEvent", function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_div_10_Template_cx_pagination_viewPageEvent_1_listener($event) {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const type_r4 = ɵɵnextContext(3).ngIf;
    ɵɵadvance();
    ɵɵproperty("pagination", type_r4.orderHistory.pagination);
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_ng_container_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "th", 15);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "th", 15);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "orderHistory.PONumber"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 4, "orderHistory.costCenter"), " ");
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_ng_container_8_a_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 23);
    ɵɵpipe(1, "cxUrl");
    ɵɵtext(2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r6 = ɵɵnextContext(2).$implicit;
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵproperty("routerLink", ɵɵpipeBind1(1, 3, ɵɵpureFunction1(5, _c4, order_r6)))("queryParams", ctx_r1.getQueryParams(order_r6));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", order_r6.purchaseOrderNumber, "");
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_ng_container_8_a_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 23);
    ɵɵpipe(1, "cxUrl");
    ɵɵtext(2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const order_r6 = ɵɵnextContext(2).$implicit;
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵproperty("routerLink", ɵɵpipeBind1(1, 3, ɵɵpureFunction1(5, _c4, order_r6)))("queryParams", ctx_r1.getQueryParams(order_r6));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", order_r6.costCenter == null ? null : order_r6.costCenter.name, "");
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "td", 27)(2, "div", 22);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(5, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_ng_container_8_a_5_Template, 3, 7, "a", 28);
    ɵɵelementEnd();
    ɵɵelementStart(6, "td", 29)(7, "div", 22);
    ɵɵtext(8);
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(10, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_ng_container_8_a_10_Template, 3, 7, "a", 28);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r6 = ɵɵnextContext().$implicit;
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 4, "orderHistory.PONumber"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", order_r6.purchaseOrderNumber);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 6, "orderHistory.costCenter"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", order_r6.costCenter == null ? null : order_r6.costCenter.name);
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "tr", 20);
    ɵɵlistener("click", function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_Template_tr_click_0_listener() {
      const order_r6 = ɵɵrestoreView(_r5).$implicit;
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.goToOrderDetail(order_r6));
    });
    ɵɵelementStart(1, "td", 21)(2, "div", 22);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "a", 23);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵelementEnd()();
    ɵɵtemplate(8, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_ng_container_8_Template, 11, 8, "ng-container", 2);
    ɵɵelementStart(9, "td", 24)(10, "div", 22);
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(13, "a", 23);
    ɵɵpipe(14, "cxUrl");
    ɵɵtext(15);
    ɵɵpipe(16, "cxDate");
    ɵɵelementEnd()();
    ɵɵelementStart(17, "td", 25)(18, "div", 22);
    ɵɵtext(19);
    ɵɵpipe(20, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(21, "a", 23);
    ɵɵpipe(22, "cxUrl");
    ɵɵtext(23);
    ɵɵpipe(24, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(25, "td", 26)(26, "div", 22);
    ɵɵtext(27);
    ɵɵpipe(28, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(29, "a", 23);
    ɵɵpipe(30, "cxUrl");
    ɵɵtext(31);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const order_r6 = ctx.$implicit;
    const ctx_r1 = ɵɵnextContext(4);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 17, "orderHistory.orderId"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 19, ɵɵpureFunction1(38, _c4, order_r6)))("queryParams", ctx_r1.getQueryParams(order_r6));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", order_r6 == null ? null : order_r6.code, "");
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.hasPONumber);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(12, 21, "orderHistory.date"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(14, 23, ɵɵpureFunction1(40, _c4, order_r6)))("queryParams", ctx_r1.getQueryParams(order_r6));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind2(16, 25, order_r6 == null ? null : order_r6.placed, "longDate"));
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(20, 28, "orderHistory.status"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(22, 30, ɵɵpureFunction1(42, _c4, order_r6)))("queryParams", ctx_r1.getQueryParams(order_r6));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(24, 32, "orderDetails.statusDisplay_" + (order_r6 == null ? null : order_r6.statusDisplay)), "");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(28, 34, "orderHistory.total"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(30, 36, ɵɵpureFunction1(44, _c4, order_r6)))("queryParams", ctx_r1.getQueryParams(order_r6));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", order_r6 == null ? null : order_r6.total.formattedValue, "");
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 18)(1, "cx-pagination", 19);
    ɵɵlistener("viewPageEvent", function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_div_33_Template_cx_pagination_viewPageEvent_1_listener($event) {
      ɵɵrestoreView(_r7);
      const ctx_r1 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const type_r4 = ɵɵnextContext(3).ngIf;
    ɵɵadvance();
    ɵɵproperty("pagination", type_r4.orderHistory.pagination);
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 7)(2, "label", 8)(3, "span");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(6, "cx-sorting", 9);
    ɵɵpipe(7, "cxTranslate");
    ɵɵpipe(8, "async");
    ɵɵpipe(9, "cxTranslate");
    ɵɵlistener("sortListEvent", function OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_Template_cx_sorting_sortListEvent_6_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.changeSortCode($event));
    });
    ɵɵelementEnd()();
    ɵɵtemplate(10, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_div_10_Template, 2, 1, "div", 10);
    ɵɵelementEnd();
    ɵɵelementStart(11, "table", 11)(12, "caption", 12);
    ɵɵtext(13);
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(15, "thead", 13)(16, "tr", 14)(17, "th", 15);
    ɵɵtext(18);
    ɵɵpipe(19, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(20, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_ng_container_20_Template, 7, 6, "ng-container", 2);
    ɵɵelementStart(21, "th", 15);
    ɵɵtext(22);
    ɵɵpipe(23, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(24, "th", 15);
    ɵɵtext(25);
    ɵɵpipe(26, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(27, "th", 15);
    ɵɵtext(28);
    ɵɵpipe(29, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelementStart(30, "tbody");
    ɵɵtemplate(31, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_tr_31_Template, 32, 46, "tr", 16);
    ɵɵelementEnd()();
    ɵɵelementStart(32, "div", 17);
    ɵɵtemplate(33, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_div_33_Template, 2, 1, "div", 10);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const type_r4 = ɵɵnextContext(2).ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 16, "orderHistory.sortBy"), " ");
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(7, 18, "orderHistory.sortBy"));
    ɵɵproperty("sortOptions", type_r4.orderHistory.sorts)("sortLabels", ɵɵpipeBind1(8, 20, ctx_r1.getSortLabels()))("selectedOption", type_r4.orderHistory.pagination.sort)("ariaLabel", ɵɵpipeBind1(9, 22, "orderHistory.sortOrders"));
    ɵɵadvance(4);
    ɵɵproperty("ngIf", type_r4.orderHistory.pagination.totalPages > 1);
    ɵɵadvance();
    ɵɵproperty("ngClass", ɵɵpureFunction1(34, _c23, ctx_r1.hasPONumber));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 24, "orderHistory.orderHistory"), " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 26, "orderHistory.orderId"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.hasPONumber);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(23, 28, "orderHistory.date"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(26, 30, "orderHistory.status"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(29, 32, "orderHistory.total"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngForOf", type_r4.orderHistory.orders);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", type_r4.orderHistory.pagination.totalPages > 1);
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_div_0_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 1, "orderHistory.notFound"));
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_div_0_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(3, "a", 31);
    ɵɵpipe(4, "cxUrl");
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate(ɵɵpipeBind1(2, 3, "orderHistory.noOrders"));
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(4, 5, ɵɵpureFunction0(9, _c7)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(6, 7, "orderHistory.startShopping"));
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 4)(1, "div");
    ɵɵtemplate(2, OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_div_0_ng_container_2_Template, 4, 3, "ng-container", 6)(3, OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_div_0_ng_template_3_Template, 7, 10, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const otherOrder_r8 = ɵɵreference(4);
    const type_r4 = ɵɵnextContext(3).ngIf;
    ɵɵproperty("ngClass", type_r4.replenishmentOrder ? "cx-replenishment-details-order-history-no-order" : "cx-order-history-no-order");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", type_r4.replenishmentOrder)("ngIfElse", otherOrder_r8);
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_div_0_Template, 5, 3, "div", 30);
    ɵɵpipe(1, "async");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx_r1.isLoaded$));
  }
}
function OrderHistoryComponent_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 3)(2, "div", 4);
    ɵɵtemplate(3, OrderHistoryComponent_ng_container_0_ng_container_1_h4_3_Template, 3, 3, "h4", 2)(4, OrderHistoryComponent_ng_container_0_ng_container_1_h2_4_Template, 3, 3, "h2", 2);
    ɵɵelementEnd();
    ɵɵelementStart(5, "div", 5);
    ɵɵtemplate(6, OrderHistoryComponent_ng_container_0_ng_container_1_ng_container_6_Template, 34, 36, "ng-container", 6)(7, OrderHistoryComponent_ng_container_0_ng_container_1_ng_template_7_Template, 2, 3, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const noOrder_r9 = ɵɵreference(8);
    const type_r4 = ɵɵnextContext().ngIf;
    ɵɵadvance(2);
    ɵɵproperty("ngClass", type_r4.replenishmentOrder ? "cx-replenishment-details-order-history-header" : "cx-order-history-header");
    ɵɵadvance();
    ɵɵproperty("ngIf", type_r4.replenishmentOrder);
    ɵɵadvance();
    ɵɵproperty("ngIf", !type_r4.replenishmentOrder);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", type_r4.orderHistory.pagination.totalResults > 0)("ngIfElse", noOrder_r9);
  }
}
function OrderHistoryComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, OrderHistoryComponent_ng_container_0_ng_container_1_Template, 9, 5, "ng-container", 2);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const type_r4 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngIf", type_r4.orderHistory);
  }
}
var _c24 = (a0) => ({
  param: a0
});
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_ng_container_1_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 7);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const tracking_r1 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("href", tracking_r1.trackingUrl, ɵɵsanitizeUrl);
    ɵɵadvance();
    ɵɵtextInterpolate(tracking_r1.trackingID);
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_ng_container_1_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0);
  }
  if (rf & 2) {
    const tracking_r1 = ɵɵnextContext().ngIf;
    ɵɵtextInterpolate1(" ", tracking_r1.trackingID, " ");
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "span");
    ɵɵpipe(2, "cxTranslate");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵtemplate(5, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_ng_container_1_ng_container_5_Template, 3, 2, "ng-container", 5);
    ɵɵtext(6, " | ");
    ɵɵelementEnd();
    ɵɵelementStart(7, "span");
    ɵɵpipe(8, "cxTranslate");
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵpipe(11, "cxDate");
    ɵɵelementEnd();
    ɵɵtemplate(12, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_ng_container_1_ng_template_12_Template, 1, 1, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const tracking_r1 = ctx.ngIf;
    const showNumber_r2 = ɵɵreference(13);
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 7, "orderDetails.consignmentTracking.dialog.trackingId"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 9, "orderDetails.consignmentTracking.dialog.trackingId"), ": ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", tracking_r1.trackingUrl)("ngIfElse", showNumber_r2);
    ɵɵadvance(2);
    ɵɵattribute("aria-label", ɵɵpipeBind1(8, 11, "myAccountV2OrderHistory.estimateDeliveryLabel"));
    ɵɵadvance(2);
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(10, 13, "orderDetails.consignmentTracking.dialog.estimate"), ": ", ɵɵpipeBind2(11, 15, tracking_r1.targetArrivalDate, "d, MMMM, yyyy"), " ");
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_ng_container_1_Template, 14, 18, "ng-container", 6);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignment_r3 = ɵɵnextContext(2).$implicit;
    ɵɵadvance();
    ɵɵproperty("ngIf", consignment_r3.consignmentTracking);
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_template_8_span_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const consignment_r3 = ɵɵnextContext(3).$implicit;
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 2, "myAccountV2OrderHistory.consignmentStatusLabel"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "orderDetails.deliveryStatus_" + (consignment_r3 == null ? null : consignment_r3.status == null ? null : consignment_r3.status.toUpperCase())), " ");
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_template_8_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2);
    ɵɵpipe(3, "cxDate");
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const consignment_r3 = ɵɵnextContext(3).$implicit;
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 2, "myAccountV2OrderHistory.consignmentStatusDateLabel"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" | ", ɵɵpipeBind2(4, 7, "myAccountV2OrderHistory.statusDate", ɵɵpureFunction1(10, _c24, ɵɵpipeBind2(3, 4, consignment_r3.statusDate, "d, MMMM, yyyy"))), " ");
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_template_8_span_0_Template, 4, 6, "span", 6)(1, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_template_8_span_1_Template, 5, 12, "span", 6);
  }
  if (rf & 2) {
    const consignment_r3 = ɵɵnextContext(2).$implicit;
    ɵɵproperty("ngIf", consignment_r3.status);
    ɵɵadvance();
    ɵɵproperty("ngIf", consignment_r3.statusDate);
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 4);
    ɵɵpipe(1, "cxTranslate");
    ɵɵelementStart(2, "span");
    ɵɵpipe(3, "cxTranslate");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtext(6, " | ");
    ɵɵtemplate(7, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_container_7_Template, 2, 1, "ng-container", 5)(8, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_ng_template_8_Template, 2, 2, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const showLastUpdated_r4 = ɵɵreference(9);
    const ctx_r4 = ɵɵnextContext();
    const consignment_r3 = ctx_r4.$implicit;
    const i_r6 = ctx_r4.index;
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 5, "myAccountV2OrderHistory.consignmentDetailLabel"));
    ɵɵadvance(2);
    ɵɵattribute("aria-label", ɵɵpipeBind1(3, 7, "myAccountV2OrderHistory.consignmentNumberLabel"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(5, 9, "myAccountV2OrderHistory.consignmentCode", ɵɵpureFunction1(12, _c24, i_r6 + 1)), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", consignment_r3.trackingID)("ngIfElse", showLastUpdated_r4);
  }
}
function MyAccountV2ConsignmentEntriesComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, MyAccountV2ConsignmentEntriesComponent_ng_container_0_div_1_Template, 10, 14, "div", 3);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const consignment_r3 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("ngIf", consignment_r3);
  }
}
var _c25 = (a0) => ({
  count: a0
});
var _c26 = (a0) => ({
  cxRoute: "returnRequestDetails",
  params: a0
});
var _c27 = () => ({
  param: 1
});
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_2_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 10);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵtemplate(4, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_2_ng_container_4_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
    ɵɵelement(5, "cx-my-account-v2-consignment-entries", 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_6_0;
    let tmp_7_0;
    let tmp_8_0;
    const ctx_r0 = ɵɵnextContext(2);
    const showManyItems_r2 = ɵɵreference(2);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 5, "myAccountV2OrderHistory.deliveryPointOfServiceDetails.itemsToBePickUp"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", showManyItems_r2)("ngTemplateOutletContext", ɵɵpureFunction1(8, _c25, ctx_r0.getConsignmentsCount(ctx_r0.getPickupConsignments((tmp_6_0 = ctx_r0.order.consignments) !== null && tmp_6_0 !== void 0 ? tmp_6_0 : ɵɵpureFunction0(7, _c9)))));
    ɵɵadvance();
    ɵɵproperty("orderCode", (tmp_7_0 = ctx_r0.order.code) !== null && tmp_7_0 !== void 0 ? tmp_7_0 : "")("consignments", ctx_r0.getPickupConsignments((tmp_8_0 = ctx_r0.order.consignments) !== null && tmp_8_0 !== void 0 ? tmp_8_0 : ɵɵpureFunction0(10, _c9)));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_3_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 10);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵtemplate(4, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_3_ng_container_4_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
    ɵɵelement(5, "cx-my-account-v2-consignment-entries", 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_6_0;
    let tmp_7_0;
    let tmp_8_0;
    const ctx_r0 = ɵɵnextContext(2);
    const showManyItems_r2 = ɵɵreference(2);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 5, "myAccountV2OrderHistory.checkoutMode.deliveryEntries"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", showManyItems_r2)("ngTemplateOutletContext", ɵɵpureFunction1(8, _c25, ctx_r0.getConsignmentsCount(ctx_r0.getDeliveryConsignments((tmp_6_0 = ctx_r0.order.consignments) !== null && tmp_6_0 !== void 0 ? tmp_6_0 : ɵɵpureFunction0(7, _c9)))));
    ɵɵadvance();
    ɵɵproperty("orderCode", (tmp_7_0 = ctx_r0.order.code) !== null && tmp_7_0 !== void 0 ? tmp_7_0 : "")("consignments", ctx_r0.getDeliveryConsignments((tmp_8_0 = ctx_r0.order.consignments) !== null && tmp_8_0 !== void 0 ? tmp_8_0 : ɵɵpureFunction0(10, _c9)));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_div_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵtemplate(3, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_div_1_ng_container_3_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    const showManyItems_r2 = ɵɵreference(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 3, "orderDetails.statusDisplay_" + ctx_r0.order.statusDisplay), " - ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", showManyItems_r2)("ngTemplateOutletContext", ɵɵpureFunction1(5, _c25, ctx_r0.getOrderEntriesCount(ctx_r0.order.unconsignedEntries)));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_ng_template_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 10);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵtemplate(3, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_ng_template_2_ng_container_3_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(4);
    const showManyItems_r2 = ɵɵreference(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 3, "orderDetails.statusDisplay_" + ctx_r0.order.statusDisplay), " - ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", showManyItems_r2)("ngTemplateOutletContext", ɵɵpureFunction1(5, _c25, ctx_r0.getOrderEntriesCount(ctx_r0.order.unconsignedEntries)));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_div_1_Template, 4, 7, "div", 14)(2, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_ng_template_2_Template, 4, 7, "ng-template", null, 2, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const nonCritical_r3 = ɵɵreference(3);
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.isStatusCritical(ctx_r0.order.statusDisplay))("ngIfElse", nonCritical_r3);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 16);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵtemplate(3, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_2_ng_container_3_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_7_0;
    const ctx_r0 = ɵɵnextContext(3);
    const showManyItems_r2 = ɵɵreference(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 3, "myAccountV2OrderHistory.checkoutMode.deliveryEntries"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", showManyItems_r2)("ngTemplateOutletContext", ɵɵpureFunction1(6, _c25, ctx_r0.getOrderEntriesCount(ctx_r0.getDeliveryUnconsignedEntries((tmp_7_0 = ctx_r0.order.unconsignedEntries) !== null && tmp_7_0 !== void 0 ? tmp_7_0 : ɵɵpureFunction0(5, _c9)))));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_3_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 16);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵtemplate(3, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_3_ng_container_3_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_7_0;
    const ctx_r0 = ɵɵnextContext(3);
    const showManyItems_r2 = ɵɵreference(2);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 3, "myAccountV2OrderHistory.checkoutPickupInStore.heading"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", showManyItems_r2)("ngTemplateOutletContext", ɵɵpureFunction1(6, _c25, ctx_r0.getOrderEntriesCount(ctx_r0.getPickupUnconsignedEntries((tmp_7_0 = ctx_r0.order.unconsignedEntries) !== null && tmp_7_0 !== void 0 ? tmp_7_0 : ɵɵpureFunction0(5, _c9)))));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_1_Template, 4, 2, "div", 7)(2, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_2_Template, 4, 8, "div", 13)(3, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_div_3_Template, 4, 8, "div", 13);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    let tmp_5_0;
    let tmp_6_0;
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.order.statusDisplay);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.getOrderEntriesCount(ctx_r0.getDeliveryUnconsignedEntries((tmp_5_0 = ctx_r0.order.unconsignedEntries) !== null && tmp_5_0 !== void 0 ? tmp_5_0 : ɵɵpureFunction0(3, _c9))) > 0);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.getOrderEntriesCount(ctx_r0.getPickupUnconsignedEntries((tmp_6_0 = ctx_r0.order.unconsignedEntries) !== null && tmp_6_0 !== void 0 ? tmp_6_0 : ɵɵpureFunction0(4, _c9))) > 0);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_a_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 18);
    ɵɵpipe(1, "cxUrl");
    ɵɵtext(2);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const returnRequest_r4 = ɵɵnextContext().$implicit;
    ɵɵproperty("routerLink", ɵɵpipeBind1(1, 2, ɵɵpureFunction1(4, _c26, returnRequest_r4)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", returnRequest_r4.rma, "");
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0);
  }
  if (rf & 2) {
    const returnRequest_r4 = ɵɵnextContext().$implicit;
    ɵɵtextInterpolate1(" ", returnRequest_r4.code, " ");
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_div_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 16);
    ɵɵtext(1);
    ɵɵpipe(2, "cxDate");
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const creationTime_r5 = ctx.ngIf;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(3, 4, "myAccountV2OrderHistory.returnProcessed", ɵɵpureFunction1(7, _c24, ɵɵpipeBind2(2, 1, creationTime_r5, "d, MMMM, yyyy"))), " ");
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div", 15);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵtemplate(4, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_a_4_Template, 3, 6, "a", 17);
    ɵɵelementEnd();
    ɵɵtemplate(5, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_ng_template_5_Template, 1, 1, "ng-template", null, 3, ɵɵtemplateRefExtractor)(7, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_div_7_Template, 4, 9, "div", 13);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const returnRequest_r4 = ctx.$implicit;
    const showReturnCode_r6 = ɵɵreference(6);
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "returnRequestList.returnRequestId"), " ");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", returnRequest_r4.rma)("ngIfElse", showReturnCode_r6);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", returnRequest_r4.creationTime);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_ng_container_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelement(1, "cx-media", 19);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const item_r7 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("container", item_r7.PRIMARY);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, MyAccountV2OrderConsolidatedInformationComponent_div_0_ng_container_7_ng_container_1_Template, 2, 1, "ng-container", 8);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r0.getProductImages(ctx_r0.order.entries));
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5)(1, "div", 6);
    ɵɵtemplate(2, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_2_Template, 6, 11, "div", 7)(3, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_3_Template, 6, 11, "div", 7)(4, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_4_Template, 4, 5, "div", 7)(5, MyAccountV2OrderConsolidatedInformationComponent_div_0_div_5_Template, 8, 6, "div", 8);
    ɵɵelementEnd();
    ɵɵelementStart(6, "div", 9);
    ɵɵtemplate(7, MyAccountV2OrderConsolidatedInformationComponent_div_0_ng_container_7_Template, 2, 1, "ng-container", 7);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    let tmp_3_0;
    let tmp_4_0;
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.getConsignmentsCount(ctx_r0.getPickupConsignments((tmp_3_0 = ctx_r0.order.consignments) !== null && tmp_3_0 !== void 0 ? tmp_3_0 : ɵɵpureFunction0(5, _c9))) > 0);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.getConsignmentsCount(ctx_r0.getDeliveryConsignments((tmp_4_0 = ctx_r0.order.consignments) !== null && tmp_4_0 !== void 0 ? tmp_4_0 : ɵɵpureFunction0(6, _c9))) > 0);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.getOrderEntriesCount(ctx_r0.order.unconsignedEntries) > 0);
    ɵɵadvance();
    ɵɵproperty("ngForOf", ctx_r0.order.returnRequests);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.order.entries);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const count_r8 = ɵɵnextContext().count;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(2, 1, "myAccountV2OrderHistory.items", ɵɵpureFunction1(4, _c24, count_r8)), " ");
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, MyAccountV2OrderConsolidatedInformationComponent_ng_template_1_ng_container_0_Template, 3, 6, "ng-container", 20);
  }
  if (rf & 2) {
    const count_r8 = ctx.count;
    ɵɵnextContext();
    const showOneItem_r9 = ɵɵreference(4);
    ɵɵproperty("ngIf", count_r8 > 1)("ngIfElse", showOneItem_r9);
  }
}
function MyAccountV2OrderConsolidatedInformationComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(1, 1, "myAccountV2OrderHistory.item", ɵɵpureFunction0(4, _c27)), "\n");
  }
}
function MyAccountV2OrderHistoryComponent_div_0_ng_container_8_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 7)(2, "div", 8);
    ɵɵpipe(3, "cxTranslate");
    ɵɵlistener("click", function MyAccountV2OrderHistoryComponent_div_0_ng_container_8_ng_container_1_Template_div_click_2_listener() {
      const order_r2 = ɵɵrestoreView(_r1).$implicit;
      const ctx_r2 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r2.goToOrderDetail(order_r2));
    });
    ɵɵelementStart(4, "a", 9);
    ɵɵpipe(5, "cxUrl");
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(8, "div", 10)(9, "span");
    ɵɵpipe(10, "cxTranslate");
    ɵɵtext(11);
    ɵɵpipe(12, "cxDate");
    ɵɵelementEnd();
    ɵɵelementStart(13, "span");
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementStart(15, "strong");
    ɵɵtext(16);
    ɵɵpipe(17, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelement(18, "cx-my-account-v2-order-consolidated-information", 11);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const order_r2 = ctx.$implicit;
    const ctx_r2 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵattribute("aria-label", ɵɵpipeBind1(3, 10, "myAccountV2OrderHistory.orderCodeLabel"));
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(5, 12, ɵɵpureFunction1(26, _c4, order_r2)))("queryParams", ctx_r2.getQueryParams(order_r2));
    ɵɵadvance(2);
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(7, 14, "orderHistory.orderId"), " ", order_r2 == null ? null : order_r2.code, "");
    ɵɵadvance(3);
    ɵɵattribute("aria-label", ɵɵpipeBind1(10, 16, "myAccountV2OrderHistory.orderPlaced"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(12, 18, order_r2.placed, "d, MMMM, yyyy"), " | ");
    ɵɵadvance(2);
    ɵɵattribute("aria-label", ɵɵpipeBind1(14, 21, "myAccountV2OrderHistory.totalPriceLabel"));
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(17, 23, "myAccountV2OrderHistory.totalPrice", ɵɵpureFunction1(28, _c24, order_r2.total == null ? null : order_r2.total.formattedValue)), " ");
    ɵɵadvance(2);
    ɵɵproperty("order", order_r2);
  }
}
function MyAccountV2OrderHistoryComponent_div_0_ng_container_8_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 12);
    ɵɵpipe(1, "cxTranslate");
    ɵɵelementStart(2, "cx-pagination", 13);
    ɵɵlistener("viewPageEvent", function MyAccountV2OrderHistoryComponent_div_0_ng_container_8_div_2_Template_cx_pagination_viewPageEvent_2_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r2.pageChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const orderHistory_r5 = ɵɵnextContext(2).ngIf;
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 2, "myAccountV2OrderHistory.orderListPagination"));
    ɵɵadvance(2);
    ɵɵproperty("pagination", orderHistory_r5.pagination);
  }
}
function MyAccountV2OrderHistoryComponent_div_0_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, MyAccountV2OrderHistoryComponent_div_0_ng_container_8_ng_container_1_Template, 19, 30, "ng-container", 5)(2, MyAccountV2OrderHistoryComponent_div_0_ng_container_8_div_2_Template, 3, 4, "div", 6);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const orderHistory_r5 = ɵɵnextContext().ngIf;
    ɵɵadvance();
    ɵɵproperty("ngForOf", orderHistory_r5.orders);
    ɵɵadvance();
    ɵɵproperty("ngIf", orderHistory_r5.pagination.totalPages > 1);
  }
}
function MyAccountV2OrderHistoryComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵpipe(1, "cxTranslate");
    ɵɵelementStart(2, "div", 3)(3, "h2");
    ɵɵtext(4);
    ɵɵpipe(5, "async");
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(7, "div", 4);
    ɵɵtemplate(8, MyAccountV2OrderHistoryComponent_div_0_ng_container_8_Template, 3, 2, "ng-container", 2);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const orderHistory_r5 = ctx.ngIf;
    const ctx_r2 = ɵɵnextContext();
    const noOrder_r6 = ɵɵreference(3);
    ɵɵattribute("aria-label", ɵɵpipeBind1(1, 4, "myAccountV2OrderHistory.orderListResults"));
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(6, 8, "myAccountV2OrderHistory.heading", ɵɵpureFunction1(11, _c24, ɵɵpipeBind1(5, 6, ctx_r2.tabTitleParam$))), " ");
    ɵɵadvance(4);
    ɵɵproperty("ngIf", orderHistory_r5.pagination.totalResults > 0)("ngIfElse", noOrder_r6);
  }
}
function MyAccountV2OrderHistoryComponent_ng_template_2_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "div");
    ɵɵpipe(2, "cxTranslate");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "a", 14);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵattribute("aria-label", ɵɵpipeBind1(2, 4, "orderHistory.notFound"));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 6, "orderHistory.noOrders"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 8, ɵɵpureFunction0(12, _c7)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(8, 10, "orderHistory.startShopping"));
  }
}
function MyAccountV2OrderHistoryComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, MyAccountV2OrderHistoryComponent_ng_template_2_div_0_Template, 9, 13, "div", 2);
    ɵɵpipe(1, "async");
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    const loading_r7 = ɵɵreference(5);
    ɵɵproperty("ngIf", ɵɵpipeBind1(1, 2, ctx_r2.isLoaded$))("ngIfElse", loading_r7);
  }
}
function MyAccountV2OrderHistoryComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵelement(1, "cx-spinner");
    ɵɵelementEnd();
  }
}
var _c28 = () => ({
  cxRoute: "replenishmentOrders"
});
function ReplenishmentOrderCancellationComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 2)(1, "button", 5, 0);
    ɵɵlistener("click", function ReplenishmentOrderCancellationComponent_div_6_Template_button_click_1_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.openDialog());
    });
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 1, "orderDetails.cancelReplenishment.title"), " ");
  }
}
var _c29 = (a0) => ({
  cxRoute: "replenishmentDetails",
  params: a0
});
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 16)(1, "cx-pagination", 18);
    ɵɵlistener("viewPageEvent", function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_div_10_Template_cx_pagination_viewPageEvent_1_listener($event) {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const replenishmentOrders_r4 = ɵɵnextContext(2).ngIf;
    ɵɵadvance();
    ɵɵproperty("pagination", replenishmentOrders_r4.pagination);
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_thead_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead", 19)(1, "th", 20)(2, "span", 21);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(5, "th", 20)(6, "span", 21);
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(9, "th", 20)(10, "span", 21);
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(13, "th", 20)(14, "span", 21);
    ɵɵtext(15);
    ɵɵpipe(16, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(17, "th", 20)(18, "span", 21);
    ɵɵtext(19);
    ɵɵpipe(20, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(21, "th", 22)(22, "span", 21);
    ɵɵtext(23);
    ɵɵpipe(24, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(25, "th", 20)(26, "span", 21);
    ɵɵtext(27);
    ɵɵpipe(28, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 7, "orderHistory.replenishmentOrderId"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(8, 9, "orderHistory.purchaseOrderNumber"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(12, 11, "orderHistory.startOn"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(16, 13, "orderHistory.frequency"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(20, 15, "orderHistory.nextOrderDate"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(24, 17, "orderHistory.total"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(28, 19, "orderHistory.actions"), " ");
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_thead_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead", 19)(1, "tr")(2, "th", 20)(3, "span", 21);
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(6, "th", 20)(7, "span", 21);
    ɵɵtext(8);
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(10, "th", 20)(11, "span", 21);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(14, "th", 20)(15, "span", 21);
    ɵɵtext(16);
    ɵɵpipe(17, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(18, "th", 20)(19, "span", 21);
    ɵɵtext(20);
    ɵɵpipe(21, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(22, "th", 22)(23, "span", 21);
    ɵɵtext(24);
    ɵɵpipe(25, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(26, "th", 20)(27, "span", 21);
    ɵɵtext(28);
    ɵɵpipe(29, "cxTranslate");
    ɵɵelementEnd()()()();
  }
  if (rf & 2) {
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 7, "orderHistory.replenishmentOrderId"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 9, "orderHistory.purchaseOrderNumber"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 11, "orderHistory.startOn"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(17, 13, "orderHistory.frequency"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(21, 15, "orderHistory.nextOrderDate"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(25, 17, "orderHistory.total"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(29, 19, "orderHistory.actions"), " ");
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_tr_18_button_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 34, 1);
    ɵɵlistener("click", function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_tr_18_button_50_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r7);
      const order_r6 = ɵɵnextContext().$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.openDialog($event, order_r6 == null ? null : order_r6.replenishmentOrderCode));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 1, "orderHistory.cancel"), " ");
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_tr_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "tr", 23);
    ɵɵlistener("click", function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_tr_18_Template_tr_click_0_listener() {
      const order_r6 = ɵɵrestoreView(_r5).$implicit;
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.goToOrderDetail(order_r6));
    });
    ɵɵelementStart(1, "td", 24)(2, "div", 25);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "a", 26);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵelementEnd()();
    ɵɵelementStart(8, "td", 27)(9, "div", 25);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(12, "a", 28);
    ɵɵpipe(13, "cxUrl");
    ɵɵtext(14);
    ɵɵpipe(15, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(16, "td", 27)(17, "div", 25);
    ɵɵtext(18);
    ɵɵpipe(19, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(20, "a", 26);
    ɵɵpipe(21, "cxUrl");
    ɵɵtext(22);
    ɵɵpipe(23, "cxDate");
    ɵɵelementEnd()();
    ɵɵelementStart(24, "td", 29)(25, "div", 25);
    ɵɵtext(26);
    ɵɵpipe(27, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(28, "a", 26);
    ɵɵpipe(29, "cxUrl");
    ɵɵtext(30);
    ɵɵpipe(31, "slice");
    ɵɵelementEnd()();
    ɵɵelementStart(32, "td", 27)(33, "div", 25);
    ɵɵtext(34);
    ɵɵpipe(35, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(36, "a", 30);
    ɵɵpipe(37, "cxUrl");
    ɵɵtext(38);
    ɵɵpipe(39, "cxDate");
    ɵɵpipe(40, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(41, "td", 31)(42, "div", 25);
    ɵɵtext(43);
    ɵɵpipe(44, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(45, "a", 26);
    ɵɵpipe(46, "cxUrl");
    ɵɵtext(47);
    ɵɵelementEnd()();
    ɵɵelementStart(48, "td", 32);
    ɵɵelement(49, "div", 25);
    ɵɵtemplate(50, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_tr_18_button_50_Template, 4, 3, "button", 33);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const order_r6 = ctx.$implicit;
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 19, "orderHistory.replenishmentOrderId"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 21, ɵɵpureFunction1(57, _c29, order_r6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", order_r6 == null ? null : order_r6.replenishmentOrderCode, "");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 23, "orderHistory.purchaseOrderNumber"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(13, 25, ɵɵpureFunction1(59, _c29, order_r6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", (order_r6 == null ? null : order_r6.purchaseOrderNumber == null ? null : order_r6.purchaseOrderNumber.length) > 0 ? order_r6 == null ? null : order_r6.purchaseOrderNumber : ɵɵpipeBind1(15, 27, "orderHistory.emptyPurchaseOrderId"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 29, "orderHistory.startOn"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(21, 31, ɵɵpureFunction1(61, _c29, order_r6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(23, 33, order_r6 == null ? null : order_r6.firstDate, "M/d/yyyy"), "");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(27, 36, "orderHistory.frequency"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(29, 38, ɵɵpureFunction1(63, _c29, order_r6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind3(31, 40, order_r6 == null ? null : order_r6.trigger.displayTimeTable, 0, -12), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(35, 44, "orderHistory.nextOrderDate"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(37, 46, ɵɵpureFunction1(65, _c29, order_r6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", (order_r6 == null ? null : order_r6.active) ? ɵɵpipeBind2(39, 48, order_r6 == null ? null : order_r6.trigger.activationTime, "M/d/yyyy") : ɵɵpipeBind1(40, 51, "orderHistory.cancelled"), " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(44, 53, "orderHistory.total"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(46, 55, ɵɵpureFunction1(67, _c29, order_r6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", order_r6 == null ? null : order_r6.totalPriceWithTax.formattedValue, "");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", order_r6 == null ? null : order_r6.active);
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_cx_pagination_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "cx-pagination", 18);
    ɵɵlistener("viewPageEvent", function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_cx_pagination_21_Template_cx_pagination_viewPageEvent_0_listener($event) {
      ɵɵrestoreView(_r8);
      const ctx_r1 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const replenishmentOrders_r4 = ɵɵnextContext(2).ngIf;
    ɵɵproperty("pagination", replenishmentOrders_r4.pagination);
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 7)(2, "label", 8)(3, "span");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(6, "cx-sorting", 9);
    ɵɵpipe(7, "cxTranslate");
    ɵɵpipe(8, "async");
    ɵɵpipe(9, "cxTranslate");
    ɵɵlistener("sortListEvent", function ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_Template_cx_sorting_sortListEvent_6_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.changeSortCode($event));
    });
    ɵɵelementEnd()();
    ɵɵtemplate(10, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_div_10_Template, 2, 1, "div", 10);
    ɵɵelementEnd();
    ɵɵelementStart(11, "table", 11)(12, "caption", 12);
    ɵɵtext(13);
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtemplate(15, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_thead_15_Template, 29, 21, "thead", 13)(16, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_thead_16_Template, 30, 21, "thead", 13);
    ɵɵelementStart(17, "tbody");
    ɵɵtemplate(18, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_tr_18_Template, 51, 69, "tr", 14);
    ɵɵelementEnd()();
    ɵɵelementStart(19, "div", 15)(20, "div", 16);
    ɵɵtemplate(21, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_cx_pagination_21_Template, 1, 1, "cx-pagination", 17);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const replenishmentOrders_r4 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 12, "orderHistory.sortBy"));
    ɵɵadvance(2);
    ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(7, 14, "orderHistory.sortBy"));
    ɵɵproperty("sortOptions", replenishmentOrders_r4.sorts)("sortLabels", ɵɵpipeBind1(8, 16, ctx_r1.getSortLabels()))("selectedOption", replenishmentOrders_r4.pagination.sort)("ariaLabel", ɵɵpipeBind1(9, 18, "orderHistory.sortOrders"));
    ɵɵadvance(4);
    ɵɵproperty("ngIf", replenishmentOrders_r4.pagination.totalPages > 1);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 20, "orderHistory.orderHistory"), " ");
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "!a11yTableHeaderReadout");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yTableHeaderReadout");
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", replenishmentOrders_r4.replenishmentOrders);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", replenishmentOrders_r4.pagination.totalPages > 1);
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_template_8_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 36)(1, "div", 37)(2, "div");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "a", 38);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 3, "orderHistory.noReplenishmentOrders"));
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 5, ɵɵpureFunction0(9, _c7)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(8, 7, "orderHistory.startShopping"));
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ReplenishmentOrderHistoryComponent_ng_container_0_ng_template_8_div_0_Template, 9, 10, "div", 35);
    ɵɵpipe(1, "async");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx_r1.isLoaded$));
  }
}
function ReplenishmentOrderHistoryComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 3)(2, "div", 4)(3, "h3");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(6, "div", 5);
    ɵɵtemplate(7, ReplenishmentOrderHistoryComponent_ng_container_0_ng_container_7_Template, 22, 22, "ng-container", 6)(8, ReplenishmentOrderHistoryComponent_ng_container_0_ng_template_8_Template, 2, 3, "ng-template", null, 0, ɵɵtemplateRefExtractor);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const replenishmentOrders_r4 = ctx.ngIf;
    const noOrder_r9 = ɵɵreference(9);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 3, "orderHistory.replenishmentOrderHistory"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", replenishmentOrders_r4.pagination.totalResults > 0)("ngIfElse", noOrder_r9);
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const returnEntry_r1 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.product.name, " ");
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_div_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 23);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const returnEntry_r1 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate2(" ", ɵɵpipeBind1(2, 2, "cartItems.id"), " ", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.product.code, " ");
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_div_7_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 27);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const variant_r2 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", variant_r2.name, ": ");
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_div_7_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 20);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const variant_r2 = ɵɵnextContext().$implicit;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", variant_r2.value, " ");
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_div_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 24);
    ɵɵtemplate(1, ReturnRequestItemsComponent_table_0_tr_19_div_7_div_1_Template, 2, 1, "div", 25)(2, ReturnRequestItemsComponent_table_0_tr_19_div_7_div_2_Template, 2, 1, "div", 26);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const variant_r2 = ctx.$implicit;
    ɵɵadvance();
    ɵɵproperty("ngIf", variant_r2.name);
    ɵɵadvance();
    ɵɵproperty("ngIf", variant_r2.value);
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_td_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 28)(1, "div", 19);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "div", 20);
    ɵɵtext(5);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const returnEntry_r1 = ɵɵnextContext().$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, "returnRequest.itemPrice"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.basePrice == null ? null : returnEntry_r1.orderEntry.basePrice.formattedValue, " ");
  }
}
function ReturnRequestItemsComponent_table_0_tr_19_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tr", 9)(1, "td", 10)(2, "div", 11);
    ɵɵelement(3, "cx-media", 12);
    ɵɵelementStart(4, "div", 13);
    ɵɵtemplate(5, ReturnRequestItemsComponent_table_0_tr_19_div_5_Template, 2, 1, "div", 14)(6, ReturnRequestItemsComponent_table_0_tr_19_div_6_Template, 3, 4, "div", 15)(7, ReturnRequestItemsComponent_table_0_tr_19_div_7_Template, 3, 2, "div", 16);
    ɵɵelementEnd()()();
    ɵɵtemplate(8, ReturnRequestItemsComponent_table_0_tr_19_td_8_Template, 6, 4, "td", 17);
    ɵɵelementStart(9, "td", 18)(10, "div", 19);
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(13, "div", 20);
    ɵɵtext(14);
    ɵɵelementEnd()();
    ɵɵelementStart(15, "td", 21)(16, "div", 19);
    ɵɵtext(17);
    ɵɵpipe(18, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(19, "div", 20);
    ɵɵtext(20);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const returnEntry_r1 = ctx.$implicit;
    ɵɵadvance(3);
    ɵɵproperty("container", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.product.images == null ? null : returnEntry_r1.orderEntry.product.images.PRIMARY);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.product.name);
    ɵɵadvance();
    ɵɵproperty("ngIf", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.product.code);
    ɵɵadvance();
    ɵɵproperty("ngForOf", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.product.baseOptions[0] == null ? null : returnEntry_r1.orderEntry.product.baseOptions[0].selected == null ? null : returnEntry_r1.orderEntry.product.baseOptions[0].selected.variantOptionQualifiers);
    ɵɵadvance();
    ɵɵproperty("ngIf", returnEntry_r1.orderEntry == null ? null : returnEntry_r1.orderEntry.basePrice);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(12, 9, "returnRequest.returnQty"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", returnEntry_r1.expectedQuantity, " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(18, 11, "returnRequest.total"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", returnEntry_r1.refundAmount == null ? null : returnEntry_r1.refundAmount.formattedValue, " ");
  }
}
function ReturnRequestItemsComponent_table_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "table", 1)(1, "caption", 2);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "thead")(5, "tr")(6, "th", 3);
    ɵɵtext(7);
    ɵɵpipe(8, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(9, "th", 4);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(12, "th", 5);
    ɵɵtext(13);
    ɵɵpipe(14, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(15, "th", 6);
    ɵɵtext(16);
    ɵɵpipe(17, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelementStart(18, "tbody", 7);
    ɵɵtemplate(19, ReturnRequestItemsComponent_table_0_tr_19_Template, 21, 13, "tr", 8);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const returnRequest_r3 = ctx.ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 6, "returnRequest.caption"), " ");
    ɵɵadvance(5);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(8, 8, "returnRequest.item"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 10, "returnRequest.itemPrice"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 12, "returnRequest.returnQty"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(17, 14, "returnRequest.total"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngForOf", returnRequest_r3.returnEntries);
  }
}
function ReturnRequestOverviewComponent_ng_container_0_button_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 9);
    ɵɵpipe(1, "async");
    ɵɵlistener("click", function ReturnRequestOverviewComponent_ng_container_0_button_7_Template_button_click_0_listener() {
      ɵɵrestoreView(_r3);
      const returnRequest_r4 = ɵɵnextContext().ngIf;
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.cancelReturn(returnRequest_r4.rma));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵproperty("disabled", ɵɵpipeBind1(1, 2, ctx_r1.isCancelling$));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "returnRequest.cancel"), " ");
  }
}
function ReturnRequestOverviewComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "button", 3);
    ɵɵlistener("click", function ReturnRequestOverviewComponent_ng_container_0_Template_button_click_3_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.back());
    });
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd()();
    ɵɵelementStart(6, "div", 2);
    ɵɵtemplate(7, ReturnRequestOverviewComponent_ng_container_0_button_7_Template, 4, 6, "button", 4);
    ɵɵelementEnd()();
    ɵɵelementStart(8, "div", 5)(9, "div", 6)(10, "div", 7);
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(13, "div", 8);
    ɵɵtext(14);
    ɵɵelementEnd()();
    ɵɵelementStart(15, "div", 6)(16, "div", 7);
    ɵɵtext(17);
    ɵɵpipe(18, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(19, "div", 8);
    ɵɵtext(20);
    ɵɵelementEnd()();
    ɵɵelementStart(21, "div", 6)(22, "div", 7);
    ɵɵtext(23);
    ɵɵpipe(24, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(25, "div", 8);
    ɵɵtext(26);
    ɵɵpipe(27, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const returnRequest_r4 = ctx.ngIf;
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 8, "common.back"), " ");
    ɵɵadvance(3);
    ɵɵproperty("ngIf", returnRequest_r4.cancellable);
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(12, 10, "returnRequest.returnRequestId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate(returnRequest_r4.rma);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(18, 12, "returnRequest.orderCode"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate(returnRequest_r4.order == null ? null : returnRequest_r4.order.code);
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(24, 14, "returnRequest.status"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(27, 16, "returnRequestList.statusDisplay_" + (returnRequest_r4 == null ? null : returnRequest_r4.status)), " ");
  }
}
function ReturnRequestTotalsComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "h4");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(6, "div", 3)(7, "div", 4);
    ɵɵtext(8);
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(10, "div", 5);
    ɵɵtext(11);
    ɵɵelementEnd()();
    ɵɵelementStart(12, "div", 3)(13, "div", 4);
    ɵɵtext(14);
    ɵɵpipe(15, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(16, "div", 5);
    ɵɵtext(17);
    ɵɵelementEnd()();
    ɵɵelementStart(18, "div", 6)(19, "div", 4);
    ɵɵtext(20);
    ɵɵpipe(21, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(22, "div", 5);
    ɵɵtext(23);
    ɵɵelementEnd()();
    ɵɵelementStart(24, "div", 7);
    ɵɵtext(25);
    ɵɵpipe(26, "cxTranslate");
    ɵɵelementEnd()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const returnRequest_r1 = ctx.ngIf;
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 8, "returnRequest.summary"));
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 10, "returnRequest.subtotal"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", returnRequest_r1.subTotal == null ? null : returnRequest_r1.subTotal.formattedValue, " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(15, 12, "returnRequest.deliveryCode"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", returnRequest_r1.deliveryCost == null ? null : returnRequest_r1.deliveryCost.formattedValue, " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(21, 14, "returnRequest.estimatedRefund"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", returnRequest_r1.totalPrice == null ? null : returnRequest_r1.totalPrice.formattedValue, " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(26, 16, "returnRequest.note"), " ");
  }
}
function OrderReturnRequestListComponent_ng_container_0_ng_container_3_thead_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead", 12)(1, "th", 13);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(4, "th", 13);
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(7, "th", 13);
    ɵɵtext(8);
    ɵɵpipe(9, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(10, "th", 13);
    ɵɵtext(11);
    ɵɵpipe(12, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 4, "returnRequestList.returnRequestId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(6, 6, "returnRequestList.orderId"));
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(9, 8, "returnRequestList.date"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate(ɵɵpipeBind1(12, 10, "returnRequestList.status"));
  }
}
function OrderReturnRequestListComponent_ng_container_0_ng_container_3_thead_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "thead", 12)(1, "tr")(2, "th", 13);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "th", 13);
    ɵɵtext(6);
    ɵɵpipe(7, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(8, "th", 13);
    ɵɵtext(9);
    ɵɵpipe(10, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(11, "th", 13);
    ɵɵtext(12);
    ɵɵpipe(13, "cxTranslate");
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 4, "returnRequestList.returnRequestId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 6, "returnRequestList.orderId"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 8, "returnRequestList.date"), " ");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 10, "returnRequestList.status"), " ");
  }
}
function OrderReturnRequestListComponent_ng_container_0_ng_container_3_tr_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tr")(1, "td", 14)(2, "div", 15);
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(5, "a", 16);
    ɵɵpipe(6, "cxUrl");
    ɵɵtext(7);
    ɵɵelementEnd()();
    ɵɵelementStart(8, "td", 14)(9, "div", 15);
    ɵɵtext(10);
    ɵɵpipe(11, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(12, "a", 16);
    ɵɵpipe(13, "cxUrl");
    ɵɵtext(14);
    ɵɵelementEnd()();
    ɵɵelementStart(15, "td", 17)(16, "div", 15);
    ɵɵtext(17);
    ɵɵpipe(18, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtext(19);
    ɵɵpipe(20, "cxDate");
    ɵɵelementEnd();
    ɵɵelementStart(21, "td", 18)(22, "div", 15);
    ɵɵtext(23);
    ɵɵpipe(24, "cxTranslate");
    ɵɵelementEnd();
    ɵɵtext(25);
    ɵɵpipe(26, "cxTranslate");
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const return_r3 = ctx.$implicit;
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 10, "returnRequestList.returnRequestId"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(6, 12, ɵɵpureFunction1(27, _c26, return_r3)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", return_r3 == null ? null : return_r3.rma, "");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(11, 14, "returnRequestList.orderId"), " ");
    ɵɵadvance(2);
    ɵɵproperty("routerLink", ɵɵpipeBind1(13, 16, ɵɵpureFunction1(29, _c4, return_r3 == null ? null : return_r3.order)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", return_r3 == null ? null : return_r3.order == null ? null : return_r3.order.code, "");
    ɵɵadvance(3);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(18, 18, "returnRequestList.date"), " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(20, 20, return_r3 == null ? null : return_r3.creationTime, "longDate"), " ");
    ɵɵadvance(4);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(24, 23, "returnRequestList.status"), " ");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(26, 25, "returnRequestList.statusDisplay_" + (return_r3 == null ? null : return_r3.status)), " ");
  }
}
function OrderReturnRequestListComponent_ng_container_0_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 3)(2, "label", 4)(3, "span");
    ɵɵtext(4);
    ɵɵpipe(5, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(6, "cx-sorting", 5);
    ɵɵpipe(7, "async");
    ɵɵpipe(8, "cxTranslate");
    ɵɵlistener("sortListEvent", function OrderReturnRequestListComponent_ng_container_0_ng_container_3_Template_cx_sorting_sortListEvent_6_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.changeSortCode($event));
    });
    ɵɵelementEnd()();
    ɵɵelementStart(9, "div", 6)(10, "cx-pagination", 7);
    ɵɵlistener("viewPageEvent", function OrderReturnRequestListComponent_ng_container_0_ng_container_3_Template_cx_pagination_viewPageEvent_10_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()()();
    ɵɵelementStart(11, "table", 8);
    ɵɵtemplate(12, OrderReturnRequestListComponent_ng_container_0_ng_container_3_thead_12_Template, 13, 12, "thead", 9)(13, OrderReturnRequestListComponent_ng_container_0_ng_container_3_thead_13_Template, 14, 12, "thead", 9);
    ɵɵelementStart(14, "tbody");
    ɵɵtemplate(15, OrderReturnRequestListComponent_ng_container_0_ng_container_3_tr_15_Template, 27, 31, "tr", 10);
    ɵɵelementEnd()();
    ɵɵelementStart(16, "div", 11)(17, "label", 4)(18, "span");
    ɵɵtext(19);
    ɵɵpipe(20, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementStart(21, "cx-sorting", 5);
    ɵɵpipe(22, "async");
    ɵɵpipe(23, "cxTranslate");
    ɵɵlistener("sortListEvent", function OrderReturnRequestListComponent_ng_container_0_ng_container_3_Template_cx_sorting_sortListEvent_21_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.changeSortCode($event));
    });
    ɵɵelementEnd()();
    ɵɵelementStart(24, "div", 6)(25, "cx-pagination", 7);
    ɵɵlistener("viewPageEvent", function OrderReturnRequestListComponent_ng_container_0_ng_container_3_Template_cx_pagination_viewPageEvent_25_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.pageChange($event));
    });
    ɵɵelementEnd()()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const returnRequests_r4 = ɵɵnextContext().ngIf;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(5, 15, "returnRequestList.sortBy"));
    ɵɵadvance(2);
    ɵɵproperty("sortOptions", returnRequests_r4.sorts)("sortLabels", ɵɵpipeBind1(7, 17, ctx_r1.getSortLabels()))("selectedOption", returnRequests_r4.pagination.sort)("ariaLabel", ɵɵpipeBind1(8, 19, "returnRequestList.sortReturns"));
    ɵɵadvance(4);
    ɵɵproperty("pagination", returnRequests_r4.pagination);
    ɵɵadvance(2);
    ɵɵproperty("cxFeature", "!a11yTableHeaderReadout");
    ɵɵadvance();
    ɵɵproperty("cxFeature", "a11yTableHeaderReadout");
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", returnRequests_r4.returnRequests);
    ɵɵadvance(4);
    ɵɵtextInterpolate(ɵɵpipeBind1(20, 21, "returnRequestList.sortBy"));
    ɵɵadvance(2);
    ɵɵproperty("sortOptions", returnRequests_r4.sorts)("sortLabels", ɵɵpipeBind1(22, 23, ctx_r1.getSortLabels()))("selectedOption", returnRequests_r4.pagination.sort)("ariaLabel", ɵɵpipeBind1(23, 25, "returnRequestList.sortReturns"));
    ɵɵadvance(4);
    ɵɵproperty("pagination", returnRequests_r4.pagination);
  }
}
function OrderReturnRequestListComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 1)(2, "div", 2);
    ɵɵtemplate(3, OrderReturnRequestListComponent_ng_container_0_ng_container_3_Template, 26, 27, "ng-container", 0);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const returnRequests_r4 = ctx.ngIf;
    ɵɵadvance(3);
    ɵɵproperty("ngIf", returnRequests_r4.pagination.totalResults > 0);
  }
}
var AmendOrderActionsComponent = class _AmendOrderActionsComponent {
  constructor(routingService) {
    this.routingService = routingService;
    this.styles = "row";
  }
  continue(event) {
    if (this.amendOrderForm.valid) {
      this.routingService.go({
        cxRoute: this.forwardRoute,
        params: {
          code: this.orderCode
        }
      });
    } else {
      this.amendOrderForm.markAllAsTouched();
      event.stopPropagation();
    }
  }
  static {
    this.ɵfac = function AmendOrderActionsComponent_Factory(t) {
      return new (t || _AmendOrderActionsComponent)(ɵɵdirectiveInject(RoutingService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AmendOrderActionsComponent,
      selectors: [["cx-amend-order-actions"]],
      hostVars: 2,
      hostBindings: function AmendOrderActionsComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.styles);
        }
      },
      inputs: {
        orderCode: "orderCode",
        amendOrderForm: "amendOrderForm",
        backRoute: "backRoute",
        forwardRoute: "forwardRoute"
      },
      decls: 8,
      vars: 13,
      consts: [[1, "col-xs-12", "col-md-4", "col-lg-3"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], ["class", "btn btn-block btn-primary", 3, "click", 4, "ngIf"], ["class", "btn btn-block btn-primary", "type", "submit", 4, "ngIf"], [1, "btn", "btn-block", "btn-primary", 3, "click"], ["type", "submit", 1, "btn", "btn-block", "btn-primary"]],
      template: function AmendOrderActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0)(1, "a", 1);
          ɵɵpipe(2, "cxUrl");
          ɵɵtext(3);
          ɵɵpipe(4, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(5, "div", 0);
          ɵɵtemplate(6, AmendOrderActionsComponent_button_6_Template, 3, 3, "button", 2)(7, AmendOrderActionsComponent_button_7_Template, 4, 6, "button", 3);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵproperty("routerLink", ɵɵpipeBind1(2, 4, ɵɵpureFunction2(10, _c1, ctx.backRoute, ɵɵpureFunction1(8, _c02, ctx.orderCode))));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 6, "common.back"), " ");
          ɵɵadvance(3);
          ɵɵproperty("ngIf", ctx.forwardRoute);
          ɵɵadvance();
          ɵɵproperty("ngIf", !ctx.forwardRoute);
        }
      },
      dependencies: [NgIf, RouterLink, BtnLikeLinkDirective, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AmendOrderActionsComponent, [{
    type: Component,
    args: [{
      selector: "cx-amend-order-actions",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div class="col-xs-12 col-md-4 col-lg-3">
  <a
    [routerLink]="
      {
        cxRoute: backRoute,
        params: { code: orderCode },
      } | cxUrl
    "
    cxBtnLikeLink
    class="btn btn-block btn-secondary"
  >
    {{ 'common.back' | cxTranslate }}
  </a>
</div>
<div class="col-xs-12 col-md-4 col-lg-3">
  <button
    *ngIf="forwardRoute"
    class="btn btn-block btn-primary"
    (click)="continue($event)"
  >
    {{ 'common.continue' | cxTranslate }}
  </button>

  <button
    *ngIf="!forwardRoute"
    class="btn btn-block btn-primary"
    type="submit"
    [attr.aria-label]="
      'orderDetails.cancellationAndReturn.submitDescription' | cxTranslate
    "
  >
    {{ 'orderDetails.cancellationAndReturn.submit' | cxTranslate }}
  </button>
</div>
`
    }]
  }], () => [{
    type: RoutingService
  }], {
    orderCode: [{
      type: Input
    }],
    amendOrderForm: [{
      type: Input
    }],
    backRoute: [{
      type: Input
    }],
    forwardRoute: [{
      type: Input
    }],
    styles: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var AmendOrderActionsModule = class _AmendOrderActionsModule {
  static {
    this.ɵfac = function AmendOrderActionsModule_Factory(t) {
      return new (t || _AmendOrderActionsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AmendOrderActionsModule,
      declarations: [AmendOrderActionsComponent],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, BtnLikeLinkModule],
      exports: [AmendOrderActionsComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AmendOrderActionsModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, BtnLikeLinkModule],
      declarations: [AmendOrderActionsComponent],
      exports: [AmendOrderActionsComponent]
    }]
  }], null, null);
})();
var AmendOrderType;
(function(AmendOrderType2) {
  AmendOrderType2[AmendOrderType2["CANCEL"] = 0] = "CANCEL";
  AmendOrderType2[AmendOrderType2["RETURN"] = 1] = "RETURN";
})(AmendOrderType || (AmendOrderType = {}));
var OrderDetailsService = class _OrderDetailsService {
  constructor(orderHistoryFacade, routingService) {
    this.orderHistoryFacade = orderHistoryFacade;
    this.routingService = routingService;
    this.orderCode$ = this.routingService.getRouterState().pipe(map((routingData) => routingData.state.params.orderCode), distinctUntilChanged());
    this.orderLoad$ = this.orderCode$.pipe(tap((orderCode) => {
      if (orderCode) {
        this.orderHistoryFacade.loadOrderDetails(orderCode);
      } else {
        this.orderHistoryFacade.clearOrderDetails();
      }
    }), shareReplay({
      bufferSize: 1,
      refCount: true
    }));
  }
  isOrderDetailsLoading() {
    return this.orderHistoryFacade.getOrderDetailsLoading();
  }
  getOrderDetails() {
    return this.orderLoad$.pipe(switchMap(() => this.orderHistoryFacade.getOrderDetails()));
  }
  static {
    this.ɵfac = function OrderDetailsService_Factory(t) {
      return new (t || _OrderDetailsService)(ɵɵinject(OrderHistoryFacade), ɵɵinject(RoutingService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderDetailsService,
      factory: _OrderDetailsService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailsService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderHistoryFacade
  }, {
    type: RoutingService
  }], null);
})();
function ValidateQuantityToCancel(control) {
  if (!control.value) {
    return null;
  }
  const quantity = Object.values(control.value).reduce((acc, val) => acc + val, 0);
  return quantity > 0 ? null : {
    cxNoSelectedItemToCancel: true
  };
}
var OrderAmendService = class _OrderAmendService {
  constructor(orderDetailsService) {
    this.orderDetailsService = orderDetailsService;
  }
  /**
   * Returns entries with an amended quantity.
   */
  getAmendedEntries() {
    return this.getForm().pipe(switchMap((form) => {
      return this.getEntries().pipe(map((entries) => entries.filter((entry) => this.getFormControl(form, entry).value > 0)));
    }));
  }
  getOrder() {
    return this.orderDetailsService.getOrderDetails();
  }
  /**
   * returns the form with form data at runtime
   */
  getForm() {
    return this.getOrder().pipe(tap((order) => {
      if (!this.form || this.form.get("orderCode")?.value !== order.code) {
        this.buildForm(order);
      }
    }), map(() => this.form));
  }
  buildForm(order) {
    this.form = new UntypedFormGroup({});
    this.form.addControl("orderCode", new UntypedFormControl(order.code));
    const entryGroup = new UntypedFormGroup({}, {
      validators: [ValidateQuantityToCancel]
    });
    this.form.addControl("entries", entryGroup);
    (order.entries || []).forEach((entry) => {
      const key = entry?.entryNumber?.toString() ?? "";
      entryGroup.addControl(key, new UntypedFormControl(0, {
        validators: [Validators.min(0), Validators.max(this.getMaxAmendQuantity(entry))]
      }));
    });
  }
  getFormControl(form, entry) {
    return form.get("entries")?.get(entry.entryNumber?.toString() ?? "");
  }
  /**
   * As discussed, this calculation is moved to SPA side.
   * The calculation and validation should be in backend facade layer.
   */
  getAmendedPrice(entry) {
    const amendedQuantity = this.getFormControl(this.form, entry).value;
    const amendedPrice = Object.assign({}, entry.basePrice);
    amendedPrice.value = Math.round((entry.basePrice?.value ?? 0) * amendedQuantity * 100) / 100;
    amendedPrice.formattedValue = formatCurrency(
      amendedPrice.value,
      // TODO: user current language
      "en",
      getCurrencySymbol(amendedPrice.currencyIso ?? "", "narrow"),
      amendedPrice.currencyIso
    );
    return amendedPrice;
  }
  getMaxAmendQuantity(entry) {
    return (this.isCancellation() ? entry.cancellableQuantity : entry.returnableQuantity) || entry.quantity || 0;
  }
  isCancellation() {
    return this.amendType === AmendOrderType.CANCEL;
  }
  static {
    this.ɵfac = function OrderAmendService_Factory(t) {
      return new (t || _OrderAmendService)(ɵɵinject(OrderDetailsService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderAmendService,
      factory: _OrderAmendService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderAmendService, [{
    type: Injectable
  }], () => [{
    type: OrderDetailsService
  }], null);
})();
var CancelOrReturnItemsComponent = class _CancelOrReturnItemsComponent {
  constructor(orderAmendService) {
    this.orderAmendService = orderAmendService;
    this.isConfirmation = false;
    this.form$ = this.orderAmendService.getForm();
  }
  getControl(form, entry) {
    const control = form.get("entries")?.get(entry.entryNumber?.toString() ?? "");
    return control;
  }
  setAll(form) {
    this.entries.forEach((entry) => this.getControl(form, entry).setValue(this.getMaxAmendQuantity(entry)));
  }
  getItemPrice(entry) {
    return this.orderAmendService.getAmendedPrice(entry);
  }
  getMaxAmendQuantity(entry) {
    return this.orderAmendService.getMaxAmendQuantity(entry);
  }
  isCancellation() {
    return this.orderAmendService.isCancellation();
  }
  static {
    this.ɵfac = function CancelOrReturnItemsComponent_Factory(t) {
      return new (t || _CancelOrReturnItemsComponent)(ɵɵdirectiveInject(OrderAmendService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CancelOrReturnItemsComponent,
      selectors: [["cx-amend-order-items"]],
      inputs: {
        entries: "entries",
        isConfirmation: "isConfirmation"
      },
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], ["class", "btn btn-link cx-action-link", 3, "click", 4, "ngIf"], [1, "cx-amend-order-items"], [1, "cx-visually-hidden"], ["role", "columnheader", 1, "cx-item-list-desc"], ["role", "columnheader", 1, "cx-item-list-price"], ["role", "columnheader", "class", "cx-item-list-amend-qty", 4, "ngIf"], ["role", "columnheader", 1, "cx-item-list-qty"], ["role", "columnheader", "class", "cx-item-list-total", 4, "ngIf"], [1, "cx-item-list-items"], ["class", "cx-item-list-row cx-amend-order-item-row", 4, "ngFor", "ngForOf"], [1, "btn", "btn-link", "cx-action-link", 3, "click"], ["role", "columnheader", 1, "cx-item-list-amend-qty"], ["role", "columnheader", 1, "cx-item-list-total"], [1, "cx-item-list-row", "cx-amend-order-item-row"], ["role", "cell"], [1, "cx-table-item-container"], ["format", "thumbnail", 3, "container"], [1, "cx-info"], [1, "cx-name"], ["class", "cx-code", 4, "ngIf"], ["role", "cell", "class", "cx-price", 4, "ngIf"], ["role", "cell", "class", "cx-request-qty", 4, "ngIf"], ["role", "cell", 1, "cx-quantity"], [1, "cx-mobile-header"], [1, "cx-value"], [3, "min", "max", "control", 4, "ngIf"], ["role", "cell", "class", "cx-total", 4, "ngIf"], [1, "cx-code"], ["class", "cx-property", 4, "ngFor", "ngForOf"], [1, "cx-property"], ["class", "cx-label", 4, "ngIf"], ["class", "cx-value", 4, "ngIf"], [1, "cx-label"], ["role", "cell", 1, "cx-price"], ["role", "cell", 1, "cx-request-qty"], [1, "cx-mobile-header", 3, "title"], [3, "min", "max", "control"], ["role", "cell", 1, "cx-total"]],
      template: function CancelOrReturnItemsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CancelOrReturnItemsComponent_div_0_Template, 21, 16, "div", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.form$));
        }
      },
      dependencies: [NgForOf, NgIf, MediaComponent, ItemCounterComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CancelOrReturnItemsComponent, [{
    type: Component,
    args: [{
      selector: "cx-amend-order-items",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div *ngIf="form$ | async as form">
  <button
    *ngIf="!isConfirmation"
    class="btn btn-link cx-action-link"
    (click)="setAll(form)"
  >
    {{ 'orderDetails.cancellationAndReturn.setAll' | cxTranslate }}
  </button>

  <table class="cx-amend-order-items">
    <caption class="cx-visually-hidden">
      {{
        'orderDetails.caption' | cxTranslate
      }}
    </caption>
    <thead>
      <tr>
        <th role="columnheader" class="cx-item-list-desc">
          {{ 'orderDetails.cancellationAndReturn.item' | cxTranslate }}
        </th>
        <th role="columnheader" class="cx-item-list-price">
          {{ 'orderDetails.cancellationAndReturn.itemPrice' | cxTranslate }}
        </th>
        <th
          *ngIf="!isConfirmation"
          role="columnheader"
          class="cx-item-list-amend-qty"
        >
          {{ 'orderDetails.cancellationAndReturn.quantity' | cxTranslate }}
        </th>
        <th role="columnheader" class="cx-item-list-qty">
          {{
            (isCancellation()
              ? 'orderDetails.cancellationAndReturn.cancelQty'
              : 'orderDetails.cancellationAndReturn.returnQty'
            ) | cxTranslate
          }}
        </th>
        <th
          *ngIf="isConfirmation"
          role="columnheader"
          class="cx-item-list-total"
        >
          {{ 'orderDetails.cancellationAndReturn.totalPrice' | cxTranslate }}
        </th>
      </tr>
    </thead>
    <tbody class="cx-item-list-items">
      <!--    TODO: This should be a separate component-->
      <tr
        *ngFor="let item of entries; let i = index"
        class="cx-item-list-row cx-amend-order-item-row"
      >
        <td role="cell">
          <div class="cx-table-item-container">
            <cx-media
              [container]="item.product.images?.PRIMARY"
              format="thumbnail"
            ></cx-media>

            <div class="cx-info">
              <div class="cx-name">
                {{ item.product.name }}
              </div>

              <div *ngIf="item.product.code" class="cx-code">
                {{ 'cartItems.id' | cxTranslate }} {{ item.product.code }}
              </div>
            </div>

            <ng-container *ngIf="item.product.baseOptions?.length">
              <div
                *ngFor="
                  let variant of item.product.baseOptions[0]?.selected
                    ?.variantOptionQualifiers
                "
                class="cx-property"
              >
                <div class="cx-label" *ngIf="variant.name">
                  {{ variant.name }}:
                </div>
                <div class="cx-value" *ngIf="variant.value">
                  {{ variant.value }}
                </div>
              </div>
            </ng-container>
          </div>
        </td>

        <td role="cell" class="cx-price" *ngIf="item.basePrice">
          <div class="cx-mobile-header">
            {{ 'orderDetails.cancellationAndReturn.itemPrice' | cxTranslate }}
          </div>
          <div class="cx-value">
            {{ item.basePrice?.formattedValue }}
          </div>
        </td>

        <td role="cell" *ngIf="!isConfirmation" class="cx-request-qty">
          <div
            class="cx-mobile-header"
            title="{{ 'cartItems.quantityTitle' | cxTranslate }}"
          >
            {{ 'orderDetails.cancellationAndReturn.quantity' | cxTranslate }}
          </div>
          <div class="cx-value">
            {{ getMaxAmendQuantity(item) }}
          </div>
        </td>

        <td role="cell" class="cx-quantity">
          <div class="cx-mobile-header">
            {{
              (isCancellation()
                ? 'orderDetails.cancellationAndReturn.cancelQty'
                : 'orderDetails.cancellationAndReturn.returnQty'
              ) | cxTranslate
            }}
          </div>
          <div class="cx-value">
            <ng-container *ngIf="isConfirmation">
              {{ getControl(form, item).value }}
            </ng-container>
            <cx-item-counter
              *ngIf="!isConfirmation"
              [min]="0"
              [max]="getMaxAmendQuantity(item)"
              [control]="getControl(form, item)"
            ></cx-item-counter>
          </div>
        </td>

        <td role="cell" *ngIf="isConfirmation" class="cx-total">
          <div class="cx-mobile-header">
            {{ 'orderDetails.cancellationAndReturn.totalPrice' | cxTranslate }}
          </div>
          <div class="cx-value">{{ getItemPrice(item)?.formattedValue }}</div>
        </td>
      </tr>
    </tbody>
  </table>
</div>
`
    }]
  }], () => [{
    type: OrderAmendService
  }], {
    entries: [{
      type: Input
    }],
    isConfirmation: [{
      type: Input
    }]
  });
})();
var AmendOrderItemsModule = class _AmendOrderItemsModule {
  static {
    this.ɵfac = function AmendOrderItemsModule_Factory(t) {
      return new (t || _AmendOrderItemsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _AmendOrderItemsModule,
      declarations: [CancelOrReturnItemsComponent],
      imports: [CommonModule, ReactiveFormsModule, I18nModule, MediaModule, ItemCounterModule, FormErrorsModule],
      exports: [CancelOrReturnItemsComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [CommonModule, ReactiveFormsModule, I18nModule, MediaModule, ItemCounterModule, FormErrorsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AmendOrderItemsModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, ReactiveFormsModule, I18nModule, MediaModule, ItemCounterModule, FormErrorsModule],
      declarations: [CancelOrReturnItemsComponent],
      exports: [CancelOrReturnItemsComponent]
    }]
  }], null, null);
})();
var CancelOrderConfirmationComponent = class _CancelOrderConfirmationComponent {
  constructor(orderAmendService) {
    this.orderAmendService = orderAmendService;
    this.form$ = this.orderAmendService.getForm().pipe(tap((form) => this.orderCode = form.value.orderCode));
    this.entries$ = this.orderAmendService.getAmendedEntries();
  }
  submit(form) {
    if (form.valid) {
      this.orderAmendService.save();
    } else {
      form.markAllAsTouched();
    }
  }
  static {
    this.ɵfac = function CancelOrderConfirmationComponent_Factory(t) {
      return new (t || _CancelOrderConfirmationComponent)(ɵɵdirectiveInject(OrderAmendService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CancelOrderConfirmationComponent,
      selectors: [["cx-cancel-order-confirmation"]],
      decls: 2,
      vars: 3,
      consts: [["actions", ""], [3, "formGroup", "ngSubmit", 4, "ngIf"], [3, "ngSubmit", "formGroup"], [4, "ngTemplateOutlet"], [3, "entries", "isConfirmation", 4, "ngIf"], [3, "entries", "isConfirmation"], ["backRoute", "orderCancel", 3, "orderCode", "amendOrderForm", 4, "ngIf"], ["backRoute", "orderCancel", 3, "orderCode", "amendOrderForm"]],
      template: function CancelOrderConfirmationComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CancelOrderConfirmationComponent_form_0_Template, 7, 6, "form", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.form$));
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, ɵNgNoValidate, NgControlStatusGroup, FormGroupDirective, CancelOrReturnItemsComponent, AmendOrderActionsComponent, AsyncPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CancelOrderConfirmationComponent, [{
    type: Component,
    args: [{
      selector: "cx-cancel-order-confirmation",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: '<form\n  *ngIf="form$ | async as form"\n  [formGroup]="form"\n  (ngSubmit)="submit(form)"\n>\n  <ng-container *ngTemplateOutlet="actions"></ng-container>\n\n  <cx-amend-order-items\n    *ngIf="entries$ | async as entries"\n    [entries]="entries"\n    [isConfirmation]="true"\n  >\n  </cx-amend-order-items>\n\n  <ng-container *ngTemplateOutlet="actions"></ng-container>\n\n  <ng-template #actions>\n    <cx-amend-order-actions\n      *ngIf="orderCode"\n      [orderCode]="orderCode"\n      [amendOrderForm]="form"\n      backRoute="orderCancel"\n    ></cx-amend-order-actions>\n  </ng-template>\n</form>\n'
    }]
  }], () => [{
    type: OrderAmendService
  }], null);
})();
var OrderCancellationService = class _OrderCancellationService extends OrderAmendService {
  constructor(orderDetailsService, orderHistoryFacade, routing, globalMessageService) {
    super(orderDetailsService);
    this.orderDetailsService = orderDetailsService;
    this.orderHistoryFacade = orderHistoryFacade;
    this.routing = routing;
    this.globalMessageService = globalMessageService;
    this.amendType = AmendOrderType.CANCEL;
  }
  /**
   * Return cancellable order entries.
   */
  getEntries() {
    return this.getOrder().pipe(filter((order) => !!order?.entries), map((order) => order.entries?.filter((entry) => entry.entryNumber !== -1 && entry.cancellableQuantity && entry.cancellableQuantity > 0) ?? []));
  }
  save() {
    const orderCode = this.form.value.orderCode;
    const entries = this.form.value.entries;
    const inputs = Object.keys(entries).filter((entryNumber) => entries[entryNumber] > 0).map((entryNumber) => ({
      orderEntryNumber: Number(entryNumber),
      quantity: entries[entryNumber]
    }));
    this.form.reset();
    this.orderHistoryFacade.cancelOrder(orderCode, {
      cancellationRequestEntryInputs: inputs
    });
    this.orderHistoryFacade.getCancelOrderSuccess().pipe(first(Boolean)).subscribe(() => this.afterSave(orderCode));
  }
  afterSave(orderCode) {
    this.orderHistoryFacade.resetCancelOrderProcessState();
    this.globalMessageService.add({
      key: "orderDetails.cancellationAndReturn.cancelSuccess",
      params: {
        orderCode
      }
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.routing.go({
      cxRoute: "orders"
    });
  }
  static {
    this.ɵfac = function OrderCancellationService_Factory(t) {
      return new (t || _OrderCancellationService)(ɵɵinject(OrderDetailsService), ɵɵinject(OrderHistoryFacade), ɵɵinject(RoutingService), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderCancellationService,
      factory: _OrderCancellationService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderCancellationService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderDetailsService
  }, {
    type: OrderHistoryFacade
  }, {
    type: RoutingService
  }, {
    type: GlobalMessageService
  }], null);
})();
var OrderCancellationGuard = class _OrderCancellationGuard {
  constructor(orderAmendService, semanticPathService, router) {
    this.orderAmendService = orderAmendService;
    this.semanticPathService = semanticPathService;
    this.router = router;
  }
  canActivate() {
    return this.orderAmendService.getForm().pipe(map((form) => {
      if (!form.valid) {
        return this.router.parseUrl(this.semanticPathService.get("orders") ?? "");
      } else {
        return true;
      }
    }));
  }
  static {
    this.ɵfac = function OrderCancellationGuard_Factory(t) {
      return new (t || _OrderCancellationGuard)(ɵɵinject(OrderCancellationService), ɵɵinject(SemanticPathService), ɵɵinject(Router));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderCancellationGuard,
      factory: _OrderCancellationGuard.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderCancellationGuard, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderCancellationService
  }, {
    type: SemanticPathService
  }, {
    type: Router
  }], null);
})();
var CancelOrderConfirmationModule = class _CancelOrderConfirmationModule {
  static {
    this.ɵfac = function CancelOrderConfirmationModule_Factory(t) {
      return new (t || _CancelOrderConfirmationModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _CancelOrderConfirmationModule,
      declarations: [CancelOrderConfirmationComponent],
      imports: [CommonModule, ReactiveFormsModule, AmendOrderItemsModule, AmendOrderActionsModule],
      exports: [CancelOrderConfirmationComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          CancelOrderConfirmationComponent: {
            component: CancelOrderConfirmationComponent,
            guards: [AuthGuard, OrderCancellationGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderCancellationService
            }]
          }
        }
      })],
      imports: [CommonModule, ReactiveFormsModule, AmendOrderItemsModule, AmendOrderActionsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CancelOrderConfirmationModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, ReactiveFormsModule, AmendOrderItemsModule, AmendOrderActionsModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          CancelOrderConfirmationComponent: {
            component: CancelOrderConfirmationComponent,
            guards: [AuthGuard, OrderCancellationGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderCancellationService
            }]
          }
        }
      })],
      declarations: [CancelOrderConfirmationComponent],
      exports: [CancelOrderConfirmationComponent]
    }]
  }], null, null);
})();
var CancelOrderComponent = class _CancelOrderComponent {
  constructor(orderAmendService) {
    this.orderAmendService = orderAmendService;
    this.globalMessageType = GlobalMessageType;
    this.form$ = this.orderAmendService.getForm().pipe(tap((form) => this.orderCode = form.value.orderCode));
    this.entries$ = this.orderAmendService.getEntries();
  }
  static {
    this.ɵfac = function CancelOrderComponent_Factory(t) {
      return new (t || _CancelOrderComponent)(ɵɵdirectiveInject(OrderAmendService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CancelOrderComponent,
      selectors: [["cx-cancel-order"]],
      decls: 2,
      vars: 3,
      consts: [["actions", ""], [4, "ngIf"], ["role", "alert", 3, "text", "isVisibleCloseButton", "type", 4, "ngIf"], [4, "ngTemplateOutlet"], [3, "entries", 4, "ngIf"], [3, "control", 4, "cxFeature"], ["role", "alert", 3, "text", "isVisibleCloseButton", "type"], [3, "entries"], [3, "control"], ["backRoute", "orderDetails", "forwardRoute", "orderCancelConfirmation", 3, "orderCode", "amendOrderForm", 4, "ngIf"], ["backRoute", "orderDetails", "forwardRoute", "orderCancelConfirmation", 3, "orderCode", "amendOrderForm"]],
      template: function CancelOrderComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, CancelOrderComponent_ng_container_0_Template, 9, 7, "ng-container", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.form$));
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, CancelOrReturnItemsComponent, AmendOrderActionsComponent, FormErrorsComponent, MessageComponent, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CancelOrderComponent, [{
    type: Component,
    args: [{
      selector: "cx-cancel-order",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="form$ | async as form">
  <cx-message
    role="alert"
    *ngIf="!form.get('entries').valid && form.get('entries').touched"
    [text]="'formErrors.cxNoSelectedItemToCancel' | cxTranslate"
    [isVisibleCloseButton]="false"
    [type]="globalMessageType.MSG_TYPE_ERROR"
  >
  </cx-message>
  <ng-container *ngTemplateOutlet="actions"></ng-container>
  <cx-amend-order-items *ngIf="entries$ | async as entries" [entries]="entries">
  </cx-amend-order-items>

  <cx-form-errors
    *cxFeature="'!a11yRepeatedCancelOrderError'"
    [control]="form.get('entries')"
  ></cx-form-errors>

  <ng-container *ngTemplateOutlet="actions"></ng-container>

  <ng-template #actions>
    <cx-amend-order-actions
      *ngIf="orderCode"
      [orderCode]="orderCode"
      [amendOrderForm]="form"
      backRoute="orderDetails"
      forwardRoute="orderCancelConfirmation"
    ></cx-amend-order-actions>
  </ng-template>
</ng-container>
`
    }]
  }], () => [{
    type: OrderAmendService
  }], null);
})();
var CancelOrderModule = class _CancelOrderModule {
  static {
    this.ɵfac = function CancelOrderModule_Factory(t) {
      return new (t || _CancelOrderModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _CancelOrderModule,
      declarations: [CancelOrderComponent],
      imports: [CommonModule, I18nModule, AmendOrderItemsModule, AmendOrderActionsModule, FormErrorsModule, MessageComponentModule, FeaturesConfigModule],
      exports: [CancelOrderComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          CancelOrderComponent: {
            component: CancelOrderComponent,
            guards: [AuthGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderCancellationService
            }]
          }
        }
      })],
      imports: [CommonModule, I18nModule, AmendOrderItemsModule, AmendOrderActionsModule, FormErrorsModule, MessageComponentModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CancelOrderModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, I18nModule, AmendOrderItemsModule, AmendOrderActionsModule, FormErrorsModule, MessageComponentModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          CancelOrderComponent: {
            component: CancelOrderComponent,
            guards: [AuthGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderCancellationService
            }]
          }
        }
      })],
      declarations: [CancelOrderComponent],
      exports: [CancelOrderComponent]
    }]
  }], null, null);
})();
var OrderCancellationModule = class _OrderCancellationModule {
  static {
    this.ɵfac = function OrderCancellationModule_Factory(t) {
      return new (t || _OrderCancellationModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderCancellationModule,
      imports: [CancelOrderModule, CancelOrderConfirmationModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [CancelOrderModule, CancelOrderConfirmationModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderCancellationModule, [{
    type: NgModule,
    args: [{
      imports: [CancelOrderModule, CancelOrderConfirmationModule]
    }]
  }], null, null);
})();
var OrderReturnService = class _OrderReturnService extends OrderAmendService {
  constructor(orderDetailsService, returnRequestService, routing, globalMessageService) {
    super(orderDetailsService);
    this.orderDetailsService = orderDetailsService;
    this.returnRequestService = returnRequestService;
    this.routing = routing;
    this.globalMessageService = globalMessageService;
    this.amendType = AmendOrderType.RETURN;
  }
  getEntries() {
    return this.getOrder().pipe(filter((order) => !!order.entries), map((order) => order.entries?.filter((entry) => entry.entryNumber !== -1 && entry.returnableQuantity && entry.returnableQuantity > 0) ?? []));
  }
  save() {
    const orderCode = this.form.value.orderCode;
    const entries = this.form.value.entries;
    const inputs = Object.keys(entries).filter((entryNumber) => entries[entryNumber] > 0).map((entryNumber) => ({
      orderEntryNumber: Number(entryNumber),
      quantity: entries[entryNumber]
    }));
    this.form.reset();
    this.returnRequestService.createOrderReturnRequest({
      orderCode,
      returnRequestEntryInputs: inputs
    });
    this.returnRequestService.getReturnRequestSuccess().pipe(first(Boolean)).subscribe(() => this.afterSave());
  }
  afterSave() {
    this.returnRequestService.getOrderReturnRequest().pipe(first((r) => !!r)).subscribe((returnRequest) => {
      const rma = returnRequest.rma;
      this.globalMessageService.add({
        key: "orderDetails.cancellationAndReturn.returnSuccess",
        params: {
          rma
        }
      }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
      this.routing.go({
        cxRoute: "returnRequestDetails",
        params: {
          rma
        }
      });
    });
  }
  static {
    this.ɵfac = function OrderReturnService_Factory(t) {
      return new (t || _OrderReturnService)(ɵɵinject(OrderDetailsService), ɵɵinject(OrderReturnRequestFacade), ɵɵinject(RoutingService), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderReturnService,
      factory: _OrderReturnService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderReturnService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderDetailsService
  }, {
    type: OrderReturnRequestFacade
  }, {
    type: RoutingService
  }, {
    type: GlobalMessageService
  }], null);
})();
var OrderReturnGuard = class _OrderReturnGuard {
  constructor(orderAmendService, semanticPathService, router) {
    this.orderAmendService = orderAmendService;
    this.semanticPathService = semanticPathService;
    this.router = router;
  }
  canActivate() {
    return this.orderAmendService.getForm().pipe(map((form) => {
      if (!form.valid) {
        return this.router.parseUrl(this.semanticPathService.get("orders") ?? "");
      } else {
        return true;
      }
    }));
  }
  static {
    this.ɵfac = function OrderReturnGuard_Factory(t) {
      return new (t || _OrderReturnGuard)(ɵɵinject(OrderReturnService), ɵɵinject(SemanticPathService), ɵɵinject(Router));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderReturnGuard,
      factory: _OrderReturnGuard.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderReturnGuard, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderReturnService
  }, {
    type: SemanticPathService
  }, {
    type: Router
  }], null);
})();
var ReturnOrderConfirmationComponent = class _ReturnOrderConfirmationComponent {
  constructor(orderAmendService) {
    this.orderAmendService = orderAmendService;
    this.form$ = this.orderAmendService.getForm().pipe(tap((form) => this.orderCode = form.value.orderCode));
    this.entries$ = this.orderAmendService.getAmendedEntries();
  }
  submit(form) {
    form.disable();
    this.orderAmendService.save();
  }
  static {
    this.ɵfac = function ReturnOrderConfirmationComponent_Factory(t) {
      return new (t || _ReturnOrderConfirmationComponent)(ɵɵdirectiveInject(OrderAmendService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReturnOrderConfirmationComponent,
      selectors: [["cx-return-order-confirmation"]],
      decls: 2,
      vars: 3,
      consts: [["actions", ""], [3, "formGroup", "ngSubmit", 4, "ngIf"], [3, "ngSubmit", "formGroup"], [4, "ngTemplateOutlet"], [3, "entries", "isConfirmation", 4, "ngIf"], [3, "entries", "isConfirmation"], ["backRoute", "orderReturn", 3, "orderCode", "amendOrderForm", 4, "ngIf"], ["backRoute", "orderReturn", 3, "orderCode", "amendOrderForm"]],
      template: function ReturnOrderConfirmationComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ReturnOrderConfirmationComponent_form_0_Template, 7, 6, "form", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.form$));
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, CancelOrReturnItemsComponent, ɵNgNoValidate, NgControlStatusGroup, FormGroupDirective, AmendOrderActionsComponent, AsyncPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnOrderConfirmationComponent, [{
    type: Component,
    args: [{
      selector: "cx-return-order-confirmation",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: '<form\n  *ngIf="form$ | async as form"\n  [formGroup]="form"\n  (ngSubmit)="submit(form)"\n>\n  <ng-container *ngTemplateOutlet="actions"></ng-container>\n\n  <cx-amend-order-items\n    *ngIf="entries$ | async as entries"\n    [entries]="entries"\n    [isConfirmation]="true"\n  >\n  </cx-amend-order-items>\n\n  <ng-container *ngTemplateOutlet="actions"></ng-container>\n\n  <ng-template #actions>\n    <cx-amend-order-actions\n      *ngIf="orderCode"\n      [orderCode]="orderCode"\n      [amendOrderForm]="form"\n      backRoute="orderReturn"\n    ></cx-amend-order-actions>\n  </ng-template>\n</form>\n'
    }]
  }], () => [{
    type: OrderAmendService
  }], null);
})();
var ReturnOrderConfirmationModule = class _ReturnOrderConfirmationModule {
  static {
    this.ɵfac = function ReturnOrderConfirmationModule_Factory(t) {
      return new (t || _ReturnOrderConfirmationModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReturnOrderConfirmationModule,
      declarations: [ReturnOrderConfirmationComponent],
      imports: [CommonModule, AmendOrderItemsModule, I18nModule, ReactiveFormsModule, AmendOrderActionsModule],
      exports: [ReturnOrderConfirmationComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturnOrderConfirmationComponent: {
            component: ReturnOrderConfirmationComponent,
            guards: [AuthGuard, OrderReturnGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderReturnService
            }]
          }
        }
      })],
      imports: [CommonModule, AmendOrderItemsModule, I18nModule, ReactiveFormsModule, AmendOrderActionsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnOrderConfirmationModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, AmendOrderItemsModule, I18nModule, ReactiveFormsModule, AmendOrderActionsModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturnOrderConfirmationComponent: {
            component: ReturnOrderConfirmationComponent,
            guards: [AuthGuard, OrderReturnGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderReturnService
            }]
          }
        }
      })],
      declarations: [ReturnOrderConfirmationComponent],
      exports: [ReturnOrderConfirmationComponent]
    }]
  }], null, null);
})();
var ReturnOrderComponent = class _ReturnOrderComponent {
  constructor(orderAmendService) {
    this.orderAmendService = orderAmendService;
    this.form$ = this.orderAmendService.getForm().pipe(tap((form) => this.orderCode = form.value.orderCode));
    this.entries$ = this.orderAmendService.getEntries();
  }
  static {
    this.ɵfac = function ReturnOrderComponent_Factory(t) {
      return new (t || _ReturnOrderComponent)(ɵɵdirectiveInject(OrderAmendService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReturnOrderComponent,
      selectors: [["cx-return-order"]],
      decls: 2,
      vars: 3,
      consts: [["actions", ""], [4, "ngIf"], [4, "ngTemplateOutlet"], [3, "entries", 4, "ngIf"], [3, "control"], [3, "entries"], ["backRoute", "orderDetails", "forwardRoute", "orderReturnConfirmation", 3, "orderCode", "amendOrderForm", 4, "ngIf"], ["backRoute", "orderDetails", "forwardRoute", "orderReturnConfirmation", 3, "orderCode", "amendOrderForm"]],
      template: function ReturnOrderComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ReturnOrderComponent_ng_container_0_Template, 8, 6, "ng-container", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.form$));
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, CancelOrReturnItemsComponent, AmendOrderActionsComponent, FormErrorsComponent, AsyncPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnOrderComponent, [{
    type: Component,
    args: [{
      selector: "cx-return-order",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="form$ | async as form">
  <ng-container *ngTemplateOutlet="actions"></ng-container>

  <cx-amend-order-items *ngIf="entries$ | async as entries" [entries]="entries">
  </cx-amend-order-items>

  <cx-form-errors [control]="form.get('entries')"></cx-form-errors>

  <ng-container *ngTemplateOutlet="actions"></ng-container>

  <ng-template #actions>
    <cx-amend-order-actions
      *ngIf="orderCode"
      [orderCode]="orderCode"
      [amendOrderForm]="form"
      backRoute="orderDetails"
      forwardRoute="orderReturnConfirmation"
    ></cx-amend-order-actions>
  </ng-template>
</ng-container>
`
    }]
  }], () => [{
    type: OrderAmendService
  }], null);
})();
var ReturnOrderModule = class _ReturnOrderModule {
  static {
    this.ɵfac = function ReturnOrderModule_Factory(t) {
      return new (t || _ReturnOrderModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReturnOrderModule,
      declarations: [ReturnOrderComponent],
      imports: [CommonModule, AmendOrderItemsModule, AmendOrderActionsModule, FormErrorsModule],
      exports: [ReturnOrderComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturnOrderComponent: {
            component: ReturnOrderComponent,
            guards: [AuthGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderReturnService
            }]
          }
        }
      })],
      imports: [CommonModule, AmendOrderItemsModule, AmendOrderActionsModule, FormErrorsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnOrderModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, AmendOrderItemsModule, AmendOrderActionsModule, FormErrorsModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturnOrderComponent: {
            component: ReturnOrderComponent,
            guards: [AuthGuard],
            providers: [{
              provide: OrderAmendService,
              useExisting: OrderReturnService
            }]
          }
        }
      })],
      declarations: [ReturnOrderComponent],
      exports: [ReturnOrderComponent]
    }]
  }], null, null);
})();
var OrderReturnModule = class _OrderReturnModule {
  static {
    this.ɵfac = function OrderReturnModule_Factory(t) {
      return new (t || _OrderReturnModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderReturnModule,
      imports: [ReturnOrderModule, ReturnOrderConfirmationModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [ReturnOrderModule, ReturnOrderConfirmationModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderReturnModule, [{
    type: NgModule,
    args: [{
      imports: [ReturnOrderModule, ReturnOrderConfirmationModule]
    }]
  }], null, null);
})();
var OrderConfirmationGuard = class _OrderConfirmationGuard {
  constructor(orderFacade, router, semanticPathService) {
    this.orderFacade = orderFacade;
    this.router = router;
    this.semanticPathService = semanticPathService;
  }
  canActivate() {
    return this.orderFacade.getOrderDetails().pipe(map((orderDetails) => {
      if (orderDetails && Object.keys(orderDetails).length !== 0) {
        return true;
      } else {
        return this.router.parseUrl(this.semanticPathService.get("orders") ?? "");
      }
    }));
  }
  static {
    this.ɵfac = function OrderConfirmationGuard_Factory(t) {
      return new (t || _OrderConfirmationGuard)(ɵɵinject(OrderFacade), ɵɵinject(Router), ɵɵinject(SemanticPathService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderConfirmationGuard,
      factory: _OrderConfirmationGuard.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationGuard, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderFacade
  }, {
    type: Router
  }, {
    type: SemanticPathService
  }], null);
})();
var MyAccountV2OrdersComponent = class _MyAccountV2OrdersComponent {
  constructor() {
    this.service = inject(MyAccountV2OrderHistoryService);
    this.PAGE_SIZE = 3;
    this.orders$ = this.service.getOrderHistoryList(this.PAGE_SIZE).pipe(tap(() => this.isLoaded$.next(true)));
    this.isLoaded$ = new BehaviorSubject(false);
  }
  getProduct(order) {
    if (order.entries) {
      for (const entry of order.entries) {
        if (entry.product && entry.product.name && entry.product.images) {
          return entry.product;
        }
      }
      return order.entries[0].product;
    }
  }
  ngOnDestroy() {
    this.isLoaded$.next(false);
    this.service.clearOrderList();
  }
  static {
    this.ɵfac = function MyAccountV2OrdersComponent_Factory(t) {
      return new (t || _MyAccountV2OrdersComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2OrdersComponent,
      selectors: [["cx-my-account-v2-orders"]],
      decls: 17,
      vars: 20,
      consts: [["noOrder", ""], ["loading", ""], [1, "cx-my-account-view-header"], ["role", "heading", "aria-level", "4", 1, "cx-my-account-view-heading"], [1, "cx-my-account-view-show-more"], ["id", "show-more-orders", 1, "btn-link", "cx-action-link", 3, "routerLink"], [4, "ngIf", "ngIfElse"], [1, "cx-my-account-view-body"], [4, "ngFor", "ngForOf"], [1, "cx-my-account-view-order"], [1, "cx-my-account-view-order-header"], ["class", "cx-my-account-view-status", 4, "ngIf"], [1, "cx-my-account-view-code"], [1, "cx-my-account-view-order-body"], [4, "ngIf"], [1, "cx-my-account-view-status"], [1, "cx-my-account-view-order-column-1"], [1, "cx-my-account-view-order-column-1-image"], ["format", "thumbnail", "role", "presentation", 1, "cx-my-account-view-order-img", 3, "container"], [1, "cx-my-account-view-order-column-1-details"], [1, "cx-my-account-view-order-column-1-details-top"], [1, "cx-my-account-view-product-name"], [1, "cx-my-account-view-purchased-on"], [1, "cx-my-account-view-item-count"], [1, "cx-my-account-view-order-column-1-details-bottom"], [1, "cx-my-account-view-total-price"], [1, "cx-my-account-view-order-column-2"], [1, "btn-link", "cx-action-link", 3, "routerLink"], ["class", "cx-my-account-no-order", 4, "ngIf", "ngIfElse"], [1, "cx-my-account-no-order"], ["routerLinkActive", "active", 1, "cx-no-order", 3, "routerLink"], [1, "cx-spinner"]],
      template: function MyAccountV2OrdersComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 2)(1, "div", 3);
          ɵɵpipe(2, "cxTranslate");
          ɵɵtext(3);
          ɵɵpipe(4, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(5, "div", 4)(6, "a", 5);
          ɵɵpipe(7, "cxUrl");
          ɵɵpipe(8, "cxTranslate");
          ɵɵtext(9);
          ɵɵpipe(10, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵtemplate(11, MyAccountV2OrdersComponent_div_11_Template, 2, 2, "div", 6);
          ɵɵpipe(12, "async");
          ɵɵtemplate(13, MyAccountV2OrdersComponent_ng_template_13_Template, 2, 4, "ng-template", null, 0, ɵɵtemplateRefExtractor)(15, MyAccountV2OrdersComponent_ng_template_15_Template, 2, 0, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const noOrder_r5 = ɵɵreference(14);
          ɵɵadvance();
          ɵɵattribute("aria-label", ɵɵpipeBind1(2, 7, "myAccountV2OrderHistory.orderListResults"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(4, 9, "myAccountV2Orders.heading"), " ");
          ɵɵadvance(3);
          ɵɵproperty("routerLink", ɵɵpipeBind1(7, 11, ɵɵpureFunction0(19, _c2)));
          ɵɵattribute("aria-label", ɵɵpipeBind1(8, 13, "myAccountV2Orders.showMoreLabel"));
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(10, 15, "myAccountV2Orders.showMore"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(12, 17, ctx.orders$))("ngIfElse", noOrder_r5);
        }
      },
      dependencies: [NgForOf, NgIf, RouterLink, RouterLinkActive, SpinnerComponent, MediaComponent, AsyncPipe, UrlPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrdersComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-orders",
      template: `<div class="cx-my-account-view-header">
  <!-- HEADER -->
  <div
    class="cx-my-account-view-heading"
    role="heading"
    aria-level="4"
    [attr.aria-label]="'myAccountV2OrderHistory.orderListResults' | cxTranslate"
  >
    {{ 'myAccountV2Orders.heading' | cxTranslate }}
  </div>

  <!-- SHOW MORE -->
  <div class="cx-my-account-view-show-more">
    <a
      id="show-more-orders"
      [attr.aria-label]="'myAccountV2Orders.showMoreLabel' | cxTranslate"
      class="btn-link cx-action-link"
      [routerLink]="
        {
          cxRoute: 'orders',
        } | cxUrl
      "
    >
      {{ 'myAccountV2Orders.showMore' | cxTranslate }}
    </a>
  </div>
</div>

<div *ngIf="orders$ | async as orderHistory; else noOrder">
  <!-- BODY -->
  <ng-container *ngIf="orderHistory.pagination.totalResults > 0; else noOrder">
    <div class="cx-my-account-view-body">
      <ng-container *ngFor="let order of orderHistory.orders">
        <div class="cx-my-account-view-order">
          <div class="cx-my-account-view-order-header">
            <div
              class="cx-my-account-view-status"
              *ngIf="order.statusDisplay"
              [attr.aria-label]="
                'myAccountV2Orders.orderStatusLabel' | cxTranslate
              "
            >
              {{
                'orderDetails.statusDisplay_' + order.statusDisplay
                  | cxTranslate
              }}
            </div>
            <div
              class="cx-my-account-view-code"
              [attr.aria-label]="
                'myAccountV2OrderHistory.orderCodeLabel' | cxTranslate
              "
            >
              {{
                'myAccountV2Orders.orderNumber'
                  | cxTranslate: { value: order.code }
              }}
            </div>
          </div>
          <div class="cx-my-account-view-order-body">
            <ng-container *ngIf="getProduct(order) as product">
              <div class="cx-my-account-view-order-column-1">
                <div class="cx-my-account-view-order-column-1-image">
                  <cx-media
                    [container]="product.images?.PRIMARY"
                    class="cx-my-account-view-order-img"
                    format="thumbnail"
                    role="presentation"
                  ></cx-media>
                </div>
                <div class="cx-my-account-view-order-column-1-details">
                  <div class="cx-my-account-view-order-column-1-details-top">
                    <div class="cx-my-account-view-product-name">
                      {{ product.name }}
                      <span *ngIf="order.totalItems - 1 > 1">
                        +
                        {{
                          'myAccountV2Orders.items'
                            | cxTranslate: { value: order.totalItems - 1 }
                        }}
                      </span>
                      <span *ngIf="order.totalItems - 1 === 1">
                        +
                        {{
                          'myAccountV2Orders.item' | cxTranslate: { value: 1 }
                        }}
                      </span>
                    </div>
                    <div class="cx-my-account-view-purchased-on">
                      {{
                        'myAccountV2Orders.purchasedOn'
                          | cxTranslate
                            : {
                                value: order.placed | cxDate: 'd, MMMM, yyyy',
                              }
                      }}
                    </div>
                    <div class="cx-my-account-view-item-count">
                      {{
                        'myAccountV2Orders.orderedItems'
                          | cxTranslate: { value: order.totalItems }
                      }}
                    </div>
                  </div>
                  <div class="cx-my-account-view-order-column-1-details-bottom">
                    <div class="cx-my-account-view-total-price">
                      {{
                        'myAccountV2Orders.totalPrice'
                          | cxTranslate: { value: order.total?.formattedValue }
                      }}
                    </div>
                  </div>
                </div>
              </div>
              <div class="cx-my-account-view-order-column-2">
                <!-- order details -->
                <span>
                  <a
                    class="btn-link cx-action-link"
                    [attr.aria-label]="
                      'myAccountV2Orders.orderDetailsLabel'
                        | cxTranslate: { value: order.code }
                    "
                    [routerLink]="
                      {
                        cxRoute: 'orderDetails',
                        params: order,
                      } | cxUrl
                    "
                  >
                    {{ 'myAccountV2Orders.orderDetails' | cxTranslate }}
                  </a>
                </span>
                <!-- return order -->
                <span *ngIf="order.returnable">
                  {{ ' | '
                  }}<a
                    class="btn-link cx-action-link"
                    [routerLink]="
                      {
                        cxRoute: 'orderReturn',
                        params: order,
                      } | cxUrl
                    "
                  >
                    {{ 'myAccountV2Orders.returnOrder' | cxTranslate }}
                  </a>
                </span>
              </div>
            </ng-container>
          </div>
        </div>
      </ng-container>
    </div>
  </ng-container>
</div>
<!-- NO ORDER CONTAINER -->
<ng-template #noOrder>
  <div class="cx-my-account-no-order" *ngIf="isLoaded$ | async; else loading">
    <div [attr.aria-label]="'orderHistory.notFound' | cxTranslate">
      {{ 'orderHistory.noOrders' | cxTranslate }}
    </div>
    <a
      [routerLink]="{ cxRoute: 'home' } | cxUrl"
      routerLinkActive="active"
      class="cx-no-order"
      >{{ 'orderHistory.startShopping' | cxTranslate }}</a
    >
  </div>
</ng-template>

<!-- ORDER HISTORY DATA STILL LOADING -->
<ng-template #loading>
  <div class="cx-spinner">
    <cx-spinner></cx-spinner>
  </div>
</ng-template>
`
    }]
  }], null, null);
})();
var MyAccountV2OrdersModule = class _MyAccountV2OrdersModule {
  static {
    this.ɵfac = function MyAccountV2OrdersModule_Factory(t) {
      return new (t || _MyAccountV2OrdersModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _MyAccountV2OrdersModule,
      declarations: [MyAccountV2OrdersComponent],
      imports: [CommonModule, RouterModule, FormsModule, SpinnerModule, UrlModule, I18nModule, MediaModule],
      exports: [MyAccountV2OrdersComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          MyAccountViewOrderComponent: {
            component: MyAccountV2OrdersComponent,
            guards: [AuthGuard]
          }
        }
      })],
      imports: [CommonModule, RouterModule, FormsModule, SpinnerModule, UrlModule, I18nModule, MediaModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrdersModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, FormsModule, SpinnerModule, UrlModule, I18nModule, MediaModule],
      declarations: [MyAccountV2OrdersComponent],
      exports: [MyAccountV2OrdersComponent],
      providers: [provideDefaultConfig({
        cmsComponents: {
          MyAccountViewOrderComponent: {
            component: MyAccountV2OrdersComponent,
            guards: [AuthGuard]
          }
        }
      })]
    }]
  }], null, null);
})();
var OrderDetailBillingComponent = class _OrderDetailBillingComponent {
  constructor(orderDetailsService, translationService) {
    this.orderDetailsService = orderDetailsService;
    this.translationService = translationService;
    this.order$ = this.orderDetailsService.getOrderDetails();
  }
  getPaymentMethodCard(paymentDetails) {
    return combineLatest([this.translationService.translate("paymentForm.payment"), this.translationService.translate("paymentCard.expires", {
      month: paymentDetails.expiryMonth,
      year: paymentDetails.expiryYear
    })]).pipe(map(([textTitle, textExpires]) => paymentMethodCard(textTitle, textExpires, paymentDetails)));
  }
  getBillingAddressCard(paymentDetails) {
    return combineLatest([this.translationService.translate("paymentForm.billingAddress"), this.translationService.translate("addressCard.billTo")]).pipe(map(([billingAddress, billTo]) => billingAddressCard(billingAddress, billTo, paymentDetails)));
  }
  isPaymentInfoCardFull(payment) {
    return !!payment?.cardNumber && !!payment?.expiryMonth && !!payment?.expiryYear;
  }
  static {
    this.ɵfac = function OrderDetailBillingComponent_Factory(t) {
      return new (t || _OrderDetailBillingComponent)(ɵɵdirectiveInject(OrderDetailsService), ɵɵdirectiveInject(TranslationService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderDetailBillingComponent,
      selectors: [["cx-order-detail-billing"]],
      decls: 2,
      vars: 3,
      consts: [["class", "cx-order-items", 4, "ngIf"], [1, "cx-order-items"], ["class", "cx-review-summary", 4, "ngIf"], [1, "cx-review-summary"], ["class", "cx-review-summary-card cx-review-summary-payment-card", 4, "ngIf"], [1, "cx-review-summary-card", "cx-review-summary-payment-card"], [3, "content"]],
      template: function OrderDetailBillingComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderDetailBillingComponent_div_0_Template, 2, 1, "div", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [CardComponent, NgIf, AsyncPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailBillingComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-detail-billing",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: '<div class="cx-order-items" *ngIf="order$ | async as order">\n  <div class="cx-review-summary" *ngIf="order.paymentInfo as paymentDetails">\n    <div\n      class="cx-review-summary-card cx-review-summary-payment-card"\n      *ngIf="isPaymentInfoCardFull(paymentDetails)"\n    >\n      <cx-card\n        [content]="getPaymentMethodCard(paymentDetails) | async"\n      ></cx-card>\n    </div>\n    <div\n      class="cx-review-summary-card cx-review-summary-payment-card"\n      *ngIf="paymentDetails?.billingAddress"\n    >\n      <cx-card\n        [content]="getBillingAddressCard(paymentDetails) | async"\n      ></cx-card>\n    </div>\n  </div>\n</div>\n'
    }]
  }], () => [{
    type: OrderDetailsService
  }, {
    type: TranslationService
  }], null);
})();
var OrderOverviewComponentService = class _OrderOverviewComponentService {
  shouldShowDeliveryMode(mode) {
    return mode !== void 0;
  }
  static {
    this.ɵfac = function OrderOverviewComponentService_Factory(t) {
      return new (t || _OrderOverviewComponentService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderOverviewComponentService,
      factory: _OrderOverviewComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderOverviewComponentService, [{
    type: Injectable
  }], null, null);
})();
var OrderOverviewComponent = class _OrderOverviewComponent {
  constructor(translation, orderDetailsService, component) {
    this.translation = translation;
    this.orderDetailsService = orderDetailsService;
    this.component = component;
    this.orderOverviewComponentService = inject(OrderOverviewComponentService);
    this.cartOutlets = CartOutlets;
    this.orderOutlets = OrderOutlets;
    this.order$ = this.orderDetailsService.getOrderDetails();
    this.isOrderLoading$ = typeof this.orderDetailsService.isOrderDetailsLoading === "function" ? this.orderDetailsService.isOrderDetailsLoading() : of(false);
    this.simple$ = this.component.data$.pipe(map((data) => data.simple));
  }
  getReplenishmentCodeCardContent(orderCode) {
    return this.translation.translate("orderDetails.replenishmentId").pipe(filter(() => Boolean(orderCode)), map((textTitle) => ({
      title: textTitle,
      text: [orderCode]
    })));
  }
  getReplenishmentActiveCardContent(active) {
    return combineLatest([this.translation.translate("orderDetails.status"), this.translation.translate("orderDetails.active"), this.translation.translate("orderDetails.cancelled")]).pipe(map(([textTitle, textActive, textCancelled]) => ({
      title: textTitle,
      text: [active ? textActive : textCancelled]
    })));
  }
  getReplenishmentStartOnCardContent(isoDate) {
    return this.translation.translate("orderDetails.startOn").pipe(filter(() => Boolean(isoDate)), map((textTitle) => {
      return {
        title: textTitle,
        text: [isoDate]
      };
    }));
  }
  getReplenishmentFrequencyCardContent(frequency) {
    return this.translation.translate("orderDetails.frequency").pipe(filter(() => Boolean(frequency)), map((textTitle) => ({
      title: textTitle,
      text: [frequency]
    })));
  }
  getReplenishmentNextDateCardContent(isoDate) {
    return this.translation.translate("orderDetails.nextOrderDate").pipe(filter(() => Boolean(isoDate)), map((textTitle) => {
      return {
        title: textTitle,
        text: [isoDate]
      };
    }));
  }
  getOrderCodeCardContent(orderCode) {
    return this.translation.translate("orderDetails.orderNumber").pipe(filter(() => Boolean(orderCode)), map((textTitle) => ({
      title: textTitle,
      text: [orderCode]
    })));
  }
  getOrderCurrentDateCardContent(isoDate) {
    return this.translation.translate("orderDetails.placedOn").pipe(filter(() => Boolean(isoDate)), map((textTitle) => {
      return {
        title: textTitle,
        text: [isoDate]
      };
    }));
  }
  getOrderStatusCardContent(status) {
    return combineLatest([this.translation.translate("orderDetails.status"), this.translation.translate("orderDetails.statusDisplay_" + status)]).pipe(map(([textTitle, textStatus]) => ({
      title: textTitle,
      text: [textStatus]
    })));
  }
  getPurchaseOrderNumber(poNumber) {
    return combineLatest([this.translation.translate("orderDetails.purchaseOrderNumber"), this.translation.translate("orderDetails.emptyPurchaseOrderId")]).pipe(map(([textTitle, noneTextTitle]) => ({
      title: textTitle,
      text: [poNumber ? poNumber : noneTextTitle]
    })));
  }
  getMethodOfPaymentCardContent(hasPaymentInfo) {
    return combineLatest([this.translation.translate("orderDetails.methodOfPayment"), this.translation.translate("paymentTypes.paymentType_ACCOUNT"), this.translation.translate("paymentTypes.paymentType_CARD")]).pipe(map(([textTitle, textAccount, textCard]) => ({
      title: textTitle,
      text: [Boolean(hasPaymentInfo) ? textCard : textAccount]
    })));
  }
  getCostCenterCardContent(costCenter) {
    return this.translation.translate("orderDetails.costCenter").pipe(filter(() => Boolean(costCenter)), map((textTitle) => ({
      title: textTitle,
      textBold: costCenter?.name,
      text: ["(" + costCenter?.unit?.name + ")"]
    })));
  }
  getAddressCardContent(deliveryAddress) {
    return this.translation.translate("addressCard.shipTo").pipe(filter(() => Boolean(deliveryAddress)), map((textTitle) => {
      const formattedAddress = this.normalizeFormattedAddress(deliveryAddress.formattedAddress ?? "");
      return {
        title: textTitle,
        textBold: `${deliveryAddress.firstName} ${deliveryAddress.lastName}`,
        text: [formattedAddress, deliveryAddress.country?.name]
      };
    }));
  }
  shouldShowDeliveryMode(mode) {
    return this.orderOverviewComponentService.shouldShowDeliveryMode(mode);
  }
  getDeliveryModeCardContent(deliveryMode) {
    return this.translation.translate("orderDetails.shippingMethod").pipe(filter(() => Boolean(deliveryMode)), map((textTitle) => ({
      title: textTitle,
      textBold: deliveryMode.name,
      text: [deliveryMode.description, deliveryMode.deliveryCost?.formattedValue ? deliveryMode.deliveryCost?.formattedValue : ""]
    })));
  }
  getPaymentInfoCardContent(payment) {
    return combineLatest([this.translation.translate("paymentForm.payment"), this.translation.translate("paymentCard.expires", {
      month: Boolean(payment) ? payment.expiryMonth : "",
      year: Boolean(payment) ? payment.expiryYear : ""
    })]).pipe(filter(() => Boolean(payment)), map(([textTitle, textExpires]) => paymentMethodCard(textTitle, textExpires, payment)));
  }
  isPaymentInfoCardFull(payment) {
    return !!payment?.cardNumber && !!payment?.expiryMonth && !!payment?.expiryYear;
  }
  getBillingAddressCardContent(billingAddress) {
    return this.translation.translate("paymentForm.billingAddress").pipe(filter(() => Boolean(billingAddress)), map((textTitle) => ({
      title: textTitle,
      textBold: `${billingAddress.firstName} ${billingAddress.lastName}`,
      text: [billingAddress.formattedAddress, billingAddress.country?.name]
    })));
  }
  normalizeFormattedAddress(formattedAddress) {
    const addresses = formattedAddress.split(",").map((address) => address.trim());
    return addresses.filter(Boolean).join(", ");
  }
  static {
    this.ɵfac = function OrderOverviewComponent_Factory(t) {
      return new (t || _OrderOverviewComponent)(ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(OrderDetailsService), ɵɵdirectiveInject(CmsComponentData));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderOverviewComponent,
      selectors: [["cx-order-overview"]],
      decls: 2,
      vars: 3,
      consts: [["otherOrder", ""], ["class", "cx-order-summary", 4, "ngIf"], [1, "cx-order-summary"], [4, "ngIf"], ["class", "container", 4, "ngIf"], [1, "container"], [4, "ngIf", "ngIfElse"], [1, "cx-summary-card"], [3, "cxOutlet", "cxOutletContext"], [3, "content"], ["class", "cx-summary-card", 4, "ngIf"], [1, "cx-order-details-cards"]],
      template: function OrderOverviewComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderOverviewComponent_div_0_Template, 3, 3, "div", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [CardComponent, NgIf, OutletDirective, OrderDetailBillingComponent, AsyncPipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderOverviewComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-overview",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div class="cx-order-summary" *ngIf="order$ | async as order">
  <ng-container *ngIf="!(isOrderLoading$ | async)">
    <div *ngIf="!(simple$ | async)" class="container">
      <ng-container *ngIf="order.replenishmentOrderCode; else otherOrder">
        <div class="cx-summary-card">
          <cx-card
            [content]="
              getReplenishmentCodeCardContent(order?.replenishmentOrderCode)
                | async
            "
          ></cx-card>

          <cx-card
            [content]="getReplenishmentActiveCardContent(order?.active) | async"
          ></cx-card>
        </div>

        <div class="cx-summary-card">
          <cx-card
            [content]="
              getReplenishmentStartOnCardContent(order?.firstDate | cxDate)
                | async
            "
          ></cx-card>

          <cx-card
            [content]="
              getReplenishmentFrequencyCardContent(
                order?.trigger?.displayTimeTable
              ) | async
            "
          ></cx-card>

          <cx-card
            [content]="
              getReplenishmentNextDateCardContent(
                order?.trigger?.activationTime | cxDate
              ) | async
            "
          ></cx-card>

          <ng-template
            [cxOutlet]="cartOutlets.ORDER_OVERVIEW"
            [cxOutletContext]="{ item: order, readonly: true }"
          >
          </ng-template>
        </div>
      </ng-container>

      <ng-template #otherOrder>
        <div class="cx-summary-card">
          <cx-card
            [content]="getOrderCodeCardContent(order?.code) | async"
          ></cx-card>

          <cx-card
            [content]="
              getOrderCurrentDateCardContent(order?.created | cxDate) | async
            "
          ></cx-card>

          <cx-card
            [content]="getOrderStatusCardContent(order.statusDisplay) | async"
          ></cx-card>

          <ng-template
            [cxOutlet]="cartOutlets.ORDER_OVERVIEW"
            [cxOutletContext]="{ item: order, readonly: true }"
          >
          </ng-template>
        </div>
      </ng-template>

      <ng-container
        *ngIf="order.purchaseOrderNumber || order.purchaseOrderNumber === ''"
      >
        <div class="cx-summary-card">
          <cx-card
            [content]="
              getPurchaseOrderNumber(order?.purchaseOrderNumber) | async
            "
          ></cx-card>

          <cx-card
            [content]="getMethodOfPaymentCardContent(order.paymentInfo) | async"
          ></cx-card>

          <ng-container *ngIf="order.costCenter">
            <cx-card
              [content]="getCostCenterCardContent(order?.costCenter) | async"
            ></cx-card>
          </ng-container>
        </div>
      </ng-container>

      <div class="cx-summary-card">
        <ng-container *ngIf="order.deliveryAddress">
          <cx-card
            [content]="getAddressCardContent(order?.deliveryAddress) | async"
          ></cx-card>
        </ng-container>

        <ng-container *ngIf="shouldShowDeliveryMode(order.deliveryMode)">
          <cx-card
            [content]="getDeliveryModeCardContent(order?.deliveryMode) | async"
          ></cx-card>
        </ng-container>

        <ng-template
          [cxOutlet]="orderOutlets.SERVICE_DETAILS"
          [cxOutletContext]="{ item: order, readonly: true }"
        >
        </ng-template>
      </div>

      <ng-container *ngIf="order.paymentInfo">
        <div
          class="cx-summary-card"
          *ngIf="
            order?.paymentInfo?.billingAddress ||
            isPaymentInfoCardFull(order?.paymentInfo)
          "
        >
          <ng-container *ngIf="isPaymentInfoCardFull(order?.paymentInfo)">
            <cx-card
              [content]="getPaymentInfoCardContent(order?.paymentInfo) | async"
            ></cx-card>
          </ng-container>

          <cx-card
            [content]="
              getBillingAddressCardContent(order?.paymentInfo?.billingAddress)
                | async
            "
          ></cx-card>
        </div>
      </ng-container>
    </div>

    <div *ngIf="simple$ | async" class="container">
      <div class="cx-order-details-cards">
        <cx-card
          [content]="getOrderCodeCardContent(order?.code) | async"
        ></cx-card>

        <cx-card
          [content]="
            getOrderCurrentDateCardContent(order?.created | cxDate) | async
          "
        ></cx-card>

        <cx-card
          [content]="getOrderStatusCardContent(order.statusDisplay) | async"
        ></cx-card>

        <ng-template
          [cxOutlet]="cartOutlets.ORDER_OVERVIEW"
          [cxOutletContext]="{ item: order, readonly: true }"
        >
        </ng-template>
      </div>
      <cx-order-detail-billing
        *ngIf="
          isPaymentInfoCardFull(order?.paymentInfo) ||
          order?.paymentInfo?.billingAddress
        "
      ></cx-order-detail-billing>
    </div>
  </ng-container>
</div>
`
    }]
  }], () => [{
    type: TranslationService
  }, {
    type: OrderDetailsService
  }, {
    type: CmsComponentData
  }], null);
})();
var OrderConfirmationOrderEntriesContext = class _OrderConfirmationOrderEntriesContext {
  constructor(orderFacade) {
    this.orderFacade = orderFacade;
    this.type = OrderEntriesSource.ORDER_CONFIRMATION;
  }
  getEntries() {
    return this.orderFacade.getOrderDetails().pipe(map((order) => order?.entries ?? []));
  }
  static {
    this.ɵfac = function OrderConfirmationOrderEntriesContext_Factory(t) {
      return new (t || _OrderConfirmationOrderEntriesContext)(ɵɵinject(OrderFacade));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderConfirmationOrderEntriesContext,
      factory: _OrderConfirmationOrderEntriesContext.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationOrderEntriesContext, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderFacade
  }], null);
})();
var OrderConfirmationItemsComponent = class _OrderConfirmationItemsComponent {
  constructor(orderFacade) {
    this.orderFacade = orderFacade;
    this.cartOutlets = CartOutlets;
    this.abstractOrderType = AbstractOrderType;
    this.promotionLocation = PromotionLocation.Checkout;
    this.order$ = this.orderFacade.getOrderDetails();
  }
  ngOnDestroy() {
    this.orderFacade.clearPlacedOrder();
  }
  static {
    this.ɵfac = function OrderConfirmationItemsComponent_Factory(t) {
      return new (t || _OrderConfirmationItemsComponent)(ɵɵdirectiveInject(OrderFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderConfirmationItemsComponent,
      selectors: [["cx-order-confirmation-items"]],
      decls: 2,
      vars: 3,
      consts: [["class", "cx-order-items container", 4, "ngIf"], [1, "cx-order-items", "container"], ["class", "cx-order-items-header", 4, "cxFeature"], [3, "promotions"], [3, "cxAbstractOrderContext", "cxOutlet", "cxOutletContext"], [1, "cx-order-items-header"]],
      template: function OrderConfirmationItemsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderConfirmationItemsComponent_div_0_Template, 5, 13, "div", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, PromotionsComponent, OutletDirective, AbstractOrderContextDirective, FeatureDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationItemsComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-confirmation-items",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div class="cx-order-items container" *ngIf="order$ | async as order">
  <!-- TODO: (CXSPA-6313) - Remove feature flag next major release -->
  <h3
    *cxFeature="'a11yOrderConfirmationHeadingOrder'"
    class="cx-order-items-header"
  >
    {{ 'checkoutOrderConfirmation.orderItems' | cxTranslate }}
  </h3>
  <h4
    *cxFeature="'!a11yOrderConfirmationHeadingOrder'"
    class="cx-order-items-header"
  >
    {{ 'checkoutOrderConfirmation.orderItems' | cxTranslate }}
  </h4>

  <cx-promotions
    [promotions]="order.appliedOrderPromotions || []"
  ></cx-promotions>

  <ng-template
    [cxAbstractOrderContext]="{
      id: order.code,
      type: abstractOrderType.ORDER,
    }"
    [cxOutlet]="cartOutlets.CART_ITEM_LIST"
    [cxOutletContext]="{
      items: order.entries,
      readonly: true,
      promotionLocation: promotionLocation,
    }"
  >
  </ng-template>
</div>
`
    }]
  }], () => [{
    type: OrderFacade
  }], null);
})();
var OrderConfirmationShippingComponent = class _OrderConfirmationShippingComponent {
  constructor(orderFacade, translationService, cd, outlet) {
    this.orderFacade = orderFacade;
    this.translationService = translationService;
    this.cd = cd;
    this.outlet = outlet;
    this.showItemList = true;
    this.cartOutlets = CartOutlets;
    this.abstractOrderType = AbstractOrderType;
    this.order$ = this.orderFacade.getOrderDetails().pipe(tap((order) => {
      this.entries = order?.entries?.filter((entry) => !entry.deliveryPointOfService);
    }));
    this.subscription = new Subscription();
  }
  ngOnInit() {
    this.subscription.add(this.outlet?.context$.subscribe((context) => {
      if (context.showItemList !== void 0) {
        this.showItemList = context.showItemList;
      }
      if (context.order) {
        this.order$ = of(context.order);
      }
      this.cd.markForCheck();
    }));
  }
  getDeliveryAddressCard(deliveryAddress, countryName) {
    return combineLatest([this.translationService.translate("addressCard.shipTo"), this.translationService.translate("addressCard.phoneNumber"), this.translationService.translate("addressCard.mobileNumber")]).pipe(map(([textTitle, textPhone, textMobile]) => deliveryAddressCard(textTitle, textPhone, textMobile, deliveryAddress, countryName)));
  }
  getDeliveryModeCard(deliveryMode) {
    return combineLatest([this.translationService.translate("checkoutMode.deliveryMethod")]).pipe(map(([textTitle]) => deliveryModeCard(textTitle, deliveryMode)));
  }
  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
  static {
    this.ɵfac = function OrderConfirmationShippingComponent_Factory(t) {
      return new (t || _OrderConfirmationShippingComponent)(ɵɵdirectiveInject(OrderFacade), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(OutletContextData, 8));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderConfirmationShippingComponent,
      selectors: [["cx-order-confirmation-shipping"]],
      inputs: {
        showItemList: "showItemList"
      },
      decls: 2,
      vars: 3,
      consts: [["class", "cx-order-items", 4, "ngIf"], [1, "cx-order-items"], [4, "ngIf"], [1, "cx-review-header"], [1, "cx-review-summary", "cx-review-shipping-summary"], [1, "cx-review-summary-card-container"], [1, "cx-review-summary-card", "cx-review-card-address"], [3, "content"], ["class", "cx-review-cart-item", 4, "ngIf"], [1, "cx-review-cart-item"], [3, "cxAbstractOrderContext", "cxOutlet", "cxOutletContext"]],
      template: function OrderConfirmationShippingComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderConfirmationShippingComponent_div_0_Template, 2, 1, "div", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, CardComponent, OutletDirective, AbstractOrderContextDirective, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationShippingComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-confirmation-shipping",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div class="cx-order-items" *ngIf="order$ | async as order">
  <ng-container *ngIf="!showItemList || entries?.length > 0">
    <h2 class="cx-review-header">
      {{ 'checkoutMode.deliveryEntries' | cxTranslate }}
    </h2>

    <div class="cx-review-summary cx-review-shipping-summary">
      <!-- DELIVERY ADDRESS SECTION -->
      <div class="cx-review-summary-card-container">
        <div class="cx-review-summary-card cx-review-card-address">
          <cx-card
            [content]="getDeliveryAddressCard(order.deliveryAddress) | async"
          ></cx-card>
        </div>
      </div>

      <!-- DELIVERY MODE SECTION -->
      <div class="cx-review-summary-card-container">
        <div class="cx-review-summary-card cx-review-card-address">
          <cx-card
            [content]="getDeliveryModeCard(order.deliveryMode) | async"
          ></cx-card>
        </div>
      </div>
    </div>

    <!-- CART ITEM SECTION -->
    <div *ngIf="showItemList" class="cx-review-cart-item">
      <ng-template
        [cxAbstractOrderContext]="{
          id: order.code,
          type: abstractOrderType.ORDER,
        }"
        [cxOutlet]="cartOutlets.CART_ITEM_LIST"
        [cxOutletContext]="{
          items: entries,
          readonly: true,
        }"
      >
      </ng-template>
    </div>
  </ng-container>
</div>
`
    }]
  }], () => [{
    type: OrderFacade
  }, {
    type: TranslationService
  }, {
    type: ChangeDetectorRef
  }, {
    type: OutletContextData,
    decorators: [{
      type: Optional
    }]
  }], {
    showItemList: [{
      type: Input
    }]
  });
})();
var OrderGuestRegisterFormComponent = class _OrderGuestRegisterFormComponent {
  constructor(userRegisterFacade, routingService, authService, fb) {
    this.userRegisterFacade = userRegisterFacade;
    this.routingService = routingService;
    this.authService = authService;
    this.fb = fb;
    this.featureConfigService = inject(FeatureConfigService);
    this.passwordValidators = this.featureConfigService?.isEnabled("formErrorsDescriptiveMessages") ? this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidators : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? [...CustomFormValidators.passwordValidators, CustomFormValidators.noConsecutiveCharacters] : CustomFormValidators.passwordValidators : [this.featureConfigService.isEnabled("enableSecurePasswordValidation") ? CustomFormValidators.securePasswordValidator : this.featureConfigService.isEnabled("enableConsecutiveCharactersPasswordRequirement") ? CustomFormValidators.strongPasswordValidator : CustomFormValidators.passwordValidator];
    this.guestRegisterForm = this.fb.group({
      password: ["", [Validators.required, ...this.passwordValidators]],
      passwordconf: ["", Validators.required]
    }, {
      validators: CustomFormValidators.passwordsMustMatch("password", "passwordconf")
    });
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  submit() {
    if (this.guestRegisterForm.valid) {
      this.userRegisterFacade.registerGuest(this.guid, this.guestRegisterForm.value.password);
      if (!this.subscription) {
        this.subscription = this.authService.isUserLoggedIn().subscribe((isLoggedIn) => {
          if (isLoggedIn) {
            this.routingService.go({
              cxRoute: "home"
            });
          }
        });
      }
    } else {
      this.guestRegisterForm.markAllAsTouched();
    }
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  static {
    this.ɵfac = function OrderGuestRegisterFormComponent_Factory(t) {
      return new (t || _OrderGuestRegisterFormComponent)(ɵɵdirectiveInject(UserRegisterFacade), ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(AuthService), ɵɵdirectiveInject(UntypedFormBuilder));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderGuestRegisterFormComponent,
      selectors: [["cx-guest-register-form"]],
      inputs: {
        guid: "guid",
        email: "email"
      },
      decls: 37,
      vars: 38,
      consts: [["requiredAsterisk", ""], [1, "register-guest"], [1, "col-md-6", "col-lg-4"], [3, "ngSubmit", "formGroup"], ["class", "form-legend", 4, "cxFeature"], [1, "form-group"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "type", "password", "name", "password", "formControlName", "password", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "password", "name", "passwordconf", "formControlName", "passwordconf", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], ["type", "submit", 1, "btn", "btn-block", "btn-primary"], [1, "form-legend"], [3, "translationParams", "control"], [3, "control"], ["class", "text-decoration-none required-asterisk", "aria-hidden", "true", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function OrderGuestRegisterFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 1)(1, "div", 2)(2, "h3");
          ɵɵtext(3);
          ɵɵpipe(4, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(5, "p");
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(8, "form", 3);
          ɵɵlistener("ngSubmit", function OrderGuestRegisterFormComponent_Template_form_ngSubmit_8_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.submit());
          });
          ɵɵtemplate(9, OrderGuestRegisterFormComponent_p_9_Template, 3, 3, "p", 4);
          ɵɵelementStart(10, "div", 5)(11, "label")(12, "span", 6);
          ɵɵtext(13);
          ɵɵpipe(14, "cxTranslate");
          ɵɵtemplate(15, OrderGuestRegisterFormComponent_ng_template_15_Template, 0, 0, "ng-template", 7);
          ɵɵelementEnd();
          ɵɵelement(16, "input", 8);
          ɵɵpipe(17, "cxTranslate");
          ɵɵpipe(18, "cxTranslate");
          ɵɵtemplate(19, OrderGuestRegisterFormComponent_cx_form_errors_19_Template, 2, 6, "cx-form-errors", 9)(20, OrderGuestRegisterFormComponent_cx_form_errors_20_Template, 1, 1, "cx-form-errors", 10);
          ɵɵelementEnd()();
          ɵɵelementStart(21, "div", 5)(22, "label")(23, "span", 6);
          ɵɵtext(24);
          ɵɵpipe(25, "cxTranslate");
          ɵɵtemplate(26, OrderGuestRegisterFormComponent_ng_template_26_Template, 0, 0, "ng-template", 7);
          ɵɵelementEnd();
          ɵɵelement(27, "input", 11);
          ɵɵpipe(28, "cxTranslate");
          ɵɵpipe(29, "cxTranslate");
          ɵɵtemplate(30, OrderGuestRegisterFormComponent_cx_form_errors_30_Template, 2, 6, "cx-form-errors", 9)(31, OrderGuestRegisterFormComponent_cx_form_errors_31_Template, 1, 1, "cx-form-errors", 10);
          ɵɵelementEnd()();
          ɵɵelementStart(32, "button", 12);
          ɵɵtext(33);
          ɵɵpipe(34, "cxTranslate");
          ɵɵelementEnd()()()();
          ɵɵtemplate(35, OrderGuestRegisterFormComponent_ng_template_35_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r3 = ɵɵreference(36);
          ɵɵadvance(3);
          ɵɵtextInterpolate(ɵɵpipeBind1(4, 17, "checkoutOrderConfirmation.createAccount"));
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind2(7, 19, "checkoutOrderConfirmation.createAccountForNext", ɵɵpureFunction1(36, _c13, ctx.email)), " ");
          ɵɵadvance(2);
          ɵɵproperty("formGroup", ctx.guestRegisterForm);
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 22, "register.password.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(17, 24, "register.password.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(18, 26, "register.password.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(25, 28, "register.confirmPassword.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(28, 30, "register.confirmPassword.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(29, 32, "register.confirmPassword.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(34, 34, "common.submit"), " ");
        }
      },
      dependencies: [NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, FormErrorsComponent, PasswordVisibilityToggleDirective, FeatureDirective, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderGuestRegisterFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-guest-register-form",
      template: `<div class="register-guest">
  <div class="col-md-6 col-lg-4">
    <h3>{{ 'checkoutOrderConfirmation.createAccount' | cxTranslate }}</h3>
    <p>
      {{
        'checkoutOrderConfirmation.createAccountForNext'
          | cxTranslate: { email: email }
      }}
    </p>

    <form (ngSubmit)="submit()" [formGroup]="guestRegisterForm">
      <p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
        {{ 'formLegend.required' | cxTranslate }}
      </p>
      <div class="form-group">
        <label>
          <span class="label-content">
            {{ 'register.password.label' | cxTranslate }}
            <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
          </span>
          <input
            required="true"
            class="form-control"
            type="password"
            name="password"
            placeholder="{{ 'register.password.placeholder' | cxTranslate }}"
            formControlName="password"
            [attr.aria-label]="'register.password.placeholder' | cxTranslate"
            cxPasswordVisibilitySwitch
          />

          <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
          <cx-form-errors
            *cxFeature="'formErrorsDescriptiveMessages'"
            [translationParams]="{
              label: 'register.password.label' | cxTranslate,
            }"
            [control]="guestRegisterForm.get('password')"
          ></cx-form-errors>

          <cx-form-errors
            *cxFeature="'!formErrorsDescriptiveMessages'"
            [control]="guestRegisterForm.get('password')"
          ></cx-form-errors>
        </label>
      </div>

      <div class="form-group">
        <label>
          <span class="label-content">
            {{ 'register.confirmPassword.label' | cxTranslate }}
            <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
          </span>
          <input
            required="true"
            class="form-control"
            type="password"
            name="passwordconf"
            placeholder="{{
              'register.confirmPassword.placeholder' | cxTranslate
            }}"
            formControlName="passwordconf"
            [attr.aria-label]="
              'register.confirmPassword.placeholder' | cxTranslate
            "
            cxPasswordVisibilitySwitch
          />

          <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
          <cx-form-errors
            *cxFeature="'formErrorsDescriptiveMessages'"
            [translationParams]="{
              label: 'register.confirmPassword.label' | cxTranslate,
            }"
            [control]="guestRegisterForm.get('passwordconf')"
          ></cx-form-errors>

          <cx-form-errors
            *cxFeature="'!formErrorsDescriptiveMessages'"
            [control]="guestRegisterForm.get('passwordconf')"
          ></cx-form-errors>
        </label>
      </div>

      <button type="submit" class="btn btn-block btn-primary">
        {{ 'common.submit' | cxTranslate }}
      </button>
    </form>
  </div>
</div>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    class="text-decoration-none required-asterisk"
    aria-hidden="true"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: UserRegisterFacade
  }, {
    type: RoutingService
  }, {
    type: AuthService
  }, {
    type: UntypedFormBuilder
  }], {
    guid: [{
      type: Input
    }],
    email: [{
      type: Input
    }]
  });
})();
var OrderConfirmationThankYouMessageComponent = class _OrderConfirmationThankYouMessageComponent {
  constructor(orderFacade, globalMessageService, translationService) {
    this.orderFacade = orderFacade;
    this.globalMessageService = globalMessageService;
    this.translationService = translationService;
    this.isGuestCustomer = false;
  }
  ngOnInit() {
    this.order$ = this.orderFacade.getOrderDetails().pipe(tap((order) => {
      this.isGuestCustomer = order && "guestCustomer" in order ? order.guestCustomer ?? false : false;
      this.orderGuid = order?.guid;
    }));
  }
  ngAfterViewInit() {
    this.addThankYouMessage();
  }
  ngOnDestroy() {
    this.orderFacade.clearPlacedOrder();
  }
  addThankYouMessage() {
    this.getThankYouAssistiveMessage().pipe(take(1)).subscribe(([order, confirmationOfOrderMessage, thankYouMessage, invoiceHasBeenSentByEmailMessage]) => {
      const code = order.replenishmentOrderCode ?? order.code;
      const message = `${confirmationOfOrderMessage} ${code}. ${thankYouMessage} ${invoiceHasBeenSentByEmailMessage}`;
      this.globalMessageService.add(message, GlobalMessageType.MSG_TYPE_ASSISTIVE);
    });
  }
  getThankYouAssistiveMessage() {
    const confirmationOfOrderMessage$ = this.translationService.translate("checkoutOrderConfirmation.confirmationOfOrder");
    const thankYouMessage$ = this.translationService.translate("checkoutOrderConfirmation.thankYou");
    const invoiceHasBeenSentByEmailMessage$ = this.translationService.translate("checkoutOrderConfirmation.invoiceHasBeenSentByEmail");
    return this.order$.pipe(filter((order) => !!order), withLatestFrom(confirmationOfOrderMessage$, thankYouMessage$, invoiceHasBeenSentByEmailMessage$));
  }
  static {
    this.ɵfac = function OrderConfirmationThankYouMessageComponent_Factory(t) {
      return new (t || _OrderConfirmationThankYouMessageComponent)(ɵɵdirectiveInject(OrderFacade), ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(TranslationService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderConfirmationThankYouMessageComponent,
      selectors: [["cx-order-confirmation-thank-you-message"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "cx-page-header"], [1, "cx-page-title"], [1, "cx-order-confirmation-message"], [3, "guid", "email"]],
      template: function OrderConfirmationThankYouMessageComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderConfirmationThankYouMessageComponent_ng_container_0_Template, 14, 11, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, AddToHomeScreenBannerComponent, OrderGuestRegisterFormComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationThankYouMessageComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-confirmation-thank-you-message",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="order$ | async as order">
  <div class="cx-page-header">
    <span class="cx-page-title">
      {{ 'checkoutOrderConfirmation.confirmationOfOrder' | cxTranslate }}
      {{ order.replenishmentOrderCode ?? order.code }}
    </span>
  </div>

  <div class="cx-order-confirmation-message">
    <h2>{{ 'checkoutOrderConfirmation.thankYou' | cxTranslate }}</h2>
    <p>
      {{ 'checkoutOrderConfirmation.invoiceHasBeenSentByEmail' | cxTranslate }}
    </p>
  </div>
  <div
    *ngIf="
      isGuestCustomer && orderGuid && order?.paymentInfo?.billingAddress?.email
    "
  >
    <cx-guest-register-form
      [guid]="orderGuid"
      [email]="order.paymentInfo.billingAddress.email"
    ></cx-guest-register-form>
  </div>

  <cx-add-to-home-screen-banner></cx-add-to-home-screen-banner>
</ng-container>
`
    }]
  }], () => [{
    type: OrderFacade
  }, {
    type: GlobalMessageService
  }, {
    type: TranslationService
  }], null);
})();
var OrderConfirmationTotalsComponent = class _OrderConfirmationTotalsComponent {
  constructor(orderFacade) {
    this.orderFacade = orderFacade;
    this.cartOutlets = CartOutlets;
    this.order$ = this.orderFacade.getOrderDetails();
  }
  ngOnDestroy() {
    this.orderFacade.clearPlacedOrder();
  }
  static {
    this.ɵfac = function OrderConfirmationTotalsComponent_Factory(t) {
      return new (t || _OrderConfirmationTotalsComponent)(ɵɵdirectiveInject(OrderFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderConfirmationTotalsComponent,
      selectors: [["cx-order-confirmation-totals"]],
      decls: 2,
      vars: 3,
      consts: [["class", "cx-order-summary container", 4, "ngIf"], [1, "cx-order-summary", "container"], [1, "row", "justify-content-end"], [1, "col-sm-12", "col-md-6", "col-lg-5", "col-xl-4"], [3, "cxOutlet", "cxOutletContext"]],
      template: function OrderConfirmationTotalsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderConfirmationTotalsComponent_div_0_Template, 4, 2, "div", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, OutletDirective, AsyncPipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationTotalsComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-confirmation-totals",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: '<div class="cx-order-summary container" *ngIf="order$ | async as order">\n  <div class="row justify-content-end">\n    <div class="col-sm-12 col-md-6 col-lg-5 col-xl-4">\n      <ng-template\n        [cxOutlet]="cartOutlets.ORDER_SUMMARY"\n        [cxOutletContext]="order"\n      >\n      </ng-template>\n    </div>\n  </div>\n</div>\n'
    }]
  }], () => [{
    type: OrderFacade
  }], null);
})();
var orderConfirmationComponents = [OrderConfirmationItemsComponent, OrderConfirmationThankYouMessageComponent, OrderConfirmationTotalsComponent, OrderGuestRegisterFormComponent, OrderConfirmationShippingComponent];
var OrderConfirmationModule = class _OrderConfirmationModule {
  static {
    this.ɵfac = function OrderConfirmationModule_Factory(t) {
      return new (t || _OrderConfirmationModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderConfirmationModule,
      declarations: [OrderConfirmationItemsComponent, OrderConfirmationThankYouMessageComponent, OrderConfirmationTotalsComponent, OrderGuestRegisterFormComponent, OrderConfirmationShippingComponent],
      imports: [CommonModule, CardModule, PwaModule, PromotionsModule, I18nModule, ReactiveFormsModule, FormErrorsModule, OutletModule, PasswordVisibilityToggleModule, AbstractOrderContextModule, FeaturesConfigModule],
      exports: [OrderConfirmationItemsComponent, OrderConfirmationThankYouMessageComponent, OrderConfirmationTotalsComponent, OrderGuestRegisterFormComponent, OrderConfirmationShippingComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          OrderConfirmationThankMessageComponent: {
            component: OrderConfirmationThankYouMessageComponent,
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationMessageComponent: {
            component: OrderConfirmationThankYouMessageComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationItemsComponent: {
            component: OrderConfirmationItemsComponent,
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationItemsComponent: {
            component: OrderConfirmationItemsComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationTotalsComponent: {
            component: OrderConfirmationTotalsComponent,
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationTotalsComponent: {
            component: OrderConfirmationTotalsComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationOverviewComponent: {
            component: OrderOverviewComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: OrderFacade
            }],
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationOverviewComponent: {
            component: OrderOverviewComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: OrderFacade
            }],
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationShippingComponent: {
            component: OrderConfirmationShippingComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationBillingComponent: {
            component: OrderDetailBillingComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: OrderFacade
            }],
            guards: [OrderConfirmationGuard]
          }
        }
      }), {
        provide: OrderConfirmationOrderEntriesContextToken,
        useExisting: OrderConfirmationOrderEntriesContext
      }, provideOutlet({
        id: OrderOutlets.CONSIGNMENT_DELIVERY_INFO,
        component: OrderConfirmationShippingComponent
      })],
      imports: [CommonModule, CardModule, PwaModule, PromotionsModule, I18nModule, ReactiveFormsModule, FormErrorsModule, OutletModule.forChild(), PasswordVisibilityToggleModule, AbstractOrderContextModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConfirmationModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, CardModule, PwaModule, PromotionsModule, I18nModule, ReactiveFormsModule, FormErrorsModule, OutletModule.forChild(), PasswordVisibilityToggleModule, AbstractOrderContextModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          OrderConfirmationThankMessageComponent: {
            component: OrderConfirmationThankYouMessageComponent,
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationMessageComponent: {
            component: OrderConfirmationThankYouMessageComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationItemsComponent: {
            component: OrderConfirmationItemsComponent,
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationItemsComponent: {
            component: OrderConfirmationItemsComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationTotalsComponent: {
            component: OrderConfirmationTotalsComponent,
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationTotalsComponent: {
            component: OrderConfirmationTotalsComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationOverviewComponent: {
            component: OrderOverviewComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: OrderFacade
            }],
            guards: [OrderConfirmationGuard]
          },
          ReplenishmentConfirmationOverviewComponent: {
            component: OrderOverviewComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: OrderFacade
            }],
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationShippingComponent: {
            component: OrderConfirmationShippingComponent,
            guards: [OrderConfirmationGuard]
          },
          OrderConfirmationBillingComponent: {
            component: OrderDetailBillingComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: OrderFacade
            }],
            guards: [OrderConfirmationGuard]
          }
        }
      }), {
        provide: OrderConfirmationOrderEntriesContextToken,
        useExisting: OrderConfirmationOrderEntriesContext
      }, provideOutlet({
        id: OrderOutlets.CONSIGNMENT_DELIVERY_INFO,
        component: OrderConfirmationShippingComponent
      })],
      declarations: [...orderConfirmationComponents],
      exports: [...orderConfirmationComponents]
    }]
  }], null, null);
})();
var OrderDetailActionsComponent = class _OrderDetailActionsComponent {
  constructor(orderDetailsService) {
    this.orderDetailsService = orderDetailsService;
    this.order$ = this.orderDetailsService.getOrderDetails();
  }
  static {
    this.ɵfac = function OrderDetailActionsComponent_Factory(t) {
      return new (t || _OrderDetailActionsComponent)(ɵɵdirectiveInject(OrderDetailsService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderDetailActionsComponent,
      selectors: [["cx-order-details-actions"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "cx-nav", "row"], [1, "col-xs-12", "col-md-4", "col-lg-3"], [1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], ["cxBtnLikeLink", "", "class", "btn btn-block btn-secondary", 3, "routerLink", 4, "ngIf"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"]],
      template: function OrderDetailActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderDetailActionsComponent_ng_container_0_Template, 10, 9, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, RouterLink, BtnLikeLinkDirective, AsyncPipe, TranslatePipe, UrlPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailActionsComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-details-actions",
      template: `<ng-container *ngIf="order$ | async as order">
  <div class="cx-nav row">
    <div class="col-xs-12 col-md-4 col-lg-3">
      <button
        [routerLink]="{ cxRoute: 'orders' } | cxUrl"
        class="btn btn-block btn-secondary"
      >
        {{ 'common.back' | cxTranslate }}
      </button>
    </div>

    <div class="col-xs-12 col-md-4 col-lg-3">
      <a
        *ngIf="order.cancellable"
        [routerLink]="
          {
            cxRoute: 'orderCancel',
            params: order,
          } | cxUrl
        "
        cxBtnLikeLink
        class="btn btn-block btn-secondary"
      >
        {{ 'orderDetails.cancellationAndReturn.cancelAction' | cxTranslate }}
      </a>

      <a
        *ngIf="order.returnable"
        [routerLink]="
          {
            cxRoute: 'orderReturn',
            params: order,
          } | cxUrl
        "
        cxBtnLikeLink
        class="btn btn-block btn-secondary"
      >
        {{ 'orderDetails.cancellationAndReturn.returnAction' | cxTranslate }}
      </a>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: OrderDetailsService
  }], null);
})();
var MyAccountV2OrderDetailsActionsComponent = class _MyAccountV2OrderDetailsActionsComponent extends OrderDetailActionsComponent {
  constructor() {
    super(...arguments);
    this.eventService = inject(EventService);
  }
  ngOnInit() {
    this.order$.subscribe((order) => {
      this.order = order;
    });
  }
  showDialog(order) {
    const newEvent = new DownloadOrderInvoicesEvent();
    newEvent.order = order;
    this.eventService.dispatch(newEvent);
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵMyAccountV2OrderDetailsActionsComponent_BaseFactory;
      return function MyAccountV2OrderDetailsActionsComponent_Factory(t) {
        return (ɵMyAccountV2OrderDetailsActionsComponent_BaseFactory || (ɵMyAccountV2OrderDetailsActionsComponent_BaseFactory = ɵɵgetInheritedFactory(_MyAccountV2OrderDetailsActionsComponent)))(t || _MyAccountV2OrderDetailsActionsComponent);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2OrderDetailsActionsComponent,
      selectors: [["cx-my-account-v2-order-details-actions"]],
      features: [ɵɵInheritDefinitionFeature],
      decls: 1,
      vars: 1,
      consts: [[4, "ngIf"], [1, "cx-order-details-actions", "row"], [1, "cx-view-all-orders"], [1, "col-xs-12", "col-md-4", "col-lg-3"], [1, "cx-action-button-left"], ["id", "view-all-orders-btn", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], [1, "cx-other-actions"], ["class", "cx-action-button", 4, "ngIf"], [1, "cx-action-button"], ["id", "download-invoices-btn", 1, "btn", "btn-block", "btn-secondary", 3, "click"], ["id", "cancel-items-btn", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], ["id", "return-items-btn", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"]],
      template: function MyAccountV2OrderDetailsActionsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2OrderDetailsActionsComponent_ng_container_0_Template, 17, 12, "ng-container", 0);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ctx.order);
        }
      },
      dependencies: [NgIf, RouterLink, TranslatePipe, UrlPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrderDetailsActionsComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-order-details-actions",
      template: `<ng-container *ngIf="order">
  <div class="cx-order-details-actions row">
    <div class="cx-view-all-orders">
      <span class="col-xs-12 col-md-4 col-lg-3">
        <span class="cx-action-button-left">
          <button
            id="view-all-orders-btn"
            [routerLink]="{ cxRoute: 'orders' } | cxUrl"
            class="btn btn-block btn-secondary"
          >
            {{ 'myAccountV2OrderDetails.viewAllOrders' | cxTranslate }}
          </button>
        </span>
      </span>
    </div>
    <div class="cx-other-actions">
      <span class="col-xs-12 col-md-4 col-lg-3">
        <span *ngIf="order.cancellable" class="cx-action-button">
          <button
            id="cancel-items-btn"
            [routerLink]="
              {
                cxRoute: 'orderCancel',
                params: order,
              } | cxUrl
            "
            class="btn btn-block btn-secondary"
          >
            {{ 'myAccountV2OrderDetails.cancelItems' | cxTranslate }}
          </button>
        </span>
        <span *ngIf="order.returnable" class="cx-action-button">
          <button
            id="return-items-btn"
            [routerLink]="
              {
                cxRoute: 'orderReturn',
                params: order,
              } | cxUrl
            "
            class="btn btn-block btn-secondary"
          >
            {{ 'myAccountV2OrderDetails.returnItems' | cxTranslate }}
          </button>
        </span>
        <span class="cx-action-button">
          <button
            id="download-invoices-btn"
            class="btn btn-block btn-secondary"
            (click)="showDialog(order)"
          >
            {{ 'myAccountV2OrderDetails.downloadInvoices' | cxTranslate }}
          </button>
        </span>
      </span>
    </div>
  </div>
</ng-container>
`
    }]
  }], null, null);
})();
var MyAccountV2DownloadInvoicesComponent = class _MyAccountV2DownloadInvoicesComponent {
  constructor() {
    this.OrderOutlets = OrderOutlets;
    this.invoiceCount = void 0;
    this.iconTypes = ICON_TYPE;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
    this.launchDialogService = inject(LaunchDialogService);
    this.cdr = inject(ChangeDetectorRef);
  }
  ngAfterViewChecked() {
    this.cdr.detectChanges();
    if (this.invoiceComponent && this.invoiceComponent.pagination !== void 0) {
      this.invoiceCount = this.invoiceComponent.pagination.totalResults;
    }
  }
  close(reason, _message) {
    this.launchDialogService.closeDialog(reason);
  }
  static {
    this.ɵfac = function MyAccountV2DownloadInvoicesComponent_Factory(t) {
      return new (t || _MyAccountV2DownloadInvoicesComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2DownloadInvoicesComponent,
      selectors: [["cx-my-account-v2-download-invoices"]],
      viewQuery: function MyAccountV2DownloadInvoicesComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(InvoicesListComponent, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.invoiceComponent = _t.first);
        }
      },
      decls: 15,
      vars: 13,
      consts: [["role", "dialog", "aria-describedby", "downloadInvoicesContent", 1, "cx-modal-container", 3, "esc", "cxFocus"], ["id", "downloadInvoicesContent", 1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], ["id", "downloadInvoicesTitle", "aria-labelledby", "downloadInvoicesTitle", "tabindex", "-1", 1, "cx-dialog-title", "modal-title"], ["type", "button", "aria-controls", "downloadInvoicesContent", 1, "close", 3, "click", "title"], ["aria-hidden", "true"], [3, "type"], [1, "cx-dialog-body", "modal-body"], ["id", "noInvoice", "role", "alert", 4, "ngIf"], ["class", "cx-spinner", "aria-live", "polite", "role", "alert", 4, "ngIf"], ["id", "noInvoice", "role", "alert"], ["aria-live", "polite", "role", "alert", 1, "cx-spinner"]],
      template: function MyAccountV2DownloadInvoicesComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵlistener("esc", function MyAccountV2DownloadInvoicesComponent_Template_div_esc_0_listener() {
            return ctx.close("Escape clicked");
          });
          ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "div", 3);
          ɵɵtext(4);
          ɵɵpipe(5, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(6, "button", 4);
          ɵɵpipe(7, "cxTranslate");
          ɵɵpipe(8, "cxTranslate");
          ɵɵlistener("click", function MyAccountV2DownloadInvoicesComponent_Template_button_click_6_listener() {
            return ctx.close("Close download invoices dialog");
          });
          ɵɵelementStart(9, "span", 5);
          ɵɵelement(10, "cx-icon", 6);
          ɵɵelementEnd()()();
          ɵɵelementStart(11, "div", 7);
          ɵɵelement(12, "cx-invoices-list");
          ɵɵtemplate(13, MyAccountV2DownloadInvoicesComponent_div_13_Template, 3, 3, "div", 8)(14, MyAccountV2DownloadInvoicesComponent_div_14_Template, 2, 0, "div", 9);
          ɵɵelementEnd()()();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 7, "myAccountV2OrderDetails.downloadInvoices"), " ");
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("title", ɵɵpipeBind1(7, 9, "addToCart.closeModal"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(8, 11, "addToCart.closeModal"));
          ɵɵadvance(4);
          ɵɵproperty("type", ctx.iconTypes.CLOSE);
          ɵɵadvance(3);
          ɵɵproperty("ngIf", ctx.invoiceCount === 0);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.invoiceCount === void 0);
        }
      },
      dependencies: [NgIf, FocusDirective, IconComponent, SpinnerComponent, InvoicesListComponent, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2DownloadInvoicesComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-download-invoices",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div
  [cxFocus]="focusConfig"
  (esc)="close('Escape clicked')"
  class="cx-modal-container"
  role="dialog"
  aria-describedby="downloadInvoicesContent"
>
  <div id="downloadInvoicesContent" class="cx-modal-content">
    <div class="cx-dialog-header modal-header">
      <div
        id="downloadInvoicesTitle"
        class="cx-dialog-title modal-title"
        aria-labelledby="downloadInvoicesTitle"
        tabindex="-1"
      >
        {{ 'myAccountV2OrderDetails.downloadInvoices' | cxTranslate }}
      </div>
      <button
        type="button"
        class="close"
        attr.aria-label="{{ 'addToCart.closeModal' | cxTranslate }}"
        aria-controls="downloadInvoicesContent"
        title="{{ 'addToCart.closeModal' | cxTranslate }}"
        (click)="close('Close download invoices dialog')"
      >
        <span aria-hidden="true">
          <cx-icon [type]="iconTypes.CLOSE"></cx-icon>
        </span>
      </button>
    </div>

    <div class="cx-dialog-body modal-body">
      <cx-invoices-list> </cx-invoices-list>
      <div id="noInvoice" *ngIf="invoiceCount === 0" role="alert">
        {{ 'myAccountV2OrderDetails.noInvoices' | cxTranslate }}
      </div>
      <div
        *ngIf="invoiceCount === undefined"
        class="cx-spinner"
        aria-live="polite"
        role="alert"
      >
        <cx-spinner></cx-spinner>
      </div>
    </div>
  </div>
</div>
`
    }]
  }], null, {
    invoiceComponent: [{
      type: ViewChild,
      args: [InvoicesListComponent, {
        static: false
      }]
    }]
  });
})();
var defaultMyAccountV2DownloadInvoicesLayoutConfig = {
  launch: {
    DOWNLOAD_ORDER_INVOICES: {
      inlineRoot: true,
      component: MyAccountV2DownloadInvoicesComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var MyAccountV2DownloadInvoicesEventListener = class _MyAccountV2DownloadInvoicesEventListener {
  constructor() {
    this.subscription = new Subscription();
    this.eventService = inject(EventService);
    this.launchDialogService = inject(LaunchDialogService);
    this.onDownloadInvoices();
  }
  onDownloadInvoices() {
    this.subscription.add(this.eventService.get(DownloadOrderInvoicesEvent).subscribe((event) => {
      this.openDialog(event);
    }));
  }
  openDialog(event) {
    const dialog = this.launchDialogService.openDialog("DOWNLOAD_ORDER_INVOICES", void 0, void 0, event.order);
    if (dialog) {
      dialog.pipe(take(1)).subscribe();
    }
  }
  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
  static {
    this.ɵfac = function MyAccountV2DownloadInvoicesEventListener_Factory(t) {
      return new (t || _MyAccountV2DownloadInvoicesEventListener)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _MyAccountV2DownloadInvoicesEventListener,
      factory: _MyAccountV2DownloadInvoicesEventListener.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2DownloadInvoicesEventListener, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [], null);
})();
var MyAccountV2DownloadInvoicesModule = class _MyAccountV2DownloadInvoicesModule {
  constructor() {
    this.downloadInvoicesDialogEventListener = inject(MyAccountV2DownloadInvoicesEventListener);
  }
  static {
    this.ɵfac = function MyAccountV2DownloadInvoicesModule_Factory(t) {
      return new (t || _MyAccountV2DownloadInvoicesModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _MyAccountV2DownloadInvoicesModule,
      declarations: [MyAccountV2DownloadInvoicesComponent],
      imports: [CommonModule, KeyboardFocusModule, IconModule, I18nModule, PaginationModule, SortingModule, SpinnerModule, PDFInvoicesComponentsModule],
      exports: [MyAccountV2DownloadInvoicesComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultMyAccountV2DownloadInvoicesLayoutConfig)],
      imports: [CommonModule, KeyboardFocusModule, IconModule, I18nModule, PaginationModule, SortingModule, SpinnerModule, PDFInvoicesComponentsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2DownloadInvoicesModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, KeyboardFocusModule, IconModule, I18nModule, PaginationModule, SortingModule, SpinnerModule, PDFInvoicesComponentsModule],
      providers: [provideDefaultConfig(defaultMyAccountV2DownloadInvoicesLayoutConfig)],
      exports: [MyAccountV2DownloadInvoicesComponent],
      declarations: [MyAccountV2DownloadInvoicesComponent]
    }]
  }], null, null);
})();
var completedValues = ["DELIVERY_COMPLETED", "PICKUP_COMPLETE"];
var cancelledValues = ["CANCELLED"];
var MyAccountV2OrderConsignmentsService = class _MyAccountV2OrderConsignmentsService {
  getGroupedConsignments(order, pickup) {
    const consignments = pickup ? order.consignments?.filter((consignment) => consignment.deliveryPointOfService !== void 0) : order.consignments?.filter((consignment) => consignment.deliveryPointOfService === void 0);
    return this.groupConsignments(consignments);
  }
  getUnconsignedEntries(order, pickup) {
    if (order.replenishmentOrderCode) {
      return [];
    }
    return pickup ? order.unconsignedEntries?.filter((entry) => entry.deliveryPointOfService !== void 0) : order.unconsignedEntries?.filter((entry) => entry.deliveryPointOfService === void 0);
  }
  groupConsignments(consignments) {
    const grouped = consignments?.reduce((result, current) => {
      const key = this.getStatusGroupKey(current.status || "");
      result[key] = result[key] || [];
      result[key].push(current);
      return result;
    }, {});
    return grouped ? [...grouped[1] || [], ...grouped[0] || [], ...grouped[-1] || []] : void 0;
  }
  /**
   * complete: 0
   * processing: 1
   * cancel: -1
   */
  getStatusGroupKey(status) {
    if (completedValues.includes(status)) {
      return 0;
    }
    if (cancelledValues.includes(status)) {
      return -1;
    }
    return 1;
  }
  static {
    this.ɵfac = function MyAccountV2OrderConsignmentsService_Factory(t) {
      return new (t || _MyAccountV2OrderConsignmentsService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _MyAccountV2OrderConsignmentsService,
      factory: _MyAccountV2OrderConsignmentsService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrderConsignmentsService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var ConsignmentTrackingComponent = class _ConsignmentTrackingComponent {
  constructor(orderHistoryFacade, launchDialogService, vcr) {
    this.orderHistoryFacade = orderHistoryFacade;
    this.launchDialogService = launchDialogService;
    this.vcr = vcr;
    this.consignmentStatus = ["SHIPPED", "IN_TRANSIT", "DELIVERY_COMPLETED", "DELIVERY_REJECTED", "DELIVERING"];
  }
  ngOnInit() {
    this.consignmentTracking$ = this.orderHistoryFacade.getConsignmentTracking();
  }
  openTrackingDialog(consignment) {
    if (consignment.code) {
      this.orderHistoryFacade.loadConsignmentTracking(this.orderCode, consignment.code);
    }
    const modalInstanceData = {
      tracking$: this.consignmentTracking$,
      shipDate: consignment.statusDate
    };
    const dialog = this.launchDialogService.openDialog("CONSIGNMENT_TRACKING", this.element, this.vcr, modalInstanceData);
    if (dialog) {
      dialog.pipe(take(1)).subscribe();
    }
  }
  ngOnDestroy() {
    this.orderHistoryFacade.clearConsignmentTracking();
  }
  static {
    this.ɵfac = function ConsignmentTrackingComponent_Factory(t) {
      return new (t || _ConsignmentTrackingComponent)(ɵɵdirectiveInject(OrderHistoryFacade), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ViewContainerRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ConsignmentTrackingComponent,
      selectors: [["cx-consignment-tracking"]],
      viewQuery: function ConsignmentTrackingComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c16, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
        }
      },
      inputs: {
        consignment: "consignment",
        orderCode: "orderCode"
      },
      decls: 1,
      vars: 1,
      consts: [[4, "ngIf"], ["type", "button", 1, "btn", "btn-secondary", "btn-track", 3, "click"]],
      template: function ConsignmentTrackingComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ConsignmentTrackingComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ctx.consignment && ctx.consignment.status);
        }
      },
      dependencies: [NgIf, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ConsignmentTrackingComponent, [{
    type: Component,
    args: [{
      selector: "cx-consignment-tracking",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="consignment && consignment.status">
  <div *ngIf="consignmentStatus.includes(consignment.status)">
    <button
      (click)="openTrackingDialog(consignment)"
      class="btn btn-secondary btn-track"
      type="button"
    >
      {{ 'orderDetails.consignmentTracking.action' | cxTranslate }}
    </button>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: OrderHistoryFacade
  }, {
    type: LaunchDialogService
  }, {
    type: ViewContainerRef
  }], {
    element: [{
      type: ViewChild,
      args: ["element"]
    }],
    consignment: [{
      type: Input
    }],
    orderCode: [{
      type: Input
    }]
  });
})();
var OrderConsignedEntriesComponent = class _OrderConsignedEntriesComponent {
  constructor() {
    this.promotionLocation = PromotionLocation.Order;
    this.OrderOutlets = OrderOutlets;
    this.CartOutlets = CartOutlets;
    this.abstractOrderType = AbstractOrderType;
  }
  static {
    this.ɵfac = function OrderConsignedEntriesComponent_Factory(t) {
      return new (t || _OrderConsignedEntriesComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderConsignedEntriesComponent,
      selectors: [["cx-order-consigned-entries"]],
      inputs: {
        consignments: "consignments",
        order: "order",
        enableAddToCart: "enableAddToCart",
        buyItAgainTranslation: "buyItAgainTranslation"
      },
      decls: 3,
      vars: 1,
      consts: [["addToCartBtn", ""], ["class", "cx-list row", 4, "ngFor", "ngForOf"], [1, "cx-list", "row"], [3, "cxOutlet", "cxOutletContext"], [1, "cx-list-item", "col-12"], [3, "cxAbstractOrderContext", "cxOutlet", "cxOutletContext"], [1, "cx-list-header", "col-12"], [1, "cx-list-status"], [4, "ngIf"], ["class", "cx-list-date", 4, "ngIf"], [3, "orderCode", "consignment", 4, "cxFeature"], [1, "cx-list-date"], [3, "orderCode", "consignment"], [1, "add-to-cart", 3, "productCode", "product", "showQuantity", "options", "pickupStore"]],
      template: function OrderConsignedEntriesComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderConsignedEntriesComponent_div_0_Template, 4, 19, "div", 1)(1, OrderConsignedEntriesComponent_ng_template_1_Template, 1, 5, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          ɵɵproperty("ngForOf", ctx.consignments);
        }
      },
      dependencies: [NgForOf, NgIf, FeatureDirective, OutletDirective, AddToCartComponent, AbstractOrderContextDirective, ConsignmentTrackingComponent, TranslatePipe, CxDatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderConsignedEntriesComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-consigned-entries",
      template: `<div *ngFor="let consignment of consignments" class="cx-list row">
  <ng-template
    [cxOutlet]="OrderOutlets.ORDER_CONSIGNMENT"
    [cxOutletContext]="{ item: consignment, order: order }"
  >
    <div class="cx-list-header col-12">
      <div class="cx-list-status">
        <span *ngIf="consignment">
          {{
            'orderDetails.deliveryStatus_' + consignment?.status | cxTranslate
          }}
        </span>
      </div>
      <div *ngIf="consignment?.statusDate" class="cx-list-date">
        <div>{{ consignment?.statusDate | cxDate }}</div>
      </div>

      <cx-consignment-tracking
        [orderCode]="order.code"
        [consignment]="consignment"
        *cxFeature="'consignmentTracking'"
      >
      </cx-consignment-tracking>
    </div>
  </ng-template>
  <div class="cx-list-item col-12">
    <ng-template
      [cxAbstractOrderContext]="{
        id: order.code,
        type: abstractOrderType.ORDER,
      }"
      [cxOutlet]="CartOutlets.CART_ITEM_LIST"
      [cxOutletContext]="{
        items: consignment.entries,
        readonly: true,
        promotionLocation: promotionLocation,
        options: {
          displayAddToCart: enableAddToCart,
          addToCartString: buyItAgainTranslation,
          optionalBtn: addToCartBtn,
        },
      }"
    >
    </ng-template>
  </div>
</div>

<ng-template let-ctx #addToCartBtn>
  <cx-add-to-cart
    [productCode]="ctx.item.product?.code"
    [product]="ctx.item.product"
    [showQuantity]="false"
    [options]="ctx.options"
    [pickupStore]="ctx.item.deliveryPointOfService?.name"
    class="add-to-cart"
  >
  </cx-add-to-cart>
</ng-template>
`
    }]
  }], null, {
    consignments: [{
      type: Input
    }],
    order: [{
      type: Input
    }],
    enableAddToCart: [{
      type: Input
    }],
    buyItAgainTranslation: [{
      type: Input
    }]
  });
})();
var OrderDetailItemsComponent = class _OrderDetailItemsComponent {
  constructor(orderDetailsService, component) {
    this.orderDetailsService = orderDetailsService;
    this.component = component;
    this.orderConsignmentsService = inject(MyAccountV2OrderConsignmentsService);
    this.OrderOutlets = OrderOutlets;
    this.CartOutlets = CartOutlets;
    this.abstractOrderType = AbstractOrderType;
    this.promotionLocation = PromotionLocation.Order;
    this.order$ = this.orderDetailsService.getOrderDetails().pipe(tap((order) => {
      this.pickupConsignments = this.getGroupedConsignments(order, true);
      this.deliveryConsignments = this.getGroupedConsignments(order, false);
      this.pickupUnconsignedEntries = this.getUnconsignedEntries(order, true);
      this.deliveryUnConsignedEntries = this.getUnconsignedEntries(order, false);
    }));
    this.enableAddToCart$ = this.component.data$.pipe(map((data) => data.enableAddToCart));
    this.isOrderLoading$ = typeof this.orderDetailsService.isOrderDetailsLoading === "function" ? this.orderDetailsService.isOrderDetailsLoading() : of(false);
    this.groupCartItems$ = this.component.data$.pipe(map((data) => data.groupCartItems));
  }
  getGroupedConsignments(order, pickup) {
    return this.orderConsignmentsService.getGroupedConsignments(order, pickup);
  }
  getUnconsignedEntries(order, pickup) {
    return this.orderConsignmentsService.getUnconsignedEntries(order, pickup);
  }
  static {
    this.ɵfac = function OrderDetailItemsComponent_Factory(t) {
      return new (t || _OrderDetailItemsComponent)(ɵɵdirectiveInject(OrderDetailsService), ɵɵdirectiveInject(CmsComponentData));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderDetailItemsComponent,
      selectors: [["cx-order-details-items"]],
      decls: 2,
      vars: 3,
      consts: [["addToCartBtn", ""], [4, "ngIf"], ["class", "cx-pickup-order-consigned-entries-header", 4, "ngIf"], [3, "order", "consignments", "enableAddToCart", "buyItAgainTranslation", 4, "ngIf"], [3, "promotions"], [1, "cx-pickup-order-consigned-entries-header"], [3, "order", "consignments", "enableAddToCart", "buyItAgainTranslation"], [3, "cxOutlet", "cxOutletContext"], ["class", "cx-list-header", 4, "ngIf"], [1, "cx-list-header"], [1, "cx-list-status"], ["class", "cx-review-header", 4, "ngIf"], [1, "cx-list-item"], [3, "cxAbstractOrderContext", "cxOutlet", "cxOutletContext"], [1, "cx-review-header"], [1, "cx-list"], [1, "add-to-cart", 3, "productCode", "product", "showQuantity", "options", "pickupStore"]],
      template: function OrderDetailItemsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderDetailItemsComponent_ng_container_0_Template, 5, 3, "ng-container", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, PromotionsComponent, OutletDirective, AddToCartComponent, AbstractOrderContextDirective, OrderConsignedEntriesComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailItemsComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-details-items",
      template: `<ng-container *ngIf="order$ | async as order">
  <ng-container *ngIf="!(isOrderLoading$ | async)">
    <ng-container
      *ngIf="
        order.consignments?.length ||
        order.unconsignedEntries?.length ||
        order.replenishmentOrderCode
      "
    >
      <cx-promotions
        [promotions]="order.appliedOrderPromotions || []"
      ></cx-promotions>
    </ng-container>

    <!-- pickup consigned entries -->
    <div
      *ngIf="pickupConsignments?.length"
      class="cx-pickup-order-consigned-entries-header"
    >
      {{ 'deliveryPointOfServiceDetails.itemsToBePickUp' | cxTranslate }}
    </div>
    <cx-order-consigned-entries
      *ngIf="pickupConsignments"
      [order]="order"
      [consignments]="pickupConsignments"
      [enableAddToCart]="enableAddToCart$ | async"
      [buyItAgainTranslation]="'addToCart.buyItAgain' | cxTranslate"
    ></cx-order-consigned-entries>

    <!-- delivery consignment address and delivery mode -->
    <ng-template
      *ngIf="
        deliveryConsignments &&
        deliveryConsignments.length > 0 &&
        (groupCartItems$ | async)
      "
      [cxOutlet]="OrderOutlets.CONSIGNMENT_DELIVERY_INFO"
      [cxOutletContext]="{
        showItemList: false,
        order: order,
      }"
    >
    </ng-template>

    <!-- delivery consigned entries -->
    <cx-order-consigned-entries
      *ngIf="deliveryConsignments"
      [order]="order"
      [consignments]="deliveryConsignments"
      [enableAddToCart]="enableAddToCart$ | async"
      [buyItAgainTranslation]="'addToCart.buyItAgain' | cxTranslate"
    ></cx-order-consigned-entries>

    <!-- unconsigned entries -->
    <ng-container *ngIf="order?.unconsignedEntries?.length">
      <div *ngIf="order?.statusDisplay" class="cx-list-header">
        <div class="cx-list-status">
          {{
            'orderDetails.statusDisplay_' + order?.statusDisplay | cxTranslate
          }}
        </div>
      </div>
      <!-- delivery unconsigned entries -->
      <ng-container *ngIf="deliveryUnConsignedEntries?.length">
        <h2 *ngIf="groupCartItems$ | async" class="cx-review-header">
          {{ 'checkoutMode.deliveryEntries' | cxTranslate }}
        </h2>
        <div class="cx-list-item">
          <ng-template
            [cxAbstractOrderContext]="{
              id: order.code,
              type: abstractOrderType.ORDER,
            }"
            [cxOutlet]="CartOutlets.CART_ITEM_LIST"
            [cxOutletContext]="{
              items: deliveryUnConsignedEntries,
              readonly: true,
              promotionLocation: promotionLocation,
              options: {
                displayAddToCart: enableAddToCart$ | async,
                addToCartString: 'addToCart.buyItAgain' | cxTranslate,
                optionalBtn: addToCartBtn,
              },
            }"
          >
          </ng-template>
        </div>
      </ng-container>
      <!-- pickup unconsigned entries, b2b does not have pickup items -->
      <ng-container *ngIf="pickupUnconsignedEntries?.length">
        <h2 class="cx-review-header">
          {{ 'checkoutPickupInStore.heading' | cxTranslate }}
        </h2>
        <div class="cx-list-item">
          <ng-template
            [cxAbstractOrderContext]="{
              id: order.code,
              type: abstractOrderType.ORDER,
            }"
            [cxOutlet]="CartOutlets.CART_ITEM_LIST"
            [cxOutletContext]="{
              items: pickupUnconsignedEntries,
              readonly: true,
              promotionLocation: promotionLocation,
              options: {
                displayAddToCart: enableAddToCart$ | async,
                addToCartString: 'addToCart.buyItAgain' | cxTranslate,
                optionalBtn: addToCartBtn,
              },
            }"
          >
          </ng-template>
        </div>
      </ng-container>
    </ng-container>

    <!-- replenishment other entries -->
    <ng-container *ngIf="order?.entries && order?.replenishmentOrderCode">
      <div class="cx-list">
        <div *ngIf="order?.statusDisplay" class="cx-list-header">
          <div class="cx-list-status">
            {{
              'orderDetails.statusDisplay_' + order?.statusDisplay | cxTranslate
            }}
          </div>
        </div>
        <div class="cx-list-item">
          <ng-template
            [cxAbstractOrderContext]="{
              id: order.code,
              type: abstractOrderType.ORDER,
            }"
            [cxOutlet]="CartOutlets.CART_ITEM_LIST"
            [cxOutletContext]="{
              items: order.entries,
              readonly: true,
              promotionLocation: promotionLocation,
              options: {
                displayAddToCart: enableAddToCart$ | async,
                addToCartString: 'addToCart.buyItAgain' | cxTranslate,
                optionalBtn: addToCartBtn,
              },
            }"
          >
          </ng-template>
        </div>
      </div>
    </ng-container>
  </ng-container>

  <ng-template let-ctx #addToCartBtn>
    <cx-add-to-cart
      [productCode]="ctx.item.product?.code"
      [product]="ctx.item.product"
      [showQuantity]="false"
      [options]="ctx.options"
      [pickupStore]="ctx.item.deliveryPointOfService?.name"
      class="add-to-cart"
    >
    </cx-add-to-cart>
  </ng-template>
</ng-container>
`
    }]
  }], () => [{
    type: OrderDetailsService
  }, {
    type: CmsComponentData
  }], null);
})();
var TrackingEventsComponent = class _TrackingEventsComponent {
  handleClick(event) {
    if (event.target.tagName === this.el.nativeElement.tagName) {
      this.close("Cross click");
    }
  }
  constructor(orderHistoryFacade, launchDialogService, el) {
    this.orderHistoryFacade = orderHistoryFacade;
    this.launchDialogService = launchDialogService;
    this.el = el;
    this.subscription = new Subscription();
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: "button",
      focusOnEscape: true
    };
  }
  ngOnInit() {
    this.subscription.add(this.launchDialogService.data$.subscribe((data) => {
      if (data) {
        this.init(data.tracking$, data.shipDate);
      }
    }));
  }
  ngOnDestroy() {
    this.orderHistoryFacade.clearConsignmentTracking();
    this.subscription?.unsubscribe();
  }
  init(tracking$, shipDate) {
    this.tracking$ = tracking$;
    this.shipDate = shipDate;
  }
  close(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  static {
    this.ɵfac = function TrackingEventsComponent_Factory(t) {
      return new (t || _TrackingEventsComponent)(ɵɵdirectiveInject(OrderHistoryFacade), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ElementRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _TrackingEventsComponent,
      selectors: [["cx-tracking-events"]],
      hostBindings: function TrackingEventsComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          ɵɵlistener("click", function TrackingEventsComponent_click_HostBindingHandler($event) {
            return ctx.handleClick($event);
          });
        }
      },
      decls: 8,
      vars: 5,
      consts: [["noTracking", ""], ["loading", ""], [1, "cx-consignment-tracking-dialog", 3, "esc", "cxFocus"], [1, "cx-consignment-tracking-container"], [4, "ngIf", "ngIfElse"], [1, "cx-modal-header"], [1, "cx-consignment-tracking-title", "modal-title"], ["type", "button", 1, "close", 3, "click"], ["aria-hidden", "true"], [1, "cx-tracking-events", "modal-body"], [4, "ngFor", "ngForOf"], [1, "cx-shipment-heading"], [1, "row"], [1, "col-sm-12", "col-md-6"], [1, "cx-shipment-title"], [1, "cx-shipment-content"], [4, "ngIf"], ["target", "_blank", "rel", "noopener noreferrer", 3, "href"], [1, "cx-tracking-event-body"], [1, "cx-tracking-event-content"], [1, "cx-tracking-event-title"], [1, "cx-tracking-event-city"], [1, "cx-no-tracking-heading"], [1, "cx-tracking-loading"], [1, "header", "modal-header"], [1, "title", "modal-title"], ["type", "button", 1, "close", "btn-dismiss", 3, "click"], [1, "body", "modal-body"], [1, "col-sm-12"]],
      template: function TrackingEventsComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 2);
          ɵɵlistener("esc", function TrackingEventsComponent_Template_div_esc_0_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.close("Escape clicked"));
          });
          ɵɵelementStart(1, "div", 3);
          ɵɵtemplate(2, TrackingEventsComponent_ng_container_2_Template, 12, 9, "ng-container", 4);
          ɵɵpipe(3, "async");
          ɵɵtemplate(4, TrackingEventsComponent_ng_template_4_Template, 4, 3, "ng-template", null, 0, ɵɵtemplateRefExtractor)(6, TrackingEventsComponent_ng_template_6_Template, 13, 6, "ng-template", null, 1, ɵɵtemplateRefExtractor);
          ɵɵelementEnd()();
        }
        if (rf & 2) {
          const loading_r8 = ɵɵreference(7);
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(3, 3, ctx.tracking$))("ngIfElse", loading_r8);
        }
      },
      dependencies: [NgForOf, NgIf, SpinnerComponent, FocusDirective, AsyncPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TrackingEventsComponent, [{
    type: Component,
    args: [{
      selector: "cx-tracking-events",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div
  class="cx-consignment-tracking-dialog"
  [cxFocus]="focusConfig"
  (esc)="close('Escape clicked')"
>
  <div class="cx-consignment-tracking-container">
    <ng-container
      *ngIf="tracking$ | async as consignmentTracking; else loading"
    >
      <!-- Modal Header -->
      <div class="cx-modal-header">
        <div class="cx-consignment-tracking-title modal-title">
          {{ 'orderDetails.consignmentTracking.dialog.header' | cxTranslate }}
        </div>
        <button
          type="button"
          class="close"
          [attr.aria-label]="'common.close' | cxTranslate"
          (click)="close('Cross click')"
        >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <!-- Modal Body -->
      <!-- shipment header -->
      <ng-container
        *ngIf="
          consignmentTracking?.carrierDetails &&
            consignmentTracking?.trackingID;
          else noTracking
        "
      >
        <div class="cx-shipment-heading">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="cx-shipment-title">
                {{
                  'orderDetails.consignmentTracking.dialog.shipped'
                    | cxTranslate
                }}
              </div>
              <div class="cx-shipment-content">
                {{ shipDate | cxDate: 'medium' }}
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <div class="cx-shipment-title">
                {{
                  'orderDetails.consignmentTracking.dialog.estimate'
                    | cxTranslate
                }}
              </div>
              <div class="cx-shipment-content">
                {{ consignmentTracking?.targetArrivalDate | cxDate: 'medium' }}
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-12 col-md-6">
              <div class="cx-shipment-title">
                {{
                  'orderDetails.consignmentTracking.dialog.carrier'
                    | cxTranslate
                }}
              </div>
              <div class="cx-shipment-content">
                {{ consignmentTracking?.carrierDetails?.name }}
              </div>
            </div>
            <div class="col-sm-12 col-md-6">
              <div class="cx-shipment-title">
                {{
                  'orderDetails.consignmentTracking.dialog.trackingId'
                    | cxTranslate
                }}
              </div>
              <div class="cx-shipment-content">
                <ng-container *ngIf="consignmentTracking?.trackingUrl">
                  <a
                    target="_blank"
                    rel="noopener noreferrer"
                    [href]="consignmentTracking.trackingUrl"
                    >{{ consignmentTracking?.trackingID }}</a
                  >
                </ng-container>
                <ng-container *ngIf="!consignmentTracking?.trackingUrl">
                  <label>
                    {{ consignmentTracking?.trackingID }}
                  </label>
                </ng-container>
              </div>
            </div>
          </div>
        </div>
      </ng-container>

      <!-- tracking events -->
      <div class="cx-tracking-events modal-body">
        <ng-container
          *ngFor="let consignmentEvent of consignmentTracking.trackingEvents"
        >
          <div class="cx-tracking-event-body">
            <div class="cx-tracking-event-content">
              {{ consignmentEvent.eventDate | cxDate: 'medium' }}
            </div>
            <div class="cx-tracking-event-title">
              {{ consignmentEvent.referenceCode }}
            </div>
            <div class="cx-tracking-event-content">
              {{ consignmentEvent.detail }}
            </div>
            <div class="cx-tracking-event-city">
              location: {{ consignmentEvent.location }}
            </div>
          </div>
        </ng-container>
      </div>
    </ng-container>

    <ng-template #noTracking>
      <div class="cx-no-tracking-heading">
        <div class="cx-shipment-content">
          {{
            'orderDetails.consignmentTracking.dialog.noTracking' | cxTranslate
          }}
        </div>
      </div>
    </ng-template>

    <ng-template #loading>
      <div class="cx-tracking-loading">
        <div class="header modal-header">
          <div class="title modal-title">
            {{
              'orderDetails.consignmentTracking.dialog.loadingHeader'
                | cxTranslate
            }}
          </div>
          <button
            type="button"
            class="close btn-dismiss"
            [attr.aria-label]="'common.close' | cxTranslate"
            (click)="close('Cross click')"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <!-- Modal Body -->
        <div class="body modal-body">
          <div class="row">
            <div class="col-sm-12">
              <cx-spinner></cx-spinner>
            </div>
          </div>
        </div>
      </div>
    </ng-template>
  </div>
</div>
`
    }]
  }], () => [{
    type: OrderHistoryFacade
  }, {
    type: LaunchDialogService
  }, {
    type: ElementRef
  }], {
    handleClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var MyAccountV2ConsignmentTrackingComponent = class _MyAccountV2ConsignmentTrackingComponent extends ConsignmentTrackingComponent {
  constructor() {
    super(...arguments);
    this.componentClass = "cx-list-header col-12";
    this.outlet = inject(OutletContextData);
  }
  ngOnInit() {
    this.outlet?.context$.subscribe((context) => {
      this.consignment = context.item;
    });
    this.outlet?.context$.subscribe((context) => {
      this.orderCode = context?.order?.code ?? "";
    });
    super.ngOnInit();
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵMyAccountV2ConsignmentTrackingComponent_BaseFactory;
      return function MyAccountV2ConsignmentTrackingComponent_Factory(t) {
        return (ɵMyAccountV2ConsignmentTrackingComponent_BaseFactory || (ɵMyAccountV2ConsignmentTrackingComponent_BaseFactory = ɵɵgetInheritedFactory(_MyAccountV2ConsignmentTrackingComponent)))(t || _MyAccountV2ConsignmentTrackingComponent);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2ConsignmentTrackingComponent,
      selectors: [["cx-my-account-v2-consignment-tracking"]],
      hostVars: 1,
      hostBindings: function MyAccountV2ConsignmentTrackingComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵhostProperty("className", ctx.componentClass);
        }
      },
      features: [ɵɵInheritDefinitionFeature],
      decls: 1,
      vars: 1,
      consts: [["showNoTrackingMessage", ""], ["class", "cx-list-status", 4, "ngIf"], [1, "cx-list-status"], [4, "ngIf"], ["class", "cx-item-list-tracking-id", 4, "ngIf"], ["class", "cx-consignment-status-date", 4, "ngIf"], [1, "cx-item-list-tracking-id"], [4, "ngIf", "ngIfElse"], [1, "cx-tracking-id-link", 3, "click"], [1, "cx-consignment-status-date"]],
      template: function MyAccountV2ConsignmentTrackingComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2ConsignmentTrackingComponent_div_0_Template, 7, 3, "div", 1);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ctx.consignment);
        }
      },
      dependencies: [NgIf, TranslatePipe, CxDatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2ConsignmentTrackingComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-consignment-tracking",
      template: `<div *ngIf="consignment" class="cx-list-status">
  <span>
    <span *ngIf="consignment.status">
      {{ 'orderDetails.deliveryStatus_' + consignment.status | cxTranslate }}
    </span>
    <span
      *ngIf="consignmentStatus.includes(consignment.status ?? '')"
      class="cx-item-list-tracking-id"
    >
      <span *ngIf="consignment.trackingID; else showNoTrackingMessage">
        {{
          'orderDetails.consignmentTracking.dialog.trackingId' | cxTranslate
        }}:
        <a
          class="cx-tracking-id-link"
          (click)="openTrackingDialog(consignment)"
        >
          {{ consignment.trackingID }}
        </a>
      </span>
    </span>
  </span>
  <span *ngIf="consignment?.statusDate" class="cx-consignment-status-date">
    {{ consignment.statusDate | cxDate }}
  </span>
  <ng-template #showNoTrackingMessage>
    <a class="cx-tracking-id-link" (click)="openTrackingDialog(consignment)">
      {{ 'orderDetails.consignmentTracking.action' | cxTranslate }}
    </a>
  </ng-template>
</div>
`
    }]
  }], null, {
    componentClass: [{
      type: HostBinding,
      args: ["className"]
    }]
  });
})();
var defaultConsignmentTrackingLayoutConfig = {
  launch: {
    CONSIGNMENT_TRACKING: {
      inlineRoot: true,
      component: TrackingEventsComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var OrderDetailReorderComponent = class _OrderDetailReorderComponent {
  constructor(orderDetailsService, launchDialogService, vcr) {
    this.orderDetailsService = orderDetailsService;
    this.launchDialogService = launchDialogService;
    this.vcr = vcr;
    this.subscription = new Subscription();
  }
  ngOnInit() {
    this.order$ = this.orderDetailsService.getOrderDetails();
  }
  onReorderClick(order) {
    this.launchDialog(order.code);
  }
  launchDialog(orderCode) {
    const dialog = this.launchDialogService.openDialog("REORDER", this.element, this.vcr, {
      orderCode
    });
    if (dialog) {
      this.subscription.add(dialog.pipe(take(1)).subscribe());
    }
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  static {
    this.ɵfac = function OrderDetailReorderComponent_Factory(t) {
      return new (t || _OrderDetailReorderComponent)(ɵɵdirectiveInject(OrderDetailsService), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ViewContainerRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderDetailReorderComponent,
      selectors: [["cx-order-details-reorder"]],
      viewQuery: function OrderDetailReorderComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c16, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
        }
      },
      decls: 2,
      vars: 3,
      consts: [["element", ""], [4, "ngIf"], [1, "cx-nav", "row"], [1, "col-xs-12", "col-md-10", "col-lg-8"], [1, "btn", "btn-primary", 3, "click"]],
      template: function OrderDetailReorderComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderDetailReorderComponent_ng_container_0_Template, 2, 1, "ng-container", 1);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailReorderComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-details-reorder",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="order$ | async as order">
  <ng-container *ngIf="order.code">
    <div class="cx-nav row">
      <div class="col-xs-12 col-md-10 col-lg-8">
        <button
          #element
          class="btn btn-primary"
          (click)="onReorderClick(order)"
        >
          {{ 'reorder.button' | cxTranslate }}
        </button>
      </div>
    </div>
  </ng-container>
</ng-container>
`
    }]
  }], () => [{
    type: OrderDetailsService
  }, {
    type: LaunchDialogService
  }, {
    type: ViewContainerRef
  }], {
    element: [{
      type: ViewChild,
      args: ["element"]
    }]
  });
})();
var ReorderDialogComponent = class _ReorderDialogComponent {
  constructor(launchDialogService, reorderOrderFacade, multiCartFacade) {
    this.launchDialogService = launchDialogService;
    this.reorderOrderFacade = reorderOrderFacade;
    this.multiCartFacade = multiCartFacade;
    this.iconTypes = ICON_TYPE;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
    this.loading$ = new BehaviorSubject(false);
    this.showDecisionPrompt$ = new BehaviorSubject(true);
    this.data$ = this.launchDialogService.data$;
    this.selectFocusUtility = inject(SelectFocusUtility, {
      optional: true
    });
    this.elementRef = inject(ElementRef, {
      optional: true
    });
    this.featureConfigService = inject(FeatureConfigService, {
      optional: true
    });
    useFeatureStyles("a11yExpandedFocusIndicator");
  }
  createCartFromOrder(orderCode) {
    this.showDecisionPrompt$.next(false);
    this.loading$.next(true);
    this.reorderOrderFacade.reorder(orderCode).subscribe((cartModificationList) => {
      this.multiCartFacade.reloadCart(OCC_CART_ID_CURRENT);
      this.cartModifications = cartModificationList.cartModifications;
      this.loading$.next(false);
      this.recaptureFocus();
    });
  }
  recaptureFocus() {
    if (!this.featureConfigService?.isEnabled("a11yReorderDialog")) {
      return;
    }
    this.selectFocusUtility?.findFirstFocusable(this.elementRef?.nativeElement)?.focus();
  }
  close(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  get cartValidationStatusCode() {
    return CartValidationStatusCode;
  }
  static {
    this.ɵfac = function ReorderDialogComponent_Factory(t) {
      return new (t || _ReorderDialogComponent)(ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ReorderOrderFacade), ɵɵdirectiveInject(MultiCartFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReorderDialogComponent,
      selectors: [["cx-reorder-dialog"]],
      decls: 15,
      vars: 14,
      consts: [["result", ""], ["loading", ""], ["cartResponse", ""], ["errorIcon", ""], ["role", "dialog", "aria-labelledby", "dialogTitle", "aria-modal", "true", 1, "cx-modal-container", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], ["id", "dialogTitle", 1, "cx-dialog-title", "modal-title"], ["type", "button", 1, "close", 3, "click", "title"], ["aria-hidden", "true"], [3, "type"], [1, "cx-dialog-body", "modal-body"], [4, "ngIf"], [4, "ngIf", "ngIfElse"], [1, "cx-reorder-dialog-areyousure-section"], [1, "cx-reorder-dialog-footer"], [1, "row"], [1, "col-12"], [1, "btn", "btn-action", 3, "click"], [1, "btn", "btn-primary", 3, "click"], ["aria-live", "polite"], [1, "cx-cart-mod-entry-container"], [1, "alert-icon"], [1, "success", 3, "type"], ["class", "cx-cart-mod-entry-container", 4, "ngFor", "ngForOf"], [1, "warning", 3, "type"], [1, "error", 3, "type"], [1, "cx-spinner"]],
      template: function ReorderDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 4);
          ɵɵlistener("esc", function ReorderDialogComponent_Template_div_esc_0_listener() {
            return ctx.close("Escape clicked");
          });
          ɵɵelementStart(1, "div", 5);
          ɵɵelementContainerStart(2);
          ɵɵelementStart(3, "div", 6)(4, "div", 7);
          ɵɵtext(5);
          ɵɵpipe(6, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(7, "button", 8);
          ɵɵpipe(8, "cxTranslate");
          ɵɵpipe(9, "cxTranslate");
          ɵɵlistener("click", function ReorderDialogComponent_Template_button_click_7_listener() {
            return ctx.close("Close reorder result dialog");
          });
          ɵɵelementStart(10, "span", 9);
          ɵɵelement(11, "cx-icon", 10);
          ɵɵelementEnd()()();
          ɵɵelementContainerEnd();
          ɵɵelementStart(12, "div", 11);
          ɵɵtemplate(13, ReorderDialogComponent_ng_container_13_Template, 5, 4, "ng-container", 12);
          ɵɵpipe(14, "async");
          ɵɵelementEnd()()();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(5);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(6, 6, "reorder.dialog.reorderProducts"), " ");
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("title", ɵɵpipeBind1(8, 8, "addToCart.closeModal"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(9, 10, "addToCart.closeModal"));
          ɵɵadvance(4);
          ɵɵproperty("type", ctx.iconTypes.CLOSE);
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ɵɵpipeBind1(14, 12, ctx.data$));
        }
      },
      dependencies: [NgForOf, NgIf, SpinnerComponent, FocusDirective, IconComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReorderDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-reorder-dialog",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div
  [cxFocus]="focusConfig"
  (esc)="close('Escape clicked')"
  class="cx-modal-container"
  role="dialog"
  aria-labelledby="dialogTitle"
  aria-modal="true"
>
  <div class="cx-modal-content">
    <ng-container>
      <div class="cx-dialog-header modal-header">
        <div id="dialogTitle" class="cx-dialog-title modal-title">
          {{ 'reorder.dialog.reorderProducts' | cxTranslate }}
        </div>
        <button
          type="button"
          class="close"
          attr.aria-label="{{ 'addToCart.closeModal' | cxTranslate }}"
          title="{{ 'addToCart.closeModal' | cxTranslate }}"
          (click)="close('Close reorder result dialog')"
        >
          <span aria-hidden="true">
            <cx-icon [type]="iconTypes.CLOSE"></cx-icon>
          </span>
        </button>
      </div>
    </ng-container>

    <!-- Modal Body -->
    <div class="cx-dialog-body modal-body">
      <ng-container *ngIf="data$ | async as data">
        <ng-container *ngIf="showDecisionPrompt$ | async; else result">
          <div class="cx-reorder-dialog-areyousure-section">
            <p>
              {{ 'reorder.dialog.areYouSureToReplaceCart' | cxTranslate }}
            </p>
            <div class="cx-reorder-dialog-footer">
              <div class="row">
                <div class="col-12">
                  <button
                    class="btn btn-action"
                    (click)="close('Cancel creating cart from order')"
                  >
                    {{ 'reorder.dialog.cancel' | cxTranslate }}
                  </button>
                  <button
                    class="btn btn-primary"
                    (click)="createCartFromOrder(data.orderCode)"
                  >
                    {{ 'reorder.dialog.continue' | cxTranslate }}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </ng-container>
        <ng-template #result>
          <ng-container *ngIf="!(loading$ | async); else loading">
            <p aria-live="polite">
              <ng-container
                *ngIf="!cartModifications?.length; else cartResponse"
              >
                <span class="cx-cart-mod-entry-container">
                  <span class="alert-icon">
                    <cx-icon
                      class="success"
                      [type]="iconTypes.SUCCESS"
                    ></cx-icon>
                  </span>
                  {{ 'reorder.dialog.messages.success' | cxTranslate }}
                </span>
              </ng-container>
              <ng-template #cartResponse>
                <span
                  *ngFor="let cartModification of cartModifications"
                  class="cx-cart-mod-entry-container"
                >
                  <ng-container
                    *ngIf="
                      cartModification.statusCode ===
                        cartValidationStatusCode.LOW_STOCK;
                      else errorIcon
                    "
                  >
                    <span class="alert-icon">
                      <cx-icon
                        class="warning"
                        [type]="iconTypes.INFO"
                      ></cx-icon>
                    </span>
                  </ng-container>
                  <ng-template #errorIcon>
                    <span class="alert-icon">
                      <cx-icon class="error" [type]="iconTypes.ERROR"></cx-icon>
                    </span>
                  </ng-template>
                  <span>
                    {{
                      'reorder.dialog.messages.' + cartModification.statusCode
                        | cxTranslate
                          : {
                              quantity: cartModification.quantity,
                              quantityAdded: cartModification.quantityAdded,
                              productCode: cartModification.entry.product.code,
                              productName: cartModification.entry.product.name,
                            }
                    }}
                  </span>
                </span>
              </ng-template>
            </p>
          </ng-container>
          <ng-template #loading>
            <div class="cx-spinner">
              <cx-spinner></cx-spinner>
            </div>
          </ng-template>
        </ng-template>
      </ng-container>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }, {
    type: ReorderOrderFacade
  }, {
    type: MultiCartFacade
  }], {
    selectFocusUtility: [{
      type: Optional
    }],
    elementRef: [{
      type: Optional
    }],
    featureConfigService: [{
      type: Optional
    }]
  });
})();
var OrderDetailTotalsComponent = class _OrderDetailTotalsComponent {
  constructor(orderDetailsService) {
    this.orderDetailsService = orderDetailsService;
    this.CartOutlets = CartOutlets;
  }
  ngOnInit() {
    this.order$ = this.orderDetailsService.getOrderDetails();
  }
  static {
    this.ɵfac = function OrderDetailTotalsComponent_Factory(t) {
      return new (t || _OrderDetailTotalsComponent)(ɵɵdirectiveInject(OrderDetailsService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderDetailTotalsComponent,
      selectors: [["cx-order-details-totals"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "row", "justify-content-end"], [1, "cx-summary", "col-sm-12", "col-md-6", "col-lg-5", "col-xl-4"], [3, "cxOutlet", "cxOutletContext"]],
      template: function OrderDetailTotalsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderDetailTotalsComponent_ng_container_0_Template, 4, 2, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.order$));
        }
      },
      dependencies: [NgIf, OutletDirective, AsyncPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailTotalsComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-details-totals",
      template: '<ng-container *ngIf="order$ | async as order">\n  <div class="row justify-content-end">\n    <div class="cx-summary col-sm-12 col-md-6 col-lg-5 col-xl-4">\n      <ng-template\n        [cxOutlet]="CartOutlets.ORDER_SUMMARY"\n        [cxOutletContext]="order"\n      >\n      </ng-template>\n    </div>\n  </div>\n</ng-container>\n'
    }]
  }], () => [{
    type: OrderDetailsService
  }], null);
})();
var defaultReorderLayoutConfig = {
  launch: {
    REORDER: {
      inline: true,
      component: ReorderDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
function registerOrderOutletFactory() {
  const isMyAccountV2 = inject(USE_MY_ACCOUNT_V2_ORDER);
  const outletService = inject(OutletService);
  const componentFactoryResolver = inject(ComponentFactoryResolver$1);
  return () => {
    const config = {
      component: MyAccountV2ConsignmentTrackingComponent,
      id: OrderOutlets.ORDER_CONSIGNMENT,
      position: OutletPosition.REPLACE
    };
    if (isMyAccountV2) {
      const template = componentFactoryResolver.resolveComponentFactory(config.component);
      outletService.add(config.id, template, config.position);
    }
  };
}
var myAccountV2CmsMapping$1 = {
  cmsComponents: {
    AccountOrderDetailsActionsComponent: {
      component: MyAccountV2OrderDetailsActionsComponent
      //guards: inherited from standard config,
    }
  }
};
var moduleComponents$2 = [OrderOverviewComponent, OrderDetailActionsComponent, OrderDetailItemsComponent, OrderDetailTotalsComponent, OrderDetailBillingComponent, TrackingEventsComponent, ConsignmentTrackingComponent, OrderConsignedEntriesComponent, OrderDetailReorderComponent, ReorderDialogComponent, MyAccountV2OrderDetailsActionsComponent, MyAccountV2ConsignmentTrackingComponent];
var OrderDetailsModule = class _OrderDetailsModule {
  static {
    this.ɵfac = function OrderDetailsModule_Factory(t) {
      return new (t || _OrderDetailsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderDetailsModule,
      declarations: [OrderOverviewComponent, OrderDetailActionsComponent, OrderDetailItemsComponent, OrderDetailTotalsComponent, OrderDetailBillingComponent, TrackingEventsComponent, ConsignmentTrackingComponent, OrderConsignedEntriesComponent, OrderDetailReorderComponent, ReorderDialogComponent, MyAccountV2OrderDetailsActionsComponent, MyAccountV2ConsignmentTrackingComponent],
      imports: [CardModule, CommonModule, I18nModule, FeaturesConfigModule, PromotionsModule, UrlModule, SpinnerModule, RouterModule, OutletModule, AddToCartModule, KeyboardFocusModule, IconModule, MyAccountV2DownloadInvoicesModule, AbstractOrderContextModule, BtnLikeLinkModule],
      exports: [OrderOverviewComponent, OrderDetailActionsComponent, OrderDetailItemsComponent, OrderDetailTotalsComponent, OrderDetailBillingComponent, TrackingEventsComponent, ConsignmentTrackingComponent, OrderConsignedEntriesComponent, OrderDetailReorderComponent, ReorderDialogComponent, MyAccountV2OrderDetailsActionsComponent, MyAccountV2ConsignmentTrackingComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [OrderOverviewComponentService, provideDefaultConfig({
        cmsComponents: {
          AccountOrderDetailsActionsComponent: {
            component: OrderDetailActionsComponent,
            guards: [AuthGuard]
          },
          AccountOrderDetailsItemsComponent: {
            component: OrderDetailItemsComponent,
            guards: [AuthGuard],
            data: {
              enableAddToCart: true
            }
          },
          AccountOrderDetailsGroupedItemsComponent: {
            component: OrderDetailItemsComponent,
            guards: [AuthGuard],
            data: {
              enableAddToCart: true,
              groupCartItems: true
            }
          },
          AccountOrderDetailsTotalsComponent: {
            component: OrderDetailTotalsComponent,
            guards: [AuthGuard]
          },
          AccountOrderDetailsOverviewComponent: {
            component: OrderOverviewComponent,
            guards: [AuthGuard]
          },
          AccountOrderDetailsSimpleOverviewComponent: {
            component: OrderOverviewComponent,
            guards: [AuthGuard],
            data: {
              simple: true
            }
          },
          AccountOrderDetailsReorderComponent: {
            component: OrderDetailReorderComponent,
            guards: [AuthGuard]
          }
        },
        features: {
          consignmentTracking: "1.2"
        }
      }), provideDefaultConfig(defaultConsignmentTrackingLayoutConfig), provideDefaultConfig(defaultReorderLayoutConfig), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_ORDER) ? myAccountV2CmsMapping$1 : {}), {
        provide: MODULE_INITIALIZER,
        useFactory: registerOrderOutletFactory,
        multi: true
      }],
      imports: [CardModule, CommonModule, I18nModule, FeaturesConfigModule, PromotionsModule, UrlModule, SpinnerModule, RouterModule, OutletModule, AddToCartModule, KeyboardFocusModule, IconModule, MyAccountV2DownloadInvoicesModule, AbstractOrderContextModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailsModule, [{
    type: NgModule,
    args: [{
      imports: [CardModule, CommonModule, I18nModule, FeaturesConfigModule, PromotionsModule, UrlModule, SpinnerModule, RouterModule, OutletModule, AddToCartModule, KeyboardFocusModule, IconModule, MyAccountV2DownloadInvoicesModule, AbstractOrderContextModule, BtnLikeLinkModule],
      providers: [OrderOverviewComponentService, provideDefaultConfig({
        cmsComponents: {
          AccountOrderDetailsActionsComponent: {
            component: OrderDetailActionsComponent,
            guards: [AuthGuard]
          },
          AccountOrderDetailsItemsComponent: {
            component: OrderDetailItemsComponent,
            guards: [AuthGuard],
            data: {
              enableAddToCart: true
            }
          },
          AccountOrderDetailsGroupedItemsComponent: {
            component: OrderDetailItemsComponent,
            guards: [AuthGuard],
            data: {
              enableAddToCart: true,
              groupCartItems: true
            }
          },
          AccountOrderDetailsTotalsComponent: {
            component: OrderDetailTotalsComponent,
            guards: [AuthGuard]
          },
          AccountOrderDetailsOverviewComponent: {
            component: OrderOverviewComponent,
            guards: [AuthGuard]
          },
          AccountOrderDetailsSimpleOverviewComponent: {
            component: OrderOverviewComponent,
            guards: [AuthGuard],
            data: {
              simple: true
            }
          },
          AccountOrderDetailsReorderComponent: {
            component: OrderDetailReorderComponent,
            guards: [AuthGuard]
          }
        },
        features: {
          consignmentTracking: "1.2"
        }
      }), provideDefaultConfig(defaultConsignmentTrackingLayoutConfig), provideDefaultConfig(defaultReorderLayoutConfig), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_ORDER) ? myAccountV2CmsMapping$1 : {}), {
        provide: MODULE_INITIALIZER,
        useFactory: registerOrderOutletFactory,
        multi: true
      }],
      declarations: [...moduleComponents$2],
      exports: [...moduleComponents$2]
    }]
  }], null, null);
})();
var OrderHistoryComponent = class _OrderHistoryComponent {
  constructor(routing, orderHistoryFacade, translation, replenishmentOrderHistoryFacade) {
    this.routing = routing;
    this.orderHistoryFacade = orderHistoryFacade;
    this.translation = translation;
    this.replenishmentOrderHistoryFacade = replenishmentOrderHistoryFacade;
    this.PAGE_SIZE = 5;
    this.orders$ = this.orderHistoryFacade.getOrderHistoryList(this.PAGE_SIZE).pipe(tap((orders) => {
      this.setOrderHistoryParams(orders);
    }));
    this.hasReplenishmentOrder$ = this.replenishmentOrderHistoryFacade.getReplenishmentOrderDetails().pipe(map((order) => order && Object.keys(order).length !== 0));
    this.isLoaded$ = this.orderHistoryFacade.getOrderHistoryListLoaded();
    this.tabTitleParam$ = this.orders$.pipe(map((order) => order?.pagination?.totalResults), filter(isNotUndefined), take(1));
    useFeatureStyles("a11yTabComponent");
  }
  setOrderHistoryParams(orders) {
    if (orders?.pagination?.sort) {
      this.sortType = orders.pagination.sort;
    }
    this.hasPONumber = orders?.orders?.[0]?.purchaseOrderNumber !== void 0;
  }
  ngOnDestroy() {
    this.orderHistoryFacade.clearOrderList();
  }
  changeSortCode(sortCode) {
    const event = {
      sortCode,
      currentPage: 0
    };
    this.sortType = sortCode;
    this.fetchOrders(event);
  }
  pageChange(page) {
    const event = {
      sortCode: this.sortType,
      currentPage: page
    };
    this.fetchOrders(event);
  }
  goToOrderDetail(order) {
    this.routing.go({
      cxRoute: "orderDetails",
      params: order
    }, {
      queryParams: this.getQueryParams(order)
    });
  }
  getQueryParams(order) {
    return this.orderHistoryFacade.getQueryParams(order);
  }
  getSortLabels() {
    return combineLatest([this.translation.translate("sorting.date"), this.translation.translate("sorting.orderNumber")]).pipe(map(([textByDate, textByOrderNumber]) => {
      return {
        byDate: textByDate,
        byOrderNumber: textByOrderNumber
      };
    }));
  }
  fetchOrders(event) {
    this.orderHistoryFacade.loadOrderList(this.PAGE_SIZE, event.currentPage, event.sortCode);
  }
  static {
    this.ɵfac = function OrderHistoryComponent_Factory(t) {
      return new (t || _OrderHistoryComponent)(ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(OrderHistoryFacade), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(ReplenishmentOrderHistoryFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderHistoryComponent,
      selectors: [["cx-order-history"]],
      decls: 3,
      vars: 8,
      consts: [["noOrder", ""], ["otherOrder", ""], [4, "ngIf"], [1, "cx-order-history-container"], [3, "ngClass"], [1, "cx-order-history-body"], [4, "ngIf", "ngIfElse"], [1, "cx-order-history-sort", "top"], [1, "cx-order-history-form-group", "form-group"], ["ariaControls", "order-history-table", 3, "sortListEvent", "sortOptions", "sortLabels", "selectedOption", "placeholder", "ariaLabel"], ["class", "cx-order-history-pagination", 4, "ngIf"], ["role", "table", "id", "order-history-table", 1, "table", "cx-order-history-table", 3, "ngClass"], [1, "cx-visually-hidden"], [1, "cx-order-history-thead-mobile"], ["role", "row"], ["role", "columnheader"], ["role", "row", 3, "click", 4, "ngFor", "ngForOf"], [1, "cx-order-history-sort", "bottom"], [1, "cx-order-history-pagination"], [3, "viewPageEvent", "pagination"], ["role", "row", 3, "click"], ["role", "cell", 1, "cx-order-history-code"], [1, "cx-order-history-label"], [1, "cx-order-history-value", 3, "routerLink", "queryParams"], ["role", "cell", 1, "cx-order-history-placed"], ["role", "cell", 1, "cx-order-history-status"], ["role", "cell", 1, "cx-order-history-total"], ["role", "cell", 1, "cx-order-history-po"], ["class", "cx-order-history-value", 3, "routerLink", "queryParams", 4, "ngIf"], ["role", "cell", 1, "cx-order-history-cost-center"], [3, "ngClass", 4, "ngIf"], ["routerLinkActive", "active", "cxBtnLikeLink", "", 1, "btn", "btn-primary", "btn-block", 3, "routerLink"]],
      template: function OrderHistoryComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderHistoryComponent_ng_container_0_Template, 2, 1, "ng-container", 2);
          ɵɵpipe(1, "async");
          ɵɵpipe(2, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpureFunction2(5, _c22, ɵɵpipeBind1(1, 1, ctx.orders$), ɵɵpipeBind1(2, 3, ctx.hasReplenishmentOrder$)));
        }
      },
      dependencies: [NgClass, NgForOf, NgIf, RouterLink, RouterLinkActive, SortingComponent, PaginationComponent, BtnLikeLinkDirective, AsyncPipe, UrlPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderHistoryComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-history",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container
  *ngIf="{
    orderHistory: orders$ | async,
    replenishmentOrder: hasReplenishmentOrder$ | async,
  } as type"
>
  <ng-container *ngIf="type.orderHistory">
    <div class="cx-order-history-container">
      <!-- HEADER -->
      <div
        [ngClass]="
          type.replenishmentOrder
            ? 'cx-replenishment-details-order-history-header'
            : 'cx-order-history-header'
        "
      >
        <h4 *ngIf="type.replenishmentOrder">
          {{ 'orderHistory.replenishmentHistory' | cxTranslate }}
        </h4>
        <h2 *ngIf="!type.replenishmentOrder">
          {{ 'orderHistory.orderHistory' | cxTranslate }}
        </h2>
      </div>

      <!-- BODY -->
      <div class="cx-order-history-body">
        <ng-container
          *ngIf="type.orderHistory.pagination.totalResults > 0; else noOrder"
        >
          <!-- Select Form and Pagination Top -->
          <div class="cx-order-history-sort top">
            <label class="cx-order-history-form-group form-group"
              ><span>
                {{ 'orderHistory.sortBy' | cxTranslate }}
              </span>
              <cx-sorting
                [sortOptions]="type.orderHistory.sorts"
                [sortLabels]="getSortLabels() | async"
                (sortListEvent)="changeSortCode($event)"
                [selectedOption]="type.orderHistory.pagination.sort"
                placeholder="{{ 'orderHistory.sortBy' | cxTranslate }}"
                [ariaLabel]="'orderHistory.sortOrders' | cxTranslate"
                ariaControls="order-history-table"
              ></cx-sorting>
            </label>
            <div
              *ngIf="type.orderHistory.pagination.totalPages > 1"
              class="cx-order-history-pagination"
            >
              <cx-pagination
                [pagination]="type.orderHistory.pagination"
                (viewPageEvent)="pageChange($event)"
              ></cx-pagination>
            </div>
          </div>

          <table
            role="table"
            id="order-history-table"
            class="table cx-order-history-table"
            [ngClass]="{ 'cx-order-history-table-po': hasPONumber }"
          >
            <caption class="cx-visually-hidden">
              {{
                'orderHistory.orderHistory' | cxTranslate
              }}
            </caption>
            <thead class="cx-order-history-thead-mobile">
              <tr role="row">
                <th role="columnheader">
                  {{ 'orderHistory.orderId' | cxTranslate }}
                </th>
                <ng-container *ngIf="hasPONumber">
                  <th role="columnheader">
                    {{ 'orderHistory.PONumber' | cxTranslate }}
                  </th>
                  <th role="columnheader">
                    {{ 'orderHistory.costCenter' | cxTranslate }}
                  </th>
                </ng-container>
                <th role="columnheader">
                  {{ 'orderHistory.date' | cxTranslate }}
                </th>
                <th role="columnheader">
                  {{ 'orderHistory.status' | cxTranslate }}
                </th>
                <th role="columnheader">
                  {{ 'orderHistory.total' | cxTranslate }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr
                role="row"
                *ngFor="let order of type.orderHistory.orders"
                (click)="goToOrderDetail(order)"
              >
                <td role="cell" class="cx-order-history-code">
                  <div class="cx-order-history-label">
                    {{ 'orderHistory.orderId' | cxTranslate }}
                  </div>
                  <a
                    [routerLink]="
                      {
                        cxRoute: 'orderDetails',
                        params: order,
                      } | cxUrl
                    "
                    [queryParams]="getQueryParams(order)"
                    class="cx-order-history-value"
                  >
                    {{ order?.code }}</a
                  >
                </td>
                <ng-container *ngIf="hasPONumber">
                  <td role="cell" class="cx-order-history-po">
                    <div class="cx-order-history-label">
                      {{ 'orderHistory.PONumber' | cxTranslate }}
                    </div>
                    <a
                      *ngIf="order.purchaseOrderNumber"
                      [routerLink]="
                        {
                          cxRoute: 'orderDetails',
                          params: order,
                        } | cxUrl
                      "
                      [queryParams]="getQueryParams(order)"
                      class="cx-order-history-value"
                    >
                      {{ order.purchaseOrderNumber }}</a
                    >
                  </td>
                  <td role="cell" class="cx-order-history-cost-center">
                    <div class="cx-order-history-label">
                      {{ 'orderHistory.costCenter' | cxTranslate }}
                    </div>
                    <a
                      *ngIf="order.costCenter?.name"
                      [routerLink]="
                        {
                          cxRoute: 'orderDetails',
                          params: order,
                        } | cxUrl
                      "
                      [queryParams]="getQueryParams(order)"
                      class="cx-order-history-value"
                    >
                      {{ order.costCenter?.name }}</a
                    >
                  </td>
                </ng-container>

                <td role="cell" class="cx-order-history-placed">
                  <div class="cx-order-history-label">
                    {{ 'orderHistory.date' | cxTranslate }}
                  </div>
                  <a
                    [routerLink]="
                      {
                        cxRoute: 'orderDetails',
                        params: order,
                      } | cxUrl
                    "
                    [queryParams]="getQueryParams(order)"
                    class="cx-order-history-value"
                    >{{ order?.placed | cxDate: 'longDate' }}</a
                  >
                </td>
                <td role="cell" class="cx-order-history-status">
                  <div class="cx-order-history-label">
                    {{ 'orderHistory.status' | cxTranslate }}
                  </div>
                  <a
                    [routerLink]="
                      {
                        cxRoute: 'orderDetails',
                        params: order,
                      } | cxUrl
                    "
                    [queryParams]="getQueryParams(order)"
                    class="cx-order-history-value"
                  >
                    {{
                      'orderDetails.statusDisplay_' + order?.statusDisplay
                        | cxTranslate
                    }}</a
                  >
                </td>
                <td role="cell" class="cx-order-history-total">
                  <div class="cx-order-history-label">
                    {{ 'orderHistory.total' | cxTranslate }}
                  </div>
                  <a
                    [routerLink]="
                      {
                        cxRoute: 'orderDetails',
                        params: order,
                      } | cxUrl
                    "
                    [queryParams]="getQueryParams(order)"
                    class="cx-order-history-value"
                  >
                    {{ order?.total.formattedValue }}</a
                  >
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Select Form and Pagination Bottom -->
          <div class="cx-order-history-sort bottom">
            <div
              *ngIf="type.orderHistory.pagination.totalPages > 1"
              class="cx-order-history-pagination"
            >
              <cx-pagination
                [pagination]="type.orderHistory.pagination"
                (viewPageEvent)="pageChange($event)"
              ></cx-pagination>
            </div>
          </div>
        </ng-container>

        <!-- NO ORDER CONTAINER -->
        <ng-template #noOrder>
          <div
            *ngIf="isLoaded$ | async"
            [ngClass]="
              type.replenishmentOrder
                ? 'cx-replenishment-details-order-history-no-order'
                : 'cx-order-history-no-order'
            "
          >
            <div>
              <ng-container *ngIf="type.replenishmentOrder; else otherOrder">
                <div>{{ 'orderHistory.notFound' | cxTranslate }}</div>
              </ng-container>

              <ng-template #otherOrder>
                <div>{{ 'orderHistory.noOrders' | cxTranslate }}</div>
                <a
                  [routerLink]="{ cxRoute: 'home' } | cxUrl"
                  routerLinkActive="active"
                  class="btn btn-primary btn-block"
                  cxBtnLikeLink
                  >{{ 'orderHistory.startShopping' | cxTranslate }}</a
                >
              </ng-template>
            </div>
          </div>
        </ng-template>
      </div>
    </div>
  </ng-container>
</ng-container>
`
    }]
  }], () => [{
    type: RoutingService
  }, {
    type: OrderHistoryFacade
  }, {
    type: TranslationService
  }, {
    type: ReplenishmentOrderHistoryFacade
  }], null);
})();
var OrderCriticalStatus;
(function(OrderCriticalStatus2) {
  OrderCriticalStatus2["CANCELLED"] = "CANCELLED";
  OrderCriticalStatus2["ERROR"] = "ERROR";
  OrderCriticalStatus2["REJECTED"] = "REJECTED";
})(OrderCriticalStatus || (OrderCriticalStatus = {}));
var MyAccountV2ConsignmentEntriesComponent = class _MyAccountV2ConsignmentEntriesComponent {
  getConsignmentNumber(code) {
    if (code) {
      const consignmentNumber = Number(code.split("_")[1]);
      if (!isNaN(consignmentNumber)) {
        return (consignmentNumber + 1).toString();
      }
    }
    return code;
  }
  static {
    this.ɵfac = function MyAccountV2ConsignmentEntriesComponent_Factory(t) {
      return new (t || _MyAccountV2ConsignmentEntriesComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2ConsignmentEntriesComponent,
      selectors: [["cx-my-account-v2-consignment-entries"]],
      inputs: {
        consignments: "consignments",
        orderCode: "orderCode"
      },
      decls: 1,
      vars: 1,
      consts: [["showLastUpdated", ""], ["showNumber", ""], [4, "ngFor", "ngForOf"], ["class", "cx-consignment-info", 4, "ngIf"], [1, "cx-consignment-info"], [4, "ngIf", "ngIfElse"], [4, "ngIf"], ["target", "_blank", "rel", "noopener noreferrer", 1, "cx-tracking-id", 3, "href"]],
      template: function MyAccountV2ConsignmentEntriesComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2ConsignmentEntriesComponent_ng_container_0_Template, 2, 1, "ng-container", 2);
        }
        if (rf & 2) {
          ɵɵproperty("ngForOf", ctx.consignments);
        }
      },
      dependencies: [NgForOf, NgIf, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2ConsignmentEntriesComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-consignment-entries",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngFor="let consignment of consignments; index as i">
  <!--
example:
Consignment 1 | In Process | Last Updated: 13, September, 2023
Consignment 2 | Tracking Number: 5657474 | Estimated Delivery: 22, September, 2023
  -->
  <div
    class="cx-consignment-info"
    [attr.aria-label]="
      'myAccountV2OrderHistory.consignmentDetailLabel' | cxTranslate
    "
    *ngIf="consignment"
  >
    <span
      [attr.aria-label]="
        'myAccountV2OrderHistory.consignmentNumberLabel' | cxTranslate
      "
    >
      {{
        'myAccountV2OrderHistory.consignmentCode'
          | cxTranslate: { param: i + 1 }
      }}
    </span>
    |
    <ng-container *ngIf="consignment.trackingID; else showLastUpdated">
      <ng-container *ngIf="consignment.consignmentTracking as tracking">
        <span
          [attr.aria-label]="
            'orderDetails.consignmentTracking.dialog.trackingId' | cxTranslate
          "
        >
          {{
            'orderDetails.consignmentTracking.dialog.trackingId' | cxTranslate
          }}:
          <ng-container *ngIf="tracking.trackingUrl; else showNumber">
            <a
              class="cx-tracking-id"
              target="_blank"
              rel="noopener noreferrer"
              [href]="tracking.trackingUrl"
              >{{ tracking.trackingID }}</a
            >
          </ng-container>
          |
        </span>
        <span
          [attr.aria-label]="
            'myAccountV2OrderHistory.estimateDeliveryLabel' | cxTranslate
          "
        >
          {{
            'orderDetails.consignmentTracking.dialog.estimate' | cxTranslate
          }}:
          {{ tracking.targetArrivalDate | cxDate: 'd, MMMM, yyyy' }}
        </span>
        <ng-template #showNumber>
          {{ tracking.trackingID }}
        </ng-template>
      </ng-container>
    </ng-container>
    <ng-template #showLastUpdated>
      <span
        [attr.aria-label]="
          'myAccountV2OrderHistory.consignmentStatusLabel' | cxTranslate
        "
        *ngIf="consignment.status"
      >
        {{
          'orderDetails.deliveryStatus_' + consignment?.status?.toUpperCase()
            | cxTranslate
        }}
      </span>
      <span
        *ngIf="consignment.statusDate"
        [attr.aria-label]="
          'myAccountV2OrderHistory.consignmentStatusDateLabel' | cxTranslate
        "
      >
        |
        {{
          'myAccountV2OrderHistory.statusDate'
            | cxTranslate
              : { param: consignment.statusDate | cxDate: 'd, MMMM, yyyy' }
        }}
      </span>
    </ng-template>
  </div>
</ng-container>
`
    }]
  }], null, {
    consignments: [{
      type: Input
    }],
    orderCode: [{
      type: Input
    }]
  });
})();
var MyAccountV2OrderConsolidatedInformationComponent = class _MyAccountV2OrderConsolidatedInformationComponent {
  constructor() {
    this.orderConsignmentsService = inject(MyAccountV2OrderConsignmentsService);
    this.criticalStatuses = Object.values(OrderCriticalStatus);
    this.IMAGE_COUNT = 4;
  }
  getConsignmentsCount(consignments) {
    let count = 0;
    if (consignments) {
      for (const consignment of consignments) {
        if (consignment.entries) {
          count = count + consignment.entries.length;
        }
      }
    }
    return count;
  }
  getOrderEntriesCount(orderEntries) {
    return orderEntries?.length ?? 0;
  }
  isStatusCritical(status) {
    return this.criticalStatuses.includes(status.toUpperCase());
  }
  getPickupConsignments(consignments) {
    const orderDetail = {};
    orderDetail.consignments = consignments;
    return this.orderConsignmentsService.getGroupedConsignments(orderDetail, true) ?? [];
  }
  getDeliveryConsignments(consignments) {
    const orderDetail = {};
    orderDetail.consignments = consignments;
    return this.orderConsignmentsService.getGroupedConsignments(orderDetail, false) ?? [];
  }
  getDeliveryUnconsignedEntries(unconsignedEntries) {
    const orderDetail = {};
    orderDetail.unconsignedEntries = unconsignedEntries;
    return this.orderConsignmentsService.getUnconsignedEntries(orderDetail, false) ?? [];
  }
  getPickupUnconsignedEntries(unconsignedEntries) {
    const orderDetail = {};
    orderDetail.unconsignedEntries = unconsignedEntries;
    return this.orderConsignmentsService.getUnconsignedEntries(orderDetail, true) ?? [];
  }
  getProductImages(entries) {
    const images = [];
    let index = 0;
    for (const item of entries) {
      if (item.product?.images) {
        if (index >= this.IMAGE_COUNT) {
          break;
        }
        index++;
        images.push(item.product?.images);
      }
    }
    return images;
  }
  static {
    this.ɵfac = function MyAccountV2OrderConsolidatedInformationComponent_Factory(t) {
      return new (t || _MyAccountV2OrderConsolidatedInformationComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2OrderConsolidatedInformationComponent,
      selectors: [["cx-my-account-v2-order-consolidated-information"]],
      inputs: {
        order: "order"
      },
      decls: 5,
      vars: 1,
      consts: [["showManyItems", ""], ["showOneItem", ""], ["nonCritical", ""], ["showReturnCode", ""], ["class", "cx-consolidated-order-info", 4, "ngIf"], [1, "cx-consolidated-order-info"], [1, "cx-order-info"], [4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "cx-order-images-container"], [1, "cx-order-status"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [3, "orderCode", "consignments"], ["class", "cx-consignment-info", 4, "ngIf"], ["class", "cx-order-status-critical", 4, "ngIf", "ngIfElse"], [1, "cx-order-status-critical"], [1, "cx-consignment-info"], ["class", "cx-order-status-critical-link", 3, "routerLink", 4, "ngIf", "ngIfElse"], [1, "cx-order-status-critical-link", 3, "routerLink"], ["format", "thumbnail", "role", "presentation", 1, "cx-order-img", 3, "container"], [4, "ngIf", "ngIfElse"]],
      template: function MyAccountV2OrderConsolidatedInformationComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2OrderConsolidatedInformationComponent_div_0_Template, 8, 7, "div", 4)(1, MyAccountV2OrderConsolidatedInformationComponent_ng_template_1_Template, 1, 2, "ng-template", null, 0, ɵɵtemplateRefExtractor)(3, MyAccountV2OrderConsolidatedInformationComponent_ng_template_3_Template, 2, 5, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ctx.order);
        }
      },
      dependencies: [NgForOf, NgIf, NgTemplateOutlet, RouterLink, MediaComponent, MyAccountV2ConsignmentEntriesComponent, UrlPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrderConsolidatedInformationComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-order-consolidated-information",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div class="cx-consolidated-order-info" *ngIf="order">
  <div class="cx-order-info">
    <!-- pickup consigned entries 
  eg: To Be Picked Up - 3 Items
  -->
    <div
      *ngIf="
        getConsignmentsCount(getPickupConsignments(order.consignments ?? [])) >
        0
      "
    >
      <div class="cx-order-status">
        {{
          'myAccountV2OrderHistory.deliveryPointOfServiceDetails.itemsToBePickUp'
            | cxTranslate
        }}
        <ng-container
          *ngTemplateOutlet="
            showManyItems;
            context: {
              count: getConsignmentsCount(
                getPickupConsignments(order.consignments ?? [])
              ),
            }
          "
        ></ng-container>
      </div>
      <cx-my-account-v2-consignment-entries
        [orderCode]="order.code ?? ''"
        [consignments]="getPickupConsignments(order.consignments ?? [])"
      ></cx-my-account-v2-consignment-entries>
    </div>

    <!-- delivery consigned entries
  eg: To Be Shipped - 6 Items
  -->
    <div
      *ngIf="
        getConsignmentsCount(
          getDeliveryConsignments(order.consignments ?? [])
        ) > 0
      "
    >
      <!--heading taken from feature-libs/order/components/order-confirmation/order-confirmation-shipping/order-confirmation-shipping.component.html-->
      <!--instead of [cxOutlet]="OrderOutlets.CONSIGNMENT_DELIVERY_INFO"-->
      <div class="cx-order-status">
        {{
          'myAccountV2OrderHistory.checkoutMode.deliveryEntries' | cxTranslate
        }}
        <ng-container
          *ngTemplateOutlet="
            showManyItems;
            context: {
              count: getConsignmentsCount(
                getDeliveryConsignments(order.consignments ?? [])
              ),
            }
          "
        ></ng-container>
      </div>
      <cx-my-account-v2-consignment-entries
        [orderCode]="order.code ?? ''"
        [consignments]="getDeliveryConsignments(order.consignments ?? [])"
      ></cx-my-account-v2-consignment-entries>
    </div>

    <!-- unconsigned entries 
  eg: Some_Status - 1 Item
  -->
    <div *ngIf="getOrderEntriesCount(order.unconsignedEntries) > 0">
      <div *ngIf="order.statusDisplay">
        <div
          class="cx-order-status-critical"
          *ngIf="isStatusCritical(order.statusDisplay); else nonCritical"
        >
          {{
            'orderDetails.statusDisplay_' + order.statusDisplay | cxTranslate
          }}
          -
          <ng-container
            *ngTemplateOutlet="
              showManyItems;
              context: { count: getOrderEntriesCount(order.unconsignedEntries) }
            "
          ></ng-container>
        </div>
        <ng-template #nonCritical>
          <div class="cx-order-status">
            {{
              'orderDetails.statusDisplay_' + order.statusDisplay | cxTranslate
            }}
            -
            <ng-container
              *ngTemplateOutlet="
                showManyItems;
                context: {
                  count: getOrderEntriesCount(order.unconsignedEntries),
                }
              "
            ></ng-container>
          </div>
        </ng-template>
      </div>

      <!-- delivery unconsigned entries 
      eg: To Be Shipped - 6 Items //showing this is in extra information format
    -->
      <div
        class="cx-consignment-info"
        *ngIf="
          getOrderEntriesCount(
            getDeliveryUnconsignedEntries(order.unconsignedEntries ?? [])
          ) > 0
        "
      >
        {{
          'myAccountV2OrderHistory.checkoutMode.deliveryEntries' | cxTranslate
        }}
        <ng-container
          *ngTemplateOutlet="
            showManyItems;
            context: {
              count: getOrderEntriesCount(
                getDeliveryUnconsignedEntries(order.unconsignedEntries ?? [])
              ),
            }
          "
        ></ng-container>
      </div>

      <!-- pickup unconsigned entries, b2b does not have pickup items
      eg: To Be Picked Up - 7 Items //showing this is as an extra information format
    -->
      <div
        class="cx-consignment-info"
        *ngIf="
          getOrderEntriesCount(
            getPickupUnconsignedEntries(order.unconsignedEntries ?? [])
          ) > 0
        "
      >
        {{
          'myAccountV2OrderHistory.checkoutPickupInStore.heading' | cxTranslate
        }}
        <ng-container
          *ngTemplateOutlet="
            showManyItems;
            context: {
              count: getOrderEntriesCount(
                getPickupUnconsignedEntries(order.unconsignedEntries ?? [])
              ),
            }
          "
        ></ng-container>
      </div>
    </div>

    <!--return request details
  eg: Returned: 2 Items
      Return Processed: 15, September, 2022
  -->
    <div *ngFor="let returnRequest of order.returnRequests">
      <div class="cx-order-status-critical">
        {{ 'returnRequestList.returnRequestId' | cxTranslate }}
        <a
          *ngIf="returnRequest.rma; else showReturnCode"
          [routerLink]="
            {
              cxRoute: 'returnRequestDetails',
              params: returnRequest,
            } | cxUrl
          "
          class="cx-order-status-critical-link"
        >
          {{ returnRequest.rma }}</a
        >
      </div>
      <ng-template #showReturnCode>
        {{ returnRequest.code }}
      </ng-template>
      <div
        class="cx-consignment-info"
        *ngIf="returnRequest.creationTime as creationTime"
      >
        {{
          'myAccountV2OrderHistory.returnProcessed'
            | cxTranslate: { param: creationTime | cxDate: 'd, MMMM, yyyy' }
        }}
      </div>
    </div>
  </div>
  <div class="cx-order-images-container">
    <ng-container *ngIf="order.entries">
      <ng-container *ngFor="let item of getProductImages(order.entries)">
        <cx-media
          [container]="item.PRIMARY"
          class="cx-order-img"
          format="thumbnail"
          role="presentation"
        ></cx-media>
      </ng-container>
    </ng-container>
  </div>
</div>

<ng-template #showManyItems let-count="count">
  <ng-container *ngIf="count > 1; else showOneItem">
    {{ 'myAccountV2OrderHistory.items' | cxTranslate: { param: count } }}
  </ng-container>
</ng-template>
<ng-template #showOneItem>
  {{ 'myAccountV2OrderHistory.item' | cxTranslate: { param: 1 } }}
</ng-template>
`
    }]
  }], null, {
    order: [{
      type: Input
    }]
  });
})();
var MyAccountV2OrderHistoryComponent = class _MyAccountV2OrderHistoryComponent extends OrderHistoryComponent {
  constructor() {
    super(...arguments);
    this.service = inject(MyAccountV2OrderHistoryService);
    this.ITEMS_PER_PAGE = 5;
    this.isLoaded$ = new BehaviorSubject(false);
    this.orders$ = this.service.getOrderHistoryList(this.ITEMS_PER_PAGE).pipe(tap((orders) => {
      this.isLoaded$.next(true);
      super.setOrderHistoryParams(orders);
    }));
  }
  pageChange(page) {
    this.isLoaded$.next(false);
    this.service.clearOrderList();
    super.pageChange(page);
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵMyAccountV2OrderHistoryComponent_BaseFactory;
      return function MyAccountV2OrderHistoryComponent_Factory(t) {
        return (ɵMyAccountV2OrderHistoryComponent_BaseFactory || (ɵMyAccountV2OrderHistoryComponent_BaseFactory = ɵɵgetInheritedFactory(_MyAccountV2OrderHistoryComponent)))(t || _MyAccountV2OrderHistoryComponent);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2OrderHistoryComponent,
      selectors: [["cx-my-account-v2-order-history"]],
      features: [ɵɵInheritDefinitionFeature],
      decls: 6,
      vars: 4,
      consts: [["noOrder", ""], ["loading", ""], [4, "ngIf", "ngIfElse"], [1, "cx-my-account-v2-order-history-header"], [1, "cx-my-account-v2-order-history-body"], [4, "ngFor", "ngForOf"], ["class", "cx-order-history-pagination", 4, "ngIf"], [1, "cx-each-order"], [1, "cx-my-account-v2-order-history-code", 3, "click"], [3, "routerLink", "queryParams"], [1, "cx-my-account-v2-order-summary"], [3, "order"], [1, "cx-order-history-pagination"], [3, "viewPageEvent", "pagination"], ["routerLinkActive", "active", 1, "cx-no-order", 3, "routerLink"], [1, "cx-spinner"]],
      template: function MyAccountV2OrderHistoryComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, MyAccountV2OrderHistoryComponent_div_0_Template, 9, 13, "div", 2);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, MyAccountV2OrderHistoryComponent_ng_template_2_Template, 2, 4, "ng-template", null, 0, ɵɵtemplateRefExtractor)(4, MyAccountV2OrderHistoryComponent_ng_template_4_Template, 2, 0, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const noOrder_r6 = ɵɵreference(3);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 2, ctx.orders$))("ngIfElse", noOrder_r6);
        }
      },
      dependencies: [NgForOf, NgIf, RouterLink, RouterLinkActive, PaginationComponent, SpinnerComponent, MyAccountV2OrderConsolidatedInformationComponent, AsyncPipe, UrlPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2OrderHistoryComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-order-history",
      template: `<div
  *ngIf="orders$ | async as orderHistory; else noOrder"
  [attr.aria-label]="'myAccountV2OrderHistory.orderListResults' | cxTranslate"
>
  <!-- HEADER -->
  <div class="cx-my-account-v2-order-history-header">
    <h2>
      {{
        'myAccountV2OrderHistory.heading'
          | cxTranslate: { param: tabTitleParam$ | async }
      }}
    </h2>
  </div>
  <!--BODY-->
  <div class="cx-my-account-v2-order-history-body">
    <ng-container
      *ngIf="orderHistory.pagination.totalResults > 0; else noOrder"
    >
      <ng-container *ngFor="let order of orderHistory.orders">
        <div class="cx-each-order">
          <!--eg: Order # 12345-->
          <div
            class="cx-my-account-v2-order-history-code"
            [attr.aria-label]="
              'myAccountV2OrderHistory.orderCodeLabel' | cxTranslate
            "
            (click)="goToOrderDetail(order)"
          >
            <a
              [routerLink]="
                {
                  cxRoute: 'orderDetails',
                  params: order,
                } | cxUrl
              "
              [queryParams]="getQueryParams(order)"
            >
              {{ 'orderHistory.orderId' | cxTranslate }} {{ order?.code }}</a
            >
          </div>

          <!--eg: 12,October,2022 | Total Price: $12.00-->
          <div class="cx-my-account-v2-order-summary">
            <span
              [attr.aria-label]="
                'myAccountV2OrderHistory.orderPlaced' | cxTranslate
              "
            >
              {{ order.placed | cxDate: 'd, MMMM, yyyy' }} |
            </span>
            <span
              [attr.aria-label]="
                'myAccountV2OrderHistory.totalPriceLabel' | cxTranslate
              "
            >
              <strong>
                {{
                  'myAccountV2OrderHistory.totalPrice'
                    | cxTranslate: { param: order.total?.formattedValue }
                }}
              </strong>
            </span>
          </div>

          <!--eg: Display consolidated order information-->
          <cx-my-account-v2-order-consolidated-information [order]="order">
          </cx-my-account-v2-order-consolidated-information>
        </div>
      </ng-container>

      <!-- PAGINATION -->
      <div
        *ngIf="orderHistory.pagination.totalPages > 1"
        class="cx-order-history-pagination"
        [attr.aria-label]="
          'myAccountV2OrderHistory.orderListPagination' | cxTranslate
        "
      >
        <cx-pagination
          [pagination]="orderHistory.pagination"
          (viewPageEvent)="pageChange($event)"
        ></cx-pagination>
      </div>
    </ng-container>
  </div>
</div>

<!-- NO ORDER CONTAINER -->
<ng-template #noOrder>
  <div *ngIf="isLoaded$ | async; else loading">
    <div [attr.aria-label]="'orderHistory.notFound' | cxTranslate">
      {{ 'orderHistory.noOrders' | cxTranslate }}
    </div>
    <a
      [routerLink]="{ cxRoute: 'home' } | cxUrl"
      routerLinkActive="active"
      class="cx-no-order"
      >{{ 'orderHistory.startShopping' | cxTranslate }}</a
    >
  </div>
</ng-template>

<!-- ORDER HISTORY DATA STILL LOADING -->
<ng-template #loading>
  <div class="cx-spinner">
    <cx-spinner></cx-spinner>
  </div>
</ng-template>
`
    }]
  }], null, null);
})();
var myAccountV2CmsMapping = {
  cmsComponents: {
    AccountOrderHistoryComponent: {
      component: MyAccountV2OrderHistoryComponent
      //guards: inherited from standard config,
    }
  }
};
var moduleComponents$1 = [MyAccountV2OrderHistoryComponent, MyAccountV2OrderConsolidatedInformationComponent, MyAccountV2ConsignmentEntriesComponent];
var OrderHistoryModule = class _OrderHistoryModule {
  static {
    this.ɵfac = function OrderHistoryModule_Factory(t) {
      return new (t || _OrderHistoryModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderHistoryModule,
      declarations: [OrderHistoryComponent, MyAccountV2OrderHistoryComponent, MyAccountV2OrderConsolidatedInformationComponent, MyAccountV2ConsignmentEntriesComponent],
      imports: [CommonModule, RouterModule, FormsModule, NgSelectModule, ListNavigationModule, UrlModule, I18nModule, SpinnerModule, MediaModule, BtnLikeLinkModule],
      exports: [OrderHistoryComponent, MyAccountV2OrderHistoryComponent, MyAccountV2OrderConsolidatedInformationComponent, MyAccountV2ConsignmentEntriesComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          AccountOrderHistoryComponent: {
            component: OrderHistoryComponent,
            guards: [AuthGuard]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_ORDER) ? myAccountV2CmsMapping : {})],
      imports: [CommonModule, RouterModule, FormsModule, NgSelectModule, ListNavigationModule, UrlModule, I18nModule, SpinnerModule, MediaModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderHistoryModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, FormsModule, NgSelectModule, ListNavigationModule, UrlModule, I18nModule, SpinnerModule, MediaModule, BtnLikeLinkModule],
      declarations: [OrderHistoryComponent, ...moduleComponents$1],
      exports: [OrderHistoryComponent, ...moduleComponents$1],
      providers: [provideDefaultConfig({
        cmsComponents: {
          AccountOrderHistoryComponent: {
            component: OrderHistoryComponent,
            guards: [AuthGuard]
          }
        }
      }), provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_ORDER) ? myAccountV2CmsMapping : {})]
    }]
  }], null, null);
})();
var OrderDetailsOrderEntriesContext = class _OrderDetailsOrderEntriesContext {
  constructor(orderHistoryFacade) {
    this.orderHistoryFacade = orderHistoryFacade;
    this.type = OrderEntriesSource.ORDER_DETAILS;
  }
  getEntries() {
    return this.orderHistoryFacade.getOrderDetails().pipe(map((order) => order?.entries ?? []));
  }
  static {
    this.ɵfac = function OrderDetailsOrderEntriesContext_Factory(t) {
      return new (t || _OrderDetailsOrderEntriesContext)(ɵɵinject(OrderHistoryFacade));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OrderDetailsOrderEntriesContext,
      factory: _OrderDetailsOrderEntriesContext.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderDetailsOrderEntriesContext, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: OrderHistoryFacade
  }], null);
})();
var ReplenishmentOrderCancellationDialogComponent = class _ReplenishmentOrderCancellationDialogComponent {
  handleClick(event) {
    if (event.target.tagName === this.el.nativeElement.tagName) {
      this.close("Cross click");
    }
  }
  constructor(replenishmentOrderHistoryFacade, globalMessageService, launchDialogService, el) {
    this.replenishmentOrderHistoryFacade = replenishmentOrderHistoryFacade;
    this.globalMessageService = globalMessageService;
    this.launchDialogService = launchDialogService;
    this.el = el;
    this.subscription = new Subscription();
    this.iconTypes = ICON_TYPE;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: "button",
      focusOnEscape: true
    };
  }
  ngOnInit() {
    this.subscription.add(combineLatest([this.replenishmentOrderHistoryFacade.getReplenishmentOrderDetails().pipe(startWith(null)), this.launchDialogService.data$]).subscribe(([replenishmentOrder, code]) => {
      this.replenishmentOrderCode = code || replenishmentOrder?.replenishmentOrderCode;
    }));
    this.subscription.add(this.replenishmentOrderHistoryFacade.getCancelReplenishmentOrderSuccess().subscribe((value) => this.onSuccess(value)));
  }
  onSuccess(value) {
    if (value) {
      this.launchDialogService.closeDialog("Successffully cancelled replenishment");
      this.globalMessageService.add({
        key: "orderDetails.cancelReplenishment.cancelSuccess",
        params: {
          replenishmentOrderCode: this.replenishmentOrderCode
        }
      }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
    this.replenishmentOrderHistoryFacade.clearCancelReplenishmentOrderProcessState();
  }
  close(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  cancelReplenishment() {
    this.replenishmentOrderHistoryFacade.cancelReplenishmentOrder(this.replenishmentOrderCode);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static {
    this.ɵfac = function ReplenishmentOrderCancellationDialogComponent_Factory(t) {
      return new (t || _ReplenishmentOrderCancellationDialogComponent)(ɵɵdirectiveInject(ReplenishmentOrderHistoryFacade), ɵɵdirectiveInject(GlobalMessageService), ɵɵdirectiveInject(LaunchDialogService), ɵɵdirectiveInject(ElementRef));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReplenishmentOrderCancellationDialogComponent,
      selectors: [["cx-replenishment-order-cancellation-dialog"]],
      hostBindings: function ReplenishmentOrderCancellationDialogComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          ɵɵlistener("click", function ReplenishmentOrderCancellationDialogComponent_click_HostBindingHandler($event) {
            return ctx.handleClick($event);
          });
        }
      },
      decls: 24,
      vars: 20,
      consts: [["role", "dialog", "aria-labelledby", "dialogTitle", 1, "cx-cancel-replenishment-dialog-foreground", 3, "esc", "cxFocus"], [1, "cx-cancel-replenishment-dialog-content"], [1, "cx-cancel-replenishment-dialog-header"], ["id", "dialogTitle"], ["type", "button", 1, "close", 3, "click", "title"], ["aria-hidden", "true"], [3, "type"], [1, "cx-cancel-replenishment-dialog-description"], [1, "cx-cancel-replenishment-dialog-body"], [1, "cx-cancel-replenishment-btns", "row"], [1, "col-md-6"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], [1, "btn", "btn-block", "btn-primary", 3, "click"]],
      template: function ReplenishmentOrderCancellationDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵlistener("esc", function ReplenishmentOrderCancellationDialogComponent_Template_div_esc_0_listener() {
            return ctx.close("Escape clicked");
          });
          ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "h3", 3);
          ɵɵtext(4);
          ɵɵpipe(5, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(6, "button", 4);
          ɵɵpipe(7, "cxTranslate");
          ɵɵpipe(8, "cxTranslate");
          ɵɵlistener("click", function ReplenishmentOrderCancellationDialogComponent_Template_button_click_6_listener() {
            return ctx.close("Cross click");
          });
          ɵɵelementStart(9, "span", 5);
          ɵɵelement(10, "cx-icon", 6);
          ɵɵelementEnd()()();
          ɵɵelementStart(11, "div", 7);
          ɵɵtext(12);
          ɵɵpipe(13, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(14, "div", 8)(15, "div", 9)(16, "div", 10)(17, "button", 11);
          ɵɵlistener("click", function ReplenishmentOrderCancellationDialogComponent_Template_button_click_17_listener() {
            return ctx.close("Close Replenishment Dialog");
          });
          ɵɵtext(18);
          ɵɵpipe(19, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵelementStart(20, "div", 10)(21, "button", 12);
          ɵɵlistener("click", function ReplenishmentOrderCancellationDialogComponent_Template_button_click_21_listener() {
            return ctx.cancelReplenishment();
          });
          ɵɵtext(22);
          ɵɵpipe(23, "cxTranslate");
          ɵɵelementEnd()()()()()();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 8, "orderDetails.cancelReplenishment.title"), " ");
          ɵɵadvance(2);
          ɵɵpropertyInterpolate("title", ɵɵpipeBind1(7, 10, "common.close"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(8, 12, "common.close"));
          ɵɵadvance(4);
          ɵɵproperty("type", ctx.iconTypes.CLOSE);
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 14, "orderDetails.cancelReplenishment.description"), " ");
          ɵɵadvance(6);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 16, "orderDetails.cancelReplenishment.reject"), " ");
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(23, 18, "orderDetails.cancelReplenishment.accept"), " ");
        }
      },
      dependencies: [IconComponent, FocusDirective, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderCancellationDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-replenishment-order-cancellation-dialog",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<div
  [cxFocus]="focusConfig"
  (esc)="close('Escape clicked')"
  class="cx-cancel-replenishment-dialog-foreground"
  role="dialog"
  aria-labelledby="dialogTitle"
>
  <div class="cx-cancel-replenishment-dialog-content">
    <div class="cx-cancel-replenishment-dialog-header">
      <h3 id="dialogTitle">
        {{ 'orderDetails.cancelReplenishment.title' | cxTranslate }}
      </h3>
      <button
        type="button"
        class="close"
        title="{{ 'common.close' | cxTranslate }}"
        [attr.aria-label]="'common.close' | cxTranslate"
        (click)="close('Cross click')"
      >
        <span aria-hidden="true">
          <cx-icon [type]="iconTypes.CLOSE"></cx-icon>
        </span>
      </button>
    </div>
    <div class="cx-cancel-replenishment-dialog-description">
      {{ 'orderDetails.cancelReplenishment.description' | cxTranslate }}
    </div>

    <div class="cx-cancel-replenishment-dialog-body">
      <div class="cx-cancel-replenishment-btns row">
        <div class="col-md-6">
          <button
            class="btn btn-block btn-secondary"
            (click)="close('Close Replenishment Dialog')"
          >
            {{ 'orderDetails.cancelReplenishment.reject' | cxTranslate }}
          </button>
        </div>
        <div class="col-md-6">
          <button
            class="btn btn-block btn-primary"
            (click)="cancelReplenishment()"
          >
            {{ 'orderDetails.cancelReplenishment.accept' | cxTranslate }}
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: ReplenishmentOrderHistoryFacade
  }, {
    type: GlobalMessageService
  }, {
    type: LaunchDialogService
  }, {
    type: ElementRef
  }], {
    handleClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var ReplenishmentOrderCancellationDialogModule = class _ReplenishmentOrderCancellationDialogModule {
  static {
    this.ɵfac = function ReplenishmentOrderCancellationDialogModule_Factory(t) {
      return new (t || _ReplenishmentOrderCancellationDialogModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReplenishmentOrderCancellationDialogModule,
      declarations: [ReplenishmentOrderCancellationDialogComponent],
      imports: [CommonModule, I18nModule, IconModule, KeyboardFocusModule],
      exports: [ReplenishmentOrderCancellationDialogComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [CommonModule, I18nModule, IconModule, KeyboardFocusModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderCancellationDialogModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, I18nModule, IconModule, KeyboardFocusModule],
      declarations: [ReplenishmentOrderCancellationDialogComponent],
      exports: [ReplenishmentOrderCancellationDialogComponent]
    }]
  }], null, null);
})();
var defaultReplenishmentOrderCancellationLayoutConfig = {
  launch: {
    REPLENISHMENT_ORDER: {
      inline: true,
      component: ReplenishmentOrderCancellationDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var ReplenishmentOrderCancellationComponent = class _ReplenishmentOrderCancellationComponent {
  constructor(replenishmentOrderHistoryFacade, vcr, launchDialogService) {
    this.replenishmentOrderHistoryFacade = replenishmentOrderHistoryFacade;
    this.vcr = vcr;
    this.launchDialogService = launchDialogService;
    this.subscription = new Subscription();
    this.replenishmentOrder$ = this.replenishmentOrderHistoryFacade.getReplenishmentOrderDetails();
  }
  openDialog() {
    const dialog = this.launchDialogService.openDialog("REPLENISHMENT_ORDER", this.element, this.vcr);
    if (dialog) {
      this.subscription.add(dialog.pipe(take(1)).subscribe());
    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.replenishmentOrderHistoryFacade.clearReplenishmentOrderDetails();
  }
  static {
    this.ɵfac = function ReplenishmentOrderCancellationComponent_Factory(t) {
      return new (t || _ReplenishmentOrderCancellationComponent)(ɵɵdirectiveInject(ReplenishmentOrderHistoryFacade), ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(LaunchDialogService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReplenishmentOrderCancellationComponent,
      selectors: [["cx-replenishment-order-cancellation"]],
      viewQuery: function ReplenishmentOrderCancellationComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c16, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
        }
      },
      decls: 8,
      vars: 10,
      consts: [["element", ""], [1, "cx-cancel-replenishment-btns", "row"], [1, "col-xs-12", "col-md-5", "col-lg-4"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", 3, "routerLink"], ["class", "col-xs-12 col-md-5 col-lg-4", 4, "ngIf"], [1, "btn", "btn-block", "btn-secondary", 3, "click"]],
      template: function ReplenishmentOrderCancellationComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 1)(1, "div", 2)(2, "a", 3);
          ɵɵpipe(3, "cxUrl");
          ɵɵtext(4);
          ɵɵpipe(5, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵtemplate(6, ReplenishmentOrderCancellationComponent_div_6_Template, 5, 3, "div", 4);
          ɵɵpipe(7, "async");
          ɵɵelementEnd();
        }
        if (rf & 2) {
          let tmp_2_0;
          ɵɵadvance(2);
          ɵɵproperty("routerLink", ɵɵpipeBind1(3, 3, ɵɵpureFunction0(9, _c28)));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(5, 5, "common.back"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngIf", (tmp_2_0 = ɵɵpipeBind1(7, 7, ctx.replenishmentOrder$)) == null ? null : tmp_2_0.active);
        }
      },
      dependencies: [NgIf, RouterLink, BtnLikeLinkDirective, AsyncPipe, TranslatePipe, UrlPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderCancellationComponent, [{
    type: Component,
    args: [{
      selector: "cx-replenishment-order-cancellation",
      template: `<div class="cx-cancel-replenishment-btns row">
  <div class="col-xs-12 col-md-5 col-lg-4">
    <a
      class="btn btn-block btn-secondary"
      [routerLink]="
        {
          cxRoute: 'replenishmentOrders',
        } | cxUrl
      "
      cxBtnLikeLink
    >
      {{ 'common.back' | cxTranslate }}
    </a>
  </div>
  <div
    *ngIf="(replenishmentOrder$ | async)?.active"
    class="col-xs-12 col-md-5 col-lg-4"
  >
    <button #element class="btn btn-block btn-secondary" (click)="openDialog()">
      {{ 'orderDetails.cancelReplenishment.title' | cxTranslate }}
    </button>
  </div>
</div>
`
    }]
  }], () => [{
    type: ReplenishmentOrderHistoryFacade
  }, {
    type: ViewContainerRef
  }, {
    type: LaunchDialogService
  }], {
    element: [{
      type: ViewChild,
      args: ["element"]
    }]
  });
})();
var ReplenishmentOrderDetailsService = class _ReplenishmentOrderDetailsService {
  constructor(routingService, replenishmentOrderHistoryFacade) {
    this.routingService = routingService;
    this.replenishmentOrderHistoryFacade = replenishmentOrderHistoryFacade;
    this.replenishmentOrderCode$ = this.routingService.getRouterState().pipe(map((routingData) => routingData.state.params.replenishmentOrderCode), distinctUntilChanged());
    this.replenishmentOrderLoad$ = this.replenishmentOrderCode$.pipe(tap((replenishmentOrderCode) => {
      if (Boolean(replenishmentOrderCode)) {
        this.replenishmentOrderHistoryFacade.loadReplenishmentOrderDetails(replenishmentOrderCode);
      } else {
        this.replenishmentOrderHistoryFacade.clearReplenishmentOrderDetails();
      }
    }), shareReplay({
      bufferSize: 1,
      refCount: true
    }));
  }
  getOrderDetails() {
    return this.replenishmentOrderLoad$.pipe(switchMap((_) => this.replenishmentOrderHistoryFacade.getReplenishmentOrderDetails()));
  }
  static {
    this.ɵfac = function ReplenishmentOrderDetailsService_Factory(t) {
      return new (t || _ReplenishmentOrderDetailsService)(ɵɵinject(RoutingService), ɵɵinject(ReplenishmentOrderHistoryFacade));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReplenishmentOrderDetailsService,
      factory: _ReplenishmentOrderDetailsService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderDetailsService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: RoutingService
  }, {
    type: ReplenishmentOrderHistoryFacade
  }], null);
})();
var moduleComponents = [ReplenishmentOrderCancellationComponent];
var ReplenishmentOrderDetailsModule = class _ReplenishmentOrderDetailsModule {
  static {
    this.ɵfac = function ReplenishmentOrderDetailsModule_Factory(t) {
      return new (t || _ReplenishmentOrderDetailsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReplenishmentOrderDetailsModule,
      declarations: [ReplenishmentOrderCancellationComponent],
      imports: [CardModule, CommonModule, I18nModule, PromotionsModule, UrlModule, ReplenishmentOrderCancellationDialogModule, SpinnerModule, ListNavigationModule, RouterModule, BtnLikeLinkModule],
      exports: [ReplenishmentOrderCancellationComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultReplenishmentOrderCancellationLayoutConfig), provideDefaultConfig({
        cmsComponents: {
          ReplenishmentDetailItemsComponent: {
            component: OrderDetailItemsComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: ReplenishmentOrderDetailsService
            }]
          },
          ReplenishmentDetailTotalsComponent: {
            component: OrderDetailTotalsComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: ReplenishmentOrderDetailsService
            }]
          },
          ReplenishmentDetailShippingComponent: {
            component: OrderOverviewComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: ReplenishmentOrderDetailsService
            }]
          },
          ReplenishmentDetailActionsComponent: {
            component: ReplenishmentOrderCancellationComponent
          },
          ReplenishmentDetailOrderHistoryComponent: {
            component: OrderHistoryComponent
          }
        }
      })],
      imports: [CardModule, CommonModule, I18nModule, PromotionsModule, UrlModule, ReplenishmentOrderCancellationDialogModule, SpinnerModule, ListNavigationModule, RouterModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderDetailsModule, [{
    type: NgModule,
    args: [{
      imports: [CardModule, CommonModule, I18nModule, PromotionsModule, UrlModule, ReplenishmentOrderCancellationDialogModule, SpinnerModule, ListNavigationModule, RouterModule, BtnLikeLinkModule],
      providers: [provideDefaultConfig(defaultReplenishmentOrderCancellationLayoutConfig), provideDefaultConfig({
        cmsComponents: {
          ReplenishmentDetailItemsComponent: {
            component: OrderDetailItemsComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: ReplenishmentOrderDetailsService
            }]
          },
          ReplenishmentDetailTotalsComponent: {
            component: OrderDetailTotalsComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: ReplenishmentOrderDetailsService
            }]
          },
          ReplenishmentDetailShippingComponent: {
            component: OrderOverviewComponent,
            providers: [{
              provide: OrderDetailsService,
              useExisting: ReplenishmentOrderDetailsService
            }]
          },
          ReplenishmentDetailActionsComponent: {
            component: ReplenishmentOrderCancellationComponent
          },
          ReplenishmentDetailOrderHistoryComponent: {
            component: OrderHistoryComponent
          }
        }
      })],
      declarations: [...moduleComponents],
      exports: [...moduleComponents]
    }]
  }], null, null);
})();
var ReplenishmentOrderHistoryComponent = class _ReplenishmentOrderHistoryComponent {
  constructor(routing, replenishmentOrderHistoryFacade, translation, vcr, launchDialogService) {
    this.routing = routing;
    this.replenishmentOrderHistoryFacade = replenishmentOrderHistoryFacade;
    this.translation = translation;
    this.vcr = vcr;
    this.launchDialogService = launchDialogService;
    this.subscription = new Subscription();
    this.PAGE_SIZE = 5;
    this.replenishmentOrders$ = this.replenishmentOrderHistoryFacade.getReplenishmentOrderHistoryList(this.PAGE_SIZE).pipe(tap((replenishmentOrders) => {
      if (replenishmentOrders?.pagination?.sort) {
        this.sortType = replenishmentOrders.pagination.sort;
      }
    }));
    this.isLoaded$ = this.replenishmentOrderHistoryFacade.getReplenishmentOrderHistoryListSuccess();
  }
  changeSortCode(sortCode) {
    const event = {
      sortCode,
      currentPage: 0
    };
    this.sortType = sortCode;
    this.fetchReplenishmentOrders(event);
  }
  pageChange(page) {
    const event = {
      sortCode: this.sortType,
      currentPage: page
    };
    this.fetchReplenishmentOrders(event);
  }
  goToOrderDetail(order) {
    this.routing.go({
      cxRoute: "replenishmentDetails",
      params: order
    });
  }
  getSortLabels() {
    return combineLatest([this.translation.translate("sorting.date"), this.translation.translate("sorting.replenishmentNumber"), this.translation.translate("sorting.nextOrderDate")]).pipe(map(([textByDate, textByOrderNumber, textbyNextOrderDate]) => {
      return {
        byDate: textByDate,
        byReplenishmentNumber: textByOrderNumber,
        byNextOrderDate: textbyNextOrderDate
      };
    }));
  }
  openDialog(event, replenishmentOrderCode) {
    const dialog = this.launchDialogService.openDialog("REPLENISHMENT_ORDER", this.element, this.vcr, replenishmentOrderCode);
    if (dialog) {
      this.subscription.add(dialog.pipe(take(1)).subscribe());
    }
    event.stopPropagation();
  }
  fetchReplenishmentOrders(event) {
    this.replenishmentOrderHistoryFacade.loadReplenishmentOrderList(this.PAGE_SIZE, event.currentPage, event.sortCode);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.replenishmentOrderHistoryFacade.clearReplenishmentOrderList();
  }
  static {
    this.ɵfac = function ReplenishmentOrderHistoryComponent_Factory(t) {
      return new (t || _ReplenishmentOrderHistoryComponent)(ɵɵdirectiveInject(RoutingService), ɵɵdirectiveInject(ReplenishmentOrderHistoryFacade), ɵɵdirectiveInject(TranslationService), ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(LaunchDialogService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReplenishmentOrderHistoryComponent,
      selectors: [["cx-replenishment-order-history"]],
      viewQuery: function ReplenishmentOrderHistoryComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c16, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
        }
      },
      decls: 2,
      vars: 3,
      consts: [["noOrder", ""], ["element", ""], [4, "ngIf"], [1, "container"], [1, "cx-replenishment-order-history-header"], [1, "cx-replenishment-order-history-body"], [4, "ngIf", "ngIfElse"], [1, "cx-replenishment-order-history-sort", "top", "row"], [1, "cx-replenishment-order-history-form-group", "form-group", "col-sm-12", "col-md-4", "col-lg-4"], ["ariaControls", "replenishment-order-history-table", 3, "sortListEvent", "sortOptions", "sortLabels", "selectedOption", "placeholder", "ariaLabel"], ["class", "cx-replenishment-order-history-pagination", 4, "ngIf"], ["id", "replenishment-order-history-table", "role", "table", 1, "table", "cx-replenishment-order-history-table"], [1, "cx-visually-hidden"], ["class", "cx-replenishment-order-history-thead-mobile", 4, "cxFeature"], ["role", "row", 3, "click", 4, "ngFor", "ngForOf"], [1, "cx-replenishment-order-history-sort", "bottom", "row"], [1, "cx-replenishment-order-history-pagination"], [3, "pagination", "viewPageEvent", 4, "ngIf"], [3, "viewPageEvent", "pagination"], [1, "cx-replenishment-order-history-thead-mobile"], ["scope", "col"], [1, "cx-replenishment-order-history-ellipses"], ["scope", "col", 1, "cx-replenishment-order-history-total"], ["role", "row", 3, "click"], ["role", "cell", 1, "cx-replenishment-order-history-code"], [1, "d-md-none", "cx-replenishment-order-history-label"], [1, "cx-replenishment-order-history-value", 3, "routerLink"], ["role", "cell"], [1, "cx-replenishment-order-history-value", "cx-purchase-order-number", 3, "routerLink"], ["role", "cell", 1, "cx-replenishment-order-history-frequency"], [1, "cx-replenishment-order-history-value", "cx-next-order-date", 3, "routerLink"], [1, "cx-replenishment-order-history-total"], ["role", "cell", 1, "cx-replenishment-order-history-cancel"], ["class", "cx-order-cancel btn btn-secondary", 3, "click", 4, "ngIf"], [1, "cx-order-cancel", "btn", "btn-secondary", 3, "click"], ["class", "cx-replenishment-order-history-no-order row", 4, "ngIf"], [1, "cx-replenishment-order-history-no-order", "row"], [1, "col-sm-12", "col-md-6", "col-lg-4"], ["routerLinkActive", "active", "cxBtnLikeLink", "", 1, "btn", "btn-primary", "btn-block", 3, "routerLink"]],
      template: function ReplenishmentOrderHistoryComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ReplenishmentOrderHistoryComponent_ng_container_0_Template, 10, 5, "ng-container", 2);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.replenishmentOrders$));
        }
      },
      dependencies: [NgForOf, NgIf, RouterLink, RouterLinkActive, SortingComponent, PaginationComponent, BtnLikeLinkDirective, FeatureDirective, AsyncPipe, SlicePipe, UrlPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderHistoryComponent, [{
    type: Component,
    args: [{
      selector: "cx-replenishment-order-history",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="replenishmentOrders$ | async as replenishmentOrders">
  <div class="container">
    <!-- HEADER -->
    <div class="cx-replenishment-order-history-header">
      <h3>
        {{ 'orderHistory.replenishmentOrderHistory' | cxTranslate }}
      </h3>
    </div>

    <!-- BODY -->
    <div class="cx-replenishment-order-history-body">
      <ng-container
        *ngIf="replenishmentOrders.pagination.totalResults > 0; else noOrder"
      >
        <!-- Select Form and Pagination Top -->
        <div class="cx-replenishment-order-history-sort top row">
          <label
            class="cx-replenishment-order-history-form-group form-group col-sm-12 col-md-4 col-lg-4"
          >
            <span>{{ 'orderHistory.sortBy' | cxTranslate }}</span>
            <cx-sorting
              [sortOptions]="replenishmentOrders.sorts"
              [sortLabels]="getSortLabels() | async"
              (sortListEvent)="changeSortCode($event)"
              [selectedOption]="replenishmentOrders.pagination.sort"
              placeholder="{{ 'orderHistory.sortBy' | cxTranslate }}"
              [ariaLabel]="'orderHistory.sortOrders' | cxTranslate"
              ariaControls="replenishment-order-history-table"
            ></cx-sorting>
          </label>
          <div
            class="cx-replenishment-order-history-pagination"
            *ngIf="replenishmentOrders.pagination.totalPages > 1"
          >
            <cx-pagination
              [pagination]="replenishmentOrders.pagination"
              (viewPageEvent)="pageChange($event)"
            ></cx-pagination>
          </div>
        </div>
        <!-- TABLE -->
        <table
          id="replenishment-order-history-table"
          class="table cx-replenishment-order-history-table"
          role="table"
        >
          <caption class="cx-visually-hidden">
            {{
              'orderHistory.orderHistory' | cxTranslate
            }}
          </caption>
          <thead
            *cxFeature="'!a11yTableHeaderReadout'"
            class="cx-replenishment-order-history-thead-mobile"
          >
            <th scope="col">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.replenishmentOrderId' | cxTranslate }}
              </span>
            </th>
            <th scope="col">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.purchaseOrderNumber' | cxTranslate }}
              </span>
            </th>
            <th scope="col">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.startOn' | cxTranslate }}
              </span>
            </th>
            <th scope="col">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.frequency' | cxTranslate }}
              </span>
            </th>
            <th scope="col">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.nextOrderDate' | cxTranslate }}
              </span>
            </th>
            <th scope="col" class="cx-replenishment-order-history-total">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.total' | cxTranslate }}
              </span>
            </th>
            <th scope="col">
              <span class="cx-replenishment-order-history-ellipses">
                {{ 'orderHistory.actions' | cxTranslate }}
              </span>
            </th>
          </thead>
          <thead
            *cxFeature="'a11yTableHeaderReadout'"
            class="cx-replenishment-order-history-thead-mobile"
          >
            <tr>
              <th scope="col">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.replenishmentOrderId' | cxTranslate }}
                </span>
              </th>
              <th scope="col">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.purchaseOrderNumber' | cxTranslate }}
                </span>
              </th>
              <th scope="col">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.startOn' | cxTranslate }}
                </span>
              </th>
              <th scope="col">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.frequency' | cxTranslate }}
                </span>
              </th>
              <th scope="col">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.nextOrderDate' | cxTranslate }}
                </span>
              </th>
              <th scope="col" class="cx-replenishment-order-history-total">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.total' | cxTranslate }}
                </span>
              </th>
              <th scope="col">
                <span class="cx-replenishment-order-history-ellipses">
                  {{ 'orderHistory.actions' | cxTranslate }}
                </span>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              role="row"
              *ngFor="let order of replenishmentOrders.replenishmentOrders"
              (click)="goToOrderDetail(order)"
            >
              <td class="cx-replenishment-order-history-code" role="cell">
                <div class="d-md-none cx-replenishment-order-history-label">
                  {{ 'orderHistory.replenishmentOrderId' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'replenishmentDetails',
                      params: order,
                    } | cxUrl
                  "
                  class="cx-replenishment-order-history-value"
                >
                  {{ order?.replenishmentOrderCode }}</a
                >
              </td>
              <td role="cell">
                <div class="d-md-none cx-replenishment-order-history-label">
                  {{ 'orderHistory.purchaseOrderNumber' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'replenishmentDetails',
                      params: order,
                    } | cxUrl
                  "
                  class="cx-replenishment-order-history-value cx-purchase-order-number"
                >
                  {{
                    order?.purchaseOrderNumber?.length > 0
                      ? order?.purchaseOrderNumber
                      : ('orderHistory.emptyPurchaseOrderId' | cxTranslate)
                  }}
                </a>
              </td>
              <td role="cell">
                <div class="d-md-none cx-replenishment-order-history-label">
                  {{ 'orderHistory.startOn' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'replenishmentDetails',
                      params: order,
                    } | cxUrl
                  "
                  class="cx-replenishment-order-history-value"
                >
                  {{ order?.firstDate | cxDate: 'M/d/yyyy' }}</a
                >
              </td>
              <td class="cx-replenishment-order-history-frequency" role="cell">
                <div class="d-md-none cx-replenishment-order-history-label">
                  {{ 'orderHistory.frequency' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'replenishmentDetails',
                      params: order,
                    } | cxUrl
                  "
                  class="cx-replenishment-order-history-value"
                >
                  {{ order?.trigger.displayTimeTable | slice: 0 : -12 }}
                </a>
              </td>
              <td role="cell">
                <div class="d-md-none cx-replenishment-order-history-label">
                  {{ 'orderHistory.nextOrderDate' | cxTranslate }}
                </div>

                <a
                  [routerLink]="
                    {
                      cxRoute: 'replenishmentDetails',
                      params: order,
                    } | cxUrl
                  "
                  class="cx-replenishment-order-history-value cx-next-order-date"
                >
                  {{
                    order?.active
                      ? (order?.trigger.activationTime | cxDate: 'M/d/yyyy')
                      : ('orderHistory.cancelled' | cxTranslate)
                  }}
                </a>
              </td>
              <td class="cx-replenishment-order-history-total">
                <div class="d-md-none cx-replenishment-order-history-label">
                  {{ 'orderHistory.total' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'replenishmentDetails',
                      params: order,
                    } | cxUrl
                  "
                  class="cx-replenishment-order-history-value"
                >
                  {{ order?.totalPriceWithTax.formattedValue }}</a
                >
              </td>
              <td class="cx-replenishment-order-history-cancel" role="cell">
                <div
                  class="d-md-none cx-replenishment-order-history-label"
                ></div>
                <button
                  (click)="openDialog($event, order?.replenishmentOrderCode)"
                  class="cx-order-cancel btn btn-secondary"
                  #element
                  *ngIf="order?.active"
                >
                  {{ 'orderHistory.cancel' | cxTranslate }}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- Select Form and Pagination Bottom -->
        <div class="cx-replenishment-order-history-sort bottom row">
          <div class="cx-replenishment-order-history-pagination">
            <cx-pagination
              [pagination]="replenishmentOrders.pagination"
              (viewPageEvent)="pageChange($event)"
              *ngIf="replenishmentOrders.pagination.totalPages > 1"
            ></cx-pagination>
          </div>
        </div>
      </ng-container>

      <!-- NO ORDER CONTAINER -->
      <ng-template #noOrder>
        <div
          class="cx-replenishment-order-history-no-order row"
          *ngIf="isLoaded$ | async"
        >
          <div class="col-sm-12 col-md-6 col-lg-4">
            <div>{{ 'orderHistory.noReplenishmentOrders' | cxTranslate }}</div>
            <a
              [routerLink]="{ cxRoute: 'home' } | cxUrl"
              routerLinkActive="active"
              class="btn btn-primary btn-block"
              cxBtnLikeLink
              >{{ 'orderHistory.startShopping' | cxTranslate }}</a
            >
          </div>
        </div>
      </ng-template>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: RoutingService
  }, {
    type: ReplenishmentOrderHistoryFacade
  }, {
    type: TranslationService
  }, {
    type: ViewContainerRef
  }, {
    type: LaunchDialogService
  }], {
    element: [{
      type: ViewChild,
      args: ["element"]
    }]
  });
})();
var ReplenishmentOrderHistoryModule = class _ReplenishmentOrderHistoryModule {
  static {
    this.ɵfac = function ReplenishmentOrderHistoryModule_Factory(t) {
      return new (t || _ReplenishmentOrderHistoryModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReplenishmentOrderHistoryModule,
      declarations: [ReplenishmentOrderHistoryComponent],
      imports: [CommonModule, RouterModule, ListNavigationModule, UrlModule, I18nModule, BtnLikeLinkModule, FeaturesConfigModule],
      exports: [ReplenishmentOrderHistoryComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultReplenishmentOrderCancellationLayoutConfig), provideDefaultConfig({
        cmsComponents: {
          AccountReplenishmentHistoryComponent: {
            component: ReplenishmentOrderHistoryComponent,
            guards: [AuthGuard]
          }
        }
      })],
      imports: [CommonModule, RouterModule, ListNavigationModule, UrlModule, I18nModule, BtnLikeLinkModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReplenishmentOrderHistoryModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, ListNavigationModule, UrlModule, I18nModule, BtnLikeLinkModule, FeaturesConfigModule],
      providers: [provideDefaultConfig(defaultReplenishmentOrderCancellationLayoutConfig), provideDefaultConfig({
        cmsComponents: {
          AccountReplenishmentHistoryComponent: {
            component: ReplenishmentOrderHistoryComponent,
            guards: [AuthGuard]
          }
        }
      })],
      declarations: [ReplenishmentOrderHistoryComponent],
      exports: [ReplenishmentOrderHistoryComponent]
    }]
  }], null, null);
})();
var ReturnRequestService = class _ReturnRequestService {
  constructor(routingService, returnRequestService, globalMessageService) {
    this.routingService = routingService;
    this.returnRequestService = returnRequestService;
    this.globalMessageService = globalMessageService;
  }
  get isCancelling$() {
    return this.returnRequestService.getCancelReturnRequestLoading();
  }
  get isCancelSuccess$() {
    return this.returnRequestService.getCancelReturnRequestSuccess();
  }
  getReturnRequest() {
    return combineLatest([this.routingService.getRouterState(), this.returnRequestService.getOrderReturnRequest(), this.returnRequestService.getReturnRequestLoading()]).pipe(map(([routingState, returnRequest, isLoading]) => [routingState.state.params["returnCode"], returnRequest, isLoading]), filter(([returnCode]) => Boolean(returnCode)), tap(([returnCode, returnRequest, isLoading]) => {
      if ((returnRequest === void 0 || returnRequest.rma !== returnCode) && !isLoading) {
        this.returnRequestService.loadOrderReturnRequestDetail(returnCode);
      }
    }), map(([_, returnRequest]) => returnRequest), filter((returnRequest) => Boolean(returnRequest)), distinctUntilChanged());
  }
  clearReturnRequest() {
    this.returnRequestService.clearOrderReturnRequestDetail();
  }
  cancelReturnRequest(returnRequestCode) {
    this.returnRequestService.cancelOrderReturnRequest(returnRequestCode, {
      status: "CANCELLING"
    });
  }
  cancelSuccess(rma) {
    this.returnRequestService.resetCancelReturnRequestProcessState();
    this.globalMessageService.add({
      key: "returnRequest.cancelSuccess",
      params: {
        rma
      }
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    this.routingService.go({
      cxRoute: "orders"
    });
  }
  backToList() {
    this.routingService.go({
      cxRoute: "orders"
    }, {
      state: {
        activeTab: 1
      }
    });
  }
  static {
    this.ɵfac = function ReturnRequestService_Factory(t) {
      return new (t || _ReturnRequestService)(ɵɵinject(RoutingService), ɵɵinject(OrderReturnRequestFacade), ɵɵinject(GlobalMessageService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ReturnRequestService,
      factory: _ReturnRequestService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnRequestService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: RoutingService
  }, {
    type: OrderReturnRequestFacade
  }, {
    type: GlobalMessageService
  }], null);
})();
var ReturnRequestItemsComponent = class _ReturnRequestItemsComponent {
  constructor(returnRequestService) {
    this.returnRequestService = returnRequestService;
    this.returnRequest$ = this.returnRequestService.getReturnRequest();
  }
  static {
    this.ɵfac = function ReturnRequestItemsComponent_Factory(t) {
      return new (t || _ReturnRequestItemsComponent)(ɵɵdirectiveInject(ReturnRequestService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReturnRequestItemsComponent,
      selectors: [["cx-return-request-items"]],
      decls: 2,
      vars: 3,
      consts: [["class", "cx-return-request-items", 4, "ngIf"], [1, "cx-return-request-items"], [1, "cx-visually-hidden"], ["role", "columnheader", 1, "cx-item-list-desc"], ["role", "columnheader", 1, "cx-item-list-price"], ["role", "columnheader", 1, "cx-item-list-qty"], ["role", "columnheader", 1, "cx-item-list-total"], [1, "cx-item-list-items"], ["class", "cx-item-list-row cx-return-request-item-row", 4, "ngFor", "ngForOf"], [1, "cx-item-list-row", "cx-return-request-item-row"], ["role", "cell"], [1, "cx-table-item-container"], ["format", "thumbnail", 3, "container"], [1, "cx-info"], ["class", "cx-name", 4, "ngIf"], ["class", "cx-code", 4, "ngIf"], ["class", "cx-property", 4, "ngFor", "ngForOf"], ["role", "cell", "class", "cx-price", 4, "ngIf"], ["role", "cell", 1, "cx-quantity"], [1, "cx-mobile-header"], [1, "cx-value"], ["role", "cell", 1, "cx-total"], [1, "cx-name"], [1, "cx-code"], [1, "cx-property"], ["class", "cx-label", 4, "ngIf"], ["class", "cx-value", 4, "ngIf"], [1, "cx-label"], ["role", "cell", 1, "cx-price"]],
      template: function ReturnRequestItemsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ReturnRequestItemsComponent_table_0_Template, 20, 16, "table", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.returnRequest$));
        }
      },
      dependencies: [NgForOf, NgIf, MediaComponent, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnRequestItemsComponent, [{
    type: Component,
    args: [{
      selector: "cx-return-request-items",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<table
  class="cx-return-request-items"
  *ngIf="returnRequest$ | async as returnRequest"
>
  <caption class="cx-visually-hidden">
    {{
      'returnRequest.caption' | cxTranslate
    }}
  </caption>
  <thead>
    <tr>
      <th role="columnheader" class="cx-item-list-desc">
        {{ 'returnRequest.item' | cxTranslate }}
      </th>
      <th role="columnheader" class="cx-item-list-price">
        {{ 'returnRequest.itemPrice' | cxTranslate }}
      </th>
      <th role="columnheader" class="cx-item-list-qty">
        {{ 'returnRequest.returnQty' | cxTranslate }}
      </th>
      <th role="columnheader" class="cx-item-list-total">
        {{ 'returnRequest.total' | cxTranslate }}
      </th>
    </tr>
  </thead>

  <tbody class="cx-item-list-items">
    <!-- TODO: This should be a separate component-->
    <tr
      class="cx-item-list-row cx-return-request-item-row"
      *ngFor="let returnEntry of returnRequest.returnEntries; let i = index"
    >
      <td role="cell">
        <!-- Item Image -->
        <div class="cx-table-item-container">
          <cx-media
            [container]="returnEntry.orderEntry?.product.images?.PRIMARY"
            format="thumbnail"
          ></cx-media>
          <!-- Item Description -->
          <div class="cx-info">
            <div *ngIf="returnEntry.orderEntry?.product.name" class="cx-name">
              {{ returnEntry.orderEntry?.product.name }}
            </div>
            <div *ngIf="returnEntry.orderEntry?.product.code" class="cx-code">
              {{ 'cartItems.id' | cxTranslate }}
              {{ returnEntry.orderEntry?.product.code }}
            </div>
            <!-- Variants -->
            <div
              *ngFor="
                let variant of (returnEntry.orderEntry?.product.baseOptions)[0]
                  ?.selected?.variantOptionQualifiers
              "
              class="cx-property"
            >
              <div class="cx-label" *ngIf="variant.name">
                {{ variant.name }}:
              </div>
              <div class="cx-value" *ngIf="variant.value">
                {{ variant.value }}
              </div>
            </div>
          </div>
        </div>
      </td>
      <!-- Item Price -->
      <td
        role="cell"
        class="cx-price"
        *ngIf="returnEntry.orderEntry?.basePrice"
      >
        <div class="cx-mobile-header">
          {{ 'returnRequest.itemPrice' | cxTranslate }}
        </div>
        <div class="cx-value">
          {{ returnEntry.orderEntry?.basePrice?.formattedValue }}
        </div>
      </td>
      <!-- return Quantity -->
      <td role="cell" class="cx-quantity">
        <div class="cx-mobile-header">
          {{ 'returnRequest.returnQty' | cxTranslate }}
        </div>
        <div class="cx-value">
          {{ returnEntry.expectedQuantity }}
        </div>
      </td>
      <!-- Total Price -->
      <td role="cell" class="cx-total">
        <div class="cx-mobile-header">
          {{ 'returnRequest.total' | cxTranslate }}
        </div>
        <div class="cx-value">
          {{ returnEntry.refundAmount?.formattedValue }}
        </div>
      </td>
    </tr>
  </tbody>
</table>
`
    }]
  }], () => [{
    type: ReturnRequestService
  }], null);
})();
var ReturnRequestOverviewComponent = class _ReturnRequestOverviewComponent {
  constructor(returnRequestService) {
    this.returnRequestService = returnRequestService;
    this.returnRequest$ = this.returnRequestService.getReturnRequest().pipe(tap((returnRequest) => this.rma = returnRequest.rma ?? ""));
    this.isCancelling$ = this.returnRequestService.isCancelling$;
  }
  ngOnInit() {
    this.subscription = this.returnRequestService.isCancelSuccess$.subscribe((success) => {
      if (success) {
        this.returnRequestService.cancelSuccess(this.rma);
      }
    });
  }
  cancelReturn(returnRequestCode) {
    this.returnRequestService.cancelReturnRequest(returnRequestCode);
  }
  back() {
    this.returnRequestService.backToList();
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  static {
    this.ɵfac = function ReturnRequestOverviewComponent_Factory(t) {
      return new (t || _ReturnRequestOverviewComponent)(ɵɵdirectiveInject(ReturnRequestService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReturnRequestOverviewComponent,
      selectors: [["cx-return-request-overview"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "cx-nav", "row"], [1, "col-xs-12", "col-md-4", "col-lg-3"], [1, "btn", "btn-block", "btn-secondary", 3, "click"], ["class", "btn btn-block btn-primary", 3, "disabled", "click", 4, "ngIf"], [1, "cx-header", "row"], [1, "cx-detail", "col-sm-12", "col-md-4"], [1, "cx-detail-label"], [1, "cx-detail-value"], [1, "btn", "btn-block", "btn-primary", 3, "click", "disabled"]],
      template: function ReturnRequestOverviewComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ReturnRequestOverviewComponent_ng_container_0_Template, 28, 18, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.returnRequest$));
        }
      },
      dependencies: [NgIf, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnRequestOverviewComponent, [{
    type: Component,
    args: [{
      selector: "cx-return-request-overview",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="returnRequest$ | async as returnRequest">
  <div class="cx-nav row">
    <div class="col-xs-12 col-md-4 col-lg-3">
      <button (click)="back()" class="btn btn-block btn-secondary">
        {{ 'common.back' | cxTranslate }}
      </button>
    </div>

    <div class="col-xs-12 col-md-4 col-lg-3">
      <button
        *ngIf="returnRequest.cancellable"
        class="btn btn-block btn-primary"
        (click)="cancelReturn(returnRequest.rma)"
        [disabled]="isCancelling$ | async"
      >
        {{ 'returnRequest.cancel' | cxTranslate }}
      </button>
    </div>
  </div>
  <div class="cx-header row">
    <div class="cx-detail col-sm-12 col-md-4">
      <div class="cx-detail-label">
        {{ 'returnRequest.returnRequestId' | cxTranslate }}
      </div>
      <div class="cx-detail-value">{{ returnRequest.rma }}</div>
    </div>
    <div class="cx-detail col-sm-12 col-md-4">
      <div class="cx-detail-label">
        {{ 'returnRequest.orderCode' | cxTranslate }}
      </div>
      <div class="cx-detail-value">{{ returnRequest.order?.code }}</div>
    </div>
    <div class="cx-detail col-sm-12 col-md-4">
      <div class="cx-detail-label">
        {{ 'returnRequest.status' | cxTranslate }}
      </div>
      <div class="cx-detail-value">
        {{
          'returnRequestList.statusDisplay_' + returnRequest?.status
            | cxTranslate
        }}
      </div>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: ReturnRequestService
  }], null);
})();
var ReturnRequestTotalsComponent = class _ReturnRequestTotalsComponent {
  constructor(returnRequestService) {
    this.returnRequestService = returnRequestService;
    this.returnRequest$ = this.returnRequestService.getReturnRequest();
  }
  ngOnDestroy() {
    this.returnRequestService.clearReturnRequest();
  }
  static {
    this.ɵfac = function ReturnRequestTotalsComponent_Factory(t) {
      return new (t || _ReturnRequestTotalsComponent)(ɵɵdirectiveInject(ReturnRequestService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ReturnRequestTotalsComponent,
      selectors: [["cx-return-request-totals"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "row", "justify-content-end"], [1, "cx-summary", "col-sm-12", "col-md-6", "col-lg-5", "col-xl-4"], [1, "cx-summary-row"], [1, "col-6", "cx-summary-label"], [1, "col-6", "cx-summary-amount"], [1, "cx-summary-row", "cx-summary-total"], [1, "cx-summary-row", "cx-footnote"]],
      template: function ReturnRequestTotalsComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, ReturnRequestTotalsComponent_ng_container_0_Template, 27, 18, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.returnRequest$));
        }
      },
      dependencies: [NgIf, AsyncPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnRequestTotalsComponent, [{
    type: Component,
    args: [{
      selector: "cx-return-request-totals",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="returnRequest$ | async as returnRequest">
  <div class="row justify-content-end">
    <div class="cx-summary col-sm-12 col-md-6 col-lg-5 col-xl-4">
      <h4>{{ 'returnRequest.summary' | cxTranslate }}</h4>
      <div class="cx-summary-row">
        <div class="col-6 cx-summary-label">
          {{ 'returnRequest.subtotal' | cxTranslate }}
        </div>
        <div class="col-6 cx-summary-amount">
          {{ returnRequest.subTotal?.formattedValue }}
        </div>
      </div>
      <div class="cx-summary-row">
        <div class="col-6 cx-summary-label">
          {{ 'returnRequest.deliveryCode' | cxTranslate }}
        </div>
        <div class="col-6 cx-summary-amount">
          {{ returnRequest.deliveryCost?.formattedValue }}
        </div>
      </div>
      <div class="cx-summary-row cx-summary-total">
        <div class="col-6 cx-summary-label">
          {{ 'returnRequest.estimatedRefund' | cxTranslate }}
        </div>
        <div class="col-6 cx-summary-amount">
          {{ returnRequest.totalPrice?.formattedValue }}
        </div>
      </div>
      <div class="cx-summary-row cx-footnote">
        {{ 'returnRequest.note' | cxTranslate }}
      </div>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: ReturnRequestService
  }], null);
})();
var components = [ReturnRequestOverviewComponent, ReturnRequestItemsComponent, ReturnRequestTotalsComponent];
var ReturnRequestDetailModule = class _ReturnRequestDetailModule {
  static {
    this.ɵfac = function ReturnRequestDetailModule_Factory(t) {
      return new (t || _ReturnRequestDetailModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReturnRequestDetailModule,
      declarations: [ReturnRequestOverviewComponent, ReturnRequestItemsComponent, ReturnRequestTotalsComponent],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, MediaModule],
      exports: [ReturnRequestOverviewComponent, ReturnRequestItemsComponent, ReturnRequestTotalsComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturnRequestOverviewComponent: {
            component: ReturnRequestOverviewComponent
          },
          ReturnRequestItemsComponent: {
            component: ReturnRequestItemsComponent
          },
          ReturnRequestTotalsComponent: {
            component: ReturnRequestTotalsComponent
          }
        }
      })],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, MediaModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnRequestDetailModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, UrlModule, I18nModule, MediaModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturnRequestOverviewComponent: {
            component: ReturnRequestOverviewComponent
          },
          ReturnRequestItemsComponent: {
            component: ReturnRequestItemsComponent
          },
          ReturnRequestTotalsComponent: {
            component: ReturnRequestTotalsComponent
          }
        }
      })],
      declarations: [...components],
      exports: [...components]
    }]
  }], null, null);
})();
var OrderReturnRequestListComponent = class _OrderReturnRequestListComponent {
  constructor(returnRequestService, translation) {
    this.returnRequestService = returnRequestService;
    this.translation = translation;
    this.PAGE_SIZE = 5;
    this.returnRequests$ = this.returnRequestService.getOrderReturnRequestList(this.PAGE_SIZE).pipe(tap((requestList) => {
      if (requestList?.pagination?.sort) {
        this.sortType = requestList.pagination.sort;
      }
    }));
    this.tabTitleParam$ = this.returnRequests$.pipe(map((returnRequests) => returnRequests?.pagination?.totalResults), filter(isNotUndefined), take(1));
  }
  ngOnDestroy() {
    this.returnRequestService.clearOrderReturnRequestList();
  }
  changeSortCode(sortCode) {
    const event = {
      sortCode,
      currentPage: 0
    };
    this.sortType = sortCode;
    this.fetchReturnRequests(event);
  }
  pageChange(page) {
    const event = {
      sortCode: this.sortType,
      currentPage: page
    };
    this.fetchReturnRequests(event);
  }
  getSortLabels() {
    return combineLatest([this.translation.translate("sorting.date"), this.translation.translate("sorting.rma")]).pipe(map(([textByDate, textByRma]) => {
      return {
        byDate: textByDate,
        byRMA: textByRma
      };
    }));
  }
  fetchReturnRequests(event) {
    this.returnRequestService.loadOrderReturnRequestList(this.PAGE_SIZE, event.currentPage, event.sortCode);
  }
  static {
    this.ɵfac = function OrderReturnRequestListComponent_Factory(t) {
      return new (t || _OrderReturnRequestListComponent)(ɵɵdirectiveInject(OrderReturnRequestFacade), ɵɵdirectiveInject(TranslationService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OrderReturnRequestListComponent,
      selectors: [["cx-order-return-request-list"]],
      decls: 2,
      vars: 3,
      consts: [[4, "ngIf"], [1, "container"], [1, "cx-order-history-body"], [1, "cx-order-history-sort", "top"], [1, "cx-order-history-form-group", "form-group"], ["ariaControls", "order-return-table", 3, "sortListEvent", "sortOptions", "sortLabels", "selectedOption", "ariaLabel"], [1, "cx-order-history-pagination"], [3, "viewPageEvent", "pagination"], ["id", "order-return-table", 1, "table", "cx-order-history-table"], ["class", "cx-order-history-thead-mobile", 4, "cxFeature"], [4, "ngFor", "ngForOf"], [1, "cx-order-history-sort", "bottom"], [1, "cx-order-history-thead-mobile"], ["scope", "col"], [1, "cx-order-history-code"], [1, "cx-order-history-label"], [1, "cx-order-history-value", 3, "routerLink"], [1, "cx-order-history-placed"], [1, "cx-order-history-status"]],
      template: function OrderReturnRequestListComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, OrderReturnRequestListComponent_ng_container_0_Template, 4, 1, "ng-container", 0);
          ɵɵpipe(1, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 1, ctx.returnRequests$));
        }
      },
      dependencies: [NgForOf, NgIf, RouterLink, SortingComponent, PaginationComponent, FeatureDirective, AsyncPipe, UrlPipe, TranslatePipe, CxDatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderReturnRequestListComponent, [{
    type: Component,
    args: [{
      selector: "cx-order-return-request-list",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<ng-container *ngIf="returnRequests$ | async as returnRequests">
  <div class="container">
    <!-- BODY -->
    <div class="cx-order-history-body">
      <ng-container *ngIf="returnRequests.pagination.totalResults > 0">
        <!-- Select Form and Pagination Top -->
        <div class="cx-order-history-sort top">
          <label class="cx-order-history-form-group form-group"
            ><span>{{ 'returnRequestList.sortBy' | cxTranslate }}</span>
            <cx-sorting
              [sortOptions]="returnRequests.sorts"
              [sortLabels]="getSortLabels() | async"
              (sortListEvent)="changeSortCode($event)"
              [selectedOption]="returnRequests.pagination.sort"
              [ariaLabel]="'returnRequestList.sortReturns' | cxTranslate"
              ariaControls="order-return-table"
            ></cx-sorting>
          </label>
          <div class="cx-order-history-pagination">
            <cx-pagination
              [pagination]="returnRequests.pagination"
              (viewPageEvent)="pageChange($event)"
            ></cx-pagination>
          </div>
        </div>
        <!-- TABLE -->
        <table id="order-return-table" class="table cx-order-history-table">
          <thead
            *cxFeature="'!a11yTableHeaderReadout'"
            class="cx-order-history-thead-mobile"
          >
            <th scope="col">
              {{ 'returnRequestList.returnRequestId' | cxTranslate }}
            </th>
            <th scope="col">{{ 'returnRequestList.orderId' | cxTranslate }}</th>
            <th scope="col">
              {{ 'returnRequestList.date' | cxTranslate }}
            </th>
            <th scope="col">{{ 'returnRequestList.status' | cxTranslate }}</th>
          </thead>
          <thead
            *cxFeature="'a11yTableHeaderReadout'"
            class="cx-order-history-thead-mobile"
          >
            <tr>
              <th scope="col">
                {{ 'returnRequestList.returnRequestId' | cxTranslate }}
              </th>
              <th scope="col">
                {{ 'returnRequestList.orderId' | cxTranslate }}
              </th>
              <th scope="col">
                {{ 'returnRequestList.date' | cxTranslate }}
              </th>
              <th scope="col">
                {{ 'returnRequestList.status' | cxTranslate }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let return of returnRequests.returnRequests">
              <td class="cx-order-history-code">
                <div class="cx-order-history-label">
                  {{ 'returnRequestList.returnRequestId' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'returnRequestDetails',
                      params: return,
                    } | cxUrl
                  "
                  class="cx-order-history-value"
                >
                  {{ return?.rma }}</a
                >
              </td>
              <td class="cx-order-history-code">
                <div class="cx-order-history-label">
                  {{ 'returnRequestList.orderId' | cxTranslate }}
                </div>
                <a
                  [routerLink]="
                    {
                      cxRoute: 'orderDetails',
                      params: return?.order,
                    } | cxUrl
                  "
                  class="cx-order-history-value"
                >
                  {{ return?.order?.code }}</a
                >
              </td>

              <td class="cx-order-history-placed">
                <div class="cx-order-history-label">
                  {{ 'returnRequestList.date' | cxTranslate }}
                </div>
                {{ return?.creationTime | cxDate: 'longDate' }}
              </td>
              <td class="cx-order-history-status">
                <div class="cx-order-history-label">
                  {{ 'returnRequestList.status' | cxTranslate }}
                </div>
                {{
                  'returnRequestList.statusDisplay_' + return?.status
                    | cxTranslate
                }}
              </td>
            </tr>
          </tbody>
        </table>
        <!-- Select Form and Pagination Bottom -->
        <div class="cx-order-history-sort bottom">
          <label class="cx-order-history-form-group form-group"
            ><span>{{ 'returnRequestList.sortBy' | cxTranslate }}</span>
            <cx-sorting
              [sortOptions]="returnRequests.sorts"
              [sortLabels]="getSortLabels() | async"
              (sortListEvent)="changeSortCode($event)"
              [selectedOption]="returnRequests.pagination.sort"
              [ariaLabel]="'returnRequestList.sortReturns' | cxTranslate"
              ariaControls="order-return-table"
            ></cx-sorting>
          </label>
          <div class="cx-order-history-pagination">
            <cx-pagination
              [pagination]="returnRequests.pagination"
              (viewPageEvent)="pageChange($event)"
            ></cx-pagination>
          </div>
        </div>
      </ng-container>
    </div>
  </div>
</ng-container>
`
    }]
  }], () => [{
    type: OrderReturnRequestFacade
  }, {
    type: TranslationService
  }], null);
})();
var ReturnRequestListModule = class _ReturnRequestListModule {
  static {
    this.ɵfac = function ReturnRequestListModule_Factory(t) {
      return new (t || _ReturnRequestListModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ReturnRequestListModule,
      declarations: [OrderReturnRequestListComponent],
      imports: [CommonModule, RouterModule, ListNavigationModule, UrlModule, I18nModule, FeaturesConfigModule],
      exports: [OrderReturnRequestListComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          OrderReturnRequestListComponent: {
            component: OrderReturnRequestListComponent,
            guards: [AuthGuard]
          }
        }
      })],
      imports: [CommonModule, RouterModule, ListNavigationModule, UrlModule, I18nModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReturnRequestListModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, ListNavigationModule, UrlModule, I18nModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          OrderReturnRequestListComponent: {
            component: OrderReturnRequestListComponent,
            guards: [AuthGuard]
          }
        }
      })],
      declarations: [OrderReturnRequestListComponent],
      exports: [OrderReturnRequestListComponent]
    }]
  }], null, null);
})();
var OrderComponentsModule = class _OrderComponentsModule {
  static {
    this.ɵfac = function OrderComponentsModule_Factory(t) {
      return new (t || _OrderComponentsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderComponentsModule,
      imports: [OrderHistoryModule, OrderDetailsModule, ReplenishmentOrderDetailsModule, OrderCancellationModule, OrderReturnModule, ReplenishmentOrderHistoryModule, ReturnRequestListModule, ReturnRequestDetailModule, OrderConfirmationModule, MyAccountV2OrdersModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [{
        provide: OrderDetailsOrderEntriesContextToken,
        useExisting: OrderDetailsOrderEntriesContext
      }],
      imports: [OrderHistoryModule, OrderDetailsModule, ReplenishmentOrderDetailsModule, OrderCancellationModule, OrderReturnModule, ReplenishmentOrderHistoryModule, ReturnRequestListModule, ReturnRequestDetailModule, OrderConfirmationModule, MyAccountV2OrdersModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderComponentsModule, [{
    type: NgModule,
    args: [{
      imports: [OrderHistoryModule, OrderDetailsModule, ReplenishmentOrderDetailsModule, OrderCancellationModule, OrderReturnModule, ReplenishmentOrderHistoryModule, ReturnRequestListModule, ReturnRequestDetailModule, OrderConfirmationModule, MyAccountV2OrdersModule],
      providers: [{
        provide: OrderDetailsOrderEntriesContextToken,
        useExisting: OrderDetailsOrderEntriesContext
      }]
    }]
  }], null, null);
})();

// node_modules/@spartacus/order/fesm2022/spartacus-order-occ.mjs
var OccOrderNormalizer = class _OccOrderNormalizer {
  constructor(converter) {
    this.converter = converter;
  }
  convert(source, target) {
    if (target === void 0) {
      target = __spreadValues({}, source);
    }
    if (source.entries) {
      target.entries = source.entries.map((entry) => this.convertOrderEntry(entry, source.code, source.appliedProductPromotions));
    }
    if (source.consignments) {
      target.consignments = source.consignments.map((consignment) => __spreadProps(__spreadValues({}, consignment), {
        entries: consignment.entries?.map((entry) => __spreadProps(__spreadValues({}, entry), {
          orderEntry: this.convertOrderEntry(entry.orderEntry, source.code, source.appliedProductPromotions)
        }))
      }));
    }
    if (source.unconsignedEntries) {
      target.unconsignedEntries = source.unconsignedEntries.map((entry) => this.convertOrderEntry(entry, source.code, source.appliedProductPromotions));
    }
    return target;
  }
  convertOrderEntry(source, code, promotions) {
    return __spreadProps(__spreadValues({}, source), {
      product: this.converter.convert(source?.product, PRODUCT_NORMALIZER),
      orderCode: code,
      promotions: this.converter.convert({
        item: source,
        promotions
      }, ORDER_ENTRY_PROMOTIONS_NORMALIZER)
    });
  }
  static {
    this.ɵfac = function OccOrderNormalizer_Factory(t) {
      return new (t || _OccOrderNormalizer)(ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccOrderNormalizer,
      factory: _OccOrderNormalizer.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccOrderNormalizer, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: ConverterService
  }], null);
})();
var OccReplenishmentOrderNormalizer = class _OccReplenishmentOrderNormalizer {
  constructor(converter) {
    this.converter = converter;
  }
  convert(source, target) {
    if (target === void 0) {
      target = __spreadValues({}, source);
    }
    if (source.entries) {
      target.entries = source.entries.map((entry) => __spreadProps(__spreadValues({}, entry), {
        product: this.converter.convert(entry.product, PRODUCT_NORMALIZER),
        promotions: this.converter.convert({
          item: entry,
          promotions: source.appliedProductPromotions
        }, ORDER_ENTRY_PROMOTIONS_NORMALIZER)
      }));
    }
    return target;
  }
  static {
    this.ɵfac = function OccReplenishmentOrderNormalizer_Factory(t) {
      return new (t || _OccReplenishmentOrderNormalizer)(ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccReplenishmentOrderNormalizer,
      factory: _OccReplenishmentOrderNormalizer.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccReplenishmentOrderNormalizer, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: ConverterService
  }], null);
})();
var OccReturnRequestNormalizer = class _OccReturnRequestNormalizer {
  constructor(converter) {
    this.converter = converter;
  }
  convert(source, target) {
    if (target === void 0) {
      target = __spreadValues({}, source);
    }
    if (source.returnEntries) {
      target.returnEntries = source.returnEntries.map((entry) => __spreadProps(__spreadValues({}, entry), {
        orderEntry: this.convertOrderEntry(entry.orderEntry)
      }));
    }
    return target;
  }
  convertOrderEntry(source) {
    return __spreadProps(__spreadValues({}, source), {
      product: this.converter.convert(source?.product, PRODUCT_NORMALIZER)
    });
  }
  static {
    this.ɵfac = function OccReturnRequestNormalizer_Factory(t) {
      return new (t || _OccReturnRequestNormalizer)(ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccReturnRequestNormalizer,
      factory: _OccReturnRequestNormalizer.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccReturnRequestNormalizer, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{
    type: ConverterService
  }], null);
})();
var OccScheduledReplenishmentOrderFormSerializer = class _OccScheduledReplenishmentOrderFormSerializer {
  convert(source, target) {
    if (target === void 0) {
      target = __spreadValues({}, source);
    }
    if (source.replenishmentStartDate) {
      target.replenishmentStartDate = this.convertDate(source.replenishmentStartDate);
    }
    return target;
  }
  /**
   * Adds the current timestamp (including timezone offset) to a date string in the format YYYY-mm-dd
   * @Example
   * Converts 2021-10-15 to 2021-10-15T15:38:05-05:00
   */
  convertDate(date) {
    const localTime = (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    });
    return `${date}T${localTime}:00${TimeUtils.getLocalTimezoneOffset()}`;
  }
  static {
    this.ɵfac = function OccScheduledReplenishmentOrderFormSerializer_Factory(t) {
      return new (t || _OccScheduledReplenishmentOrderFormSerializer)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccScheduledReplenishmentOrderFormSerializer,
      factory: _OccScheduledReplenishmentOrderFormSerializer.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccScheduledReplenishmentOrderFormSerializer, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var CONTENT_TYPE_JSON_HEADER = {
  "Content-Type": "application/json"
};
var OccOrderHistoryAdapter = class _OccOrderHistoryAdapter {
  constructor(http, occEndpoints, converter) {
    this.http = http;
    this.occEndpoints = occEndpoints;
    this.converter = converter;
    this.logger = inject(LoggerService);
  }
  load(userId, orderCode) {
    const url = this.occEndpoints.buildUrl("orderDetail", {
      urlParams: {
        userId,
        orderId: orderCode
      }
    });
    let headers = new HttpHeaders();
    if (userId === OCC_USER_ID_ANONYMOUS) {
      headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
    }
    return this.http.get(url, {
      headers
    }).pipe(this.converter.pipeable(ORDER_NORMALIZER));
  }
  loadHistory(userId, pageSize, currentPage, sort) {
    const params = {};
    if (pageSize) {
      params["pageSize"] = pageSize.toString();
    }
    if (currentPage) {
      params["currentPage"] = currentPage.toString();
    }
    if (sort) {
      params["sort"] = sort.toString();
    }
    const url = this.occEndpoints.buildUrl("orderHistory", {
      urlParams: {
        userId
      },
      queryParams: params
    });
    return this.http.get(url).pipe(this.converter.pipeable(ORDER_HISTORY_NORMALIZER));
  }
  getConsignmentTracking(orderCode, consignmentCode, userId = OCC_USER_ID_CURRENT) {
    const url = this.occEndpoints.buildUrl("consignmentTracking", {
      urlParams: {
        userId,
        orderCode,
        consignmentCode
      }
    });
    return this.http.get(url).pipe(this.converter.pipeable(CONSIGNMENT_TRACKING_NORMALIZER));
  }
  cancel(userId, orderCode, cancelRequestInput) {
    const url = this.occEndpoints.buildUrl("cancelOrder", {
      urlParams: {
        userId,
        orderId: orderCode
      }
    });
    const headers = new HttpHeaders(__spreadValues({}, CONTENT_TYPE_JSON_HEADER));
    return this.http.post(url, cancelRequestInput, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }));
  }
  createReturnRequest(userId, returnRequestInput) {
    const url = this.occEndpoints.buildUrl("returnOrder", {
      urlParams: {
        userId
      }
    });
    const headers = new HttpHeaders(__spreadValues({}, CONTENT_TYPE_JSON_HEADER));
    returnRequestInput = this.converter.convert(returnRequestInput, ORDER_RETURN_REQUEST_INPUT_SERIALIZER);
    return this.http.post(url, returnRequestInput, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), this.converter.pipeable(ORDER_RETURN_REQUEST_NORMALIZER));
  }
  loadReturnRequestList(userId, pageSize, currentPage, sort) {
    const params = {};
    if (pageSize) {
      params["pageSize"] = pageSize.toString();
    }
    if (currentPage) {
      params["currentPage"] = currentPage.toString();
    }
    if (sort) {
      params["sort"] = sort.toString();
    }
    const url = this.occEndpoints.buildUrl("orderReturns", {
      urlParams: {
        userId
      },
      queryParams: params
    });
    return this.http.get(url).pipe(this.converter.pipeable(ORDER_RETURNS_NORMALIZER));
  }
  loadReturnRequestDetail(userId, returnRequestCode) {
    const url = this.occEndpoints.buildUrl("orderReturnDetail", {
      urlParams: {
        userId,
        returnRequestCode
      }
    });
    return this.http.get(url).pipe(this.converter.pipeable(ORDER_RETURN_REQUEST_NORMALIZER));
  }
  cancelReturnRequest(userId, returnRequestCode, returnRequestModification) {
    const url = this.occEndpoints.buildUrl("cancelReturn", {
      urlParams: {
        userId,
        returnRequestCode
      }
    });
    const headers = new HttpHeaders(__spreadValues({}, CONTENT_TYPE_JSON_HEADER));
    return this.http.patch(url, returnRequestModification, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }));
  }
  static {
    this.ɵfac = function OccOrderHistoryAdapter_Factory(t) {
      return new (t || _OccOrderHistoryAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccOrderHistoryAdapter,
      factory: _OccOrderHistoryAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccOrderHistoryAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var OccOrderAdapter = class _OccOrderAdapter {
  constructor(http, occEndpoints, converter) {
    this.http = http;
    this.occEndpoints = occEndpoints;
    this.converter = converter;
    this.logger = inject(LoggerService);
  }
  placeOrder(userId, cartId, termsChecked) {
    let headers = new HttpHeaders({
      "Content-Type": "application/x-www-form-urlencoded"
    });
    if (userId === OCC_USER_ID_ANONYMOUS) {
      headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
    }
    return this.http.post(this.getPlaceOrderEndpoint(userId, cartId, termsChecked.toString()), {}, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), backOff({
      shouldRetry: isJaloError
    }), this.converter.pipeable(ORDER_NORMALIZER));
  }
  placePaymentAuthorizedOrder(userId, cartId, termsChecked) {
    let headers = new HttpHeaders({
      "Content-Type": "application/x-www-form-urlencoded"
    });
    if (userId === OCC_USER_ID_ANONYMOUS) {
      headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
    }
    return this.http.post(this.getPlacePaymentAuthorizedOrderEndpoint(userId, cartId, termsChecked.toString()), {}, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), backOff({
      shouldRetry: isJaloError
    }), backOff({
      shouldRetry: isServerError,
      maxTries: DEFAULT_SERVER_ERROR_RETRIES_COUNT
    }), this.converter.pipeable(ORDER_NORMALIZER));
  }
  getPlaceOrderEndpoint(userId, cartId, termsChecked) {
    return this.occEndpoints.buildUrl("placeOrder", {
      urlParams: {
        userId
      },
      queryParams: {
        cartId,
        termsChecked
      }
    });
  }
  getPlacePaymentAuthorizedOrderEndpoint(userId, cartId, termsChecked) {
    return this.occEndpoints.buildUrl("placePaymentAuthorizedOrder", {
      urlParams: {
        userId
      },
      queryParams: {
        cartId,
        termsChecked
      }
    });
  }
  static {
    this.ɵfac = function OccOrderAdapter_Factory(t) {
      return new (t || _OccOrderAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccOrderAdapter,
      factory: _OccOrderAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccOrderAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var OccReplenishmentOrderHistoryAdapter = class _OccReplenishmentOrderHistoryAdapter {
  constructor(http, occEndpoints, converter) {
    this.http = http;
    this.occEndpoints = occEndpoints;
    this.converter = converter;
  }
  load(userId, replenishmentOrderCode) {
    return this.http.get(this.occEndpoints.buildUrl("replenishmentOrderDetails", {
      urlParams: {
        userId,
        replenishmentOrderCode
      }
    })).pipe(this.converter.pipeable(REPLENISHMENT_ORDER_NORMALIZER));
  }
  loadReplenishmentDetailsHistory(userId, replenishmentOrderCode, pageSize, currentPage, sort) {
    const params = {};
    if (pageSize) {
      params["pageSize"] = pageSize.toString();
    }
    if (currentPage) {
      params["currentPage"] = currentPage.toString();
    }
    if (sort) {
      params["sort"] = sort.toString();
    }
    return this.http.get(this.occEndpoints.buildUrl("replenishmentOrderDetailsHistory", {
      urlParams: {
        userId,
        replenishmentOrderCode
      },
      queryParams: params
    })).pipe(this.converter.pipeable(ORDER_HISTORY_NORMALIZER));
  }
  cancelReplenishmentOrder(userId, replenishmentOrderCode) {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    return this.http.patch(this.occEndpoints.buildUrl("cancelReplenishmentOrder", {
      urlParams: {
        userId,
        replenishmentOrderCode
      }
    }), {}, {
      headers
    }).pipe(this.converter.pipeable(REPLENISHMENT_ORDER_NORMALIZER));
  }
  loadHistory(userId, pageSize, currentPage, sort) {
    const params = {};
    if (pageSize) {
      params["pageSize"] = pageSize.toString();
    }
    if (currentPage) {
      params["currentPage"] = currentPage.toString();
    }
    if (sort) {
      params["sort"] = sort.toString();
    }
    const url = this.occEndpoints.buildUrl("replenishmentOrderHistory", {
      urlParams: {
        userId
      },
      queryParams: params
    });
    return this.http.get(url).pipe(this.converter.pipeable(REPLENISHMENT_ORDER_HISTORY_NORMALIZER));
  }
  static {
    this.ɵfac = function OccReplenishmentOrderHistoryAdapter_Factory(t) {
      return new (t || _OccReplenishmentOrderHistoryAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccReplenishmentOrderHistoryAdapter,
      factory: _OccReplenishmentOrderHistoryAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccReplenishmentOrderHistoryAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var OccScheduledReplenishmentOrderAdapter = class _OccScheduledReplenishmentOrderAdapter {
  constructor(http, occEndpoints, converter) {
    this.http = http;
    this.occEndpoints = occEndpoints;
    this.converter = converter;
    this.logger = inject(LoggerService);
  }
  scheduleReplenishmentOrder(cartId, scheduleReplenishmentForm, termsChecked, userId) {
    scheduleReplenishmentForm = this.converter.convert(scheduleReplenishmentForm, REPLENISHMENT_ORDER_FORM_SERIALIZER);
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    return this.http.post(this.getScheduleReplenishmentOrderEndpoint(userId, cartId, termsChecked.toString()), scheduleReplenishmentForm, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), backOff({
      shouldRetry: isJaloError
    }), this.converter.pipeable(REPLENISHMENT_ORDER_NORMALIZER));
  }
  getScheduleReplenishmentOrderEndpoint(userId, cartId, termsChecked) {
    return this.occEndpoints.buildUrl("scheduleReplenishmentOrder", {
      urlParams: {
        userId
      },
      queryParams: {
        cartId,
        termsChecked
      }
    });
  }
  static {
    this.ɵfac = function OccScheduledReplenishmentOrderAdapter_Factory(t) {
      return new (t || _OccScheduledReplenishmentOrderAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccScheduledReplenishmentOrderAdapter,
      factory: _OccScheduledReplenishmentOrderAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccScheduledReplenishmentOrderAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var OccReorderOrderNormalizer = class _OccReorderOrderNormalizer {
  convert(source, target) {
    if (target === void 0) {
      target = __spreadValues({}, source);
    }
    return target;
  }
  static {
    this.ɵfac = function OccReorderOrderNormalizer_Factory(t) {
      return new (t || _OccReorderOrderNormalizer)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccReorderOrderNormalizer,
      factory: _OccReorderOrderNormalizer.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccReorderOrderNormalizer, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var OccReorderOrderAdapter = class _OccReorderOrderAdapter {
  constructor(http, occEndpoints, converter) {
    this.http = http;
    this.occEndpoints = occEndpoints;
    this.converter = converter;
    this.logger = inject(LoggerService);
  }
  reorder(orderId, userId) {
    const headers = new HttpHeaders().set("Content-Type", "application/json");
    return this.http.post(this.getReorderOrderEndpoint(orderId, userId), {}, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), this.converter.pipeable(REORDER_ORDER_NORMALIZER));
  }
  getReorderOrderEndpoint(orderCode, userId) {
    return this.occEndpoints.buildUrl("reorder", {
      urlParams: {
        userId
      },
      queryParams: {
        orderCode
      }
    });
  }
  static {
    this.ɵfac = function OccReorderOrderAdapter_Factory(t) {
      return new (t || _OccReorderOrderAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccReorderOrderAdapter,
      factory: _OccReorderOrderAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccReorderOrderAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var defaultOccOrderConfig = {
  backend: {
    occ: {
      endpoints: {
        /* eslint-disable max-len */
        orderHistory: "users/${userId}/orders",
        orderDetail: "users/${userId}/orders/${orderId}?fields=FULL",
        consignmentTracking: "users/${userId}/orders/${orderCode}/consignments/${consignmentCode}/tracking",
        cancelOrder: "users/${userId}/orders/${orderId}/cancellation",
        returnOrder: "users/${userId}/orderReturns?fields=BASIC,returnEntries(BASIC,refundAmount(formattedValue),orderEntry(basePrice(formattedValue),product(name,code,baseOptions,images(DEFAULT,galleryIndex)))),deliveryCost(formattedValue),totalPrice(formattedValue),subTotal(formattedValue)",
        orderReturns: "users/${userId}/orderReturns?fields=BASIC",
        orderReturnDetail: "users/${userId}/orderReturns/${returnRequestCode}?fields=BASIC,returnEntries(BASIC,refundAmount(formattedValue),orderEntry(basePrice(formattedValue),product(name,code,baseOptions,images(DEFAULT,galleryIndex)))),deliveryCost(formattedValue),totalPrice(formattedValue),subTotal(formattedValue)",
        cancelReturn: "users/${userId}/orderReturns/${returnRequestCode}",
        /* eslint-enable */
        /** scheduled replenishment endpoints start */
        replenishmentOrderDetails: "users/${userId}/replenishmentOrders/${replenishmentOrderCode}?fields=FULL,costCenter(FULL),purchaseOrderNumber,paymentType,user",
        replenishmentOrderDetailsHistory: "users/${userId}/replenishmentOrders/${replenishmentOrderCode}/orders",
        cancelReplenishmentOrder: "users/${userId}/replenishmentOrders/${replenishmentOrderCode}?fields=FULL,costCenter(FULL),purchaseOrderNumber,paymentType,user",
        replenishmentOrderHistory: "users/${userId}/replenishmentOrders?fields=FULL,replenishmentOrders(FULL, purchaseOrderNumber)",
        /** scheduled replenishment endpoints end */
        /** placing an order endpoints start **/
        placeOrder: "users/${userId}/orders?fields=FULL",
        placePaymentAuthorizedOrder: "users/${userId}/orders/paymentAuthorizedOrderPlacement?fields=FULL"
        /** placing an order endpoints end **/
      }
    }
  }
};
var OrderOccModule = class _OrderOccModule {
  static {
    this.ɵfac = function OrderOccModule_Factory(t) {
      return new (t || _OrderOccModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderOccModule,
      imports: [CommonModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultOccOrderConfig), {
        provide: OrderHistoryAdapter,
        useClass: OccOrderHistoryAdapter
      }, {
        provide: ReplenishmentOrderHistoryAdapter,
        useClass: OccReplenishmentOrderHistoryAdapter
      }, {
        provide: OrderAdapter,
        useClass: OccOrderAdapter
      }, {
        provide: ScheduledReplenishmentOrderAdapter,
        useClass: OccScheduledReplenishmentOrderAdapter
      }, {
        provide: ReorderOrderAdapter,
        useClass: OccReorderOrderAdapter
      }, {
        provide: ORDER_RETURN_REQUEST_NORMALIZER,
        useExisting: OccReturnRequestNormalizer,
        multi: true
      }, {
        provide: ORDER_NORMALIZER,
        useExisting: OccOrderNormalizer,
        multi: true
      }, {
        provide: REPLENISHMENT_ORDER_NORMALIZER,
        useExisting: OccReplenishmentOrderNormalizer,
        multi: true
      }, {
        provide: REPLENISHMENT_ORDER_FORM_SERIALIZER,
        useExisting: OccScheduledReplenishmentOrderFormSerializer,
        multi: true
      }, {
        provide: REORDER_ORDER_NORMALIZER,
        useExisting: OccReorderOrderNormalizer,
        multi: true
      }],
      imports: [CommonModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderOccModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule],
      providers: [provideDefaultConfig(defaultOccOrderConfig), {
        provide: OrderHistoryAdapter,
        useClass: OccOrderHistoryAdapter
      }, {
        provide: ReplenishmentOrderHistoryAdapter,
        useClass: OccReplenishmentOrderHistoryAdapter
      }, {
        provide: OrderAdapter,
        useClass: OccOrderAdapter
      }, {
        provide: ScheduledReplenishmentOrderAdapter,
        useClass: OccScheduledReplenishmentOrderAdapter
      }, {
        provide: ReorderOrderAdapter,
        useClass: OccReorderOrderAdapter
      }, {
        provide: ORDER_RETURN_REQUEST_NORMALIZER,
        useExisting: OccReturnRequestNormalizer,
        multi: true
      }, {
        provide: ORDER_NORMALIZER,
        useExisting: OccOrderNormalizer,
        multi: true
      }, {
        provide: REPLENISHMENT_ORDER_NORMALIZER,
        useExisting: OccReplenishmentOrderNormalizer,
        multi: true
      }, {
        provide: REPLENISHMENT_ORDER_FORM_SERIALIZER,
        useExisting: OccScheduledReplenishmentOrderFormSerializer,
        multi: true
      }, {
        provide: REORDER_ORDER_NORMALIZER,
        useExisting: OccReorderOrderNormalizer,
        multi: true
      }]
    }]
  }], null, null);
})();

// node_modules/@spartacus/order/fesm2022/spartacus-order.mjs
var OrderModule = class _OrderModule {
  static {
    this.ɵfac = function OrderModule_Factory(t) {
      return new (t || _OrderModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OrderModule,
      imports: [OrderCoreModule, OrderOccModule, OrderComponentsModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [OrderCoreModule, OrderOccModule, OrderComponentsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrderModule, [{
    type: NgModule,
    args: [{
      imports: [OrderCoreModule, OrderOccModule, OrderComponentsModule]
    }]
  }], null, null);
})();
export {
  OrderModule
};
//# sourceMappingURL=@spartacus_order.js.map
