import "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/product/fesm2022/spartacus-product-image-zoom-assets.mjs
var productImageZoomTrigger = {
  expand: "Expand image"
};
var productImageZoomDialog = {
  zoomedInImage: "Zoomed in image",
  previousSlide: "Previous slide",
  nextSlide: "Next slide",
  close: "Close"
};
var productImageZoom = {
  productImageZoomTrigger,
  productImageZoomDialog
};
var en = {
  productImageZoom
};
var productImageZoomTranslations = {
  en
};
var productImageZoomTranslationChunksConfig = {
  productImageZoom: ["productImageZoomTrigger", "productImageZoomDialog"]
};
export {
  productImageZoomTranslationChunksConfig,
  productImageZoomTranslations
};
//# sourceMappingURL=@spartacus_product_image-zoom_assets.js.map
