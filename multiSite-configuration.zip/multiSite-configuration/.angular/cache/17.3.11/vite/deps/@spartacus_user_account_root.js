import {
  USER_ACCOUNT_CORE_FEATURE,
  USER_ACCOUNT_FEATURE,
  UserAccountChangedEvent,
  UserAccountEvent,
  UserAccountEventListener,
  UserAccountEventModule,
  UserAccountFacade,
  UserAccountRootModule,
  VERIFICATION_TOKEN_DIALOG_ACTION,
  VerificationTokenFacade,
  defaultUserAccountComponentsConfig
} from "./chunk-SPYT22X6.js";
import "./chunk-FIMZ5LIU.js";
import "./chunk-CJWHFW34.js";
import "./chunk-OIYGDMWQ.js";
import "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import "./chunk-XWT3SXR6.js";
import "./chunk-JMCPXHNJ.js";
import "./chunk-FTQ24RAU.js";
export {
  USER_ACCOUNT_CORE_FEATURE,
  USER_ACCOUNT_FEATURE,
  UserAccountChangedEvent,
  UserAccountEvent,
  UserAccountEventListener,
  UserAccountEventModule,
  UserAccountFacade,
  UserAccountRootModule,
  VERIFICATION_TOKEN_DIALOG_ACTION,
  VerificationTokenFacade,
  defaultUserAccountComponentsConfig
};
//# sourceMappingURL=@spartacus_user_account_root.js.map
