import {
  UserAccountChangedEvent,
  UserAccountFacade,
  VERIFICATION_TOKEN_DIALOG_ACTION,
  VerificationTokenFacade
} from "./chunk-SPYT22X6.js";
import {
  BtnLikeLinkDirective,
  BtnLikeLinkModule,
  CustomFormValidators,
  DIALOG_TYPE,
  DefaultValueAccessor,
  FocusDirective,
  FormControlName,
  FormErrorsComponent,
  FormErrorsModule,
  FormGroupDirective,
  FormsModule,
  IconComponent,
  IconModule,
  KeyboardFocusModule,
  LaunchDialogService,
  NgControlStatus,
  NgControlStatusGroup,
  PageSlotComponent,
  PageSlotModule,
  PasswordVisibilityToggleDirective,
  PasswordVisibilityToggleModule,
  ReactiveFormsModule,
  RequiredValidator,
  SpinnerComponent,
  SpinnerModule,
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
  ɵNgNoValidate
} from "./chunk-FIMZ5LIU.js";
import {
  ActivatedRoute,
  AuthGuard,
  AuthService,
  CommandService,
  ConverterService,
  FeatureDirective,
  FeaturesConfigModule,
  GlobalMessageService,
  GlobalMessageType,
  I18nModule,
  InterceptorUtil,
  LoggerService,
  LoginEvent,
  LogoutEvent,
  NotAuthGuard,
  OccEndpointsService,
  QueryService,
  RouterLink,
  RouterModule,
  RoutingService,
  TranslatePipe,
  USE_CLIENT_TOKEN,
  UrlModule,
  UrlPipe,
  UserIdService,
  WindowRef,
  normalizeHttpError,
  provideDefaultConfig,
  useFeatureStyles
} from "./chunk-CJWHFW34.js";
import "./chunk-OIYGDMWQ.js";
import "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import {
  AsyncPipe,
  CommonModule,
  HttpClient,
  HttpHeaders,
  NgClass,
  NgIf,
  NgTemplateOutlet
} from "./chunk-XWT3SXR6.js";
import {
  BehaviorSubject,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  HostBinding,
  Injectable,
  InjectionToken,
  NgModule,
  Optional,
  ViewChild,
  catchError,
  from,
  inject,
  of,
  setClassMetadata,
  switchMap,
  tap,
  withLatestFrom,
  ɵɵInheritDefinitionFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵinject,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-JMCPXHNJ.js";
import {
  __spreadValues
} from "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/user/fesm2022/spartacus-user-account-components.mjs
var _c0 = () => ({
  cxRoute: "forgotPassword"
});
var _c1 = (a0) => ({
  label: a0
});
function LoginFormComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 12);
  }
}
function LoginFormComponent_p_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 13);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), " ");
  }
}
function LoginFormComponent_ng_template_8_Template(rf, ctx) {
}
function LoginFormComponent_cx_form_errors_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c1, ɵɵpipeBind1(1, 2, "loginForm.emailAddress.label")))("control", ctx_r1.form.get("userId"));
  }
}
function LoginFormComponent_cx_form_errors_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("userId"));
  }
}
function LoginFormComponent_ng_template_17_Template(rf, ctx) {
}
function LoginFormComponent_cx_form_errors_21_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 14);
    ɵɵpipe(1, "cxTranslate");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("translationParams", ɵɵpureFunction1(4, _c1, ɵɵpipeBind1(1, 2, "loginForm.password.label")))("control", ctx_r1.form.get("password"));
  }
}
function LoginFormComponent_cx_form_errors_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-form-errors", 15);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("control", ctx_r1.form.get("password"));
  }
}
function LoginFormComponent_ng_template_30_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 17);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function LoginFormComponent_ng_template_30_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, LoginFormComponent_ng_template_30_abbr_0_Template, 3, 3, "abbr", 16);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
var _c2 = () => ({
  cxRoute: "register"
});
var _c3 = () => ({
  cxRoute: "checkoutLogin"
});
function LoginRegisterComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "button", 3);
    ɵɵlistener("click", function LoginRegisterComponent_ng_container_4_Template_button_click_1_listener() {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.navigateTo(ctx_r1.loginAsGuest ? "checkoutLogin" : "register"));
    });
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngClass", ctx_r1.loginAsGuest ? "btn-guest" : "btn-register");
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 2, ctx_r1.loginAsGuest ? "loginForm.guestCheckout" : "loginForm.register"), " ");
  }
}
function LoginRegisterComponent_ng_container_5_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 5);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction0(6, _c2)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 4, "loginForm.register"));
  }
}
function LoginRegisterComponent_ng_container_5_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "a", 6);
    ɵɵpipe(2, "cxUrl");
    ɵɵtext(3);
    ɵɵpipe(4, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(2, 2, ɵɵpureFunction0(6, _c3)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(4, 4, "loginForm.guestCheckout"));
  }
}
function LoginRegisterComponent_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, LoginRegisterComponent_ng_container_5_ng_container_1_Template, 5, 7, "ng-container", 4)(2, LoginRegisterComponent_ng_container_5_ng_container_2_Template, 5, 7, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.loginAsGuest);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.loginAsGuest);
  }
}
var _c4 = (a0) => ({
  name: a0
});
var _c5 = () => ({
  cxRoute: "login"
});
function LoginComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2);
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelement(4, "cx-page-slot", 3);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const user_r1 = ctx.ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(3, 1, "miniLogin.userGreeting", ɵɵpureFunction1(4, _c4, user_r1.name)), " ");
  }
}
function LoginComponent_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 4);
    ɵɵpipe(1, "cxUrl");
    ɵɵtext(2);
    ɵɵpipe(3, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵproperty("routerLink", ɵɵpipeBind1(1, 2, ɵɵpureFunction0(6, _c5)));
    ɵɵadvance(2);
    ɵɵtextInterpolate(ɵɵpipeBind1(3, 4, "miniLogin.signInRegister"));
  }
}
var _c6 = () => ({
  cxRoute: "logout"
});
function MyAccountV2UserComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementStart(3, "a", 3);
    ɵɵpipe(4, "cxUrl");
    ɵɵtext(5);
    ɵɵpipe(6, "cxTranslate");
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const user_r1 = ctx.ngIf;
    ɵɵadvance(2);
    ɵɵtextInterpolate2("", user_r1.title, "", user_r1.name, "");
    ɵɵadvance();
    ɵɵproperty("routerLink", ɵɵpipeBind1(4, 4, ɵɵpureFunction0(8, _c6)));
    ɵɵadvance(2);
    ɵɵtextInterpolate1("", ɵɵpipeBind1(6, 6, "myAccountV2User.signOut"), " ");
  }
}
function OneTimePasswordLoginFormComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 11);
  }
}
function OneTimePasswordLoginFormComponent_p_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 12);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), " ");
  }
}
function OneTimePasswordLoginFormComponent_ng_template_8_Template(rf, ctx) {
}
function OneTimePasswordLoginFormComponent_ng_template_16_Template(rf, ctx) {
}
function OneTimePasswordLoginFormComponent_ng_template_28_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 14);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function OneTimePasswordLoginFormComponent_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, OneTimePasswordLoginFormComponent_ng_template_28_abbr_0_Template, 3, 3, "abbr", 13);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
function VerificationTokenDialogComponent_h3_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "h3", 12);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "verificationTokenDialog.title"), " ");
  }
}
function VerificationTokenDialogComponent_span_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 12);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "verificationTokenDialog.title"), " ");
  }
}
var _c7 = ["noReceiveCodeLink"];
var _c8 = ["resendLink"];
var _c9 = (a0) => ({
  "disabled-link": a0
});
var _c10 = (a0) => ({
  waitTime: a0
});
function VerificationTokenFormComponent_cx_spinner_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "cx-spinner", 22);
  }
}
function VerificationTokenFormComponent_p_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "p", 23);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind1(2, 1, "formLegend.required"), " ");
  }
}
function VerificationTokenFormComponent_ng_template_8_Template(rf, ctx) {
}
function VerificationTokenFormComponent_ng_container_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵpipe(2, "cxTranslate");
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ɵɵpipeBind2(2, 1, "verificationTokenForm.sendRateLime", ɵɵpureFunction1(4, _c10, ctx_r1.waitTime)), " ");
  }
}
function VerificationTokenFormComponent_ng_template_37_abbr_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "abbr", 25);
    ɵɵpipe(1, "cxTranslate");
    ɵɵtext(2, "*");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵpropertyInterpolate("title", ɵɵpipeBind1(1, 1, "common.required"));
  }
}
function VerificationTokenFormComponent_ng_template_37_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, VerificationTokenFormComponent_ng_template_37_abbr_0_Template, 3, 3, "abbr", 24);
  }
  if (rf & 2) {
    ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
  }
}
var LoginFormComponentService = class _LoginFormComponentService {
  constructor(auth, globalMessage, winRef) {
    this.auth = auth;
    this.globalMessage = globalMessage;
    this.winRef = winRef;
    this.busy$ = new BehaviorSubject(false);
    this.isUpdating$ = this.busy$.pipe(tap((state) => {
      const userId = this.winRef.nativeWindow?.history?.state?.["newUid"];
      if (userId) {
        this.form.patchValue({
          userId
        });
      }
      state === true ? this.form.disable() : this.form.enable();
    }));
    this.form = new UntypedFormGroup({
      userId: new UntypedFormControl("", [Validators.required, CustomFormValidators.emailValidator]),
      password: new UntypedFormControl("", Validators.required)
    });
  }
  login() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    from(this.auth.loginWithCredentials(
      // TODO: consider dropping toLowerCase as this should not be part of the UI,
      // as it's too opinionated and doesn't work with other AUTH services
      this.form.value.userId.toLowerCase(),
      this.form.value.password
    )).pipe(withLatestFrom(this.auth.isUserLoggedIn()), tap(([_, isLoggedIn]) => this.onSuccess(isLoggedIn))).subscribe();
  }
  onSuccess(isLoggedIn) {
    if (isLoggedIn) {
      this.globalMessage.remove(GlobalMessageType.MSG_TYPE_ERROR);
      this.form.reset();
    }
    this.busy$.next(false);
  }
  static {
    this.ɵfac = function LoginFormComponentService_Factory(t) {
      return new (t || _LoginFormComponentService)(ɵɵinject(AuthService), ɵɵinject(GlobalMessageService), ɵɵinject(WindowRef));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _LoginFormComponentService,
      factory: _LoginFormComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginFormComponentService, [{
    type: Injectable
  }], () => [{
    type: AuthService
  }, {
    type: GlobalMessageService
  }, {
    type: WindowRef
  }], null);
})();
var LoginFormComponent = class _LoginFormComponent {
  constructor(service) {
    this.service = service;
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    this.style = true;
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  onSubmit() {
    this.service.login();
  }
  static {
    this.ɵfac = function LoginFormComponent_Factory(t) {
      return new (t || _LoginFormComponent)(ɵɵdirectiveInject(LoginFormComponentService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _LoginFormComponent,
      selectors: [["cx-login-form"]],
      hostVars: 2,
      hostBindings: function LoginFormComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassProp("user-form", ctx.style);
        }
      },
      decls: 32,
      vars: 37,
      consts: [["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], [3, "ngSubmit", "formGroup"], ["class", "form-legend", 4, "cxFeature"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "type", "email", "formControlName", "userId", 1, "form-control", 3, "placeholder"], [3, "translationParams", "control", 4, "cxFeature"], [3, "control", 4, "cxFeature"], ["required", "true", "type", "password", "formControlName", "password", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [1, "btn-link", 3, "routerLink"], ["type", "submit", 1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "overlay"], [1, "form-legend"], [3, "translationParams", "control"], [3, "control"], ["class", "text-decoration-none required-asterisk", "aria-hidden", "true", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function LoginFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, LoginFormComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 1);
          ɵɵpipe(1, "async");
          ɵɵelementStart(2, "form", 2);
          ɵɵlistener("ngSubmit", function LoginFormComponent_Template_form_ngSubmit_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onSubmit());
          });
          ɵɵtemplate(3, LoginFormComponent_p_3_Template, 3, 3, "p", 3);
          ɵɵelementStart(4, "label")(5, "span", 4);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵtemplate(8, LoginFormComponent_ng_template_8_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(9, "input", 6);
          ɵɵpipe(10, "cxTranslate");
          ɵɵtemplate(11, LoginFormComponent_cx_form_errors_11_Template, 2, 6, "cx-form-errors", 7)(12, LoginFormComponent_cx_form_errors_12_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(13, "label")(14, "span", 4);
          ɵɵtext(15);
          ɵɵpipe(16, "cxTranslate");
          ɵɵtemplate(17, LoginFormComponent_ng_template_17_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(18, "input", 9);
          ɵɵpipe(19, "cxTranslate");
          ɵɵpipe(20, "cxTranslate");
          ɵɵtemplate(21, LoginFormComponent_cx_form_errors_21_Template, 2, 6, "cx-form-errors", 7)(22, LoginFormComponent_cx_form_errors_22_Template, 1, 1, "cx-form-errors", 8);
          ɵɵelementEnd();
          ɵɵelementStart(23, "a", 10);
          ɵɵpipe(24, "cxUrl");
          ɵɵtext(25);
          ɵɵpipe(26, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(27, "button", 11);
          ɵɵtext(28);
          ɵɵpipe(29, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵtemplate(30, LoginFormComponent_ng_template_30_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r3 = ɵɵreference(31);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 18, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 20, "loginForm.emailAddress.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(10, 22, "loginForm.emailAddress.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(16, 24, "loginForm.password.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(19, 26, "loginForm.password.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(20, 28, "loginForm.password.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("cxFeature", "formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!formErrorsDescriptiveMessages");
          ɵɵadvance();
          ɵɵproperty("routerLink", ɵɵpipeBind1(24, 30, ɵɵpureFunction0(36, _c0)));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(26, 32, "loginForm.forgotPassword"), " ");
          ɵɵadvance(2);
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(29, 34, "loginForm.signIn"), " ");
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, RouterLink, FormErrorsComponent, SpinnerComponent, PasswordVisibilityToggleDirective, FeatureDirective, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-login-form",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"></cx-spinner>

<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <!-- TODO: (CXSPA-5953) Remove feature flags next major -->
  <p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
    {{ 'formLegend.required' | cxTranslate }}
  </p>
  <label>
    <span class="label-content">
      {{ 'loginForm.emailAddress.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
    </span>
    <input
      required="true"
      type="email"
      class="form-control"
      formControlName="userId"
      placeholder="{{ 'loginForm.emailAddress.placeholder' | cxTranslate }}"
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'loginForm.emailAddress.label' | cxTranslate,
      }"
      [control]="form.get('userId')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('userId')"
    ></cx-form-errors>
  </label>

  <label>
    <span class="label-content">
      {{ 'loginForm.password.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
    </span>
    <input
      required="true"
      type="password"
      class="form-control"
      placeholder="{{ 'loginForm.password.placeholder' | cxTranslate }}"
      formControlName="password"
      [attr.aria-label]="'loginForm.password.placeholder' | cxTranslate"
      cxPasswordVisibilitySwitch
    />

    <!-- TODO: (CXSPA-7315) Remove feature toggle in the next major -->
    <cx-form-errors
      *cxFeature="'formErrorsDescriptiveMessages'"
      [translationParams]="{
        label: 'loginForm.password.label' | cxTranslate,
      }"
      [control]="form.get('password')"
    ></cx-form-errors>

    <cx-form-errors
      *cxFeature="'!formErrorsDescriptiveMessages'"
      [control]="form.get('password')"
    ></cx-form-errors>
  </label>

  <a [routerLink]="{ cxRoute: 'forgotPassword' } | cxUrl" class="btn-link">
    {{ 'loginForm.forgotPassword' | cxTranslate }}
  </a>

  <button
    type="submit"
    class="btn btn-block btn-primary"
    [disabled]="form.disabled"
  >
    {{ 'loginForm.signIn' | cxTranslate }}
  </button>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    class="text-decoration-none required-asterisk"
    aria-hidden="true"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [{
    type: LoginFormComponentService
  }], {
    style: [{
      type: HostBinding,
      args: ["class.user-form"]
    }]
  });
})();
var LoginFormModule = class _LoginFormModule {
  static {
    this.ɵfac = function LoginFormModule_Factory(t) {
      return new (t || _LoginFormModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _LoginFormModule,
      declarations: [LoginFormComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturningCustomerLoginComponent: {
            component: LoginFormComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: LoginFormComponentService,
              useClass: LoginFormComponentService,
              deps: [AuthService, GlobalMessageService, WindowRef]
            }]
          }
        }
      })],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginFormModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturningCustomerLoginComponent: {
            component: LoginFormComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: LoginFormComponentService,
              useClass: LoginFormComponentService,
              deps: [AuthService, GlobalMessageService, WindowRef]
            }]
          }
        }
      })],
      declarations: [LoginFormComponent]
    }]
  }], null, null);
})();
var LoginRegisterComponent = class _LoginRegisterComponent {
  constructor(activatedRoute) {
    this.activatedRoute = activatedRoute;
    this.loginAsGuest = false;
    this.routingService = inject(RoutingService, {
      optional: true
    });
  }
  ngOnInit() {
    this.loginAsGuest = this.activatedRoute.snapshot.queryParams["forced"];
  }
  navigateTo(cxRoute) {
    this.routingService?.go({
      cxRoute
    });
  }
  static {
    this.ɵfac = function LoginRegisterComponent_Factory(t) {
      return new (t || _LoginRegisterComponent)(ɵɵdirectiveInject(ActivatedRoute));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _LoginRegisterComponent,
      selectors: [["cx-login-register"]],
      decls: 6,
      vars: 5,
      consts: [[1, "register"], [1, "cx-section-title"], [4, "cxFeature"], [1, "btn", "btn-block", "btn-secondary", 3, "click", "ngClass"], [4, "ngIf"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", "btn-register", 3, "routerLink"], ["cxBtnLikeLink", "", 1, "btn", "btn-block", "btn-secondary", "btn-guest", 3, "routerLink"]],
      template: function LoginRegisterComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0)(1, "p", 1);
          ɵɵtext(2);
          ɵɵpipe(3, "cxTranslate");
          ɵɵelementEnd();
          ɵɵtemplate(4, LoginRegisterComponent_ng_container_4_Template, 4, 4, "ng-container", 2)(5, LoginRegisterComponent_ng_container_5_Template, 3, 2, "ng-container", 2);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(3, 3, "loginForm.dontHaveAccount"), " ");
          ɵɵadvance(2);
          ɵɵproperty("cxFeature", "a11yUseButtonsForBtnLinks");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yUseButtonsForBtnLinks");
        }
      },
      dependencies: [NgClass, NgIf, RouterLink, FeatureDirective, BtnLikeLinkDirective, UrlPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginRegisterComponent, [{
    type: Component,
    args: [{
      selector: "cx-login-register",
      template: `<div class="register">
  <p class="cx-section-title">
    {{ 'loginForm.dontHaveAccount' | cxTranslate }}
  </p>

  <!-- TODO: (CXSPA-7252) - Remove feature flag next major release -->
  <ng-container *cxFeature="'a11yUseButtonsForBtnLinks'">
    <button
      (click)="navigateTo(loginAsGuest ? 'checkoutLogin' : 'register')"
      class="btn btn-block btn-secondary"
      [ngClass]="loginAsGuest ? 'btn-guest' : 'btn-register'"
    >
      {{
        (loginAsGuest ? 'loginForm.guestCheckout' : 'loginForm.register')
          | cxTranslate
      }}
    </button>
  </ng-container>

  <ng-container *cxFeature="'!a11yUseButtonsForBtnLinks'">
    <ng-container *ngIf="!loginAsGuest">
      <a
        [routerLink]="{ cxRoute: 'register' } | cxUrl"
        class="btn btn-block btn-secondary btn-register"
        cxBtnLikeLink
        >{{ 'loginForm.register' | cxTranslate }}</a
      >
    </ng-container>

    <ng-container *ngIf="loginAsGuest">
      <a
        [routerLink]="{ cxRoute: 'checkoutLogin' } | cxUrl"
        class="btn btn-block btn-secondary btn-guest"
        cxBtnLikeLink
        >{{ 'loginForm.guestCheckout' | cxTranslate }}</a
      >
    </ng-container>
  </ng-container>
</div>
`
    }]
  }], () => [{
    type: ActivatedRoute
  }], {
    routingService: [{
      type: Optional
    }]
  });
})();
var LoginRegisterModule = class _LoginRegisterModule {
  static {
    this.ɵfac = function LoginRegisterModule_Factory(t) {
      return new (t || _LoginRegisterModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _LoginRegisterModule,
      declarations: [LoginRegisterComponent],
      imports: [CommonModule, RouterModule, UrlModule, PageSlotModule, I18nModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturningCustomerRegisterComponent: {
            component: LoginRegisterComponent,
            guards: [NotAuthGuard]
          }
        }
      })],
      imports: [CommonModule, RouterModule, UrlModule, PageSlotModule, I18nModule, FeaturesConfigModule, BtnLikeLinkModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginRegisterModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, UrlModule, PageSlotModule, I18nModule, FeaturesConfigModule, BtnLikeLinkModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturningCustomerRegisterComponent: {
            component: LoginRegisterComponent,
            guards: [NotAuthGuard]
          }
        }
      })],
      declarations: [LoginRegisterComponent]
    }]
  }], null, null);
})();
var LoginComponent = class _LoginComponent {
  constructor(auth, userAccount) {
    this.auth = auth;
    this.userAccount = userAccount;
    useFeatureStyles("a11yMyAccountLinkOutline");
  }
  ngOnInit() {
    this.user$ = this.auth.isUserLoggedIn().pipe(switchMap((isUserLoggedIn) => {
      if (isUserLoggedIn) {
        return this.userAccount.get();
      } else {
        return of(void 0);
      }
    }));
  }
  static {
    this.ɵfac = function LoginComponent_Factory(t) {
      return new (t || _LoginComponent)(ɵɵdirectiveInject(AuthService), ɵɵdirectiveInject(UserAccountFacade));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _LoginComponent,
      selectors: [["cx-login"]],
      decls: 4,
      vars: 4,
      consts: [["login", ""], [4, "ngIf", "ngIfElse"], ["id", "greeting", 1, "cx-login-greet"], ["id", "account-nav", "position", "HeaderLinks"], ["role", "link", 3, "routerLink"]],
      template: function LoginComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, LoginComponent_ng_container_0_Template, 5, 6, "ng-container", 1);
          ɵɵpipe(1, "async");
          ɵɵtemplate(2, LoginComponent_ng_template_2_Template, 4, 7, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const login_r2 = ɵɵreference(3);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 2, ctx.user$))("ngIfElse", login_r2);
        }
      },
      dependencies: [NgIf, RouterLink, PageSlotComponent, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginComponent, [{
    type: Component,
    args: [{
      selector: "cx-login",
      template: `<ng-container *ngIf="user$ | async as user; else login">
  <div class="cx-login-greet" id="greeting">
    {{ 'miniLogin.userGreeting' | cxTranslate: { name: user.name } }}
  </div>
  <cx-page-slot id="account-nav" position="HeaderLinks"></cx-page-slot>
</ng-container>

<ng-template #login>
  <a role="link" [routerLink]="{ cxRoute: 'login' } | cxUrl">{{
    'miniLogin.signInRegister' | cxTranslate
  }}</a>
</ng-template>
`
    }]
  }], () => [{
    type: AuthService
  }, {
    type: UserAccountFacade
  }], null);
})();
var LoginModule = class _LoginModule {
  static {
    this.ɵfac = function LoginModule_Factory(t) {
      return new (t || _LoginModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _LoginModule,
      declarations: [LoginComponent],
      imports: [CommonModule, RouterModule, UrlModule, PageSlotModule, I18nModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          LoginComponent: {
            component: LoginComponent
          }
        }
      })],
      imports: [CommonModule, RouterModule, UrlModule, PageSlotModule, I18nModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, UrlModule, PageSlotModule, I18nModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          LoginComponent: {
            component: LoginComponent
          }
        }
      })],
      declarations: [LoginComponent]
    }]
  }], null, null);
})();
var MyAccountV2UserComponent = class _MyAccountV2UserComponent extends LoginComponent {
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵMyAccountV2UserComponent_BaseFactory;
      return function MyAccountV2UserComponent_Factory(t) {
        return (ɵMyAccountV2UserComponent_BaseFactory || (ɵMyAccountV2UserComponent_BaseFactory = ɵɵgetInheritedFactory(_MyAccountV2UserComponent)))(t || _MyAccountV2UserComponent);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _MyAccountV2UserComponent,
      selectors: [["cx-my-account-v2-user"]],
      features: [ɵɵInheritDefinitionFeature],
      decls: 3,
      vars: 3,
      consts: [[1, "cx-my-account-v2-user"], [4, "ngIf"], [1, "cx-name"], [1, "cx-sign-out", 3, "routerLink"]],
      template: function MyAccountV2UserComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵtemplate(1, MyAccountV2UserComponent_ng_container_1_Template, 7, 9, "ng-container", 1);
          ɵɵpipe(2, "async");
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵadvance();
          ɵɵproperty("ngIf", ɵɵpipeBind1(2, 1, ctx.user$));
        }
      },
      dependencies: [NgIf, RouterLink, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2UserComponent, [{
    type: Component,
    args: [{
      selector: "cx-my-account-v2-user",
      template: `<div class="cx-my-account-v2-user">
  <ng-container *ngIf="user$ | async as user">
    <div class="cx-name">{{ user.title }}{{ user.name }}</div>
    <a
      class="cx-sign-out"
      [routerLink]="
        {
          cxRoute: 'logout',
        } | cxUrl
      "
      >{{ 'myAccountV2User.signOut' | cxTranslate }}
    </a>
  </ng-container>
</div>
`
    }]
  }], null, null);
})();
var MyAccountV2UserModule = class _MyAccountV2UserModule {
  static {
    this.ɵfac = function MyAccountV2UserModule_Factory(t) {
      return new (t || _MyAccountV2UserModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _MyAccountV2UserModule,
      declarations: [MyAccountV2UserComponent],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule],
      exports: [MyAccountV2UserComponent]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          MyAccountViewUserComponent: {
            component: MyAccountV2UserComponent,
            guards: [AuthGuard]
          }
        }
      })],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MyAccountV2UserModule, [{
    type: NgModule,
    args: [{
      providers: [provideDefaultConfig({
        cmsComponents: {
          MyAccountViewUserComponent: {
            component: MyAccountV2UserComponent,
            guards: [AuthGuard]
          }
        }
      })],
      declarations: [MyAccountV2UserComponent],
      exports: [MyAccountV2UserComponent],
      imports: [CommonModule, RouterModule, UrlModule, I18nModule]
    }]
  }], null, null);
})();
var ONE_TIME_PASSWORD_LOGIN_PURPOSE = "LOGIN";
var OneTimePasswordLoginFormComponent = class _OneTimePasswordLoginFormComponent {
  constructor() {
    this.routingService = inject(RoutingService);
    this.verificationTokenFacade = inject(VerificationTokenFacade);
    this.winRef = inject(WindowRef);
    this.busy$ = new BehaviorSubject(false);
    this.isUpdating$ = this.busy$.pipe(tap((state) => {
      const userId = this.winRef.nativeWindow?.history?.state?.["newUid"];
      if (userId) {
        this.form.patchValue({
          userId
        });
      }
      state === true ? this.form.disable() : this.form.enable();
    }));
    this.form = new UntypedFormGroup({
      userId: new UntypedFormControl("", [Validators.required, CustomFormValidators.emailValidator]),
      password: new UntypedFormControl("", Validators.required)
    });
    this.style = true;
    useFeatureStyles("a11yPasswordVisibliltyBtnValueOverflow");
  }
  onSubmit() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    const verificationTokenCreation = this.collectDataFromLoginForm();
    this.verificationTokenFacade.createVerificationToken(verificationTokenCreation).subscribe({
      next: (result) => this.goToVerificationTokenForm(result, verificationTokenCreation),
      error: () => this.busy$.next(false),
      complete: () => this.onCreateVerificationTokenComplete()
    });
  }
  goToVerificationTokenForm(verificationToken, verificationTokenCreation) {
    this.routingService.go({
      cxRoute: "verifyToken"
    }, {
      state: {
        loginId: verificationTokenCreation.loginId,
        password: verificationTokenCreation.password,
        tokenId: verificationToken.tokenId,
        expiresIn: verificationToken.expiresIn
      }
    });
  }
  onCreateVerificationTokenComplete() {
    this.form.reset();
    this.busy$.next(false);
  }
  collectDataFromLoginForm() {
    return {
      // TODO: consider dropping toLowerCase as this should not be part of the UI,
      // as it's too opinionated and doesn't work with other AUTH services
      loginId: this.form.value.userId.toLowerCase(),
      password: this.form.value.password,
      purpose: ONE_TIME_PASSWORD_LOGIN_PURPOSE
    };
  }
  static {
    this.ɵfac = function OneTimePasswordLoginFormComponent_Factory(t) {
      return new (t || _OneTimePasswordLoginFormComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _OneTimePasswordLoginFormComponent,
      selectors: [["cx-otp-login-form"]],
      hostVars: 2,
      hostBindings: function OneTimePasswordLoginFormComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassProp("user-form", ctx.style);
        }
      },
      decls: 30,
      vars: 35,
      consts: [["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], [3, "ngSubmit", "formGroup"], ["class", "form-legend", 4, "cxFeature"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "type", "email", "formControlName", "userId", 1, "form-control", 3, "placeholder"], [3, "control"], ["required", "true", "type", "password", "formControlName", "password", "cxPasswordVisibilitySwitch", "", 1, "form-control", 3, "placeholder"], [1, "btn-link", 3, "routerLink"], ["type", "submit", 1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "overlay"], [1, "form-legend"], ["aria-hidden", "true", "class", "text-decoration-none required-asterisk", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function OneTimePasswordLoginFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, OneTimePasswordLoginFormComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 1);
          ɵɵpipe(1, "async");
          ɵɵelementStart(2, "form", 2);
          ɵɵlistener("ngSubmit", function OneTimePasswordLoginFormComponent_Template_form_ngSubmit_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onSubmit());
          });
          ɵɵtemplate(3, OneTimePasswordLoginFormComponent_p_3_Template, 3, 3, "p", 3);
          ɵɵelementStart(4, "label")(5, "span", 4);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵtemplate(8, OneTimePasswordLoginFormComponent_ng_template_8_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(9, "input", 6);
          ɵɵpipe(10, "cxTranslate");
          ɵɵelement(11, "cx-form-errors", 7);
          ɵɵelementEnd();
          ɵɵelementStart(12, "label")(13, "span", 4);
          ɵɵtext(14);
          ɵɵpipe(15, "cxTranslate");
          ɵɵtemplate(16, OneTimePasswordLoginFormComponent_ng_template_16_Template, 0, 0, "ng-template", 5);
          ɵɵelementEnd();
          ɵɵelement(17, "input", 8);
          ɵɵpipe(18, "cxTranslate");
          ɵɵpipe(19, "cxTranslate");
          ɵɵelement(20, "cx-form-errors", 7);
          ɵɵelementEnd();
          ɵɵelementStart(21, "a", 9);
          ɵɵpipe(22, "cxUrl");
          ɵɵtext(23);
          ɵɵpipe(24, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(25, "button", 10);
          ɵɵtext(26);
          ɵɵpipe(27, "cxTranslate");
          ɵɵelementEnd()();
          ɵɵtemplate(28, OneTimePasswordLoginFormComponent_ng_template_28_Template, 1, 1, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r2 = ɵɵreference(29);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 16, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 18, "loginForm.emailAddress.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r2);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(10, 20, "loginForm.emailAddress.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("control", ctx.form.get("userId"));
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(15, 22, "loginForm.password.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r2);
          ɵɵadvance();
          ɵɵpropertyInterpolate("placeholder", ɵɵpipeBind1(18, 24, "loginForm.password.placeholder"));
          ɵɵattribute("aria-label", ɵɵpipeBind1(19, 26, "loginForm.password.placeholder"));
          ɵɵadvance(3);
          ɵɵproperty("control", ctx.form.get("password"));
          ɵɵadvance();
          ɵɵproperty("routerLink", ɵɵpipeBind1(22, 28, ɵɵpureFunction0(34, _c0)));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(24, 30, "loginForm.forgotPassword"), " ");
          ɵɵadvance(2);
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(27, 32, "loginForm.signIn"), " ");
        }
      },
      dependencies: [NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, RouterLink, FormErrorsComponent, SpinnerComponent, PasswordVisibilityToggleDirective, FeatureDirective, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OneTimePasswordLoginFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-otp-login-form",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"></cx-spinner>

<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <!-- TODO: (CXSPA-5953) Remove feature flags next major -->
  <p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
    {{ 'formLegend.required' | cxTranslate }}
  </p>
  <label>
    <span class="label-content">
      {{ 'loginForm.emailAddress.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
    </span>
    <input
      required="true"
      type="email"
      class="form-control"
      formControlName="userId"
      placeholder="{{ 'loginForm.emailAddress.placeholder' | cxTranslate }}"
    />
    <cx-form-errors [control]="form.get('userId')"></cx-form-errors>
  </label>

  <label>
    <span class="label-content">
      {{ 'loginForm.password.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
    </span>
    <input
      required="true"
      type="password"
      class="form-control"
      placeholder="{{ 'loginForm.password.placeholder' | cxTranslate }}"
      formControlName="password"
      [attr.aria-label]="'loginForm.password.placeholder' | cxTranslate"
      cxPasswordVisibilitySwitch
    />
    <cx-form-errors [control]="form.get('password')"></cx-form-errors>
  </label>

  <a [routerLink]="{ cxRoute: 'forgotPassword' } | cxUrl" class="btn-link">
    {{ 'loginForm.forgotPassword' | cxTranslate }}
  </a>

  <button
    type="submit"
    class="btn btn-block btn-primary"
    [disabled]="form.disabled"
  >
    {{ 'loginForm.signIn' | cxTranslate }}
  </button>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    aria-hidden="true"
    class="text-decoration-none required-asterisk"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [], {
    style: [{
      type: HostBinding,
      args: ["class.user-form"]
    }]
  });
})();
var OneTimePasswordLoginFormModeule = class _OneTimePasswordLoginFormModeule {
  static {
    this.ɵfac = function OneTimePasswordLoginFormModeule_Factory(t) {
      return new (t || _OneTimePasswordLoginFormModeule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _OneTimePasswordLoginFormModeule,
      declarations: [OneTimePasswordLoginFormComponent],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturningCustomerOTPLoginComponent: {
            component: OneTimePasswordLoginFormComponent,
            guards: [NotAuthGuard]
          }
        }
      })],
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OneTimePasswordLoginFormModeule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule, UrlModule, I18nModule, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          ReturningCustomerOTPLoginComponent: {
            component: OneTimePasswordLoginFormComponent,
            guards: [NotAuthGuard]
          }
        }
      })],
      declarations: [OneTimePasswordLoginFormComponent]
    }]
  }], null, null);
})();
var VerificationTokenDialogComponent = class _VerificationTokenDialogComponent {
  constructor(launchDialogService) {
    this.launchDialogService = launchDialogService;
    this.VERIFICATION_TOKEN_DIALOG_ACTION = VERIFICATION_TOKEN_DIALOG_ACTION;
    this.focusConfig = {
      trap: true,
      block: true,
      autofocus: true,
      focusOnEscape: true
    };
  }
  closeModal(reason) {
    this.launchDialogService.closeDialog(reason);
  }
  static {
    this.ɵfac = function VerificationTokenDialogComponent_Factory(t) {
      return new (t || _VerificationTokenDialogComponent)(ɵɵdirectiveInject(LaunchDialogService));
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _VerificationTokenDialogComponent,
      selectors: [["cx-verification-token-dialog"]],
      decls: 28,
      vars: 21,
      consts: [["role", "dialog", "aria-labelledby", "verification-token-dialog-title", 1, "cx-verification-token-dialog", "cx-modal-container", "cx-asm-dialog", 3, "esc", "cxFocus"], [1, "cx-modal-content"], [1, "cx-dialog-header", "modal-header"], [1, "info-icon"], ["type", "INFO"], ["id", "verification-token-dialog-title", "class", "title modal-title", 4, "cxFeature"], [1, "spliter"], [1, "cx-dialog-body", "modal-body"], [1, "cx-dialog-row"], [1, "cx-dialog-item"], [1, "cx-dialog-footer", "modal-footer"], ["type", "button", 1, "btn", "btn-primary", 3, "click"], ["id", "verification-token-dialog-title", 1, "title", "modal-title"]],
      template: function VerificationTokenDialogComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵlistener("esc", function VerificationTokenDialogComponent_Template_div_esc_0_listener() {
            return ctx.closeModal(ctx.VERIFICATION_TOKEN_DIALOG_ACTION.OK);
          });
          ɵɵelementStart(1, "div", 1)(2, "div", 2)(3, "div")(4, "span", 3);
          ɵɵelement(5, "cx-icon", 4);
          ɵɵelementEnd();
          ɵɵtemplate(6, VerificationTokenDialogComponent_h3_6_Template, 3, 3, "h3", 5)(7, VerificationTokenDialogComponent_span_7_Template, 3, 3, "span", 5);
          ɵɵelementEnd()();
          ɵɵelement(8, "hr", 6);
          ɵɵelementStart(9, "div", 7)(10, "div", 8)(11, "div", 9);
          ɵɵtext(12);
          ɵɵpipe(13, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(14, "div", 9);
          ɵɵtext(15);
          ɵɵpipe(16, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(17, "div", 9);
          ɵɵtext(18);
          ɵɵpipe(19, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(20, "div", 9);
          ɵɵtext(21);
          ɵɵpipe(22, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵelementStart(23, "div", 10)(24, "button", 11);
          ɵɵpipe(25, "cxTranslate");
          ɵɵlistener("click", function VerificationTokenDialogComponent_Template_button_click_24_listener() {
            return ctx.closeModal(ctx.VERIFICATION_TOKEN_DIALOG_ACTION.OK);
          });
          ɵɵtext(26);
          ɵɵpipe(27, "cxTranslate");
          ɵɵelementEnd()()()();
        }
        if (rf & 2) {
          ɵɵproperty("cxFocus", ctx.focusConfig);
          ɵɵadvance(6);
          ɵɵproperty("cxFeature", "a11yDialogsHeading");
          ɵɵadvance();
          ɵɵproperty("cxFeature", "!a11yDialogsHeading");
          ɵɵadvance(5);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(13, 9, "verificationTokenDialog.noReceiveCode"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(16, 11, "verificationTokenDialog.contentLine1"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(19, 13, "verificationTokenDialog.contentLine2"), " ");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(22, 15, "verificationTokenDialog.contentLine3"), " ");
          ɵɵadvance(3);
          ɵɵattribute("aria-label", ɵɵpipeBind1(25, 17, "verificationTokenDialog.ok"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(27, 19, "verificationTokenDialog.close"), " ");
        }
      },
      dependencies: [FocusDirective, IconComponent, FeatureDirective, TranslatePipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(VerificationTokenDialogComponent, [{
    type: Component,
    args: [{
      selector: "cx-verification-token-dialog",
      template: `<div
  class="cx-verification-token-dialog cx-modal-container cx-asm-dialog"
  role="dialog"
  [cxFocus]="focusConfig"
  (esc)="closeModal(VERIFICATION_TOKEN_DIALOG_ACTION.OK)"
  aria-labelledby="verification-token-dialog-title"
>
  <div class="cx-modal-content">
    <!-- Modal Header -->
    <div class="cx-dialog-header modal-header">
      <div>
        <span class="info-icon">
          <cx-icon type="INFO"></cx-icon>
        </span>
        <h3
          *cxFeature="'a11yDialogsHeading'"
          id="verification-token-dialog-title"
          class="title modal-title"
        >
          {{ 'verificationTokenDialog.title' | cxTranslate }}
        </h3>
        <span
          *cxFeature="'!a11yDialogsHeading'"
          id="verification-token-dialog-title"
          class="title modal-title"
        >
          {{ 'verificationTokenDialog.title' | cxTranslate }}
        </span>
      </div>
    </div>
    <hr class="spliter" />

    <!-- Modal Body -->
    <div class="cx-dialog-body modal-body">
      <div class="cx-dialog-row">
        <div class="cx-dialog-item">
          {{ 'verificationTokenDialog.noReceiveCode' | cxTranslate }}
        </div>
        <div class="cx-dialog-item">
          {{ 'verificationTokenDialog.contentLine1' | cxTranslate }}
        </div>
        <div class="cx-dialog-item">
          {{ 'verificationTokenDialog.contentLine2' | cxTranslate }}
        </div>
        <div class="cx-dialog-item">
          {{ 'verificationTokenDialog.contentLine3' | cxTranslate }}
        </div>
      </div>
    </div>

    <!-- Modal Footer -->
    <div class="cx-dialog-footer modal-footer">
      <button
        (click)="closeModal(VERIFICATION_TOKEN_DIALOG_ACTION.OK)"
        [attr.aria-label]="'verificationTokenDialog.ok' | cxTranslate"
        class="btn btn-primary"
        type="button"
      >
        {{ 'verificationTokenDialog.close' | cxTranslate }}
      </button>
    </div>
  </div>
</div>
`
    }]
  }], () => [{
    type: LaunchDialogService
  }], null);
})();
var defaultVerificationTokenLayoutConfig = {
  launch: {
    [
      "ACCOUNT_VERIFICATION_TOKEN"
      /* LAUNCH_CALLER.ACCOUNT_VERIFICATION_TOKEN */
    ]: {
      inlineRoot: true,
      component: VerificationTokenDialogComponent,
      dialogType: DIALOG_TYPE.DIALOG
    }
  }
};
var globalMsgShowTime = 1e4;
var VerificationTokenFormComponentService = class _VerificationTokenFormComponentService {
  constructor() {
    this.globalMessage = inject(GlobalMessageService);
    this.verificationTokenFacade = inject(VerificationTokenFacade);
    this.auth = inject(AuthService);
    this.busy$ = new BehaviorSubject(false);
    this.isUpdating$ = this.busy$.pipe(tap((state) => {
      state === true ? this.form.disable() : this.form.enable();
    }));
    this.form = new UntypedFormGroup({
      tokenId: new UntypedFormControl("", [Validators.required]),
      tokenCode: new UntypedFormControl("", [Validators.required])
    });
  }
  login() {
    if (!this.form.valid) {
      this.form.markAllAsTouched();
      return;
    }
    this.busy$.next(true);
    from(this.auth.otpLoginWithCredentials(this.form.value.tokenId, this.form.value.tokenCode)).pipe(withLatestFrom(this.auth.isUserLoggedIn()), tap(([_, isLoggedIn]) => this.onSuccess(isLoggedIn))).subscribe();
  }
  displayMessage(key, params) {
    this.globalMessage.add({
      key,
      params
    }, GlobalMessageType.MSG_TYPE_CONFIRMATION, globalMsgShowTime);
  }
  createVerificationToken(loginId, password, purpose) {
    return this.verificationTokenFacade.createVerificationToken({
      loginId,
      password,
      purpose
    });
  }
  onSuccess(isLoggedIn) {
    if (isLoggedIn) {
      this.globalMessage.remove(GlobalMessageType.MSG_TYPE_ERROR);
      this.form.reset();
    }
    this.busy$.next(false);
  }
  static {
    this.ɵfac = function VerificationTokenFormComponentService_Factory(t) {
      return new (t || _VerificationTokenFormComponentService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _VerificationTokenFormComponentService,
      factory: _VerificationTokenFormComponentService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(VerificationTokenFormComponentService, [{
    type: Injectable
  }], () => [], null);
})();
var VerificationTokenFormComponent = class _VerificationTokenFormComponent {
  constructor() {
    this.service = inject(VerificationTokenFormComponentService);
    this.launchDialogService = inject(LaunchDialogService);
    this.cdr = inject(ChangeDetectorRef);
    this.routingService = inject(RoutingService);
    this.waitTime = 60;
    this.form = this.service.form;
    this.isUpdating$ = this.service.isUpdating$;
    this.style = true;
    this.isResendDisabled = true;
  }
  ngOnInit() {
    if (!!history.state) {
      this.tokenId = history.state["tokenId"];
      this.password = history.state["password"];
      this.target = history.state["loginId"];
      history.pushState({
        tokenId: "",
        password: "",
        loginId: ""
      }, "verifyToken");
      if (!this.target || !this.password || !this.tokenId) {
        this.service.displayMessage("verificationTokenForm.needInputCredentials", {});
        this.routingService.go(["/login"]);
      } else {
        this.startWaitTimeInterval();
        this.service.displayMessage("verificationTokenForm.createVerificationToken", {
          target: this.target
        });
      }
    }
  }
  onSubmit() {
    this.service.login();
  }
  resendOTP() {
    this.isResendDisabled = true;
    this.resendLink.nativeElement.tabIndex = -1;
    this.resendLink.nativeElement.blur();
    this.waitTime = 60;
    this.startWaitTimeInterval();
    this.service.createVerificationToken(this.target, this.password, ONE_TIME_PASSWORD_LOGIN_PURPOSE).subscribe({
      next: (result) => this.tokenId = result.tokenId,
      complete: () => this.service.displayMessage("verificationTokenForm.createVerificationToken", {
        target: this.target
      })
    });
  }
  startWaitTimeInterval() {
    const interval = setInterval(() => {
      this.waitTime--;
      this.cdr.detectChanges();
      if (this.waitTime <= 0) {
        clearInterval(interval);
        this.isResendDisabled = false;
        this.resendLink.nativeElement.tabIndex = 0;
        this.cdr.detectChanges();
      }
    }, 1e3);
  }
  openInfoDailog() {
    this.launchDialogService.openDialogAndSubscribe("ACCOUNT_VERIFICATION_TOKEN", this.element);
  }
  onOpenInfoDailogKeyDown(event) {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      this.openInfoDailog();
    }
  }
  static {
    this.ɵfac = function VerificationTokenFormComponent_Factory(t) {
      return new (t || _VerificationTokenFormComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _VerificationTokenFormComponent,
      selectors: [["cx-verification-token-form"]],
      viewQuery: function VerificationTokenFormComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c7, 5);
          ɵɵviewQuery(_c8, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.element = _t.first);
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.resendLink = _t.first);
        }
      },
      hostVars: 2,
      hostBindings: function VerificationTokenFormComponent_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassProp("user-form", ctx.style);
        }
      },
      decls: 39,
      vars: 38,
      consts: [["resendLink", ""], ["noReceiveCodeLink", ""], ["requiredAsterisk", ""], ["class", "overlay", 4, "ngIf"], [3, "ngSubmit", "formGroup"], ["class", "form-legend", 4, "cxFeature"], [1, "label-content"], [3, "ngTemplateOutlet"], ["required", "true", "formControlName", "tokenCode", "aria-describedby", "tokenInputHint", 1, "form-control", 3, "placeholder"], [3, "control"], ["id", "tokenInputHint", 1, "cx-visually-hidden"], ["type", "hidden", "formControlName", "tokenId", 3, "ngModelChange", "ngModel"], [1, "resend-link-text"], [1, "left-text"], ["role", "timer", "aria-live", "polite", "aria-atomic", "true"], ["role", "button", "tabindex", "-1", 1, "btn-link", 3, "keydown.enter", "keydown.space", "click", "ngClass"], [4, "ngIf"], [1, "right-text"], ["role", "button", "tabindex", "0", 1, "btn-link", 3, "keydown", "click"], [1, "verify-container"], ["type", "submit", 1, "btn", "btn-block", "btn-primary", 3, "disabled"], [1, "btn", "btn-block", "btn-secondary", "btn-register", 3, "routerLink"], [1, "overlay"], [1, "form-legend"], ["class", "text-decoration-none required-asterisk", "aria-hidden", "true", 3, "title", 4, "cxFeature"], ["aria-hidden", "true", 1, "text-decoration-none", "required-asterisk", 3, "title"]],
      template: function VerificationTokenFormComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵtemplate(0, VerificationTokenFormComponent_cx_spinner_0_Template, 1, 0, "cx-spinner", 3);
          ɵɵpipe(1, "async");
          ɵɵelementStart(2, "form", 4);
          ɵɵlistener("ngSubmit", function VerificationTokenFormComponent_Template_form_ngSubmit_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onSubmit());
          });
          ɵɵtemplate(3, VerificationTokenFormComponent_p_3_Template, 3, 3, "p", 5);
          ɵɵelementStart(4, "label")(5, "span", 6);
          ɵɵtext(6);
          ɵɵpipe(7, "cxTranslate");
          ɵɵtemplate(8, VerificationTokenFormComponent_ng_template_8_Template, 0, 0, "ng-template", 7);
          ɵɵelementEnd();
          ɵɵelement(9, "input", 8);
          ɵɵpipe(10, "cxTranslate");
          ɵɵelement(11, "cx-form-errors", 9);
          ɵɵelementEnd();
          ɵɵelementStart(12, "span", 10);
          ɵɵtext(13);
          ɵɵpipe(14, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(15, "input", 11);
          ɵɵtwoWayListener("ngModelChange", function VerificationTokenFormComponent_Template_input_ngModelChange_15_listener($event) {
            ɵɵrestoreView(_r1);
            ɵɵtwoWayBindingSet(ctx.tokenId, $event) || (ctx.tokenId = $event);
            return ɵɵresetView($event);
          });
          ɵɵelementEnd();
          ɵɵelementStart(16, "div", 12)(17, "div", 13)(18, "span", 14)(19, "a", 15, 0);
          ɵɵlistener("keydown.enter", function VerificationTokenFormComponent_Template_a_keydown_enter_19_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.resendOTP());
          })("keydown.space", function VerificationTokenFormComponent_Template_a_keydown_space_19_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.resendOTP());
          })("click", function VerificationTokenFormComponent_Template_a_click_19_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.resendOTP());
          });
          ɵɵtext(21);
          ɵɵpipe(22, "cxTranslate");
          ɵɵelementEnd();
          ɵɵtemplate(23, VerificationTokenFormComponent_ng_container_23_Template, 3, 6, "ng-container", 16);
          ɵɵelementEnd()();
          ɵɵelementStart(24, "div", 17)(25, "a", 18, 1);
          ɵɵlistener("keydown", function VerificationTokenFormComponent_Template_a_keydown_25_listener($event) {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onOpenInfoDailogKeyDown($event));
          })("click", function VerificationTokenFormComponent_Template_a_click_25_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.openInfoDailog());
          });
          ɵɵtext(27);
          ɵɵpipe(28, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵelementStart(29, "div", 19)(30, "button", 20);
          ɵɵtext(31);
          ɵɵpipe(32, "cxTranslate");
          ɵɵelementEnd();
          ɵɵelementStart(33, "button", 21);
          ɵɵpipe(34, "cxUrl");
          ɵɵtext(35);
          ɵɵpipe(36, "cxTranslate");
          ɵɵelementEnd()()();
          ɵɵtemplate(37, VerificationTokenFormComponent_ng_template_37_Template, 1, 1, "ng-template", null, 2, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const requiredAsterisk_r3 = ɵɵreference(38);
          ɵɵproperty("ngIf", ɵɵpipeBind1(1, 17, ctx.isUpdating$));
          ɵɵadvance(2);
          ɵɵproperty("formGroup", ctx.form);
          ɵɵadvance();
          ɵɵproperty("cxFeature", "a11yRequiredAsterisks");
          ɵɵadvance(3);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(7, 19, "verificationTokenForm.verificationCode.label"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngTemplateOutlet", requiredAsterisk_r3);
          ɵɵadvance();
          ɵɵproperty("placeholder", ɵɵpipeBind1(10, 21, "verificationTokenForm.verificationCode.placeholder"));
          ɵɵadvance(2);
          ɵɵproperty("control", ctx.form.get("tokenCode"));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(14, 23, "verificationTokenForm.tokenInputHint"), " ");
          ɵɵadvance(2);
          ɵɵtwoWayProperty("ngModel", ctx.tokenId);
          ɵɵadvance(4);
          ɵɵproperty("ngClass", ɵɵpureFunction1(35, _c9, ctx.isResendDisabled));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(22, 25, "verificationTokenForm.resend"), " ");
          ɵɵadvance(2);
          ɵɵproperty("ngIf", ctx.isResendDisabled);
          ɵɵadvance(4);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(28, 27, "verificationTokenForm.noReceiveCode"), " ");
          ɵɵadvance(3);
          ɵɵproperty("disabled", ctx.form.disabled);
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(32, 29, "verificationTokenForm.verify"), " ");
          ɵɵadvance(2);
          ɵɵproperty("routerLink", ɵɵpipeBind1(34, 31, ɵɵpureFunction0(37, _c5)));
          ɵɵadvance(2);
          ɵɵtextInterpolate1(" ", ɵɵpipeBind1(36, 33, "verificationTokenForm.back"), " ");
        }
      },
      dependencies: [NgClass, NgIf, NgTemplateOutlet, ɵNgNoValidate, DefaultValueAccessor, NgControlStatus, NgControlStatusGroup, RequiredValidator, FormGroupDirective, FormControlName, RouterLink, FormErrorsComponent, SpinnerComponent, FeatureDirective, AsyncPipe, UrlPipe, TranslatePipe],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(VerificationTokenFormComponent, [{
    type: Component,
    args: [{
      selector: "cx-verification-token-form",
      changeDetection: ChangeDetectionStrategy.OnPush,
      template: `<cx-spinner class="overlay" *ngIf="isUpdating$ | async"></cx-spinner>

<form (ngSubmit)="onSubmit()" [formGroup]="form">
  <p *cxFeature="'a11yRequiredAsterisks'" class="form-legend">
    {{ 'formLegend.required' | cxTranslate }}
  </p>
  <label>
    <span class="label-content">
      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}
      <ng-template [ngTemplateOutlet]="requiredAsterisk"></ng-template>
    </span>
    <input
      required="true"
      class="form-control"
      formControlName="tokenCode"
      [placeholder]="
        'verificationTokenForm.verificationCode.placeholder' | cxTranslate
      "
      aria-describedby="tokenInputHint"
    />
    <cx-form-errors [control]="form.get('tokenCode')"></cx-form-errors>
  </label>
  <span id="tokenInputHint" class="cx-visually-hidden">
    {{ 'verificationTokenForm.tokenInputHint' | cxTranslate }}
  </span>

  <input type="hidden" formControlName="tokenId" [(ngModel)]="tokenId" />

  <div class="resend-link-text">
    <div class="left-text">
      <span role="timer" aria-live="polite" aria-atomic="true">
        <a
          role="button"
          tabindex="-1"
          #resendLink
          (keydown.enter)="resendOTP()"
          (keydown.space)="resendOTP()"
          (click)="resendOTP()"
          class="btn-link"
          [ngClass]="{ 'disabled-link': isResendDisabled }"
        >
          {{ 'verificationTokenForm.resend' | cxTranslate }}
        </a>
        <ng-container *ngIf="isResendDisabled">
          {{
            'verificationTokenForm.sendRateLime'
              | cxTranslate: { waitTime: waitTime }
          }}
        </ng-container>
      </span>
    </div>
    <div class="right-text">
      <a
        role="button"
        tabindex="0"
        #noReceiveCodeLink
        (keydown)="onOpenInfoDailogKeyDown($event)"
        (click)="openInfoDailog()"
        class="btn-link"
      >
        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}
      </a>
    </div>
  </div>

  <div class="verify-container">
    <button
      type="submit"
      class="btn btn-block btn-primary"
      [disabled]="form.disabled"
    >
      {{ 'verificationTokenForm.verify' | cxTranslate }}
    </button>
    <button
      [routerLink]="{ cxRoute: 'login' } | cxUrl"
      class="btn btn-block btn-secondary btn-register"
    >
      {{ 'verificationTokenForm.back' | cxTranslate }}
    </button>
  </div>
</form>

<ng-template #requiredAsterisk>
  <abbr
    *cxFeature="'a11yRequiredAsterisks'"
    class="text-decoration-none required-asterisk"
    aria-hidden="true"
    title="{{ 'common.required' | cxTranslate }}"
    >*</abbr
  >
</ng-template>
`
    }]
  }], () => [], {
    style: [{
      type: HostBinding,
      args: ["class.user-form"]
    }],
    element: [{
      type: ViewChild,
      args: ["noReceiveCodeLink"]
    }],
    resendLink: [{
      type: ViewChild,
      args: ["resendLink"]
    }]
  });
})();
var VerificationTokenFormModule = class _VerificationTokenFormModule {
  static {
    this.ɵfac = function VerificationTokenFormModule_Factory(t) {
      return new (t || _VerificationTokenFormModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _VerificationTokenFormModule,
      declarations: [VerificationTokenFormComponent, VerificationTokenDialogComponent],
      imports: [CommonModule, FormsModule, KeyboardFocusModule, ReactiveFormsModule, RouterModule, UrlModule, IconModule, I18nModule, FormErrorsModule, SpinnerModule, FeaturesConfigModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        cmsComponents: {
          VerifyOTPTokenComponent: {
            component: VerificationTokenFormComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: VerificationTokenFormComponentService,
              useClass: VerificationTokenFormComponentService,
              deps: [AuthService, GlobalMessageService, VerificationTokenFacade, WindowRef]
            }]
          }
        }
      }), provideDefaultConfig(defaultVerificationTokenLayoutConfig)],
      imports: [CommonModule, FormsModule, KeyboardFocusModule, ReactiveFormsModule, RouterModule, UrlModule, IconModule, I18nModule, FormErrorsModule, SpinnerModule, FeaturesConfigModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(VerificationTokenFormModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, FormsModule, KeyboardFocusModule, ReactiveFormsModule, RouterModule, UrlModule, IconModule, I18nModule, FormErrorsModule, SpinnerModule, FeaturesConfigModule],
      providers: [provideDefaultConfig({
        cmsComponents: {
          VerifyOTPTokenComponent: {
            component: VerificationTokenFormComponent,
            guards: [NotAuthGuard],
            providers: [{
              provide: VerificationTokenFormComponentService,
              useClass: VerificationTokenFormComponentService,
              deps: [AuthService, GlobalMessageService, VerificationTokenFacade, WindowRef]
            }]
          }
        }
      }), provideDefaultConfig(defaultVerificationTokenLayoutConfig)],
      declarations: [VerificationTokenFormComponent, VerificationTokenDialogComponent]
    }]
  }], null, null);
})();
var UserAccountComponentsModule = class _UserAccountComponentsModule {
  static {
    this.ɵfac = function UserAccountComponentsModule_Factory(t) {
      return new (t || _UserAccountComponentsModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UserAccountComponentsModule,
      imports: [LoginModule, LoginFormModule, VerificationTokenFormModule, LoginRegisterModule, MyAccountV2UserModule, OneTimePasswordLoginFormModeule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [LoginModule, LoginFormModule, VerificationTokenFormModule, LoginRegisterModule, MyAccountV2UserModule, OneTimePasswordLoginFormModeule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserAccountComponentsModule, [{
    type: NgModule,
    args: [{
      imports: [LoginModule, LoginFormModule, VerificationTokenFormModule, LoginRegisterModule, MyAccountV2UserModule, OneTimePasswordLoginFormModeule]
    }]
  }], null, null);
})();

// node_modules/@spartacus/user/fesm2022/spartacus-user-account-core.mjs
var USER_ACCOUNT_NORMALIZER = new InjectionToken("UserAccountNormalizer");
var USER_ACCOUNT_SERIALIZER = new InjectionToken("UserAccountSerializer");
var VERIFICATION_TOKEN_NORMALIZER = new InjectionToken("VerificationTokenNormalizer");
var LOGIN_FORM_SERIALIZER = new InjectionToken("LoginFormSerializer");
var UserAccountAdapter = class {
};
var UserAccountConnector = class _UserAccountConnector {
  constructor(adapter) {
    this.adapter = adapter;
  }
  get(userId) {
    return this.adapter.load(userId);
  }
  createVerificationToken(verificationTokenCreation) {
    return this.adapter.createVerificationToken(verificationTokenCreation);
  }
  static {
    this.ɵfac = function UserAccountConnector_Factory(t) {
      return new (t || _UserAccountConnector)(ɵɵinject(UserAccountAdapter));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _UserAccountConnector,
      factory: _UserAccountConnector.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserAccountConnector, [{
    type: Injectable
  }], () => [{
    type: UserAccountAdapter
  }], null);
})();
var UserAccountService = class _UserAccountService {
  constructor(userAccountConnector, userIdService, query) {
    this.userAccountConnector = userAccountConnector;
    this.userIdService = userIdService;
    this.query = query;
    this.userQuery = this.query.create(() => this.userIdService.takeUserId(true).pipe(switchMap((userId) => this.userAccountConnector.get(userId))), {
      reloadOn: [UserAccountChangedEvent],
      resetOn: [LoginEvent, LogoutEvent]
    });
  }
  /**
   * Returns the user according the userId
   * no use query for userId can change every time
   */
  getById(userId) {
    return this.userAccountConnector.get(userId);
  }
  /**
   * Returns the current user.
   */
  get() {
    return this.userQuery.get();
  }
  static {
    this.ɵfac = function UserAccountService_Factory(t) {
      return new (t || _UserAccountService)(ɵɵinject(UserAccountConnector), ɵɵinject(UserIdService), ɵɵinject(QueryService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _UserAccountService,
      factory: _UserAccountService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserAccountService, [{
    type: Injectable
  }], () => [{
    type: UserAccountConnector
  }, {
    type: UserIdService
  }, {
    type: QueryService
  }], null);
})();
var VerificationTokenService = class _VerificationTokenService {
  constructor() {
    this.connector = inject(UserAccountConnector);
    this.command = inject(CommandService);
    this.createVerificationTokenCommand = this.command.create(({
      verificationTokenCreation
    }) => this.connector.createVerificationToken(verificationTokenCreation));
  }
  /**
   * create verification token
   */
  createVerificationToken(verificationTokenCreation) {
    return this.createVerificationTokenCommand.execute({
      verificationTokenCreation
    });
  }
  static {
    this.ɵfac = function VerificationTokenService_Factory(t) {
      return new (t || _VerificationTokenService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _VerificationTokenService,
      factory: _VerificationTokenService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(VerificationTokenService, [{
    type: Injectable
  }], null, null);
})();
var facadeProviders = [UserAccountService, {
  provide: UserAccountFacade,
  useExisting: UserAccountService
}, VerificationTokenService, {
  provide: VerificationTokenFacade,
  useExisting: VerificationTokenService
}];
var UserAccountCoreModule = class _UserAccountCoreModule {
  static {
    this.ɵfac = function UserAccountCoreModule_Factory(t) {
      return new (t || _UserAccountCoreModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UserAccountCoreModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [UserAccountConnector, ...facadeProviders]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserAccountCoreModule, [{
    type: NgModule,
    args: [{
      providers: [UserAccountConnector, ...facadeProviders]
    }]
  }], null, null);
})();

// node_modules/@spartacus/user/fesm2022/spartacus-user-account-occ.mjs
var defaultOccUserAccountConfig = {
  backend: {
    occ: {
      endpoints: {
        user: "users/${userId}",
        createVerificationToken: "users/anonymous/verificationToken"
      }
    }
  }
};
var CONTENT_TYPE_JSON_HEADER = {
  "Content-Type": "application/json"
};
var OccUserAccountAdapter = class _OccUserAccountAdapter {
  constructor(http, occEndpoints, converter) {
    this.http = http;
    this.occEndpoints = occEndpoints;
    this.converter = converter;
    this.logger = inject(LoggerService);
  }
  load(userId) {
    const url = this.occEndpoints.buildUrl("user", {
      urlParams: {
        userId
      }
    });
    return this.http.get(url).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), this.converter.pipeable(USER_ACCOUNT_NORMALIZER));
  }
  createVerificationToken(verificationTokenCreation) {
    const url = this.occEndpoints.buildUrl("createVerificationToken");
    const headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, new HttpHeaders(__spreadValues({}, CONTENT_TYPE_JSON_HEADER)));
    verificationTokenCreation = this.converter.convert(verificationTokenCreation, LOGIN_FORM_SERIALIZER);
    return this.http.post(url, verificationTokenCreation, {
      headers
    }).pipe(catchError((error) => {
      throw normalizeHttpError(error, this.logger);
    }), this.converter.pipeable(VERIFICATION_TOKEN_NORMALIZER));
  }
  static {
    this.ɵfac = function OccUserAccountAdapter_Factory(t) {
      return new (t || _OccUserAccountAdapter)(ɵɵinject(HttpClient), ɵɵinject(OccEndpointsService), ɵɵinject(ConverterService));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _OccUserAccountAdapter,
      factory: _OccUserAccountAdapter.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OccUserAccountAdapter, [{
    type: Injectable
  }], () => [{
    type: HttpClient
  }, {
    type: OccEndpointsService
  }, {
    type: ConverterService
  }], null);
})();
var UserAccountOccModule = class _UserAccountOccModule {
  static {
    this.ɵfac = function UserAccountOccModule_Factory(t) {
      return new (t || _UserAccountOccModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UserAccountOccModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig(defaultOccUserAccountConfig), {
        provide: UserAccountAdapter,
        useClass: OccUserAccountAdapter
      }]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserAccountOccModule, [{
    type: NgModule,
    args: [{
      providers: [provideDefaultConfig(defaultOccUserAccountConfig), {
        provide: UserAccountAdapter,
        useClass: OccUserAccountAdapter
      }]
    }]
  }], null, null);
})();

// node_modules/@spartacus/user/fesm2022/spartacus-user-account.mjs
var UserAccountModule = class _UserAccountModule {
  static {
    this.ɵfac = function UserAccountModule_Factory(t) {
      return new (t || _UserAccountModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _UserAccountModule,
      imports: [UserAccountCoreModule, UserAccountOccModule, UserAccountComponentsModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [UserAccountCoreModule, UserAccountOccModule, UserAccountComponentsModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UserAccountModule, [{
    type: NgModule,
    args: [{
      imports: [UserAccountCoreModule, UserAccountOccModule, UserAccountComponentsModule]
    }]
  }], null, null);
})();
export {
  UserAccountModule
};
//# sourceMappingURL=@spartacus_user_account.js.map
