import "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/cart/fesm2022/spartacus-cart-wish-list-assets.mjs
var wishlist = {
  empty: "No products in your wish list yet",
  itemRemoved: "Selected item has been removed.",
  caption: "Wish list contents."
};
var wishlist$1 = {
  wishlist
};
var en = {
  wishlist: wishlist$1
};
var wishListTranslations = {
  en
};
var wishListTranslationChunksConfig = {
  wishlist: ["wishlist"]
};
export {
  wishListTranslationChunksConfig,
  wishListTranslations
};
//# sourceMappingURL=@spartacus_cart_wish-list_assets.js.map
