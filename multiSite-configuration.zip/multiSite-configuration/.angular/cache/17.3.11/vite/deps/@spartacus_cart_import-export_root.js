import {
  provideDefaultConfig
} from "./chunk-CJWHFW34.js";
import "./chunk-OIYGDMWQ.js";
import "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import "./chunk-XWT3SXR6.js";
import {
  NgModule,
  setClassMetadata,
  ɵɵdefineInjector,
  ɵɵdefineNgModule
} from "./chunk-JMCPXHNJ.js";
import "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/cart/fesm2022/spartacus-cart-import-export-root.mjs
var CART_IMPORT_EXPORT_FEATURE = "cartImportExport";
var ImportExportRootModule = class _ImportExportRootModule {
  static {
    this.ɵfac = function ImportExportRootModule_Factory(t) {
      return new (t || _ImportExportRootModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ImportExportRootModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfig({
        featureModules: {
          [CART_IMPORT_EXPORT_FEATURE]: {
            cmsComponents: ["ImportExportOrderEntriesComponent", "ImportOrderEntriesComponent", "ExportOrderEntriesComponent"]
          }
        }
      })]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ImportExportRootModule, [{
    type: NgModule,
    args: [{
      providers: [provideDefaultConfig({
        featureModules: {
          [CART_IMPORT_EXPORT_FEATURE]: {
            cmsComponents: ["ImportExportOrderEntriesComponent", "ImportOrderEntriesComponent", "ExportOrderEntriesComponent"]
          }
        }
      })]
    }]
  }], null, null);
})();
export {
  CART_IMPORT_EXPORT_FEATURE,
  ImportExportRootModule
};
//# sourceMappingURL=@spartacus_cart_import-export_root.js.map
