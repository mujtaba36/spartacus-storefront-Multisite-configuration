import "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/product/fesm2022/spartacus-product-variants-assets.mjs
var productVariants = {
  style: "Style",
  selectedStyle: "Selected style",
  size: "Size",
  color: "Color",
  sizeGuideLabel: "Style guide"
};
var productVariants$1 = {
  productVariants
};
var en = {
  productVariants: productVariants$1
};
var productVariantsTranslations = {
  en
};
var productVariantsTranslationChunksConfig = {
  productVariants: ["productVariants"]
};
export {
  productVariantsTranslationChunksConfig,
  productVariantsTranslations
};
//# sourceMappingURL=@spartacus_product_variants_assets.js.map
