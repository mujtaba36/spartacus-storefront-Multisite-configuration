import "./chunk-FIMZ5LIU.js";
import {
  provideDefaultConfigFactory
} from "./chunk-CJWHFW34.js";
import "./chunk-OIYGDMWQ.js";
import "./chunk-PJOH4OHD.js";
import "./chunk-JNY6ZBZY.js";
import "./chunk-XWT3SXR6.js";
import {
  NgModule,
  setClassMetadata,
  ɵɵdefineInjector,
  ɵɵdefineNgModule
} from "./chunk-JMCPXHNJ.js";
import "./chunk-FTQ24RAU.js";

// node_modules/@spartacus/product/fesm2022/spartacus-product-image-zoom-root.mjs
var PRODUCT_IMAGE_ZOOM_FEATURE = "productImageZoom";
function defaultImageZoomComponentsConfig() {
  const config = {
    featureModules: {
      [PRODUCT_IMAGE_ZOOM_FEATURE]: {
        cmsComponents: ["ProductImagesComponent"]
      }
    }
  };
  return config;
}
var ProductImageZoomRootModule = class _ProductImageZoomRootModule {
  static {
    this.ɵfac = function ProductImageZoomRootModule_Factory(t) {
      return new (t || _ProductImageZoomRootModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _ProductImageZoomRootModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [provideDefaultConfigFactory(defaultImageZoomComponentsConfig)]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ProductImageZoomRootModule, [{
    type: NgModule,
    args: [{
      imports: [],
      providers: [provideDefaultConfigFactory(defaultImageZoomComponentsConfig)]
    }]
  }], null, null);
})();
export {
  PRODUCT_IMAGE_ZOOM_FEATURE,
  ProductImageZoomRootModule,
  defaultImageZoomComponentsConfig
};
//# sourceMappingURL=@spartacus_product_image-zoom_root.js.map
